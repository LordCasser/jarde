from pathlib import Path
import json,hashlib,importlib.util,os,shutil,datetime
W=Path('/home/lordcasser/.codex/worktrees/core-integrity/jarde');B=Path('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015');OLD=Path('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014');D=Path(__file__).resolve().parent;O=D/'run-v1'
NEW=B/'jarde-cli-loop-transfer-complete-local-native-v1';PRIOR=B/'jarde-cli-call-return-finally-final-test-assertions-native-v1';NATIVE=B/'CORE/loop-transfer-finally-complete-local-native-v1/execution.json'
def pin(p):
 p=Path(p);v=p.read_bytes();return dict(path=str(p),bytes=len(v),sha256=hashlib.sha256(v).hexdigest())
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
assert not O.exists() and not(W/'target').exists() and shutil.disk_usage(W).free>=5*1024**3
n=json.loads(NATIVE.read_text());assert n['source_manifest_before']==n['source_manifest_after'] and n['target_absent'];assert pin(NEW)=={k:n['frozen_cli'][k] for k in ['path','bytes','sha256']}
oldnative=B/'CORE/call-return-finally-final-test-assertions-native-v1/execution.json';old=json.loads(oldnative.read_text());assert pin(PRIOR)=={k:old['frozen_cli'][k] for k in ['path','bytes','sha256']}
closure=load('parent_return_control_closure',OLD/'tools-prep/workspace_runner.py');closure.ROOT=W;paths=set(closure.source_paths())|{W/r['path'] for r in json.loads((W/'tests/fixtures/corpus-fingerprint.json').read_text())['files']}
def sources():return [dict(path=str(p.relative_to(W)),bytes=p.stat().st_size,sha256=pin(p)['sha256']) for p in sorted(paths)]
before=sources();assert before==n['source_manifest_before']
jd=json.loads((OLD/'tools/jdk-manifest.json').read_text());tools={}
for leg in jd['legs']:
 if leg.get('leg') in ['javac23','javac8']:
  p=leg['jdk_tools']['javac'];assert pin(p['path'])=={k:p[k] for k in ['path','bytes','sha256']};tools[leg['leg']]=Path(p['path'])
ex=W/'openspec/evidence/java-syntax-2026-10-05/exception-shape-family-patrol/fixture/EX.class';classes={leg:W/('openspec/changes/recover-proved-finally-cleanup/results/finally-final-gates-root-v2/cases/FinallyCompletion-'+leg+'-source/classes/FinallyCompletion.class') for leg in tools}
inputs={Path(__file__).resolve(),NEW,PRIOR,NATIVE,oldnative,ex,*classes.values(),*tools.values(),OLD/'tools/jdk-manifest.json',OLD/'tools-prep/guard.py',OLD/'tools-prep/target_scan.py',OLD/'tools-prep/workspace_runner.py'};ip=[pin(p) for p in sorted(inputs)];O.mkdir();g=load('parent_return_controls_guard',OLD/'tools-prep/guard.py');scan=load('parent_return_controls_scan',OLD/'tools-prep/target_scan.py');g.ROOT=W;g.OUT=O;g.FREE_LIMIT=5*1024**3;g.TARGET_LIMIT=1024**3;g.target_bytes=lambda:scan.target_bytes(W);g.expected_test_summaries=lambda _a,_b:None;g.command_stream=pin;g.ENV_VALUES={}
r=dict(status='running',scope='Read-only current-vs-prior EX.finReturn text comparison and exact whole FinallyCompletion compile observation. No original JVM/driver replay or changed implementation; no general finally-return acceptance.',native_receipt=pin(NATIVE),old_native_receipt=pin(oldnative),source_manifest_before=before,inputs_before=ip,default_stack=True,commands=[],cases={})
def save():(O/'execution.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
def run(label,argv,expected):
 env={'HOME':'/home/lordcasser','PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8'};tool=next((p for p in tools.values() if str(p) in [str(a) for a in argv]),None)
 if tool:env.update(JAVA_HOME=str(tool.parent.parent),PATH=str(tool.parent)+':/usr/bin:/bin')
 q=g.run_command(len(r['commands'])+1,[str(a) for a in argv],env);q.update(label=label,expected_exit=expected);r['commands'].append(q);save();assert q['exit_code'] in expected and q['guard_stop'] is None;return q
try:
 docs=[]
 for label,cli in [('prior',PRIOR),('current',NEW)]:
  q=run(label+'-EX-whole-json',[cli,'class-source','--input',ex,'--class','EX','--policy','single-class','--release','8','--format','json','--evidence','all'],[0]);docs.append(json.loads(Path(q['streams']['stdout']['path']).read_text()))
 methods=[]
 for doc in docs:
  m=next(m for m in doc['methods'] if m['item']['name']['escaped']=='finReturn');methods.append(m)
 assert methods[0]['outcome']['report']['text']==methods[1]['outcome']['report']['text']
 r['cases']['EX.finReturn']=dict(method_text_byte_identical=True,prior=methods[0],current=methods[1],whole_class_recompiled=False,rebuilt_runtime_commands=0);save()
 for leg,cl in classes.items():
  q=run(leg+'-FinallyCompletion-whole-json',[NEW,'class-source','--input',cl,'--class','FinallyCompletion','--policy','single-class','--release','8','--format','json','--evidence','all'],[0]);doc=json.loads(Path(q['streams']['stdout']['path']).read_text());assert len(doc['methods'])==7
  dest=O/leg;dest.mkdir();src=dest/'FinallyCompletion.java';src.write_bytes(doc['text'].encode());rebuilt=dest/'classes';rebuilt.mkdir();empty=dest/'empty-sourcepath';empty.mkdir();flags=['--release','8','-Xlint:-options'] if leg=='javac23' else ['-source','8','-target','8']
  c=run(leg+'-FinallyCompletion-exact-whole-compile',[tools[leg],*flags,'-g:none','-classpath',rebuilt,'-sourcepath',empty,'-d',rebuilt,src],[0,1]);assert src.read_bytes()==doc['text'].encode()
  r['cases'][leg+'/FinallyCompletion']=dict(original_class=pin(cl),method_count=7,methods=[dict(item=m['item'],outcome=m['outcome']) for m in doc['methods']],generated_source=pin(src),compile_exit=c['exit_code'],rebuilt_runtime_commands=0);save()
 assert len(r['commands'])==6;r['status']='captured_six_command_parent_finally_return_controls_not_blanket_acceptance'
except BaseException as e:r.update(status='failed_raw_preserved',error=repr(e))
finally:
 r.update(source_manifest_after=sources(),inputs_after=[pin(p) for p in sorted(inputs)],target_absent=not(W/'target').exists(),finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());r['sources_identical']=r['source_manifest_after']==before;r['inputs_identical']=r['inputs_after']==ip
 if not r['sources_identical'] or not r['inputs_identical'] or not r['target_absent']:r['status']='failed_integrity'
 save()
print(r['status'],[(q['label'],q['exit_code']) for q in r['commands']]);raise SystemExit(0 if r['status']=='captured_six_command_parent_finally_return_controls_not_blanket_acceptance' else 1)
