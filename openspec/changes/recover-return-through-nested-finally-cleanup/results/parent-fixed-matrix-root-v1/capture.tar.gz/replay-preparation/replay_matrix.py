#!/usr/bin/env python3
"""Portable replay of archived FY/FX/FO matrices; preparation only, not executed here."""
from __future__ import annotations
import argparse, hashlib, json, os, re, signal, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def pin(path: Path) -> dict:
    data = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(data), 'sha256': sha(data)}

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--cli', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--javac8', type=Path, required=True)
    ap.add_argument('--javac23', type=Path, required=True)
    ap.add_argument('--java8', type=Path, required=True)
    ap.add_argument('--java23', type=Path, required=True)
    ap.add_argument('--jadx-jar', type=Path, required=True)
    ap.add_argument('--timeout-seconds', type=int, default=120)
    args = ap.parse_args()
    repo, cli, out = args.repo.resolve(), args.cli.resolve(), args.out.resolve()
    if out.exists(): raise SystemExit(f'refusing to overwrite {out}')
    if not cli.is_file(): raise SystemExit(f'CLI is missing: {cli}')
    for p in (args.javac8,args.javac23,args.java8,args.java23,args.jadx_jar):
        if not p.is_file(): raise SystemExit(f'pinned tool input missing: {p}')
    fixed_root = HERE / 'fixed'
    fixed = json.loads((HERE/'fixed-inputs.json').read_text())
    for leg in ('javac8','javac23'):
        for name in ('FY','FX','FO'):
            for section,ext in (('target_jars','jar'),('target_classes','class')):
                record=fixed[section][leg][name]
                path=Path(record['path'])
                if pin(path)['bytes'] != record['bytes'] or pin(path)['sha256'] != record['sha256']:
                    raise SystemExit(f'fixed target pin mismatch: {path}')
    for legs in fixed['original_oracles'].values():
        for runtimes in legs.values():
            for record in runtimes.values():
                for stream in ('stdout','stderr'):
                    pinrow=record[stream]
                    path=Path(pinrow['path'])
                    if pin(path)['bytes'] != pinrow['bytes'] or pin(path)['sha256'] != pinrow['sha256']:
                        raise SystemExit(f'fixed oracle pin mismatch: {path}')
    index = json.loads((HERE/'parent-replay-index.json').read_text())
    out.mkdir(parents=True); (out/'raw').mkdir()
    old_worktree='/home/lordcasser/.codex/worktrees/core-integrity/jarde'
    old_core='/home/lordcasser/.cache/jarde-validation/core-integrity-20261015/CORE'
    original_home=f'{old_core}/effectful-finally-current-screen-v1/run-v1'
    tools={
      '/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/jdk8/amazon-corretto-8.504.04.1-linux-x64/bin/javac':str(args.javac8.resolve()),
      '/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/jdk23/jdk-23.0.1/bin/javac':str(args.javac23.resolve()),
      '/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/jdk8/amazon-corretto-8.504.04.1-linux-x64/bin/java':str(args.java8.resolve()),
      '/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/jdk23/jdk-23.0.1/bin/java':str(args.java23.resolve()),
      '/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/jadx/lib/jadx-1.5.6-all.jar':str(args.jadx_jar.resolve()),
    }
    matrix_specs=[]
    for phase,key in [('jarde','screen_commands'),('jadx','jadx_commands')]:
        for item in index['fy_fx_fo'][key]:
            matrix_specs.append((phase,item))
    rows=[]
    def rewrite(text: str, phase: str) -> str:
        text=text.replace(old_worktree,str(repo))
        for old,new in tools.items(): text=text.replace(old,new)
        if 'jarde-cli-loop-transfer-complete-local-native-v1' in text:
            text=text.replace(old_core+'/../jarde-cli-loop-transfer-complete-local-native-v1',str(cli))
            text=text.replace('/home/lordcasser/.cache/jarde-validation/core-integrity-20261015/jarde-cli-loop-transfer-complete-local-native-v1',str(cli))
        for leg in ('javac8','javac23'):
            for name in ('FY','FX','FO'):
                old=f'{original_home}/{leg}-original-jars/{name}.jar'
                new=fixed_root/f'originals/{leg}/jars/{name}.jar'
                text=text.replace(old,str(new))
        oldout=f'{old_core}/effectful-finally-final-loop-transfer-screen-v1/run-v1'
        oldjadx=f'{old_core}/effectful-finally-jadx-final-loop-transfer-comparison-v1/run-v1'
        text=text.replace(oldout,str(out/'jarde')).replace(oldjadx,str(out/'jadx'))
        if phase=='jadx':
            text=text.replace('/home/lordcasser/.cache/jarde-validation/ordinary-try-list-20261014/tools/jadx/lib/jadx-1.5.6-all.jar',str(args.jadx_jar.resolve()))
        return text
    for serial,(phase,item) in enumerate(matrix_specs,1):
        original=item['argv']; timeout=None; argv=list(original)
        if argv and argv[0]=='/usr/bin/timeout':
            timeout=int(argv[2][:-1]); argv=argv[3:]
        rewritten=[rewrite(str(x),phase) for x in argv]
        label=item['label']
        # Establish generated-source destination required by the archived javac argv.
        if label.endswith('-current-whole-source-FY') or label.endswith('-current-whole-source-FX') or label.endswith('-current-whole-source-FO'):
            m=re.search(r'whole-source-(FY|FX|FO)$',label); name=m.group(1)
            leg='javac8' if label.startswith('javac8-') else 'javac23'
            dest=out/'jarde'/f'{leg}-{name}'; dest.mkdir(parents=True,exist_ok=True)
            (dest/'classes').mkdir(exist_ok=True); (dest/'empty-sourcepath').mkdir(exist_ok=True)
        if label.endswith('-jadx-whole-source-FY') or label.endswith('-jadx-whole-source-FX') or label.endswith('-jadx-whole-source-FO'):
            m=re.search(r'whole-source-(FY|FX|FO)$',label); name=m.group(1)
            leg='javac8' if label.startswith('javac8-') else 'javac23'
            dest=out/'jadx'/f'{leg}-{name}'; dest.mkdir(parents=True,exist_ok=True)
            (dest/'classes').mkdir(exist_ok=True); (dest/'empty-sourcepath').mkdir(exist_ok=True)
        for i,arg in enumerate(rewritten[:-1]):
            if arg in ('-d','-sourcepath'):
                Path(rewritten[i+1]).mkdir(parents=True,exist_ok=True)
        cwd=repo
        env=os.environ.copy()
        for name in ('JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','CARGO_TARGET_DIR'):
            env.pop(name,None)
        env['LANG']='C.UTF-8';env['LC_ALL']='C.UTF-8'
        java_tool=next((Path(x) for x in rewritten if x.endswith('/java') or x.endswith('/javac')),None)
        if java_tool is not None: env['JAVA_HOME']=str(java_tool.parent.parent)
        try:
            proc=subprocess.Popen(rewritten,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                                  start_new_session=True)
            try: stdout,stderr=proc.communicate(timeout=timeout or args.timeout_seconds)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid,signal.SIGKILL)
                stdout,stderr=proc.communicate()
                stderr += b'\nportable replay timeout expired\n'
                rc=124
            else: rc=proc.returncode
            spawn_error=None
        except Exception as exc:
            rc=127; stdout=b''; stderr=str(exc).encode(); spawn_error=repr(exc)
        raw_idx=f'{serial:02d}'
        op=out/'raw'/f'{raw_idx}.stdout.raw'; ep=out/'raw'/f'{raw_idx}.stderr.raw'
        op.write_bytes(stdout);ep.write_bytes(stderr)
        output_row={'serial':serial,'phase':phase,'label':label,'archived_argv':original,
                    'argv':rewritten,'timeout_seconds':timeout or args.timeout_seconds,
                    'cwd':str(cwd),'exit_code':rc,'expected_exit_code':item.get('expected_exit_code') if item.get('expected_exit_code') is not None else item['exit_code'],
                    'stdout':pin(op),'stderr':pin(ep),'spawn_error':spawn_error}
        if phase=='jarde' and 'current-whole-source-' in label and rc==0:
            try:
                doc=json.loads(stdout.decode('utf-8'))
                name=re.search(r'whole-source-(FY|FX|FO)$',label).group(1)
                leg='javac8' if label.startswith('javac8-') else 'javac23'
                dest=out/'jarde'/f'{leg}-{name}'/(name+'.java')
                dest.write_text(doc['text'],encoding='utf-8')
                output_row['source_text']=pin(dest);output_row['method_count']=len(doc['methods'])
                wanted={'FY':5,'FX':6,'FO':5}[name]
                methods=doc['methods']
                output_row['all_methods_recovered_java_structured_no_fallback']=len(methods)==wanted and all(
                    m.get('outcome',{}).get('kind')=='recovered'
                    and m.get('outcome',{}).get('report',{}).get('quality')=='structured'
                    and m.get('outcome',{}).get('report',{}).get('representation')=='java'
                    and m.get('outcome',{}).get('report',{}).get('fallbacks')==[] for m in methods)
                output_row['method_identities']=[m.get('item',{}).get('identity') for m in methods]
                output_row['method_facts']=[{'index':m.get('item',{}).get('index'),
                    'name':m.get('item',{}).get('name',{}).get('escaped'),
                    'descriptor':m.get('item',{}).get('descriptor',{}).get('escaped'),
                    'outcome':m.get('outcome',{}).get('kind'),
                    'quality':m.get('outcome',{}).get('report',{}).get('quality'),
                    'representation':m.get('outcome',{}).get('report',{}).get('representation'),
                    'fallbacks':m.get('outcome',{}).get('report',{}).get('fallbacks'),
                    'regions':m.get('outcome',{}).get('report',{}).get('regions')}
                    for m in methods]
                if not output_row['all_methods_recovered_java_structured_no_fallback']:
                    output_row['source_check_failed']=True
            except Exception as exc: output_row['source_parse_error']=repr(exc)
        if phase=='jadx' and label=='pinned-jadx-version':
            output_row['jadx_version_text']=(stdout+stderr).decode('utf-8',errors='replace').strip()
            output_row['jadx_version_verified']='1.5.6' in output_row['jadx_version_text']
        if phase=='jadx' and re.search(r'compile-exact-jadx-generated-FX$',label):
            diagnostic=(stdout+stderr).decode('utf-8',errors='replace')
            output_row['known_undefined_th_diagnostic']=('cannot find symbol' in diagnostic
                and 'symbol:   variable th' in diagnostic and 'throw th;' in diagnostic)
        if 'rebuilt-main-' in label:
            m=re.search(r'^(javac8|javac23)-java(8|23)-.*rebuilt-main-(FY|FX|FO)$',label)
            if m:
                input_leg,runtime,name=m.groups(); expected=fixed['original_oracles'][input_leg][f'java{runtime}'][name]
                expected_stdout=Path(expected['stdout']['path']).read_bytes()
                output_row['oracle_stdout_sha256']=expected['stdout']['sha256']
                output_row['oracle_stdout_matches']=stdout==expected_stdout
                expected_stderr=Path(expected['stderr']['path']).read_bytes()
                output_row['oracle_stderr_matches']=stderr==expected_stderr
        rows.append(output_row)
        partial={'schema':'portable-effectful-finally-replay-v1','status':'running',
                 'cli':pin(cli),'fixed_inputs':fixed,'commands':rows,
                 'command_count':len(rows),'jarde_command_count':sum(r['phase']=='jarde' for r in rows),
                 'jadx_command_count':sum(r['phase']=='jadx' for r in rows),
                 'note':'Archived argv and raw streams are retained; rebuilt outputs are compared with fixed original runtime streams.'}
        (out/'execution.json').write_text(json.dumps(partial,indent=2)+'\n')
        # Materialize JADX's untouched source is performed by JADX itself under --output-dir.
        if phase=='jarde' and 'current-whole-source-' in label and rc==0 and not output_row.get('source_text'):
            pass
    report={'schema':'portable-effectful-finally-replay-v1','status':'pending_review',
            'cli':pin(cli),'fixed_inputs':fixed,'commands':rows,
            'command_count':len(rows),'jarde_command_count':sum(r['phase']=='jarde' for r in rows),
            'jadx_command_count':sum(r['phase']=='jadx' for r in rows),
            'note':'The archived 24+21 argv are retained alongside rewritten argv. Original target JARs/classes and raw runtime oracle streams are fixed extracted inputs; this runner never builds its oracle from candidate output.'}
    (out/'execution.json').write_text(json.dumps(report,indent=2)+'\n')
    failures=[r for r in rows if r['exit_code']!=r.get('expected_exit_code') or r.get('source_check_failed')
              or (r['label']=='pinned-jadx-version' and not r.get('jadx_version_verified'))
              or (r['label'].endswith('compile-exact-jadx-generated-FX')
                  and not r.get('known_undefined_th_diagnostic'))]
    fx_red=[r for r in rows if r['phase']=='jadx' and r['label'].endswith('compile-exact-jadx-generated-FX')]
    jadx_fx_runs=[r for r in rows if r['phase']=='jadx' and 'rebuilt-main-FX' in r['label']]
    if len(fx_red)!=2 or jadx_fx_runs: failures.extend(fx_red)
    exact=[r for r in rows if 'oracle_stdout_matches' in r and (not r['oracle_stdout_matches'] or not r['oracle_stderr_matches'])]
    report['status']='commands_passed_pending_independent_acceptance' if not failures and not exact else 'replay_mismatch_pending_review'
    report['command_mismatches']=[r['serial'] for r in failures]
    report['oracle_mismatches']=[r['serial'] for r in exact]
    (out/'execution.json').write_text(json.dumps(report,indent=2)+'\n')
    return 0 if not failures and not exact else 1

if __name__=='__main__': raise SystemExit(main())
