#!/usr/bin/env python3
"""Read-only independent acceptance of an already completed 45-command FY/FX/FO replay."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, re
from pathlib import Path

HERE=Path(__file__).resolve().parent
RUN_DEFAULT=Path('/private/tmp/jarde-nested-parent-fixed-matrix-root-v1-20261017')
NESTED_COMPARATOR=Path('/private/tmp/jarde-nested-fin-matrix-prep-20261017/nested-compare.py')
FIXED_INDEX=HERE/'fixed-inputs.json'
COMMAND_INDEX=HERE/'parent-replay-index.json'


def sha(data: bytes)->str:return hashlib.sha256(data).hexdigest()
def read_json(path:Path):return json.loads(path.read_text(encoding='utf-8'))
def pin(path:Path)->dict:
    b=path.read_bytes();return {'path':str(path),'bytes':len(b),'sha256':sha(b)}
def barray(data):return bytes(data).decode('utf-8',errors='replace')


def physical_methods(path:Path, classfile_facts)->list[dict]:
    data=path.read_bytes();pos=0
    def take(n):
        nonlocal pos
        v=data[pos:pos+n];pos+=n
        if len(v)!=n:raise ValueError(f'truncated class file {path} at {pos-n}')
        return v
    def u1():return take(1)[0]
    def u2():return int.from_bytes(take(2),'big')
    def u4():return int.from_bytes(take(4),'big')
    if u4()!=0xCAFEBABE:raise ValueError(f'not a class file: {path}')
    minor,major=u2(),u2(); ncp=u2();cp=[None]*ncp;i=1
    while i<ncp:
        tag=u1()
        if tag==1:cp[i]=('utf8',take(u2()).decode('utf-8',errors='replace'))
        elif tag in (3,4):take(4)
        elif tag in (5,6):take(8);i+=1
        elif tag in (7,8,16,19,20):cp[i]=(tag,u2())
        elif tag in (9,10,11,12,17,18):cp[i]=(tag,u2(),u2())
        elif tag==15:take(3)
        else:raise ValueError(f'unknown CP tag {tag} in {path}')
        i+=1
    def utf(index):
        entry=cp[index]
        if not entry or entry[0]!='utf8':raise ValueError(f'bad UTF8 pool index {index} in {path}')
        return entry[1]
    def attrs():
        for _ in range(u2()):take(2);take(u4())
    access=u2();this_idx=u2();u2()
    this_class=utf(cp[this_idx][1])
    for _ in range(u2()):u2()
    for _ in range(u2()):u2();u2();u2();attrs()
    facts=[]
    for ordinal in range(u2()):
        flags=u2();name=utf(u2());desc=utf(u2());attrs()
        code=classfile_facts(path,name,desc)
        bcis=code['instruction_bcis']; length=code['code_length_bytes'];rows=code['rows']
        endpoints=set(bcis)|{length}
        rows_valid=all(a in endpoints and b in endpoints and c in bcis and a<b<=length
                       for a,b,c,_ in rows)
        facts.append({'index':ordinal,'name':name,'descriptor':desc,'access_flags':flags,
                      'code_length':length,'instruction_bcis':bcis,'exception_rows':rows,
                      'exception_rows_valid':rows_valid})
    return {'class_name':this_class,'major':major,'minor':minor,'access_flags':access,'methods':facts}


def owner_of(identity):return identity.get('owner',{})
def source_report_checks(doc:dict, physical:dict, class_name:str, leg:str, stream_label:str)->dict:
    methods=doc.get('methods',[]); actual=physical['methods'];errors=[];map_rows=[]
    if len(methods)!=len(actual):errors.append(f'method count {len(methods)} != physical {len(actual)}')
    source_class_bytes=None;source_owner=None
    for ordinal,m in enumerate(methods):
        item=m.get('item',{});ident=item.get('identity',{});outcome=m.get('outcome',{});report=outcome.get('report') or {}
        name=item.get('name',{}).get('escaped');desc=item.get('descriptor',{}).get('escaped')
        if ordinal>=len(actual):continue
        p=actual[ordinal]
        if item.get('index')!=ordinal:errors.append(f'method {ordinal}: reported index {item.get("index")}')
        if (name,desc)!=(p['name'],p['descriptor']):errors.append(f'method {ordinal}: {name}{desc} != {p["name"]}{p["descriptor"]}')
        if ident.get('name')!=item.get('name',{}).get('raw') or ident.get('descriptor')!=item.get('descriptor',{}).get('raw'):
            errors.append(f'method {ordinal}: identity name/descriptor differs from item')
        owner=owner_of(ident); cb=owner.get('class_bytes',{}); location=owner.get('location',{}); entry=location.get('entry',{})
        binding=report.get('artifact',{}).get('binding',{})
        if binding.get('method')!=ident or binding.get('member_ordinal')!=ordinal:errors.append(f'method {ordinal}: artifact binding identity/ordinal differs')
        if owner!=doc.get('class'):errors.append(f'method {ordinal}: owner differs from reported class identity')
        if report.get('method')!=p['name']+p['descriptor']:errors.append(f'method {ordinal}: report signature differs')
        if cb.get('length')!=Path(physical['_path']).stat().st_size:errors.append(f'method {ordinal}: owner class byte length mismatch')
        if barray(entry.get('raw_name',[]))!=class_name+'.class':errors.append(f'method {ordinal}: owner raw_name mismatch')
        if location.get('kind')!='archive_entry' or entry.get('ordinal')!=0:errors.append(f'method {ordinal}: owner location mismatch')
        if source_class_bytes is None:source_class_bytes=cb;source_owner=owner
        elif cb!=source_class_bytes or owner!=source_owner:errors.append(f'method {ordinal}: owner identity differs from peer methods')
        if outcome.get('kind')!='recovered' or report.get('quality')!='structured' or report.get('representation')!='java' or report.get('fallbacks')!=[]:
            errors.append(f'method {ordinal}: not Structured Java with empty fallback')
        text=report.get('text')
        if not isinstance(text,str):errors.append(f'method {ordinal}: report.text missing');text=''
        text_bytes=text.encode('utf-8');sm=report.get('source_map')
        if not isinstance(sm,dict) or not isinstance(sm.get('segments'),list):
            errors.append(f'method {ordinal}: source_map.segments missing');segments=[]
        else:segments=sm['segments']
        evidence=report.get('evidence',{}).get('categories',[])
        source_map_evidence=next((x for x in evidence if x.get('kind')=='source_map'),None)
        if not source_map_evidence or source_map_evidence.get('state',{}).get('state')!='complete':
            errors.append(f'method {ordinal}: source_map evidence is not complete')
        bci_set=set(p['instruction_bcis'])
        tested=0;seen_bcis=set()
        for seg_index,seg in enumerate(segments):
            start,end=seg.get('start'),seg.get('end')
            if not isinstance(start,int) or not isinstance(end,int) or not (0<=start<=end<=len(text_bytes)):
                errors.append(f'method {ordinal} source-map segment {seg_index}: range outside report.text bytes')
            else:
                for boundary in (start,end):
                    try:text_bytes[:boundary].decode('utf-8')
                    except UnicodeDecodeError:errors.append(f'method {ordinal} source-map boundary {boundary} splits UTF-8')
            origin=seg.get('origin') or {};refs=[]
            primary=origin.get('primary')
            if isinstance(primary,dict):refs.append(primary)
            refs.extend(x for x in origin.get('derived',[]) if isinstance(x,dict))
            for ref in refs:
                tested+=1;bci=ref.get('bci');ref_method=ref.get('method');seen_bcis.add(bci)
                if not isinstance(bci,int) or bci not in bci_set:errors.append(f'method {ordinal} source-map BCI {bci} is not a physical instruction boundary')
                if ref_method!=ident:errors.append(f'method {ordinal} source-map method identity differs from physical owner/method')
        if seen_bcis!=bci_set:errors.append(f'method {ordinal}: missing physical source-map BCIs {sorted(bci_set-seen_bcis)}')
        map_rows.append({'index':ordinal,'name':name,'descriptor':desc,'report_text_bytes':len(text_bytes),
                         'source_map_segments':len(segments),'source_map_origins_checked':tested,
                         'physical_bcis':p['instruction_bcis'],'physical_exception_rows':p['exception_rows'],
                         'method_identity':ident,'physical_exception_rows_valid':p['exception_rows_valid']})
        if not p['exception_rows_valid']:errors.append(f'method {ordinal}: exception table endpoints invalid')
    if len(actual)!=len(methods):
        for p in actual[len(methods):]:errors.append(f'unreported physical method {p["index"]}:{p["name"]}{p["descriptor"]}')
    return {'label':stream_label,'class':class_name,'compiler':leg,'method_count':len(methods),
            'physical_method_count':len(actual),'physical_methods':[{k:v for k,v in p.items() if k!='exception_rows'} for p in actual],
            'source_map_checks':map_rows,'errors':errors,'passed':not errors}


def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--run',type=Path,default=RUN_DEFAULT)
    ap.add_argument('--fixed-inputs',type=Path,default=FIXED_INDEX)
    ap.add_argument('--command-index',type=Path,default=COMMAND_INDEX)
    ap.add_argument('--nested-comparator',type=Path,default=NESTED_COMPARATOR)
    ap.add_argument('--out',type=Path,required=True)
    a=ap.parse_args();run=a.run.resolve();out=a.out.resolve()
    if out.exists():raise SystemExit(f'refusing to overwrite {out}')
    modspec=importlib.util.spec_from_file_location('nested_fin_compare_acceptance',a.nested_comparator)
    mod=importlib.util.module_from_spec(modspec);modspec.loader.exec_module(mod)
    fixed=read_json(a.fixed_inputs);index=read_json(a.command_index);execution=read_json(run/'execution.json')
    report={'schema':'effectful-finally-parent-matrix-acceptance-v1','inputs':{},'errors':[],
            'jarde':{'source_reports':[],'source_text_comparisons':[]},'jadx':{},'raw_streams':[],
            'fixed_original_class_facts':[]}
    if len(execution.get('commands',[]))!=45:report['errors'].append('expected exactly 45 actual commands')
    if execution.get('jarde_command_count')!=24 or execution.get('jadx_command_count')!=21:report['errors'].append('actual command phase counts are not 24+21')
    # Verify all actual raw streams and actual exits against the archived expected outcomes.
    for c in execution.get('commands',[]):
        for stream in ('stdout','stderr'):
            r=c.get(stream,{})
            path=Path(r.get('path',''))
            if not path.is_file():report['errors'].append(f'missing raw stream {c.get("serial")} {stream}');continue
            p=pin(path);report['raw_streams'].append({'serial':c.get('serial'),'stream':stream,**p,
                'record_matches':p['bytes']==r.get('bytes') and p['sha256']==r.get('sha256')})
            if not report['raw_streams'][-1]['record_matches']:report['errors'].append(f'raw pin mismatch {c.get("serial")} {stream}')
        if c.get('exit_code')!=c.get('expected_exit_code'):report['errors'].append(f'actual/expected exit differs for {c.get("serial")} {c.get("label")}')
    if len(report['raw_streams'])!=90:report['errors'].append('expected all 90 raw streams')
    commands=execution.get('commands',[])
    # Fixed original artifacts and runtime streams are pin-checked once; no oracle is built from candidate output.
    for leg in ('javac8','javac23'):
      for name in ('FY','FX','FO'):
        for section in ('target_jars','target_classes'):
          rec=fixed[section][leg][name];path=Path(rec['path']);p=pin(path)
          report['inputs'][f'{section}/{leg}/{name}']=p
          if (p['bytes'],p['sha256'])!=(rec['bytes'],rec['sha256']):report['errors'].append(f'fixed input pin mismatch {section}/{leg}/{name}')
    for leg,runtimes in fixed['original_oracles'].items():
      for runtime,classes_map in runtimes.items():
        for name,streams in classes_map.items():
          for stream in ('stdout','stderr'):
            rec=streams[stream];path=Path(rec['path']);p=pin(path)
            report['inputs'][f'original_oracle/{leg}/{runtime}/{name}/{stream}']=p
            if (p['bytes'],p['sha256'])!=(rec['bytes'],rec['sha256']):report['errors'].append(f'fixed oracle pin mismatch {leg}/{runtime}/{name}/{stream}')
    classes={}
    for leg in ('javac8','javac23'):
      classes[leg]={}
      for name in ('FY','FX','FO'):
        rec=fixed['target_classes'][leg][name];path=Path(rec['path']);p=pin(path)
        if (p['bytes'],p['sha256'])!=(rec['bytes'],rec['sha256']):report['errors'].append(f'fixed class pin mismatch {leg}/{name}')
        physical=physical_methods(path,mod.classfile_method_facts);physical['_path']=str(path)
        classes[leg][name]=physical
        report['fixed_original_class_facts'].append({'compiler':leg,'class':name,'pin':p,
          'classfile_name':physical['class_name'],'physical_method_count':len(physical['methods']),
          'methods':physical['methods'],
          'exception_rows_valid':all(m['exception_rows_valid'] for m in physical['methods'])})
        expected={'FY':5,'FX':6,'FO':5}[name]
        if physical['class_name']!=name:report['errors'].append(f'classfile owner mismatch {leg}/{name}')
        if len(physical['methods'])!=expected:report['errors'].append(f'physical method count mismatch {leg}/{name}')
        if not all(m['exception_rows_valid'] for m in physical['methods']):report['errors'].append(f'exception table boundary error {leg}/{name}')
    # Validate six new Jarde all-evidence reports against physical ordinal, identity, BCI, and text-map bounds.
    new_sources={}
    for c in commands:
      if c['phase']!='jarde' or '-current-whole-source-' not in c['label']:continue
      name=c['label'].rsplit('-',1)[-1];leg='javac8' if c['label'].startswith('javac8-') else 'javac23'
      doc=json.loads(Path(c['stdout']['path']).read_bytes())
      check=source_report_checks(doc,classes[leg][name],name,leg,c['label'])
      report['jarde']['source_reports'].append(check);new_sources[(leg,name)]=doc
      if not check['passed']:report['errors'].extend(f'{c["label"]}: {e}' for e in check['errors'])
      if not c.get('all_methods_recovered_java_structured_no_fallback'):report['errors'].append(f'{c["label"]}: wrapper method quality flag false')
      if c.get('source_text'):
        generated=Path(c['source_text']['path']);actual=pin(generated)
        if actual['bytes']!=c['source_text']['bytes'] or actual['sha256']!=c['source_text']['sha256'] or generated.read_bytes()!=doc.get('text','').encode('utf-8'):
          report['errors'].append(f'{c["label"]}: materialized source differs from recorded raw JSON text')
      else:report['errors'].append(f'{c["label"]}: no generated source pin')
    # Check and compare old archived all-evidence report.text per exact physical method.
    old_sources={}
    screen=index['fy_fx_fo']['screen_commands']
    for c in screen:
      if '-current-whole-source-' not in c['label']:continue
      name=c['label'].rsplit('-',1)[-1];leg='javac8' if c['label'].startswith('javac8-') else 'javac23'
      old_raw=Path(c['archived_streams']['stdout']['path']).read_bytes()
      if sha(old_raw)!=c['archived_streams']['stdout']['sha256']:report['errors'].append(f'old archived source raw pin mismatch {c["label"]}')
      old_doc=json.loads(old_raw);old_sources[(leg,name)]=old_doc
      old_check=source_report_checks(old_doc,classes[leg][name],name,leg,'archived-'+c['label'])
      report['jarde'].setdefault('archived_source_reports',[]).append(old_check)
      if not old_check['passed']:report['errors'].extend(f'archived {c["label"]}: {e}' for e in old_check['errors'])
    if len(old_sources)!=6 or len(new_sources)!=6:report['errors'].append('expected six old and six new all-evidence source JSON reports')
    for key,new_doc in sorted(new_sources.items()):
      old_doc=old_sources.get(key)
      if old_doc is None:continue
      old_methods=old_doc.get('methods',[]);new_methods=new_doc.get('methods',[])
      if len(old_methods)!=len(new_methods):report['errors'].append(f'{key}: report method counts differ')
      for i,(old_m,new_m) in enumerate(zip(old_methods,new_methods)):
        old_item=old_m.get('item',{});new_item=new_m.get('item',{})
        old_report=(old_m.get('outcome') or {}).get('report') or {};new_report=(new_m.get('outcome') or {}).get('report') or {}
        ot=old_report.get('text');nt=new_report.get('text')
        row={'compiler':key[0],'class':key[1],'index':i,
             'old_name':old_item.get('name',{}).get('escaped'),'new_name':new_item.get('name',{}).get('escaped'),
             'old_descriptor':old_item.get('descriptor',{}).get('escaped'),'new_descriptor':new_item.get('descriptor',{}).get('escaped'),
             'identity_same':old_item.get('identity')==new_item.get('identity'),
             'old_report_text_sha256':sha((ot or '').encode()),'new_report_text_sha256':sha((nt or '').encode()),
             'old_report_text_bytes':len((ot or '').encode()),'new_report_text_bytes':len((nt or '').encode()),
             'report_text_identical':ot==nt}
        if not row['identity_same'] or row['old_name']!=row['new_name'] or row['old_descriptor']!=row['new_descriptor']:
          report['errors'].append(f'{key} method {i}: archived/current physical identity differs')
        # Text changes are recorded as evidence; they do not alter this acceptance result.
        report['jarde']['source_text_comparisons'].append(row)
    # Jarde run assertions: 6 whole-source reports, 6 compiles, 12 exact same-runtime oracle runs.
    jarde=[c for c in commands if c['phase']=='jarde']
    jcompile=[c for c in jarde if '-compile-exact-current-generated-' in c['label']]
    jrun=[c for c in jarde if '-rebuilt-main-' in c['label']]
    jsource=[c for c in jarde if '-current-whole-source-' in c['label']]
    if (len(jsource),len(jcompile),len(jrun))!=(6,6,12):report['errors'].append('Jarde matrix must be 6 source + 6 compile + 12 runtime commands')
    if any(c['exit_code']!=0 for c in jsource+jcompile+jrun):report['errors'].append('Jarde commands must all exit zero')
    compile_artifacts=[]
    for c in jcompile:
      args=c.get('argv',[]);name=c['label'].rsplit('-',1)[-1];dest=Path(args[args.index('-d')+1]) if '-d' in args else None
      source_path=Path(args[-1]) if args else None
      class_file=(dest/f'{name}.class') if dest else None
      row={'label':c['label'],'source':str(source_path),'class_file':str(class_file),
           'source_exists':bool(source_path and source_path.is_file()),'class_exists':bool(class_file and class_file.is_file()),
           'source_matches_recorded_text':bool(source_path and source_path.is_file() and source_path.read_bytes()==(new_sources[('javac8' if c['label'].startswith('javac8-') else 'javac23',name)].get('text','')).encode())}
      compile_artifacts.append(row)
      if not row['source_exists'] or not row['class_exists'] or not row['source_matches_recorded_text']:
        report['errors'].append(f'{c["label"]}: rebuild artifact/source check failed')
    report['jarde']['compile_artifacts']=compile_artifacts
    computed_runtime=[]
    for c in [x for x in commands if 'rebuilt-main-' in x['label']]:
      match=re.search(r'^(javac8|javac23)-java(8|23)-(?:jadx-)?rebuilt-main-(FY|FX|FO)$',c['label'])
      if not match:continue
      leg,runtime,name=match.groups();oracle=fixed['original_oracles'][leg][f'java{runtime}'][name]
      actual_out=Path(c['stdout']['path']).read_bytes();actual_err=Path(c['stderr']['path']).read_bytes()
      expected_out=Path(oracle['stdout']['path']).read_bytes();expected_err=Path(oracle['stderr']['path']).read_bytes()
      row={'label':c['label'],'exit_code':c['exit_code'],'stdout_matches_fixed':actual_out==expected_out,
           'stderr_matches_fixed':actual_err==expected_err,'fixed_stdout_sha256':oracle['stdout']['sha256'],
           'actual_stdout_sha256':sha(actual_out),'fixed_stderr_sha256':oracle['stderr']['sha256'],
           'actual_stderr_sha256':sha(actual_err)}
      computed_runtime.append(row)
      argv=c.get('argv',[]);cp=Path(argv[argv.index('-cp')+1]) if '-cp' in argv else None
      compile_label=leg+'-compile-exact-'+('jadx-' if c['phase']=='jadx' else 'current-')+'generated-'+name
      compile_row=next((x for x in commands if x['label']==compile_label),None)
      build_dir=None
      if compile_row and '-d' in compile_row.get('argv',[]):build_dir=Path(compile_row['argv'][compile_row['argv'].index('-d')+1])
      row['rebuilt_only_classpath']=bool(cp and build_dir and cp.resolve()==build_dir.resolve())
      original_cp_paths=[]
      for by_leg in fixed['target_classes'].values():
        for v in by_leg.values():original_cp_paths.extend((Path(v['path']).resolve(),Path(v['path']).parent.resolve()))
      for by_leg in fixed['target_jars'].values():
        for v in by_leg.values():original_cp_paths.append(Path(v['path']).resolve())
      row['original_target_classpath_absent']=not (cp and cp.resolve() in original_cp_paths)
      if not row['rebuilt_only_classpath'] or not row['original_target_classpath_absent']:
        report['errors'].append(f'{c["label"]}: runtime classpath is not rebuilt-only')
      if c['exit_code']!=0 or not row['stdout_matches_fixed'] or not row['stderr_matches_fixed']:
        report['errors'].append(f'{c["label"]}: actual runtime stream differs from fixed original oracle')
    report['computed_runtime_oracle_comparisons']=computed_runtime
    if sum(c.get('method_count',0) for c in jsource)!=32:report['errors'].append('Jarde reports do not total 32 physical methods')
    # JADX exact matrix facts, accepting only the two Chinese/English localized undefined-th errors.
    jadx=[c for c in commands if c['phase']=='jadx']
    jd_versions=[c for c in jadx if c['label']=='pinned-jadx-version']
    jd_gen=[c for c in jadx if '-jadx-whole-source-' in c['label']]
    jd_comp=[c for c in jadx if '-compile-exact-jadx-generated-' in c['label']]
    jd_run=[c for c in jadx if '-jadx-rebuilt-main-' in c['label']]
    fx_fail=[c for c in jd_comp if c['label'].endswith('-FX') and c['exit_code']==1]
    fx_runtime=[c for c in jd_run if 'rebuilt-main-FX' in c['label']]
    valid_red=[]
    for c in fx_fail:
        stderr=Path(c['stderr']['path']).read_bytes().decode('utf-8',errors='replace')
        valid=('throw th;' in stderr and ('找不到符号' in stderr or 'cannot find symbol' in stderr)
               and ('变量 th' in stderr or re.search(r'variable\s+th\b',stderr))
               and re.search(r':56:\s*(?:错误|error):',stderr))
        valid_red.append({'label':c['label'],'stderr_sha256':c['stderr']['sha256'],'line_56_throw_th_undefined':bool(valid)})
        if not valid:report['errors'].append(f'{c["label"]}: failure is not the expected line-56 undefined throw th')
    report['jadx']={'command_count':len(jadx),'version_rows':len(jd_versions),'version_verified':len(jd_versions)==1 and jd_versions[0].get('jadx_version_verified',False),
       'source_generation_successes':sum(c['exit_code']==0 for c in jd_gen),'source_generation_rows':len(jd_gen),
       'compile_successes':sum(c['exit_code']==0 for c in jd_comp),'compile_failure_rows':len(fx_fail),'compile_rows':len(jd_comp),
       'expected_fx_red':valid_red,'runtime_rows':len(jd_run),'fx_rebuilt_runtime_rows':len(fx_runtime),
       'runtime_oracle_matches':sum(bool(c.get('oracle_stdout_matches') and c.get('oracle_stderr_matches')) for c in jd_run)}
    if (len(jadx),len(jd_versions),len(jd_gen),len(jd_comp),len(jd_run))!=(21,1,6,6,8):report['errors'].append('JADX matrix command shape is not 1+6+6+8')
    if len(jd_versions)!=1 or not jd_versions[0].get('jadx_version_verified'):report['errors'].append('JADX version not pinned to 1.5.6')
    if any(c['exit_code']!=0 for c in jd_gen):report['errors'].append('JADX source generation did not all succeed')
    if sum(c['exit_code']==0 for c in jd_comp)!=4 or len(fx_fail)!=2:report['errors'].append('JADX must retain four successful compiles and two FX compile failures')
    if len(fx_runtime)!=0:report['errors'].append('JADX FX must have zero rebuilt runtime commands')
    if any(not c.get('oracle_stdout_matches') or not c.get('oracle_stderr_matches') for c in jd_run):report['errors'].append('successful JADX rebuilt runtime differs from fixed original oracle')
    jadx_artifacts=[]
    for c in jd_comp:
      args=c.get('argv',[]);name=c['label'].rsplit('-',1)[-1];dest=Path(args[args.index('-d')+1]) if '-d' in args else None
      source_path=Path(args[-1]) if args else None;class_name=f'defpackage/{name}.class'
      class_file=dest/class_name if dest else None
      row={'label':c['label'],'source_exists':bool(source_path and source_path.is_file()),
           'class_file':str(class_file) if class_file else None,'class_exists':bool(class_file and class_file.is_file()),
           'exit_code':c['exit_code']}
      jadx_artifacts.append(row)
      if c['exit_code']==0 and (not row['source_exists'] or not row['class_exists']):report['errors'].append(f'{c["label"]}: successful JADX compile lacks source/class artifact')
    report['jadx']['compile_artifacts']=jadx_artifacts
    report['summary']={'raw_stream_count':len(report['raw_streams']),'jarde_sources':len(jsource),'jarde_physical_method_rows':sum(x['physical_method_count'] for x in report['jarde']['source_reports']),
       'jarde_compile_successes':sum(c['exit_code']==0 for c in jcompile),'jarde_rebuilt_runtime_oracle_matches':sum(bool(c.get('oracle_stdout_matches') and c.get('oracle_stderr_matches')) for c in jrun),
       'jarde_report_text_identical':sum(r['report_text_identical'] for r in report['jarde']['source_text_comparisons']),
       'jarde_report_text_changed':sum(not r['report_text_identical'] for r in report['jarde']['source_text_comparisons']),
       'source_map_checks_passed':all(c['passed'] for c in report['jarde']['source_reports']),
       'status':'accepted' if not report['errors'] else 'rejected'}
    out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({'status':report['summary']['status'],'out':str(out),'errors':report['errors']},ensure_ascii=False))
    return 0 if not report['errors'] else 1

if __name__=='__main__':raise SystemExit(main())
