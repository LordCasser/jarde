# Effectful-finally parent replay index

This private bundle contains a read-only extraction of the archived parent 29-command gate and FY/FX/FO comparison. No compiler, Cargo, Git, JADX, or replay command was run while preparing it.

`parent-replay-index.json` preserves every original full argv, cwd, expected exit, test selector and result summary for the 29 gates and the 24 Jarde plus 21 JADX screen commands. It also pins every archived stdout/stderr raw stream for the 45 screen commands. `fixed-inputs.json` pins six immutable original input JARs, six matching original class files, and the 12 original runtime stdout/stderr oracle pairs. The replay script reads these saved oracles and never derives expected output from candidate output.

Exact archived source scripts are under `sources/parent29/` and `sources/fy-fx-fo/`. `replay_matrix.py` accepts local repository, candidate CLI, JDK 8/23 compiler/runtime, JADX 1.5.6 JAR, and a fresh output path; it rewrites the archived absolute paths, saves every new command's raw stdout/stderr with SHA-256, and compares successful rebuilt runs against the pinned original runtime streams. It was syntax checked only and has not been executed. The archived argv and raw streams remain available alongside the rewritten replay.

Example for root to adapt after confirming local tool paths:

```sh
python3 /private/tmp/effectful-finally-parent-replay-index-20261017/replay_matrix.py \
  --repo /Users/lordcasser/workspace/projects/jarde \
  --cli /path/to/final-jarde-cli \
  --out /private/tmp/effectful-finally-parent-replay-final-v1 \
  --javac8 /path/to/jdk8/bin/javac --javac23 /path/to/jdk23/bin/javac \
  --java8 /path/to/jdk8/bin/java --java23 /path/to/jdk23/bin/java \
  --jadx-jar /path/to/jadx-1.5.6-all.jar
```

The archived absolute paths are historical provenance; only the runner's rewritten argv are portable. The archived command counts and results remain historical evidence and do not stand in for a new run.

`accept_parent_matrix.py` is a separate read-only verifier for the completed output directory. It checks all 90 actual raw stream pins, the 45 exits, the six fixed target class/JAR pins and 12 fixed oracle streams; decodes all 32 physical methods from each compiler/profile source report; validates reported method ordinal/name/descriptor/owner identity, every instruction BCI, exception-row boundaries, and every source-map span/origin against the original classfile. It separately records each old-versus-new `outcome.report.text` comparison for all six all-evidence JSON reports. Text changes are recorded with hashes and lengths and are not used as a pass/fail condition. For JADX it accepts the two line-56 undefined-`th` failures in Chinese or English and requires no FX runtime rows.

Example (root runs this after review, to a fresh output path):

```sh
python3 /private/tmp/effectful-finally-parent-replay-index-20261017/accept_parent_matrix.py \
  --run /private/tmp/jarde-nested-parent-fixed-matrix-root-v1-20261017 \
  --out /private/tmp/jarde-nested-parent-fixed-matrix-root-v1-20261017/acceptance.json
```

The acceptor has only been syntax-checked here; it has not been run against the output.
