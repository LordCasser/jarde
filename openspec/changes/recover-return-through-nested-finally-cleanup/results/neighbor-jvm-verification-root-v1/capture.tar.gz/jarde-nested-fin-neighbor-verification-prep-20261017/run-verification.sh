#!/bin/bash
set -euo pipefail

usage() {
  echo "usage: $0 --jdk8-home PATH --jdk23-home PATH --output-dir PATH [--variants-dir PATH]" >&2
}

jdk8_home=""
jdk23_home=""
output_dir=""
variants_dir="/private/tmp/jarde-nested-fin-neighbor-verification-prep-20261017/variants"
while (($#)); do
  case "$1" in
    --jdk8-home) jdk8_home="$2"; shift 2 ;;
    --jdk23-home) jdk23_home="$2"; shift 2 ;;
    --output-dir) output_dir="$2"; shift 2 ;;
    --variants-dir) variants_dir="$2"; shift 2 ;;
    *) usage; exit 2 ;;
  esac
done
if [[ -z "$jdk8_home" || -z "$jdk23_home" || -z "$output_dir" ]]; then
  usage
  exit 2
fi

for executable in "$jdk8_home/bin/javac" "$jdk8_home/bin/java" \
                  "$jdk23_home/bin/javac" "$jdk23_home/bin/java"; do
  if [[ ! -x "$executable" ]]; then
    echo "not executable: $executable" >&2
    exit 2
  fi
done
if [[ ! -f "$variants_dir/manifest.json" ]]; then
  echo "missing variant manifest: $variants_dir/manifest.json" >&2
  exit 2
fi
if [[ -e "$output_dir" ]]; then
  echo "output directory already exists: $output_dir" >&2
  exit 2
fi
mkdir -p "$output_dir"
mkdir -p "$output_dir/classes-java8" "$output_dir/classes-java23"
: > "$output_dir/commands.txt"

record() {
  local label="$1"
  local raw="$output_dir/$label.raw"
  shift
  {
    printf '%s argv:' "$label"
    printf ' %q' "$@"
    printf '\nraw: %s\n' "$raw"
  } >> "$output_dir/commands.txt"
  local status
  if "$@" > "$raw" 2>&1; then
    status=0
  else
    status=$?
  fi
  printf 'exit_status: %s\nsha256: ' "$status" >> "$output_dir/commands.txt"
  shasum -a 256 "$raw" >> "$output_dir/commands.txt"
  cat "$raw"
  return "$status"
}

source_dir="/private/tmp/jarde-nested-fin-neighbor-verification-prep-20261017"
record javac8-version "$jdk8_home/bin/javac" -version
record java8-version "$jdk8_home/bin/java" -version
record javac8 "$jdk8_home/bin/javac" -source 8 -target 8 -d "$output_dir/classes-java8" "$source_dir/VerifyNeighbors.java"
record java8 "$jdk8_home/bin/java" -Xverify:all -cp "$output_dir/classes-java8" VerifyNeighbors "$variants_dir"
record javac23-version "$jdk23_home/bin/javac" -version
record java23-version "$jdk23_home/bin/java" -version
record javac23 "$jdk23_home/bin/javac" --release 8 -d "$output_dir/classes-java23" "$source_dir/VerifyNeighbors.java"
record java23 "$jdk23_home/bin/java" -Xverify:all -cp "$output_dir/classes-java23" VerifyNeighbors "$variants_dir"

shasum -a 256 "$variants_dir/manifest.json" "$source_dir/VerifyNeighbors.java" \
  "$source_dir/run-verification.sh" > "$output_dir/prepared-inputs.sha256"
cat "$output_dir/commands.txt"
