#!/usr/bin/env python3
"""Export the exact 15 nestedFin verifier-valid classfile mutations from guard.rs."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

PREFIX = bytes([0x10, 0x0A, 0x1A, 0x6C, 0x3C, 0xB2, 0x00, 0x2F])
EXPECTED_SOURCE_SHA256 = "e6f0eb1e029a2c883d3ee5df5e089eda17fea27833a9244297cede139cd61287"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def code_start(data: bytes) -> int:
    matches = [i for i in range(len(data)) if data.startswith(PREFIX, i)]
    if len(matches) != 1:
        raise ValueError(f"expected unique nestedFin bytecode prefix, found {len(matches)}")
    return matches[0]


def cp_end(data: bytes) -> int:
    count = int.from_bytes(data[8:10], "big")
    at = 10
    index = 1
    while index < count:
        tag = data[at]
        at += 1
        if tag == 1:
            length = int.from_bytes(data[at:at + 2], "big")
            at += 2 + length
        elif tag in (3, 4):
            at += 4
        elif tag in (5, 6):
            at += 8
            index += 1
        elif tag in (7, 8, 16, 19, 20):
            at += 2
        elif tag in (9, 10, 11, 12, 17, 18):
            at += 4
        elif tag == 15:
            at += 3
        else:
            raise ValueError(f"unexpected constant-pool tag {tag} at offset {at - 1}")
        index += 1
    if at > len(data):
        raise ValueError("constant pool runs past classfile")
    return at


def append_system_err(data: bytes) -> tuple[bytearray, int]:
    changed = bytearray(data)
    count = int.from_bytes(changed[8:10], "big")
    name = count
    name_type = count + 1
    field = count + 2
    entries = bytearray([1, 0, 3, ord("e"), ord("r"), ord("r")])
    entries.extend([12])
    entries.extend(name.to_bytes(2, "big"))
    entries.extend((52).to_bytes(2, "big"))
    entries.extend([9])
    entries.extend((48).to_bytes(2, "big"))
    entries.extend(name_type.to_bytes(2, "big"))
    at = cp_end(changed)
    changed[at:at] = entries
    changed[8:10] = (count + 3).to_bytes(2, "big")
    return changed, field


def row_field(code: int, ordinal: int, field_offset: int) -> int:
    return code + 74 + ordinal * 8 + field_offset


def variants(original: bytes) -> list[tuple[str, str, bytes]]:
    code = code_start(original)
    result: list[tuple[str, str, bytes]] = []

    for label, ldc_bci in [
        ("normal inner out-copy argument differs", 16),
        ("inner handler out-copy argument differs", 28),
        ("outer handler out-copy argument differs", 49),
        ("nested outer-handler out-copy argument differs", 62),
    ]:
        changed = bytearray(original)
        if changed[code + ldc_bci] != 0x12 or changed[code + ldc_bci + 1] != 0x3E:
            raise ValueError(f"{label}: expected ldc CP #62 ('out') at BCI {ldc_bci}")
        changed[code + ldc_bci + 1] = 0x3C  # CP #60, same-typed String "in".
        result.append((label, f"ldc operand at BCI {ldc_bci}: CP #62 ('out') -> CP #60 ('in')", bytes(changed)))

    receiver, err_field = append_system_err(original)
    moved_code = code_start(receiver)
    if receiver[moved_code + 13] != 0xB2:
        raise ValueError("normal inner copy: expected getstatic at BCI 13")
    receiver[moved_code + 14:moved_code + 16] = err_field.to_bytes(2, "big")
    result.append(("normal inner out-copy receiver differs",
                   f"getstatic operand at BCI 13: System.out -> appended System.err Fieldref CP #{err_field}",
                   bytes(receiver)))

    for label, ordinal, old_end, new_end in [
        ("inner row covers the normal out-copy", 0, 13, 21),
        ("outer-cleanup row covers the normal out-copy", 2, 46, 54),
    ]:
        changed = bytearray(original)
        field = row_field(code, ordinal, 2)
        actual = int.from_bytes(changed[field:field + 2], "big")
        if actual != old_end:
            raise ValueError(f"{label}: expected exception-table end {old_end}, got {actual}")
        changed[field:field + 2] = new_end.to_bytes(2, "big")
        result.append((label, f"exception row {ordinal} end_bci: {old_end} -> {new_end}", bytes(changed)))

    changed = bytearray(original)
    field = row_field(code, 1, 2)
    if int.from_bytes(changed[field:field + 2], "big") != 5:
        raise ValueError("outer row saved-store control: expected end_bci 5")
    changed[field:field + 2] = (4).to_bytes(2, "big")
    result.append(("outer row misses the saved-result store", "exception row 1 end_bci: 5 -> 4", bytes(changed)))

    changed = bytearray(original)
    field = row_field(code, 1, 6)
    if int.from_bytes(changed[field:field + 2], "big") != 0:
        raise ValueError("outer row catch control: expected catch_type 0")
    changed[field:field + 2] = (38).to_bytes(2, "big")  # RuntimeException.
    result.append(("outer row is not catch-all", "exception row 1 catch_type: 0 -> CP #38 (RuntimeException)", bytes(changed)))

    changed = bytearray(original)
    if changed[code + 35] != 0x1B:
        raise ValueError("saved return control: expected iload_1 at BCI 35")
    changed[code + 35] = 0x1A  # iload_0, another Int producer.
    result.append(("saved return reload reads another Int producer", "iload_1 -> iload_0 at BCI 35", bytes(changed)))

    for label, bci, expected in [
        ("inner handler rethrows another value", 33, 0x2C),
        ("outer handler rethrows another value", 70, 0x2D),
    ]:
        changed = bytearray(original)
        if changed[code + bci] != expected:
            raise ValueError(f"{label}: expected local reload opcode at BCI {bci}")
        changed[code + bci] = 0x01  # aconst_null; athrow null is verifier-valid.
        result.append((label, f"local throwable reload -> aconst_null at BCI {bci}", bytes(changed)))

    changed = bytearray(original)
    if changed[code + 67:code + 69] != bytes([0x19, 0x04]):
        raise ValueError("nested outer rethrow control: expected aload 4 at BCI 67")
    changed[code + 67:code + 69] = bytes([0x01, 0x00])  # aconst_null; nop.
    result.append(("nested outer handler rethrows another value", "aload 4 -> aconst_null; nop at BCI 67", bytes(changed)))

    changed = bytearray(original)
    if changed[code + 51:code + 54] != bytes([0xB6, 0x00, 0x37]):
        raise ValueError("missing-copy control: expected invokevirtual #55 at BCI 51")
    changed[code + 51:code + 54] = bytes([0x57, 0x57, 0x00])  # pop; pop; nop.
    result.append(("outer cleanup omits one out invocation", "invokevirtual at BCI 51 -> pop; pop; nop", bytes(changed)))

    changed = bytearray(original)
    if int.from_bytes(changed[code + 72:code + 74], "big") != 4:
        raise ValueError("extra-edge control: expected four exception rows")
    rows_end = code + 74 + 4 * 8
    changed[rows_end:rows_end] = bytes([
        0, 13,  # start_bci = 13
        0, 21,  # end_bci = 21
        0, 24,  # handler_bci = 24
        0, 0,   # catch-all
    ])
    changed[code + 72:code + 74] = (5).to_bytes(2, "big")
    code_attribute_length = code - 12
    old_length = int.from_bytes(changed[code_attribute_length:code - 8], "big")
    changed[code_attribute_length:code - 8] = (old_length + 8).to_bytes(4, "big")
    result.append(("extra cleanup exception edge reaches the inner handler",
                   "append fifth catch-all row [13,21) -> handler 24; Code attribute_length +8",
                   bytes(changed)))

    if len(result) != 15:
        raise ValueError(f"expected exactly 15 mutations, got {len(result)}")
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("classfile", type=Path, help="sealed EX.class from the repository")
    parser.add_argument("output_dir", type=Path, help="new or empty directory for the 15 variants")
    args = parser.parse_args()
    original = args.classfile.read_bytes()
    if original[:4] != bytes.fromhex("cafebabe"):
        raise ValueError("input is not a JVM classfile")
    if sha(original) != EXPECTED_SOURCE_SHA256:
        raise ValueError(
            f"input is not the sealed EX fixture: expected {EXPECTED_SOURCE_SHA256}, got {sha(original)}"
        )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    entries = []
    for ordinal, (label, mutation, data) in enumerate(variants(original), 1):
        directory = args.output_dir / f"variant-{ordinal:02d}"
        directory.mkdir(exist_ok=False)
        class_path = directory / "EX.class"
        class_path.write_bytes(data)
        entries.append({
            "ordinal": ordinal,
            "directory": directory.name,
            "class_file": str(class_path),
            "binary_name": "EX",
            "method": "nestedFin(I)I",
            "label": label,
            "mutation": mutation,
            "size_bytes": len(data),
            "sha256": sha(data),
        })
    manifest = {
        "purpose": "JVM verifier validation; not a substitute for canonical CFG/SSA proof tests",
        "source_class": str(args.classfile.resolve()),
        "source_size_bytes": len(original),
        "source_sha256": sha(original),
        "mutation_count": len(entries),
        "variants": entries,
    }
    (args.output_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output_dir": str(args.output_dir.resolve()), "mutation_count": len(entries),
                      "source_sha256": sha(original), "manifest": str((args.output_dir / 'manifest.json').resolve())},
                     indent=2))


if __name__ == "__main__":
    main()
