# Nested-finally JVM verifier neighbors

This directory prepares an independent JVM verification of the exact 15 mutations in `nested_finally_rejects_complete_verifier_valid_classfile_neighbors` in `crates/jarde-java/src/guard.rs`. It does not treat canonical CFG/SSA completeness as proof that the JVM accepts the classfiles.

`export_neighbors.py` reproduces the test's byte mutations, including the `System.err` receiver variant using the existing helper's CP construction: append `Utf8("err")`, `NameAndType` (descriptor CP #52), and `Fieldref` (class CP #48) at the classfile's actual `constant_pool_count`, then patch the BCI 13 `getstatic` operand to the appended field index. It checks the original sealed class SHA, bytecode prefix, exact old operands/ranges, and exactly 15 outputs. The generator has already exported the full class files to `variants/variant-01/EX.class` through `variant-15/EX.class`. `variants/manifest.json` records each label, mutation, size, and class SHA-256, plus the sealed input SHA-256.

The Java 8-compatible `VerifyNeighbors.java` uses a separate `URLClassLoader` with `parent == null` for every variant, loads `EX` without initialization, resolves `nestedFin(int): int`, and reflects declared methods and constructors. It never invokes the method. The prepared runner compiles the driver with both JDKs (JDK 8 source/target and JDK 23 `--release 8`) and runs both with `-Xverify:all`. It records shell-escaped full argv, raw combined output, exit status, and SHA-256 for each javac/java command; JVM output reports the digest of every class file actually loaded.

The two installed JDK homes available for the root run are:

```sh
/Users/lordcasser/Library/Java/JavaVirtualMachines/corretto-1.8.0_432/Contents/Home
/Users/lordcasser/Library/Java/JavaVirtualMachines/openjdk-23.0.1/Contents/Home
```

Run only when ready to perform the independent JVM check:

```sh
/private/tmp/jarde-nested-fin-neighbor-verification-prep-20261017/run-verification.sh \
  --jdk8-home /Users/lordcasser/Library/Java/JavaVirtualMachines/corretto-1.8.0_432/Contents/Home \
  --jdk23-home /Users/lordcasser/Library/Java/JavaVirtualMachines/openjdk-23.0.1/Contents/Home \
  --output-dir /private/tmp/jarde-nested-fin-neighbor-verification-prep-20261017/jvm-run
```

A successful run produces `commands.txt`, individual `*.raw` files, `prepared-inputs.sha256`, and two independent `VERIFIED 15 variants` outputs. The JVM acceptance result remains pending until the root runs this script with the actual toolchains.
