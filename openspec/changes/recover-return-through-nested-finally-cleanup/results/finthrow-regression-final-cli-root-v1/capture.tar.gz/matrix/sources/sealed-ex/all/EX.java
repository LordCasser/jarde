// jarde: presentation of `EX` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class EX extends java.lang.Object {
    public EX() {
        // @method <init>()V
        // @declaration a constructor of `EX`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static java.lang.String multi(java.lang.String arg0) {
        // @method multi(Ljava/lang/String;)Ljava/lang/String;
        // @declaration a static method of `EX`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        try {
            return arg0.trim();
        } catch (java.lang.IllegalStateException | java.lang.NullPointerException local1) {
            return "multi:" + local1.getClass().getSimpleName();
        }
    }

    static int finReturn(int arg0) {
        // @method finReturn(I)I
        // @declaration a static method of `EX`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        int local1 = arg0;
        if (arg0 == 0) {
            return -1;
        } else {
            return local1;
        }
        // @bytecode 10 11 12 15 16 17 18
        // 3 live block(s) are reachable only through edges the normal-flow view leaves out: [10, 15, 17]
    }

    static java.lang.String finThrow(int arg0) {
        // @method finThrow(I)Ljava/lang/String;
        // @declaration a static method of `EX`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        try {
            if (arg0 < 0) {
                throw new java.lang.RuntimeException("neg");
            } else {
                java.lang.String local1 = "ok";
                return local1;
            }
        } finally {
            java.lang.System.out.println("ft");
        }
    }

    static int nestedFin(int arg0) {
        // @method nestedFin(I)I
        // @declaration a static method of `EX`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        try {
            int local1 = 10 / arg0;
            return local1;
        } finally {
            try {
                java.lang.System.out.println("in");
            } finally {
                java.lang.System.out.println("out");
            }
        }
    }

    public static void main(java.lang.String[] arg0) {
        // @method main([Ljava/lang/String;)V
        // @declaration a static method of `EX`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.lang.System.out.println("" + multi(" x ") + "/" + finReturn(0) + "/" + finThrow(1) + "/" + nestedFin(2));
        java.lang.System.out.println((java.lang.String) multi((java.lang.String) null));
        return;
    }
}
