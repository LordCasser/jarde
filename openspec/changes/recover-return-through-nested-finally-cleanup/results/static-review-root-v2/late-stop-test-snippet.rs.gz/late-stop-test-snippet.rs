    #[test]
    fn nested_saved_return_finally_stops_after_most_paid_proof_charges() {
        use jarde_reader::ledger::{
            LedgerEntryTiming, LedgerObserver, LedgerSite, OperationLedger, UsageOwner,
        };
        use std::sync::{
            Arc,
            atomic::{AtomicUsize, Ordering},
        };
        use std::time::Duration;

        #[derive(Debug)]
        struct Observer {
            charges: AtomicUsize,
            cancel_at: Option<usize>,
            delay_at: Option<usize>,
            token: CancellationToken,
        }
        impl LedgerObserver for Observer {
            fn entry(&self, site: LedgerSite, _: Option<LedgerEntryTiming>) {
                if !matches!(site, LedgerSite::Charge(_)) {
                    return;
                }
                let count = self.charges.fetch_add(1, Ordering::SeqCst) + 1;
                if self.cancel_at == Some(count) {
                    self.token.cancel();
                }
                if self.delay_at == Some(count) {
                    std::thread::sleep(Duration::from_millis(150));
                }
            }

            fn refusal(
                &self,
                _: LedgerSite,
                _: Option<jarde_reader::budget::BudgetDimension>,
            ) {
            }
        }

        const EX: &[u8] = include_bytes!(
            "../../../openspec/evidence/java-syntax-2026-10-05/exception-shape-family-patrol/fixture/EX.class"
        );
        probe_descriptor(EX, "nestedFin", b"(I)I", false, None, |facts| {
            let entry = facts.canonical.blocks()[0].id().clone();

            *facts.budget = Budget::new(limits());
            let baseline_observer = Arc::new(Observer {
                charges: AtomicUsize::new(0),
                cancel_at: None,
                delay_at: None,
                token: CancellationToken::new(),
            });
            let ledger = OperationLedger::new(facts.budget)
                .with_observer(baseline_observer.clone());
            facts.budget.with_ledger(ledger, UsageOwner::Methods);
            let Verdict::Claimed(plan) =
                resources(facts, &crate::pass::JAVA_8, &entry).unwrap()
            else {
                panic!("the complete nested saved-return proof claims its entry");
            };
            assert!(plan.nested_finally().is_some());
            let paid = facts.budget.usage().analysis_steps;
            let charges = baseline_observer.charges.load(Ordering::SeqCst);
            assert!(paid > 10 && charges > 11);
            assert_eq!(paid, u64::try_from(charges).unwrap());

            let mut late_limits = limits();
            late_limits.analysis_steps = paid - 1;
            *facts.budget = Budget::new(late_limits);
            assert!(matches!(
                resources(facts, &crate::pass::JAVA_8, &entry),
                Err(StopReason::Budget {
                    dimension: CountedBudgetDimension::AnalysisSteps,
                    written: 0,
                    ..
                })
            ));
            assert_eq!(facts.budget.usage().analysis_steps, paid - 1);

            let cancel_at = charges - 1;
            assert!(cancel_at > 10);
            let token = CancellationToken::new();
            *facts.budget = Budget::with_cancellation_token(limits(), token.clone());
            let cancel_observer = Arc::new(Observer {
                charges: AtomicUsize::new(0),
                cancel_at: Some(cancel_at),
                delay_at: None,
                token: token.clone(),
            });
            let ledger =
                OperationLedger::new(facts.budget).with_observer(cancel_observer.clone());
            facts.budget.with_ledger(ledger, UsageOwner::Methods);
            assert!(matches!(
                resources(facts, &crate::pass::JAVA_8, &entry),
                Err(StopReason::Cancelled { at: Some(_) })
            ));
            assert_eq!(cancel_observer.charges.load(Ordering::SeqCst), cancel_at);
            assert_eq!(facts.budget.usage().analysis_steps, cancel_at as u64);

            let mut deadline_limits = limits();
            deadline_limits.elapsed_millis = 100;
            let deadline_token = CancellationToken::new();
            *facts.budget =
                Budget::with_cancellation_token(deadline_limits, deadline_token.clone());
            let deadline_observer = Arc::new(Observer {
                charges: AtomicUsize::new(0),
                cancel_at: None,
                delay_at: Some(cancel_at),
                token: deadline_token,
            });
            let ledger =
                OperationLedger::new(facts.budget).with_observer(deadline_observer.clone());
            facts.budget.with_ledger(ledger, UsageOwner::Methods);
            assert!(matches!(
                resources(facts, &crate::pass::JAVA_8, &entry),
                Err(StopReason::Interrupted { at: Some(_), .. })
            ));
            assert_eq!(deadline_observer.charges.load(Ordering::SeqCst), cancel_at);
            assert_eq!(facts.budget.usage().analysis_steps, cancel_at as u64);
            assert!(facts.budget.usage().elapsed_millis >= 100);

            // The helper runs its ordinary first-row probe after this inspection closure.
            // Restore an open local budget so the deliberate stops above do not change that helper.
            *facts.budget = Budget::new(limits());
        })
        .unwrap();
    }
