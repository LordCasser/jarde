// Private insertion for guard::finally_copy_tests. This intentionally exercises the real
// classfile reader/CFG/SSA/certificate route; the helper asserts that each neighbor remains a
// complete canonical method before interpreting a missing nested-finally certificate as proof-level
// refusal.
//
// Separate source edit required before inserting the test: keep canonical/SSA completeness local
// to `nested_fin_no_nested_certificate` by calling the existing `probe_descriptor` there with an
// inspect closure that asserts `facts.canonical.completeness().is_complete()` and equal
// `facts.ssa.blocks().len()` / `facts.canonical.blocks().len()`. Do not alter the shared
// `examine_probe_labelled` helper or place an assertion at module scope.

fn nested_fin_code_start(class: &[u8]) -> usize {
    const PREFIX: [u8; 8] = [0x10, 0x0a, 0x1a, 0x6c, 0x3c, 0xb2, 0x00, 0x2f];
    let matches: Vec<_> = class
        .windows(PREFIX.len())
        .enumerate()
        .filter_map(|(at, bytes)| (bytes == PREFIX).then_some(at))
        .collect();
    assert_eq!(matches.len(), 1, "sealed EX.nestedFin bytecode must be unique");
    matches[0]
}

fn nested_fin_row_field(code: usize, ordinal: u16, field_offset: usize) -> usize {
    // Code: bytecode[0..72], exception_table_length at +72, rows at +74.
    // Row fields are start 0, end 2, handler 4, catch_type 6.
    code + 74 + usize::from(ordinal) * 8 + field_offset
}

fn nested_fin_no_nested_certificate(label: &str, class: &[u8]) {
    let _copy_proof = probe_descriptor(class, "nestedFin", b"(I)I", false, None, |facts| {
        assert!(facts.canonical.completeness().is_complete(), "{label}");
        assert_eq!(facts.ssa.blocks().len(), facts.canonical.blocks().len(), "{label}");
    })
    .unwrap_or_else(|stop| panic!("{label}: complete valid method stopped: {stop:?}"));
    let verdict = examine_probe_labelled(label, class, b"nestedFin", b"(I)I", None)
        .unwrap_or_else(|stop| panic!("{label}: complete valid neighbor stopped: {stop:?}"));
    assert!(
        !matches!(verdict, Verdict::Claimed(plan) if plan.nested_finally().is_some()),
        "{label}: altered lowering received the nested-finally certificate"
    );
}

fn append_extra_cleanup_handler_edge(class: &[u8]) -> Vec<u8> {
    // Add a fifth, catch-all row for the normal inner cleanup [13, 21), targeting the
    // already-valid inner exceptional-copy handler at 24. This is a verifier-valid additional
    // exceptional edge (not merely an altered row ordinal): the handler's existing stack-map
    // frame already accepts one Throwable. The nested proof must reject this unowned route.
    let mut changed = class.to_vec();
    let code = nested_fin_code_start(&changed);
    assert_eq!(u16::from_be_bytes([changed[code + 72], changed[code + 73]]), 4);
    let rows_end = code + 74 + 4 * 8;
    changed.splice(
        rows_end..rows_end,
        [
            0, 13, // start_bci = 13
            0, 21, // end_bci = 21
            0, 24, // handler_bci = 24
            0, 0, // catch-all
        ],
    );
    changed[code + 72..code + 74].copy_from_slice(&5_u16.to_be_bytes());
    // Code attribute_length is the four-byte field twelve bytes before bytecode start:
    // attribute_name_index(2), attribute_length(4), max_stack/max_locals(4), code_length(4).
    let code_attribute_length = code - 12;
    let old_length =
        u32::from_be_bytes(changed[code_attribute_length..code - 8].try_into().unwrap());
    changed[code_attribute_length..code - 8]
        .copy_from_slice(&old_length.checked_add(8).unwrap().to_be_bytes());
    changed
}

#[test]
fn nested_finally_rejects_complete_verifier_valid_classfile_neighbors() {
    const EX: &[u8] = include_bytes!(
        "../../../openspec/evidence/java-syntax-2026-10-05/exception-shape-family-patrol/fixture/EX.class"
    );
    let code = nested_fin_code_start(EX);
    let mut controls: Vec<(&str, Vec<u8>)> = Vec::new();

    // All four `out` copies matter independently. Replace each String argument with the
    // existing same-typed "in" constant, including the previously easy-to-miss BCI 49 copy.
    for (label, ldc_bci) in [
        ("normal inner out-copy argument differs", 16),
        ("inner handler out-copy argument differs", 28),
        ("outer handler out-copy argument differs", 49),
        ("nested outer-handler out-copy argument differs", 62),
    ] {
        let mut changed = EX.to_vec();
        assert_eq!(changed[code + ldc_bci], 0x12, "{label}: expected ldc");
        assert_eq!(changed[code + ldc_bci + 1], 0x3e, "{label}: expected CP #62 ('out')");
        changed[code + ldc_bci + 1] = 0x3c; // CP #60 is the same-typed String "in".
        controls.push((label, changed));
    }

    // Change one call receiver from System.out to the valid same-typed System.err field. Reuse
    // the existing `append_system_err` helper from `finally_copy_tests`; it already appends the
    // correct sealed-EX CP entries (#98..#100, Fieldref #100).
    let (mut receiver, err_field) = append_system_err(EX);
    let moved_code = nested_fin_code_start(&receiver);
    assert_eq!(receiver[moved_code + 13], 0xb2);
    receiver[moved_code + 14..moved_code + 16].copy_from_slice(&err_field.to_be_bytes());
    controls.push(("normal inner out-copy receiver differs", receiver));

    // Widen each cleanup-adjacent catch-all to a valid instruction boundary so it covers a full
    // normal `out` call. These are changed handler-coverage sets, even where canonical edges to
    // the existing handler remain coalesced at the block level.
    for (label, ordinal, old_end, new_end) in [
        ("inner row covers the normal out-copy", 0_u16, 13_u16, 21_u16),
        ("outer-cleanup row covers the normal out-copy", 2, 46, 54),
    ] {
        let mut changed = EX.to_vec();
        let end = nested_fin_row_field(code, ordinal, 2);
        assert_eq!(u16::from_be_bytes([changed[end], changed[end + 1]]), old_end);
        changed[end..end + 2].copy_from_slice(&new_end.to_be_bytes());
        controls.push((label, changed));
    }

    // The outer row no longer covers the saved-result store at BCI 4, or no longer catches every
    // Throwable. Both remain valid table entries with valid instruction boundaries/CP references.
    let mut missing_store_coverage = EX.to_vec();
    let end = nested_fin_row_field(code, 1, 2);
    assert_eq!(u16::from_be_bytes([missing_store_coverage[end], missing_store_coverage[end + 1]]), 5);
    missing_store_coverage[end..end + 2].copy_from_slice(&4_u16.to_be_bytes());
    controls.push(("outer row misses the saved-result store", missing_store_coverage));

    let mut named_outer_row = EX.to_vec();
    let catch_type = nested_fin_row_field(code, 1, 6);
    assert_eq!(u16::from_be_bytes([named_outer_row[catch_type], named_outer_row[catch_type + 1]]), 0);
    named_outer_row[catch_type..catch_type + 2].copy_from_slice(&38_u16.to_be_bytes()); // RuntimeException.
    controls.push(("outer row is not catch-all", named_outer_row));

    // Same verifier type, wrong producer: return the argument instead of the quotient saved by
    // the protected body. Both are Int, so this is a value-identity proof negative, not a bad type.
    let mut wrong_saved_value = EX.to_vec();
    assert_eq!(wrong_saved_value[code + 35], 0x1b); // iload_1, quotient saved at BCI 4.
    wrong_saved_value[code + 35] = 0x1a; // iload_0, method argument.
    controls.push(("saved return reload reads another Int producer", wrong_saved_value));

    // The three handler reloads become null before athrow. `athrow null` is verifier-valid but
    // raises a new NullPointerException instead of preserving the caught throwable identity.
    for (label, bci, expected) in [
        ("inner handler rethrows another value", 33, 0x2c),
        ("outer handler rethrows another value", 70, 0x2d),
    ] {
        let mut changed = EX.to_vec();
        assert_eq!(changed[code + bci], expected, "{label}: expected local reload");
        changed[code + bci] = 0x01; // aconst_null
        controls.push((label, changed));
    }
    let mut wrong_nested_rethrow = EX.to_vec();
    assert_eq!(&wrong_nested_rethrow[code + 67..code + 69], &[0x19, 0x04]); // aload 4
    wrong_nested_rethrow[code + 67..code + 69].copy_from_slice(&[0x01, 0x00]); // aconst_null; nop
    controls.push(("nested outer handler rethrows another value", wrong_nested_rethrow));

    // Remove one exceptional `out` invocation but retain the empty stack expected at BCI 54.
    let mut missing_static_copy = EX.to_vec();
    assert_eq!(&missing_static_copy[code + 51..code + 54], &[0xb6, 0x00, 0x37]);
    missing_static_copy[code + 51..code + 54].copy_from_slice(&[0x57, 0x57, 0x00]);
    controls.push(("outer cleanup omits one out invocation", missing_static_copy));

    // Keep the bytecode and stack maps unchanged: this adds one independent exception-table
    // route from the normal cleanup to the inner catch-copy handler, with Code attribute_length adjusted.
    controls.push((
        "extra cleanup exception edge reaches the inner handler",
        append_extra_cleanup_handler_edge(EX),
    ));

    assert_eq!(controls.len(), 15);
    for (label, changed) in controls {
        nested_fin_no_nested_certificate(label, &changed);
    }
}
