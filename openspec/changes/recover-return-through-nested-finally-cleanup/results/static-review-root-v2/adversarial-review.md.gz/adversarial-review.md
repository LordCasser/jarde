# Nested-finally candidate adversarial review

Scope: read-only review of `/private/tmp/jarde-nested-fin-impl-20261017/nested-fin-private.patch` and its candidate `guard.rs`, `region.rs`, and `build.rs`, against the sealed `EX.nestedFin(I)I` trace. No shared source or toolchain was changed or run.

## Findings

I found no concrete verifier-valid input that the certificate would accept with altered cleanup behavior, lost saved-return value, or wrong rethrow identity. The proof is bounded to four catch-all rows, six complete canonical blocks, no unreachable code, a small instruction/SSA ceiling, and a single entry block. It derives the nested row boundaries from the outer protected interval and handler binding, then requires exact row coverage and exact canonical block/edge sets. An extra CFG/exception edge therefore refuses.

The four code-copy relationships are checked as operation plus in-copy stack-producer sequences:

- Normal inner `in` body `[5,13)` equals the outer handler's nested `in` body `[38,46)`.
- Normal inner cleanup `[13,21)` equals the inner handler cleanup `[25,33)`.
- That same normal cleanup equals the outer handler's `out` cleanup `[46,54)` and the nested handler cleanup `[59,67)`.

The `cleanup_sequence` equality includes constants, field and invocation targets, and stack producer order, so each `out` copy's argument/receiver changes independently fail. The proof also checks the outer return's save/load/return SSA identity, verifies the divide result feeds the saved slot, and verifies each of the three catch bindings flows through its reload to `athrow`. Every instruction's exception-table coverage/effect handlers are compared; the throwing-site set must equal the canonical throw-site set. The self row is restricted to the nonthrowing handler binding store. The six owned blocks and all canonical edges are exact, and `explained` plus the per-block piece check account for every physical instruction.

The Builder path is coherent for this plan: the generic `leaving` edge at block 0 asks `examine`; the new proof is called from `resources` once that row set has candidates. Since the certificate is `Finally { structured: false }`, the existing structured-body branch does not consume it; the later claimed-verdict branch returns a guard with `body: None`, which is the form the Builder's nested descriptor path expects. That path checkpoints when `plan.nested_finally()` exists, writes the outer body and saved return, writes the inner `try/finally` from the two ranges, restores on failures, and attaches all proof facts to the outer origin. The inner origin anchors its first BCI directly and the remaining inner-body/cleanup BCIs derivatively.

## Remaining verification

This is static review only. In particular, the newly drafted exception-table mutation that adds a fifth valid row should be run through the real reader to confirm it retains complete canonical CFG and reaches proof-level refusal. The candidate's public recovery/API and byte-variant tests also still need execution. I found no additional defensive code change justified by the reviewed proof.
