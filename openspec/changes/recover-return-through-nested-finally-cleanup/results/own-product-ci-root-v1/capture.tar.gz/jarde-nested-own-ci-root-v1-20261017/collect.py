import sys,json,subprocess,hashlib,datetime,concurrent.futures
from pathlib import Path
repo=Path('/Users/lordcasser/workspace/projects/jarde');out=Path(sys.argv[1]);runid=sys.argv[2];product=sys.argv[3]
assert len(product)==40 and not out.exists();out.mkdir()
record={'product':product,'run_id':runid,'commands':[],'status':'collecting'}
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def command(argv,name):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();so=out/name;se=out/(name+'.stderr.raw')
 with so.open('xb') as a,se.open('xb') as b:rc=subprocess.run(argv,cwd=repo,stdout=a,stderr=b).returncode
 row={'argv':argv,'exit_code':rc,'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'streams':{'stdout':pin(so),'stderr':pin(se)}}
 assert rc==0,(argv,rc,se.read_text()[-1000:]);return row
api=command(['gh','run','view',runid,'--repo','LordCasser/jarde','--json','jobs,headSha,status,conclusion,url,databaseId,workflowName'],'run.json');record['commands'].append(api)
run=json.loads((out/'run.json').read_text());assert run['headSha']==product and run['status']=='completed' and run['conclusion']=='success'
names={'stable / test and specification':'stable','MSRV 1.88.0':'msrv','supply chain':'supply-chain','fuzz smoke':'fuzz-smoke'}
assert {j['name'] for j in run['jobs']}==names.keys()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
 futures=[executor.submit(command,['gh','run','view',runid,'--repo','LordCasser/jarde','--job',str(j['databaseId']),'--log'],names[j['name']]+'.log') for j in run['jobs']]
 for f in futures:record['commands'].append(f.result())
record['commands'].append(command(['git','show',product+':.github/workflows/ci.yml'],'ci.yml'))
(out/'workflow.sha256').write_text(hashlib.sha256((out/'ci.yml').read_bytes()).hexdigest()+'\n')
record['status']='raw collection complete, awaiting independent acceptance';(out/'collection.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'product':product,'run_id':runid,'collected_commands':len(record['commands']),'raw_streams':len(record['commands'])*2}))
