// default package

import java.io.PrintStream;

/* JADX INFO: loaded from: NestedFinally.class */
public class NestedFinally {
    static int nestedFin(int i) {
        try {
            int i2 = 10 / i;
            try {
                System.out.println("in");
                PrintStream printStream = System.out;
                return i2;
            } finally {
                System.out.println("out");
            }
        } catch (Throwable th) {
            try {
                System.out.println("in");
                throw th;
            } finally {
                System.out.println("out");
            }
        }
    }
}
