import json,hashlib,subprocess,datetime,tarfile,shutil
from pathlib import Path
r=Path('/Users/lordcasser/workspace/projects/jarde');o=Path('/private/tmp/jarde-nested-final-doc-closure-root-v1-20261017');o.mkdir();product='4c6852ac8c4ab9ce88f0716f4d2bd702e15684c5'
record={'status':'running','product':product,'commands':[]}
def write(): (o/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def command(argv):
 n=len(record['commands']);a=o/f'{n}.stdout.raw';b=o/f'{n}.stderr.raw';start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with a.open('xb') as so,b.open('xb') as se:rc=subprocess.run(argv,cwd=r,stdout=so,stderr=se).returncode
 row={'argv':argv,'cwd':str(r),'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':rc,'streams':{k:{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for k,p in [('stdout',a),('stderr',b)]}};record['commands'].append(row);write();assert rc==0,(argv,rc);return a.read_text()
clis=['/Users/lordcasser/Library/npm-global/bin/openspec','/private/tmp/jarde-parent-openspec114-tools-20261017/node_modules/.bin/openspec']
for cli,v in zip(clis,['1.11.0','1.14.0']):
 assert command([cli,'--version']).strip()==v
 assert 'Totals: 365 passed, 0 failed (365 items)' in command([cli,'validate','--all','--strict','--no-interactive'])
for name,total in [('recover-branch-throw-return-finally',5),('recover-return-through-nested-finally-cleanup',16),('recover-return-through-effectful-finally',7)]:
 x=json.loads(command([clis[0],'instructions','apply','--change',name,'--json']));assert x['progress']=={'total':total,'complete':total,'remaining':0} and x['state']=='all_done'
command(['git','diff','--check']);command(['git','diff','--exit-code',product,'--','src','crates','tests','Cargo.toml','Cargo.lock','.github/workflows/ci.yml'])
x=json.loads(Path('/private/tmp/jarde-nested-workspace-seed2-root-v1-20261017/execution.json').read_text());pins=x['source_pins'];assert len(pins)==4933
for p,digest in pins.items():assert sha(r/p)==digest,p
record['source_pin_count']=len(pins);record['source_equal_workspace_and_product']=True;record['target_absent']=not (r/'target').exists();assert record['target_absent']
base=r/'openspec/changes/recover-return-through-nested-finally-cleanup/results';record['archives_reopened']=[]
for name in ['final-local-gates-root-v3','final-matrix-root-v1','finthrow-regression-final-cli-root-v1','parent-fixed-matrix-root-v1','parent-final-gates-root-v1','workspace-seed1-root-v1','workspace-seed2-root-v1','own-product-ci-root-v1','finally-completion-refusal-controls-root-v1']:
 p=base/name/'capture.tar.gz';review=json.loads((p.parent/'root-review.json').read_text());assert p.stat().st_size==review['archive_bytes'] and sha(p)==review['archive_sha256'],name
 count=0;digest=hashlib.sha256()
 with tarfile.open(p) as t:
  for m in t.getmembers():
   if m.isfile():
    data=t.extractfile(m).read();assert len(data)==m.size;count+=1;digest.update(m.name.encode());digest.update(hashlib.sha256(data).digest())
 record['archives_reopened'].append({'name':name,'archive_sha256':sha(p),'files_read':count,'member_inventory_digest':digest.hexdigest()})
record['status']='root accepted final documentation closure';record['strict_each']=[365,0];record['progress']={'finThrow':[5,5],'nestedFin':[16,16],'parent':[7,7]};record['global_goal']='active';write()
shutil.copyfile('/private/tmp/jarde-nested-final-doc-closure-20261017.py',o/'collector.py')
for v in ('111','114'):
 for channel in ('stdout','stderr'):shutil.copyfile(f'/private/tmp/jarde-nested-closure-first-strict{v}.{channel}.raw',o/f'first-strict{v}.{channel}.raw')
d=base/'final-delivery-root-v1'
with tarfile.open(d/'capture.tar.gz','w:gz') as t:t.add(o,arcname=o.name)
p=d/'capture.tar.gz';review={'status':record['status'],'product_sha':product,'strict_versions':['1.11.0','1.14.0'],'strict_each':[365,0],'actual_final_commands':len(record['commands']),'source_pins_equal':4933,'target_absent':True,'progress':record['progress'],'archive_count_reopened':len(record['archives_reopened']),'payload_files_reopened':sum(x['files_read'] for x in record['archives_reopened']),'archive_bytes':p.stat().st_size,'archive_sha256':sha(p),'global_goal_active':True,'final_commit_clean_receipt_external':'/private/tmp/jarde-nested-final-clean-main-root-v1-20261017/execution.json'}
(d/'root-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(review))
