# FinallyCompletion whole-class refusal controls

These private scripts prepare a read-only CLI/source and compiler check for the two frozen `FinallyCompletion.class` inputs. The runner reuses `recover-return-through-nested-finally-cleanup/tools/compare.py` for the exact pinned JDK manifest/tools, sanitized environment, command guard, and evidence pin format. It uses the same `single-class`, release 8, JSON class-source request and compiler flags. The candidate CLI is pinned to SHA-256 `4811eea2d7f52d4c1b818c86acc1d961c91e3d7fe9d5adaa2c53131f84140f8e`; both full class inputs are checked against `/private/tmp/jarde-finallycompletion-reject-control-20261017/pins.json` before byte-for-byte copying into the evidence directory.

For each input (`javac8`, `javac23`) the runner captures default and all class-source JSON, writes the embedded whole-class `text` without edits, then compiles each emitted source with javac 8 and javac 23. It retains all methods. Acceptance uses the established full-class JSON schema: constructor, `mark`, `normalReturn`, `finallyReturns`, `finallyThrows`, `tryThrowsFinallyRuns`, and `<clinit>`. The three refusal methods must remain fallback with the recorded reasons:

* `finallyReturns()I`: `jre_region_exception_edge`, `jre_region_uncovered_blocks`
* `finallyThrows()I`: `jre_region_exception_edge`, `jre_region_uncovered_blocks`
* `tryThrowsFinallyRuns()I`: `jre_guard_finally_copy`, `jre_region_uncovered_blocks`

Each of the eight compiler invocations must fail with exactly three `missing return statement` errors, mapped to those three method regions. No Java runtime command is issued. The target directory is left in place, and no Cargo command is issued. Command argv, raw stdout/stderr, exit codes, and hashes are recorded by the existing guarded runner. Input, generated JSON, emitted source, class output (if any), tool and source pins are retained or checked.

The method schema and fallback reasons are from the existing `FinallyCompletion` source matrix at `openspec/changes/recover-proved-finally-cleanup/results/finally-final-gates-root-v2/manifest.json` (javac8/javac23 `jarde` rows), not inferred from method names.

After root authorizes the run, use a new output directory:

```sh
python3 /private/tmp/jarde-finallycompletion-control-runner-20261017/run_controls.py \
  --out /private/tmp/jarde-finallycompletion-control-runner-20261017/run-<unique-id>
python3 /private/tmp/jarde-finallycompletion-control-runner-20261017/accept_controls.py \
  /private/tmp/jarde-finallycompletion-control-runner-20261017/run-<unique-id>
```

The scripts have not been run. `accept_controls.py` reads only the resulting evidence and prints an independent acceptance report.
