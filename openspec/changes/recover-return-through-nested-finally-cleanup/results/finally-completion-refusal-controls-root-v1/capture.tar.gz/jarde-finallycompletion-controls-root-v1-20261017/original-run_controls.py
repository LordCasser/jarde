#!/usr/bin/env python3
"""Run the pinned FinallyCompletion default/all refusal controls; never edits source inputs."""
from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

ROOT_DEFAULT = Path('/Users/lordcasser/workspace/projects/jarde')
CONTROL_DIR = Path('/private/tmp/jarde-finallycompletion-reject-control-20261017')
EXPECTED_CLI_SHA256 = '4811eea2d7f52d4c1b818c86acc1d961c91e3d7fe9d5adaa2c53131f84140f8e'
EXPECTED_INPUTS = {
    'javac8': {'bytes': 907, 'sha256': '49e649478c3d45ba6486029778a8415239caafdd93234a1d5956f5ccf3031393'},
    'javac23': {'bytes': 907, 'sha256': '2b8902d998065d2d1747abaeba386e006cdf5ff7f1311abb28506e8d8dc0cc94'},
}


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load module: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', required=True, type=Path, help='new evidence directory; must not exist')
    parser.add_argument('--cli', type=Path, default=Path('/private/tmp/jarde-nested-local-gates-root-v3-20261017/candidate-cli'))
    parser.add_argument('--root', type=Path, default=ROOT_DEFAULT)
    parser.add_argument('--controls', type=Path, default=CONTROL_DIR)
    parser.add_argument('--compare', type=Path, default=ROOT_DEFAULT / 'openspec/changes/recover-return-through-nested-finally-cleanup/tools/compare.py')
    args = parser.parse_args()

    root = args.root.resolve(strict=True)
    out = args.out.resolve()
    if out.exists():
        raise SystemExit(f'refusing to overwrite evidence directory: {out}')
    if (root / 'Cargo.toml').is_file() is False:
        raise SystemExit(f'repository root not found: {root}')
    cli = args.cli.resolve(strict=True)
    controls = args.controls.resolve(strict=True)
    compare_path = args.compare.resolve(strict=True)
    pins_path = controls / 'pins.json'
    pins = json.loads(pins_path.read_text(encoding='utf-8'))
    cli_sha = hashlib.sha256(cli.read_bytes()).hexdigest()
    if cli_sha != EXPECTED_CLI_SHA256:
        raise SystemExit(f'candidate CLI SHA-256 mismatch: {cli_sha}')
    for name, expected in EXPECTED_INPUTS.items():
        entry = pins.get('classes', {}).get(name, {})
        class_path = (controls / name / 'FinallyCompletion.class').resolve(strict=True)
        digest = hashlib.sha256(class_path.read_bytes()).hexdigest()
        if (entry.get('output') != str(class_path) or entry.get('bytes') != expected['bytes']
                or entry.get('sha256') != expected['sha256'] or digest != expected['sha256']
                or class_path.stat().st_size != expected['bytes']):
            raise SystemExit(f'{name} refusal-control class does not match pins.json and expected SHA')

    compare = load_module(compare_path, 'nested_finally_compare_for_controls')
    guard_path = compare.GUARD_PATH.resolve(strict=True)
    scanner_path = compare.SCANNER_PATH.resolve(strict=True)
    if compare.sha_file(guard_path) != compare.GUARD_SHA256:
        raise SystemExit('nested comparison guard SHA-256 mismatch')
    if compare.sha_file(scanner_path) != compare.SCANNER_SHA256:
        raise SystemExit('nested target scanner SHA-256 mismatch')
    guard = load_module(guard_path, 'durable_root_guard_for_finallycompletion')
    scanner = load_module(scanner_path, 'durable_target_scanner_for_finallycompletion')
    guard.ROOT = root
    guard.OUT = out / 'raw'
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = lambda path: compare.pin(path)
    guard.expected_test_summaries = lambda index, stdout_bytes: None
    guard.OUT.mkdir(parents=True)

    jdks, jdk_manifest_record = compare.configured_jdks(
        compare.DEFAULT_JDK_MANIFEST, compare.DEFAULT_JDK_MANIFEST_SHA256)
    env_base = compare.environment(dict(os.environ))

    # Copy only the two frozen inputs, byte-for-byte, so all CLI commands consume the
    # exact classfiles recorded in this self-contained evidence directory.
    input_pins = {}
    for name in ('javac8', 'javac23'):
        source = controls / name / 'FinallyCompletion.class'
        dest = out / 'inputs' / name / 'FinallyCompletion.class'
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, dest)
        input_pins[name] = compare.pin(dest)

    static_paths = [Path(__file__).resolve(), Path(__file__).with_name('accept_controls.py').resolve(),
                    compare_path, guard_path, scanner_path, pins_path, cli,
                    compare.DEFAULT_JDK_MANIFEST.resolve(strict=True)]
    static_paths.extend(path for leg in jdks.values() for path in leg['tools'].values())
    static_before = {str(path.resolve()): compare.pin(path.resolve(strict=True)) for path in static_paths}
    source_before = compare.source_inputs(root, guard)
    jdk_before = {str(path): compare.pin(path) for leg in jdks.values() for path in leg['tools'].values()}

    results = {
        'schema': 'finallycompletion-refusal-controls-v1',
        'status': 'running',
        'product_cli': compare.pin(cli),
        'expected_product_cli_sha256': EXPECTED_CLI_SHA256,
        'inputs': input_pins,
        'input_pins_manifest': compare.pin(pins_path),
        'compare_tool': compare.pin(compare_path),
        'guard': compare.pin(guard_path),
        'scanner': compare.pin(scanner_path),
        'jdk_manifest': jdk_manifest_record,
        'source_pins_before': source_before,
        'static_inputs_before': static_before,
        'jdk_tools_before': jdk_before,
        'commands': [],
        'matrix': [],
        'expectations': {
            'complete_method_schema': [
                ['<init>', '()V'], ['mark', '(I)I'], ['normalReturn', '()I'],
                ['finallyReturns', '()I'], ['finallyThrows', '()I'],
                ['tryThrowsFinallyRuns', '()I'], ['<clinit>', '()V'],
            ],
            'refusal_methods': {
                'finallyReturns()I': ['jre_region_exception_edge', 'jre_region_uncovered_blocks'],
                'finallyThrows()I': ['jre_region_exception_edge', 'jre_region_uncovered_blocks'],
                'tryThrowsFinallyRuns()I': ['jre_guard_finally_copy', 'jre_region_uncovered_blocks'],
            },
            'compile': 'each default/all complete class source is compiled unchanged with javac8 and javac23; expected exactly three missing-return errors, with no runtime command',
        },
        'notes': [
            'Commands use the nested comparator guard.run_command, JDK manifest pins, and sanitized environment policy.',
            'The existing Cargo target directory is neither cleaned nor used; no Cargo command is issued.',
            'Full class-source JSON stdout and the exact embedded whole-class source text are both retained.',
        ],
    }
    write_json(out / 'execution.json', results)

    def command(label: str, argv: list[str], env: dict[str, str], phase: str) -> dict:
        row = guard.run_command(len(results['commands']) + 1, argv, env)
        row['label'] = label
        row['phase'] = phase
        row['environment_policy'] = {
            'removed': list(compare.STRIPPED_ENV),
            'java_home': env.get('JAVA_HOME'),
            'path_prefix': (str(Path(env['JAVA_HOME']) / 'bin') if env.get('JAVA_HOME') else None),
        }
        results['commands'].append(row)
        write_json(out / 'execution.json', results)
        if row.get('guard_stop') is not None:
            raise RuntimeError(f'guard_stop on command {row["index"]}: {row["guard_stop"]}')
        return row

    def raw(row: dict, channel: str) -> bytes:
        return Path(row['streams'][channel]['path']).read_bytes()

    for input_name in ('javac8', 'javac23'):
        class_file = out / 'inputs' / input_name / 'FinallyCompletion.class'
        cells = {}
        for evidence in ('default', 'all'):
            argv = [str(cli), 'class-source', '--input', str(class_file), '--class', 'FinallyCompletion',
                    '--policy', 'single-class', '--release', '8', '--format', 'json']
            if evidence == 'all':
                argv.extend(['--evidence', 'all'])
            row = command(f'source-{input_name}-{evidence}', argv, env_base, 'class-source-json')
            if row['exit_code'] != 0:
                raise RuntimeError(f'{input_name}/{evidence} class-source failed: exit {row["exit_code"]}')
            output = raw(row, 'stdout')
            try:
                document = json.loads(output.decode('utf-8'))
                source_text = document['text']
                if not isinstance(source_text, str):
                    raise TypeError('top-level text is not a string')
            except Exception as error:
                raise RuntimeError(f'{input_name}/{evidence} invalid class-source JSON: {type(error).__name__}: {error}')
            json_path = out / 'sources' / input_name / f'{evidence}.json'
            text_path = out / 'sources' / input_name / evidence / 'FinallyCompletion.java'
            json_path.parent.mkdir(parents=True, exist_ok=True)
            text_path.parent.mkdir(parents=True, exist_ok=True)
            json_path.write_bytes(output)
            text_path.write_bytes(source_text.encode('utf-8'))
            cell = {
                'input': input_name,
                'evidence': evidence,
                'class_source_command': row['index'],
                'json_artifact': compare.pin(json_path),
                'whole_source': compare.pin(text_path),
                'compile_commands': [],
            }
            results['matrix'].append(cell)
            cells[evidence] = (document, text_path, cell)
            write_json(out / 'execution.json', results)

        # Compile the byte-for-byte class-source text as emitted for each compiler and profile.
        for evidence in ('default', 'all'):
            document, source_path, cell = cells[evidence]
            for build_leg in ('javac8', 'javac23'):
                compile_root = out / 'compile' / input_name / evidence / build_leg
                classes = compile_root / 'classes'
                empty_cp = compile_root / 'empty-classpath-sourcepath'
                classes.mkdir(parents=True)
                empty_cp.mkdir(parents=True)
                javac = jdks[build_leg]['tools']['javac']
                if build_leg == 'javac8':
                    flags = ['-source', '8', '-target', '8', '-g:none', '-Xlint:-options', '-proc:none']
                else:
                    flags = ['--release', '8', '-g:none', '-proc:none']
                argv = [str(javac), *flags, '-classpath', str(empty_cp), '-sourcepath', str(empty_cp),
                        '-d', str(classes), str(source_path)]
                row = command(f'compile-{input_name}-{evidence}-with-{build_leg}', argv,
                              compare.environment(env_base, jdks[build_leg]), 'unchanged-whole-source-compile')
                class_output = classes / 'FinallyCompletion.class'
                compile_record = {
                    'compiler': build_leg,
                    'command': row['index'],
                    'exit_code': row['exit_code'],
                    'class_output': compare.pin(class_output) if class_output.is_file() else None,
                    'stdout': row['streams']['stdout'],
                    'stderr': row['streams']['stderr'],
                }
                cell['compile_commands'].append(compile_record)
                write_json(out / 'execution.json', results)

    results['source_pins_after'] = compare.source_inputs(root, guard)
    results['static_inputs_after'] = {str(path.resolve()): compare.pin(path.resolve(strict=True))
                                      for path in static_paths}
    results['jdk_tools_after'] = {str(path): compare.pin(path) for leg in jdks.values() for path in leg['tools'].values()}
    results['source_pins_unchanged'] = results['source_pins_before'] == results['source_pins_after']
    results['static_inputs_unchanged'] = results['static_inputs_before'] == results['static_inputs_after']
    results['jdk_tools_unchanged'] = results['jdk_tools_before'] == results['jdk_tools_after']
    results['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    results['status'] = 'commands_complete_pending_read_only_acceptance'
    write_json(out / 'execution.json', results)
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f'FinallyCompletion control runner failed: {type(error).__name__}: {error}', file=sys.stderr)
        raise SystemExit(1)
