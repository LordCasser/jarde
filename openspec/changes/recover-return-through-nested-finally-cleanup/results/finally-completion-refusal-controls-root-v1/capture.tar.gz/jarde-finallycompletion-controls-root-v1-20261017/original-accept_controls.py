#!/usr/bin/env python3
"""Read-only acceptance of the captured FinallyCompletion CLI/compiler refusal controls."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

EXPECTED_CLI_SHA256 = '4811eea2d7f52d4c1b818c86acc1d961c91e3d7fe9d5adaa2c53131f84140f8e'
EXPECTED_INPUTS = {
    'javac8': {'bytes': 907, 'sha256': '49e649478c3d45ba6486029778a8415239caafdd93234a1d5956f5ccf3031393'},
    'javac23': {'bytes': 907, 'sha256': '2b8902d998065d2d1747abaeba386e006cdf5ff7f1311abb28506e8d8dc0cc94'},
}
EXPECTED_METHODS = [
    ('<init>', '()V'), ('mark', '(I)I'), ('normalReturn', '()I'),
    ('finallyReturns', '()I'), ('finallyThrows', '()I'),
    ('tryThrowsFinallyRuns', '()I'), ('<clinit>', '()V'),
]
EXPECTED_FALLBACKS = {
    ('finallyReturns', '()I'): ['jre_region_exception_edge', 'jre_region_uncovered_blocks'],
    ('finallyThrows', '()I'): ['jre_region_exception_edge', 'jre_region_uncovered_blocks'],
    ('tryThrowsFinallyRuns', '()I'): ['jre_guard_finally_copy', 'jre_region_uncovered_blocks'],
}
MISSING_RETURN = re.compile(r'(?m)^.*FinallyCompletion\.java:(\d+): error: missing return statement\s*$')


def need(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def file_pin(row: dict, label: str) -> bytes:
    path = Path(row['path']).resolve(strict=True)
    data = path.read_bytes()
    need(len(data) == row['bytes'] and sha(data) == row['sha256'], f'{label} bytes/hash mismatch: {path}')
    return data


def method_schema(document: dict, label: str) -> dict:
    methods = document.get('methods')
    need(isinstance(methods, list), f'{label}: class-source JSON has no methods array')
    actual = []
    rows = {}
    for member in methods:
        item = member.get('item', {})
        name = item.get('name', {}).get('escaped')
        descriptor = item.get('descriptor', {}).get('escaped')
        identity = (name, descriptor)
        actual.append(identity)
        rows[identity] = member
    need(actual == EXPECTED_METHODS, f'{label}: whole-class member schema changed: {actual!r}')
    result = {}
    for identity in EXPECTED_METHODS:
        member = rows[identity]
        outcome = member.get('outcome', {})
        report = outcome.get('report', {})
        result[f'{identity[0]}{identity[1]}'] = {
            'kind': outcome.get('kind'),
            'quality': report.get('quality'),
            'fallbacks': report.get('fallbacks'),
        }
        need(outcome.get('kind') == 'recovered', f'{label}: {identity} not represented in complete class output')
        if identity in EXPECTED_FALLBACKS:
            need(report.get('quality') == 'fallback', f'{label}: {identity} ceased to be a fallback')
            need(report.get('fallbacks') == EXPECTED_FALLBACKS[identity],
                 f'{label}: {identity} fallback schema changed: {report.get("fallbacks")!r}')
            text = member.get('text', '')
            need(f'// @method {identity[0]}{identity[1]}' in text,
                 f'{label}: {identity} source marker missing')
        else:
            need(report.get('quality') == 'structured' and report.get('fallbacks') == [],
                 f'{label}: unrelated member {identity} changed from its baseline structure')
    return result


def source_error_methods(source: str, stderr: bytes, stdout: bytes, label: str) -> list[str]:
    output = (stdout + b'\n' + stderr).decode('utf-8', errors='replace')
    errors = re.findall(r'(?m)^.*\berror:\s*(.*?)\s*$', output)
    need(len(errors) == 3, f'{label}: expected exactly 3 compiler errors, found {errors!r}')
    need(all(error == 'missing return statement' for error in errors),
         f'{label}: unexpected diagnostic(s): {errors!r}')
    lines = source.splitlines()
    markers = []
    for index, line in enumerate(lines, 1):
        match = re.search(r'//\s*@method\s+([^\s]+)', line)
        if match:
            markers.append((index, match.group(1)))
    need(len(markers) == len(EXPECTED_METHODS), f'{label}: missing/duplicate method origin markers')
    reported = []
    for match in MISSING_RETURN.finditer(output):
        line_number = int(match.group(1))
        previous = [entry for entry in markers if entry[0] <= line_number]
        need(previous, f'{label}: compiler error line {line_number} is before all method markers')
        marker = previous[-1][1]
        reported.append(marker)
    need(len(reported) == 3, f'{label}: could not map all compiler errors to method markers: {reported!r}')
    need(sorted(reported) == sorted(['finallyReturns()I', 'finallyThrows()I', 'tryThrowsFinallyRuns()I']),
         f'{label}: missing-return errors do not map exactly to refusal controls: {reported!r}')
    return reported


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run_dir', type=Path, help='evidence directory created by run_controls.py')
    args = parser.parse_args()
    run_dir = args.run_dir.resolve(strict=True)
    execution = json.loads((run_dir / 'execution.json').read_text(encoding='utf-8'))
    need(execution.get('schema') == 'finallycompletion-refusal-controls-v1', 'unexpected evidence schema')
    need(execution.get('status') == 'commands_complete_pending_read_only_acceptance',
         f'unexpected runner status: {execution.get("status")!r}')
    need(execution.get('expected_product_cli_sha256') == EXPECTED_CLI_SHA256,
         'runner did not bind the requested candidate CLI SHA')
    need(execution.get('product_cli', {}).get('sha256') == EXPECTED_CLI_SHA256,
         'candidate CLI hash mismatch')
    need(execution.get('source_pins_unchanged') is True
         and execution.get('static_inputs_unchanged') is True
         and execution.get('jdk_tools_unchanged') is True,
         'source, static input, or JDK tool pins changed during the runner')

    for name, expected in EXPECTED_INPUTS.items():
        row = execution.get('inputs', {}).get(name, {})
        data = file_pin(row, f'{name} copied input')
        need(len(data) == expected['bytes'] and sha(data) == expected['sha256'],
             f'{name} copied class differs from its archive-bound pin')

    commands = execution.get('commands')
    need(isinstance(commands, list) and len(commands) == 12,
         f'expected 4 class-source and 8 compiler commands, found {len(commands) if isinstance(commands, list) else None}')
    labels = [row.get('label') for row in commands]
    expected_labels = []
    for name in ('javac8', 'javac23'):
        for evidence in ('default', 'all'):
            expected_labels.append(f'source-{name}-{evidence}')
    for name in ('javac8', 'javac23'):
        for evidence in ('default', 'all'):
            for build in ('javac8', 'javac23'):
                expected_labels.append(f'compile-{name}-{evidence}-with-{build}')
    need(set(labels) == set(expected_labels) and len(labels) == len(set(labels)),
         f'command inventory differs from the 2x2x2 matrix: {labels!r}')
    for row in commands:
        argv = row.get('argv', [])
        need(argv and Path(argv[0]).name not in ('java', 'java.exe'),
             f'unexpected runtime command in refusal control: {row.get("label")} {argv!r}')
        for channel in ('stdout', 'stderr'):
            file_pin(row['streams'][channel], f'{row.get("label")} {channel}')

    matrix = execution.get('matrix')
    need(isinstance(matrix, list) and len(matrix) == 4, 'expected exactly four class-source artifacts')
    source_rows = {}
    for cell in matrix:
        input_name, evidence = cell.get('input'), cell.get('evidence')
        need(input_name in EXPECTED_INPUTS and evidence in ('default', 'all'),
             f'invalid matrix coordinate: {cell!r}')
        coordinate = (input_name, evidence)
        need(coordinate not in source_rows, f'duplicate source matrix coordinate: {coordinate!r}')
        source_json = file_pin(cell['json_artifact'], f'{coordinate} complete class-source JSON')
        source = file_pin(cell['whole_source'], f'{coordinate} complete whole-class source')
        document = json.loads(source_json.decode('utf-8'))
        need(document.get('text', '').encode('utf-8') == source,
             f'{coordinate}: saved Java source is not byte-for-byte the JSON whole-source text')
        method_records = method_schema(document, str(coordinate))
        source_rows[coordinate] = {'source': source, 'document': document, 'methods': method_records,
                                   'json_artifact': cell['json_artifact'],
                                   'whole_source': cell['whole_source']}
        need(len(cell.get('compile_commands', [])) == 2, f'{coordinate}: missing compiler legs')

    for input_name in ('javac8', 'javac23'):
        default = source_rows[(input_name, 'default')]['source']
        all_evidence = source_rows[(input_name, 'all')]['source']
        need(default == all_evidence, f'{input_name}: default/all changed complete generated source')

    compile_reports = []
    for cell in matrix:
        input_name, evidence = cell['input'], cell['evidence']
        source_meta = source_rows[(input_name, evidence)]
        source_text = source_meta['source'].decode('utf-8')
        by_compiler = {row.get('compiler'): row for row in cell['compile_commands']}
        need(set(by_compiler) == {'javac8', 'javac23'}, f'{input_name}/{evidence}: wrong compiler inventory')
        for build_leg, row in by_compiler.items():
            need(row.get('exit_code') != 0, f'{input_name}/{evidence}/{build_leg}: unexpected successful compilation')
            need(row.get('class_output') is None,
                 f'{input_name}/{evidence}/{build_leg}: compiler emitted a complete FinallyCompletion.class')
            command_row = next(item for item in commands if item.get('index') == row.get('command'))
            need(command_row.get('exit_code') == row.get('exit_code'), 'compile exit code disagrees with command record')
            stdout = Path(command_row['streams']['stdout']['path']).read_bytes()
            stderr = Path(command_row['streams']['stderr']['path']).read_bytes()
            missing_methods = source_error_methods(source_text, stderr, stdout,
                                                   f'{input_name}/{evidence}/{build_leg}')
            compile_reports.append({
                'input': input_name, 'evidence': evidence, 'compiler': build_leg,
                'exit_code': row['exit_code'], 'missing_return_methods': missing_methods,
                'stdout_sha256': command_row['streams']['stdout']['sha256'],
                'stderr_sha256': command_row['streams']['stderr']['sha256'],
            })

    report = {
        'status': 'accepted',
        'product_cli_sha256': execution['product_cli']['sha256'],
        'input_sha256': {name: EXPECTED_INPUTS[name]['sha256'] for name in EXPECTED_INPUTS},
        'class_source_cells': [
            {'input': name, 'evidence': evidence,
             'json_sha256': source_rows[(name, evidence)]['json_artifact']['sha256'],
             'whole_source_sha256': source_rows[(name, evidence)]['whole_source']['sha256'],
             'methods': source_rows[(name, evidence)]['methods']}
            for name in ('javac8', 'javac23') for evidence in ('default', 'all')
        ],
        'compile_matrix': compile_reports,
        'runtime_commands': 0,
        'target_cleaned': False,
        'cargo_commands': 0,
        'source_pins_unchanged': True,
        'static_inputs_unchanged': True,
        'jdk_tools_unchanged': True,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as error:
        print(f'FinallyCompletion control acceptance failed: {type(error).__name__}: {error}', file=sys.stderr)
        raise SystemExit(1)
