// jarde: presentation of `NestedFinally` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
public class NestedFinally extends java.lang.Object {
    public NestedFinally() {
        // @method <init>()V
        // @declaration a constructor of `NestedFinally`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    static int nestedFin(int arg0) {
        // @method nestedFin(I)I
        // @declaration a static method of `NestedFinally`, member flags 0x0008
        // recovered from bytecode; presentation is not claimed to compile
        try {
            int local1 = 10 / arg0;
            return local1;
        } finally {
            try {
                java.lang.System.out.println("in");
            } finally {
                java.lang.System.out.println("out");
            }
        }
    }
}
