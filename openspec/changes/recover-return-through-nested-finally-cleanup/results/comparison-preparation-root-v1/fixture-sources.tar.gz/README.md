# Nested finally comparison preparation

This private package prepares a replayable comparison for `EX.nestedFin(I)I`. It does not change the shared repository and was prepared without running Git, Cargo, javac, java, javap, or JADX.

`NestedFinally.java` is an independent default-package class containing only an explicit public constructor and the exact `nestedFin` body copied from the pinned complete `EX.java`. `NestedFinallyDriver.java` is copied from the supplied 18-case driver and prints the actual throwable message while asserting injected exception object identity. It verifies both cleanup calls happen once and in `IO` order, the returned value or escaping throwable, and the exact injected type/message/identity for each case. One unchanged driver source is compiled separately against each original class.

`nested-compare.py` is adapted from the shared `recover-branch-throw-return-finally/tools/compare.py` runner. It accepts the CLI executable and its successful build receipt as arguments, verifies the CLI path and SHA binding, checks the durable root guard/scanner and JDK manifest pins, and serializes every command. It calls `class-source --input CLASS --class NestedFinally|EX --policy single-class --release 8 --format json` for default and `--evidence all`; it keeps complete JSON and source text. For each committed target compiler input it records `javap` instructions and exception rows, compiles the untouched source emitted by Jarde with both pinned compilers, and runs each successful rebuild on JDK 8 and JDK 23 against the same-runtime original output. The Jarde matrix has 16 compiler/profile/recompiler/runtime combinations and four runtime comparisons per input/profile (two recompilers × two JVMs), and two comparisons per recompiler. The driver output is validated before comparing output hashes.

JADX generation uses one thread, no resources, no config, and rename flags disabled. A failed JADX generation or partial runtime is recorded and does not abort the matrix; successful emitted source is compiled untouched with both compilers and compared with the same driver where the default-package class can link. A malformed successful JADX driver result is recorded as invalid evidence rather than treated as a matrix-level exception. Sealed `EX.java` retains every original method. The runner compiles the unchanged full source with both compilers and separately compiles `EXNestedFinallyDriver` against each original EX class in a driver directory that must not contain `EX.class`; it records JDK 8/23 runtime oracles for both source-compiler legs. If untouched Jarde or JADX full-class source compiles, it runs the same 18 nestedFin cases against the matching same-compiler original oracle. Full-class runtime behavior is not used to claim coverage of unrelated methods. It captures Jarde default/all complete-class source, compares their text identity, and preserves generated-source compile failures. In recovered mode, both untouched Jarde full-class sources must compile with both compilers and match the original nestedFin driver output; no condition requires unrelated `finReturn` source to be structured or its fallback comments to be removed.

Example invocation after the root has installed the fixture classes and built the CLI:

```sh
python3 /private/tmp/jarde-nested-fin-matrix-prep-20261017/nested-compare.py \
  --out /private/tmp/nested-fin-observed-20261017 \
  --cli /path/to/jarde \
  --cli-receipt /path/to/cli-receipt.json \
  --jadx /path/to/jadx \
  --jadx-sha256 SHA256 \
  --jadx-jar /path/to/jadx.jar \
  --jadx-jar-sha256 SHA256 \
  --expect observed
```

Use `--expect recovered` for final acceptance. The two target `.class` paths and fixture source/driver default to `tests/fixtures/recover-return-through-nested-finally-cleanup/{v8/NestedFinally.class,v8-javac8/NestedFinally.class,NestedFinally.java,NestedFinallyDriver.java}`; all are overridable with `--javac23-class`, `--javac8-class`, `--nested-source`, and `--driver-source`. The sealed EX source/class default to this package's pinned `sealed/EX.java` and `sealed/EX.class`. Output must be a new path. In observed mode, a failed or missing sealed-EX source extraction yields `observed_source_failure_pending_review`, so the run is not reported as complete. The runner requires the repository `target/` to be absent before and after, runs commands serially through the existing one-second/5-GiB/1-GiB guard, and records a pending-review report rather than claiming independent acceptance.

See `pins.json` for the fixed manifest, guard, scanner, JDK, sealed EX, and private artifact hashes. The CLI receipt, CLI binary, JADX executable, and JADX JAR are intentionally external runtime arguments so the same runner can be used for the baseline and the final build.
