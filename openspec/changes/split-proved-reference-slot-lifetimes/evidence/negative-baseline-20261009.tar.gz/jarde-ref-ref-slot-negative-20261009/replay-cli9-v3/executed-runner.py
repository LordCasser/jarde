import hashlib,json,shutil,subprocess
from pathlib import Path
ROOT=Path('/private/tmp/jarde-ref-ref-slot-negative-20261009')
WORK=ROOT/'replay-cli9-v3'
WORK.mkdir(exist_ok=True)
JDK=Path('/Library/Java/JavaVirtualMachines/openjdk-23.0.1/Contents/Home/bin')
CLI=Path('/private/tmp/jarde-generic-calls-candidate-v9-cli')
REPO=Path('/Users/lordcasser/workspace/projects/jarde')
CASES={
 'same-type':('V2',REPO/'tests/fixtures/p3-array-slot-retype-locals/v8/V2.class',REPO/'openspec/evidence/java-syntax-2026-10-01/em17-slot-reuse-patrol/variants/retype-V2.source.java'),
 'cross-phi':('V3',REPO/'tests/fixtures/p3-array-slot-retype-locals/v8/V3.class',REPO/'openspec/evidence/java-syntax-2026-10-01/em17-slot-reuse-patrol/variants/retype-V3.source.java'),
 'cfg-loop-phi':('V4',REPO/'tests/fixtures/p3-array-slot-retype-locals/v8/V4.class',REPO/'openspec/evidence/java-syntax-2026-10-01/em17-slot-reuse-patrol/variants/retype-V4.source.java'),
 'handler':('SlotReuseBoundaries',None,REPO/'openspec/changes/separate-reused-local-lifetimes/evidence/fixtures/SlotReuseBoundaries.java'),
 'parameter-header':('ParameterHeader',None,ROOT/'new-fixtures/ParameterHeader/ParameterHeader.java'),
 'unknown-null':('NullThenBuilder',None,ROOT/'new-fixtures/NullThenBuilder/NullThenBuilder.java'),
 'held-use':('HeldUse',None,ROOT/'new-fixtures/HeldUse/HeldUse.java'),
 'cfg-backedge-disjoint':('RefLoopBack',None,ROOT/'new-fixtures/RefLoopBack/RefLoopBack.java'),
}
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
records=[]
def run(label, argv, cwd, outp, errp):
 p=subprocess.run([str(x) for x in argv],cwd=str(cwd),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 Path(outp).write_bytes(p.stdout); Path(errp).write_bytes(p.stderr)
 records.append({'label':label,'argv':[str(x) for x in argv],'cwd':str(cwd),'exit':p.returncode,'stdout':str(outp),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr':str(errp),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()})
 if p.returncode!=0: raise SystemExit(f'{label} exited {p.returncode}; see {outp} and {errp}')
 return p
for family,(name,original_class,source) in CASES.items():
 d=WORK/family; d.mkdir(parents=True,exist_ok=True)
 src=d/f'{name}.java'; shutil.copyfile(source,src)
 runner_src=None
 if name=='SlotReuseBoundaries':
  runner_src=d/'SlotReuseBoundariesRunner.java'; shutil.copyfile(REPO/'openspec/changes/separate-reused-local-lifetimes/evidence/fixtures/SlotReuseBoundariesRunner.java',runner_src)
 classes=d/'classes'; classes.mkdir(exist_ok=True)
 empty_cp=d/'empty-classpath';empty_cp.mkdir(exist_ok=True)
 empty_sp=d/'empty-sourcepath';empty_sp.mkdir(exist_ok=True)
 if original_class:
  cls=classes/f'{name}.class';shutil.copyfile(original_class,cls)
 else:
  cls=classes/f'{name}.class'
  compile_sources=[src] + ([runner_src] if runner_src else [])
  run('javac-'+family,[JDK/'javac','--release','8','-g:none','-Xlint:-options','-classpath',empty_cp,'-sourcepath',empty_sp,'-d',classes,*compile_sources],d,d/'javac.stdout',d/'javac.stderr')
 # Keep bytecode inspection as a separate raw process with both streams.
 run('javap-'+family,[JDK/'javap','-p','-c','-l','-v','-classpath',classes,name],d,d/'javap.txt',d/'javap.stderr')
 run_class='SlotReuseBoundariesRunner' if runner_src else name
 run('original-Xverify-'+family,[JDK/'java','-Xverify:all','-cp',classes,run_class],d,d/'original.stdout',d/'original.stderr')
 jar=d/f'{name}.jar'
 run('jar-'+family,[JDK/'jar','cf',jar,'-C',classes,'.'],d,d/'jar.stdout',d/'jar.stderr')
 cliout=d/'cli9.stdout';clierr=d/'cli9.stderr'
 before=sha(CLI)
 p=run('cli9-class-source-'+family,[CLI,'class-source','--input',jar,'--class',name,'--policy','plain-jar','--format','json','--evidence','all','--release','8'],d,cliout,clierr)
 after=sha(CLI)
 try:
  report=json.loads(p.stdout)
  (d/'report.json').write_bytes(p.stdout)
  text=report.get('text')
  if text is not None: (d/f'{name}.jarde.java').write_text(text)
 except Exception as e:
  raise SystemExit(f'cannot parse CLI JSON for {family}: {e}')
 records[-1]['cli_sha256_before']=before;records[-1]['cli_sha256_after']=after
 records[-1]['report_outcome']=report.get('outcome')
 records[-1]['class_sha256']=sha(cls);records[-1]['jar_sha256']=sha(jar);records[-1]['source_sha256']=sha(src)
 records[-1]['report_sha256']=sha(d/'report.json')
manifest={'cli':str(CLI),'cli_sha256_pre':sha(CLI),'cli_sha256_post':sha(CLI),'jdk_bin':str(JDK),'jdk_hashes':{n:sha(JDK/n) for n in ('javac','java','javap','jar')},'commands':records,'cases':{}}
for family,(name,_,_) in CASES.items():
 d=WORK/family
 manifest['cases'][family]={'class_name':name,'source':str(d/f'{name}.java'),'source_sha256':sha(d/f'{name}.java'),'class':str(d/'classes'/f'{name}.class'),'class_sha256':sha(d/'classes'/f'{name}.class'),'jar':str(d/f'{name}.jar'),'jar_sha256':sha(d/f'{name}.jar'),'cli_stdout':str(d/'cli9.stdout'),'cli_stdout_sha256':sha(d/'cli9.stdout'),'cli_stderr':str(d/'cli9.stderr'),'cli_stderr_sha256':sha(d/'cli9.stderr'),'jarde_source':str(d/f'{name}.jarde.java'),'jarde_source_sha256':sha(d/f'{name}.jarde.java') if (d/f'{name}.jarde.java').exists() else None}
(WORK/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'manifest':str(WORK/'manifest.json'),'command_count':len(records),'cli_sha256':manifest['cli_sha256_post'],'cases':{k:{'class_sha256':v['class_sha256'],'jar_sha256':v['jar_sha256'],'jarde_source_sha256':v['jarde_source_sha256']} for k,v in manifest['cases'].items()}},indent=2))
