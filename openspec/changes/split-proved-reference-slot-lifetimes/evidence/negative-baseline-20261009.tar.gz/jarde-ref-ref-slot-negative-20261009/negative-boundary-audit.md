# CLI9 普通引用槽位分段：对抗性负例准备

只在 /private/tmp 工作；没有改仓库源码、测试、OpenSpec，没有运行 Cargo/Git/fmt。使用 JDK23 `javac --release 8 -g:none` 编译新增原始样例，并对原类 `java -Xverify:all`；CLI 只做一次 class-source raw source/report，不做 JADX 或四腿矩阵。

本次最终冻结 6 个边界族、8 个输入类。CLI 是 `/private/tmp/jarde-generic-calls-candidate-v9-cli`，SHA-256 `5bb2fcfdcf958839f0b1e060a2e55114510c6115cb225ec3279d7d7adf95e006`。每个实际 argv、stdout/stderr、exit、来源源码/类/JAR哈希、发射源码哈希、工具哈希均在 `replay-cli9-v3/manifest.json`。独立读后核验 `replay-cli9-v3/verification.json` SHA-256 `f15dd5454f28bac63fbc8e87279f85ccdfa2ccbe205884ee50a64dbbbb84148a`：37 subprocess 全部 exit 0、双流 hash 全匹配、8 次 CLI 均显式 `--format json --evidence all --release 8`。原始 CLI JSON 在各 case 的 `cli9.stdout` / `report.json`，抽取 source 在 `<case>/<Class>.jarde.java`。

| 边界族 / 输入 | 原始字节码事实 | 当前 CLI9 raw source/report 结论 |
|---|---|---|
| 同类型重复写：V2 | 原始无 LVT class SHA `22d88380...`；slot 1 两次 astore，BCI 5/19，写入与读取均为 int[]，中间读集不交叠。原 `-Xverify:all` 输出 `3`。 | 一个 `int[] local1` 被重复赋值；没有新段。当前 source SHA `a8a2f7df...` 与旧 change 保存的 before/after 两份逐字相同。这是同类 Ref→Ref 无 LVT 负例。 |
| 参数/header：ParameterHeader（新增） | Object 参数 slot 0 在 BCI 2 写 String、BCI 12 写 StringBuilder；参数身份贯穿整个方法，确为两种引用写入，但不是两个生命期局部。JDK23 Java8 class 验证运行输出 `java.lang.StringBuilder`。 | 仍以 Object 参数 `arg0` 连续赋值，没有拆成局部。 |
| unknown/null：NullThenBuilder（新增） | slot 2 在 BCI 2 执行 aconst_null、BCI 3 astore，前段读取后，BCI 24 同槽存 StringBuilder；无 LVT。JDK23 Java8 class 验证运行输出 `7`。前写只有 null 值，不能给出可拼写的引用声明类型。 | 保留一个 `Object local2`，先写 null、后写 StringBuilder；没有凭 null 造类型段。 |
| 普通 join phi：V3 | verifier-valid；slot 1 在 BCI 19/30 分别写 `[I` / `[Z`，分支在 BCI 31 合流、加载返回；StackMapTable 将合流 slot 设为 Object。class SHA `e48f8663...`，运行输出 `[I`。它是同一个源码 Object 变量，不是两个词法局部。 | 当前仍只声明 `int[] local1`，在 else 分支给它赋 `boolean[]`，没有被新规则切开；source SHA `959dce5c...` 与旧 before/after 逐字相同。保留的是既有类型冲突拒绝边界，不是一个可编译恢复结果。 |
| 旧值跨切点仍活跃：HeldUse（新增） | `run()` 中 slot 0 先存 StringBuilder。关键指令：BCI 10 `aload_0` 把旧 Builder 压栈；BCI 19 `astore_0` 将新 ArrayList 写回同槽；BCI 20 `invokestatic pick` 仍消费栈上的旧 Builder 和新 ArrayList。旧值确实越过新 store 后才被消费。JDK23 Java8 verifier 运行输出 `java.lang.StringBuilder:old`。CLI report 不序列化 SSA 表；这项结论由保存的完整 javap 指令与 JVM 栈语义直接证明，不伪称有独立 SSA dump。 | 不把 slot 0 分为两个局部；在 BCI 23 标注该值是 BCI 10 捕获的旧 local 值而 slot 已在期间被改写，保留 bytecode explanation。是清晰、真实的 Ref→Ref held-use 负控。 |
| 后段回前段 / handler：RefLoopBack（新增）、V4、handler fixture | RefLoopBack 有两个不同词法局部，slot 2 在 BCI 11/28 写 String/StringBuilder，正常边 BCI 36 回到 BCI 2（前段）。JDK23 Java8 verifier 输出 `22`。V4 slot 1 在 BCI 15/30 写 `[I`/`[Z`，是同一个 Object 局部在 loop phi 中存活，输出 `[I`。handler fixture 的 SSA slot 2 为 BCI 9 Ref(Unknown) array 与 BCI 31 IllegalStateException；`0→31` 是异常边，phi BCI 38 合并两值；原 runner verifier 输出 `11,7,9,8,3,8,4294967300`。 | RefLoopBack 没有分段，但 CLI 源把它输出成 `String local2` 后再赋 StringBuilder；这仍是已有不完整/类型冲突输出，未验证为可编译。V4 仍为一个 `int[] local1` 承接 `[Z`，source SHA `2a275195...` 与旧 before/after 逐字相同。handler 保留 catch-scope marker（`local 2 escapes catch parameter scope`），没有普通引用分段。三者分别压测正常后返、loop-carried 同一 Object、异常/caught phi，不能混成一个成功恢复。 |

新增原始样例 source/class SHA、生成 JAR SHA、CLI raw source SHA、所有真实命令和双流都在 manifest。新增样例的编译参数统一带显式空 `-classpath` 和 `-sourcepath`；handler 夹具连同已有 runner 一起编译。总计 8 个原始 class 全部由 Java 23 `-Xverify:all` 验证运行成功；其中 5 类在这次 evidence 中由 Java23 `--release 8 -g:none` 重新编译。

**静态和实测的界限：** V2/V3/V4 的当前 CLI9 输出与该 change 的历史输出 hash 已逐字相同；handler 的当前 CLI9 raw report 也已实际保存。新加的四个输入第一次有本片 CLI9 实测。CLI9 JSON report 没有独立 SSA 平面；V3/V4/handler 的 SSA 论据仍来自已有冻结记录或 StackMap/javap，HeldUse 则由 javap 的 load/store/invoke 顺序证明。这里核实的是当前 CLI9 不拆/保留既有边界；没有声称 V3/V4/RefLoopBack 的残余源码可编译，也没有将其既有冲突冒充为新回归。

**失败尝试保留：** `attempt-1-default-text-format/` 记录首次遗漏 `--format json`、harness 用 JSON parser 解析默认文本格式；CLI exit 0，属 harness 解析失败。`attempt-2-handler-no-main/` 记录第二次误启动无 main 的原 fixture；编译及 javap 成功，执行入口错误。最终 `run-boundaries-v3.py` 与 `replay-cli9-v3/` 是纠正后的实际完整 8-case 重放；两个失败目录没有被覆盖或删除。
