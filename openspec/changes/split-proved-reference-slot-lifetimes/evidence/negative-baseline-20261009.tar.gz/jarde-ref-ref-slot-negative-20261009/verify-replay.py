import hashlib,json
from pathlib import Path
ROOT=Path('/private/tmp/jarde-ref-ref-slot-negative-20261009')
mp=ROOT/'replay-cli9-v3/manifest.json'
m=json.loads(mp.read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
issues=[]
for c in m['commands']:
 if c['exit']!=0: issues.append({'kind':'command_failed','label':c['label'],'exit':c['exit']})
 for side in ('stdout','stderr'):
  p=Path(c[side])
  if not p.is_file() or sha(p)!=c[side+'_sha256']:
   issues.append({'kind':'stream_hash_mismatch','label':c['label'],'side':side,'path':str(p)})
for family,c in m['cases'].items():
 for k in ('source','class','jar','cli_stdout','cli_stderr','jarde_source'):
  p=Path(c[k]) if c.get(k) else None
  if p and (not p.is_file() or sha(p)!=c[k+'_sha256']):
   issues.append({'kind':'case_artifact_hash_mismatch','family':family,'kind_name':k,'path':str(p)})
reports={}
for family,c in m['cases'].items():
 d=Path(c['jarde_source']).parent
 r=json.loads((d/'report.json').read_text())
 reports[family]={'class_name':c['class_name'],'outcome':r['outcome'],'source_sha256':c['jarde_source_sha256'],'cli_stdout_sha256':c['cli_stdout_sha256'],'cli_stderr_sha256':c['cli_stderr_sha256'],'report_sha256':sha(d/'report.json'),'method_outcomes':[]}
 for method in r.get('methods',[]):
  item=method['item']; name=item['name']['escaped'];desc=item['descriptor']['escaped']
  out=method['outcome'];rep=out.get('report',{}) if isinstance(out,dict) else {}
  reports[family]['method_outcomes'].append({'name':name,'descriptor':desc,'kind':out.get('kind') if isinstance(out,dict) else str(out),'text':method.get('text',''),'diagnostics':rep.get('diagnostics',[])})
# Attach the separately compiled runner needed by the existing handler fixture.
handler_dir=ROOT/'replay-cli9-v3/handler'
runner=handler_dir/'SlotReuseBoundariesRunner.java'
if runner.is_file():
 reports['handler']['runner_source']={'path':str(runner),'sha256':sha(runner),'bytes':runner.stat().st_size}
cli=Path(m['cli'])
pre={x.get('cli_sha256_before') for x in m['commands'] if x['label'].startswith('cli9-')}
post={x.get('cli_sha256_after') for x in m['commands'] if x['label'].startswith('cli9-')}
result={'scope':'6 boundary families; 8 frozen input classes; one JDK23 --release 8 -g:none original compile/runtime leg where new; current CLI9 raw source/report once per case; no JADX/four-leg expansion.',
 'cli':{'path':str(cli),'sha256_recorded':m['cli_sha256_post'],'sha256_actual':sha(cli),'sha256_before_all_runs':sorted(pre),'sha256_after_each_run':sorted(post)},
 'executed_runner':m['executed_runner'],'jdk':{'bin':m['jdk_bin'],'tool_sha256':m['jdk_hashes']},
 'case_count':len(reports),'command_count':len(m['commands']),'all_commands_exit_zero':not issues,'raw_dual_streams_verified':not issues,'issues':issues,'cases':reports,
 'first_attempts_preserved':[str(ROOT/'attempt-1-default-text-format/failure-note.json'),str(ROOT/'attempt-2-handler-no-main/failure-note.json')]}
out=ROOT/'replay-cli9-v3/verification.json';out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'verification':str(out),'sha256':sha(out),'cases':len(reports),'commands':len(m['commands']),'issues':len(issues),'cli_sha256':sha(cli)},indent=2))
