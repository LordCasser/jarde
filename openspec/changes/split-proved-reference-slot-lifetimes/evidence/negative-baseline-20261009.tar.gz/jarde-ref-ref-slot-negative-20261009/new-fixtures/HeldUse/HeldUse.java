public class HeldUse {
    static Object pick(Object oldValue, Object nextValue) {
        return oldValue;
    }
    static Object run() {
        Object value = new StringBuilder("old");
        return pick(value, (value = new java.util.ArrayList<Object>()));
    }
    public static void main(String[] args) {
        Object picked = run();
        System.out.println(picked.getClass().getName() + ":" + picked.toString());
    }
}
