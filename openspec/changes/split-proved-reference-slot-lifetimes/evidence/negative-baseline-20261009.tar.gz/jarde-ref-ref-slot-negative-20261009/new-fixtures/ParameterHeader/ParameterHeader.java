public class ParameterHeader {
    static Object rewrite(Object value, boolean choose) {
        value = "first";
        value = new StringBuilder("second");
        return choose ? value : value;
    }
    public static void main(String[] args) {
        System.out.println(rewrite(new Object(), true).getClass().getName());
    }
}
