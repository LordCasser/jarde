public class NullThenBuilder {
    static Object run(boolean inspect) {
        int count = 0;
        {
            Object local = null;
            if (inspect && local == null) count++;
        }
        {
            StringBuilder local = new StringBuilder("second");
            count += local.length();
            return count;
        }
    }
    public static void main(String[] args) {
        System.out.println(run(true));
    }
}
