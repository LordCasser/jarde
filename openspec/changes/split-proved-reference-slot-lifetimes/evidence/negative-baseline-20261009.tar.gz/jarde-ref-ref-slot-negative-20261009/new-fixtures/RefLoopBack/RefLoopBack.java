public class RefLoopBack {
    static int run(int count) {
        int total = 0;
        while (count-- > 0) {
            {
                String first = "first";
                total += first.length();
            }
            {
                StringBuilder second = new StringBuilder("second");
                total += second.length();
            }
        }
        return total;
    }
    public static void main(String[] args) {
        System.out.println(run(2));
    }
}
