#!/usr/bin/env python3
import hashlib, json, re, shutil, subprocess
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde'); OUT=Path('/private/tmp/jarde-ref-ref-slot-patrol-20261009')
BASELINE=Path('/private/tmp/jarde-raw-receiver-final-v3-cli'); BASELINE_SHA='3f75dab495c9753ec2c3f1bd0ac91665ed42f8b877eea65cb7c69a6879448f70'
CANDIDATE=Path('/private/tmp/jarde-generic-calls-candidate-v9-cli'); CANDIDATE_SHA='5bb2fcfdcf958839f0b1e060a2e55114510c6115cb225ec3279d7d7adf95e006'
JADX=Path('/Users/lordcasser/workspace/testzone/jadx/jadx-cli/build/install/jadx/bin/jadx')
JDK={'javac8':(Path('/Library/Java/JavaVirtualMachines/corretto-1.8.0_432/Contents/Home'),['-source','8','-target','8']),'javac23':(Path('/Library/Java/JavaVirtualMachines/openjdk-23.0.1/Contents/Home'),['--release','8'])}
SOURCES={
'ArrayThenList':'''import java.util.ArrayList;\npublic class ArrayThenList { static int run(int[] input) { int sum=0; { int[] values=input; for(int value:values) sum+=value; } { ArrayList<Integer> out=new ArrayList<>(); out.add(sum); out.add(9); return out.get(0)+out.size(); } } public static void main(String[] x){System.out.println(run(new int[]{2,4}));} }\n''',
'StringThenBuilder':'''public class StringThenBuilder { static String run(String input) { int length; { String value=input.trim(); length=value.length(); } { StringBuilder out=new StringBuilder(); out.append(length).append(':').append(input.length()); return out.toString(); } } public static void main(String[] x){System.out.println(run(" abc "));} }\n''',
'StringThenArray':'''public class StringThenArray { static String run(String input) { int length; { String value=input.trim(); length=value.length(); } { String[] out=new String[length+1]; out[0]=input; out[length]="!"; return out[0]+out[length]; } } public static void main(String[] x){System.out.println(run(" abc "));} }\n''',
'DequeThenBuilder':'''import java.util.ArrayDeque;\npublic class DequeThenBuilder { static String run(int input) { int size; { ArrayDeque<Integer> queue=new ArrayDeque<>(); queue.add(input); queue.add(input+1); size=queue.size(); } { StringBuilder out=new StringBuilder(); out.append(size).append(':').append(input); return out.toString(); } } public static void main(String[] x){System.out.println(run(5));} }\n'''}
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def run(rows,label,argv,cwd,folder,stem):
 argv=[str(x) for x in argv];folder.mkdir(parents=True,exist_ok=True);p=subprocess.run(argv,cwd=cwd,capture_output=True)
 so=folder/(stem+'.stdout');se=folder/(stem+'.stderr');so.write_bytes(p.stdout or b'');se.write_bytes(p.stderr or b'')
 rows.append({'label':label,'argv':argv,'cwd':str(cwd),'exit':p.returncode,'stdout':str(so),'stdout_sha256':sha(so),'stderr':str(se),'stderr_sha256':sha(se)});return p
def class_name(path):
 t=Path(path).read_text(errors='replace');p=re.search(r'^\s*package\s+([\w.]+)\s*;',t,re.M);c=re.search(r'\bpublic\s+(?:final\s+)?class\s+(\w+)',t) or re.search(r'\bclass\s+(\w+)',t)
 if not c:raise RuntimeError('cannot find class '+str(path))
 return (p.group(1)+'.' if p else '')+c.group(1)
def main():
 if sha(BASELINE)!=BASELINE_SHA or sha(CANDIDATE)!=CANDIDATE_SHA:raise SystemExit('fixed CLI SHA mismatch')
 tools={}
 for leg,(home,release) in JDK.items():tools[leg]={'home':str(home),'release_flags':release,**{tool+'_sha256':sha(home/'bin'/tool) for tool in ('java','javac','jar','javap')}}
 libs=sorted(JADX.parent.parent.joinpath('lib').glob('*.jar'));tools['jadx']={'path':str(JADX),'sha256':sha(JADX),'libs':[{'path':str(p),'sha256':sha(p)} for p in libs]}
 meta={'scope':'first batch: 4 small complete Java classes x javac8/javac23 x -g/-g:none; same-slot reuse must be verified from javap before counting.','baseline_cli':str(BASELINE),'baseline_cli_sha256':BASELINE_SHA,'candidate_cli':str(CANDIDATE),'candidate_cli_sha256':CANDIDATE_SHA,'jadx':tools['jadx'],'jdk_tools':tools,'sources':{},'commands':[],'cases':[]}
 srcdir=OUT/'sources';srcdir.mkdir(exist_ok=True)
 for n,s in SOURCES.items():p=srcdir/(n+'.java');p.write_text(s);meta['sources'][n]={'path':str(p),'sha256':sha(p)}
 for leg,(home,release) in JDK.items():
  for debug in ('g','g-none'):
   for name in SOURCES:
    case=OUT/'cases'/leg/debug/name;case.mkdir(parents=True,exist_ok=True);source=srcdir/(name+'.java');cp=case/'empty-classpath';sp=case/'empty-sourcepath';cp.mkdir();sp.mkdir();original=case/'original-classes';original.mkdir();orig_source=case/'input.java';shutil.copyfile(source,orig_source);dbg=['-g'] if debug=='g' else ['-g:none']
    oc=run(meta['commands'],'original-javac',[home/'bin/javac',*release,*dbg,'-classpath',cp,'-sourcepath',sp,'-d',original,orig_source],case,case/'commands','original-javac')
    jar=case/(name+'.jar');jr=run(meta['commands'],'original-jar',[home/'bin/jar','cf',jar,'-C',original,'.'],case,case/'commands','original-jar')
    jv=run(meta['commands'],'original-javap',[home/'bin/javap','-p','-c','-l','-v','-classpath',jar,name],case,case/'commands','original-javap');(case/'javap.txt').write_bytes(jv.stdout)
    ort=run(meta['commands'],'original-Xverify-runtime',[home/'bin/java','-Xverify:all','-cp',original,name],case,case/'commands','original-run')
    jdir=case/'jadx';jd=run(meta['commands'],'reference-jadx',[JADX,'--no-res','-d',jdir/'out',jar],case,jdir,'jadx');jdsrc=sorted((jdir/'out').rglob('*.java')) if (jdir/'out').exists() else []
    row={'leg':leg,'debug':debug,'family':name,'source_sha256':sha(orig_source),'jar':str(jar),'jar_sha256':sha(jar) if jar.exists() else None,'class_hashes':{str(p.relative_to(original)):sha(p) for p in sorted(original.rglob('*.class'))},'original_compile_exit':oc.returncode,'jar_exit':jr.returncode,'javap_exit':jv.returncode,'original_runtime_exit':ort.returncode,'original_stdout_sha256':sha(case/'commands/original-run.stdout'),'original_stderr_sha256':sha(case/'commands/original-run.stderr'),'jadx_exit':jd.returncode,'jadx_sources':[{'path':str(p),'sha256':sha(p)} for p in jdsrc],'cli':{},'flavors':{}}
    for version,cli in [('baseline',BASELINE),('candidate',CANDIDATE)]:
     od=case/version;od.mkdir();c=run(meta['commands'],version+'-class-source',[cli,'class-source','--input',jar,'--class',name,'--policy','plain-jar','--format','json','--evidence','all','--release','8'],case,od,'class-source')
     try:
      rep=json.loads(c.stdout);(od/'report.json').write_bytes(c.stdout);sf=od/(name+'.java');sf.write_text(rep['text']);row['cli'][version]={'exit':c.returncode,'stdout_sha256':sha(od/'class-source.stdout'),'stderr_sha256':sha(od/'class-source.stderr'),'report_sha256':sha(od/'report.json'),'source_sha256':sha(sf),'text':str(sf)}
     except Exception as e:row['cli'][version]={'exit':c.returncode,'stdout_sha256':sha(od/'class-source.stdout'),'stderr_sha256':sha(od/'class-source.stderr'),'parse_error':repr(e)}
    variants={'original':[orig_source],'jadx':jdsrc}
    for version in ('baseline','candidate'):
     if row['cli'].get(version,{}).get('text'):variants[version]=[Path(row['cli'][version]['text'])]
    for flavor,sources in variants.items():
     fd=case/'flavors'/flavor;fd.mkdir(parents=True);fc=fd/'classes';fc.mkdir();fs=[]
     for i,s in enumerate(sources):target=fd/(Path(s).name if i==0 else f'{i}-{Path(s).name}');shutil.copyfile(s,target);fs.append(target)
     comp=run(meta['commands'],flavor+'-isolated-javac',[home/'bin/javac',*release,'-g:none','-classpath',cp,'-sourcepath',sp,'-d',fc,*fs],case,fd,'javac')
     fr={'compile_exit':comp.returncode,'sources':[{'path':str(s),'sha256':sha(s)} for s in fs],'class_hashes':{str(p.relative_to(fc)):sha(p) for p in sorted(fc.rglob('*.class'))}}
     if comp.returncode==0:
      chosen=next((p for p in fs if name in p.name),fs[0]);maincls=class_name(chosen);rt=run(meta['commands'],flavor+'-Xverify-runtime',[home/'bin/java','-Xverify:all','-cp',fc,maincls],case,fd,'runtime')
      fr.update({'main_class':maincls,'runtime_exit':rt.returncode,'runtime_stdout_sha256':sha(fd/'runtime.stdout'),'runtime_stderr_sha256':sha(fd/'runtime.stderr'),'behavior_match':(fd/'runtime.stdout').read_bytes()==(case/'commands/original-run.stdout').read_bytes()})
     row['flavors'][flavor]=fr
    meta['cases'].append(row);print('DONE',leg,debug,name,'orig',ort.returncode,'cli',row['cli'].get('candidate',{}).get('exit'),flush=True)
 files=[]
 for p in sorted(OUT.rglob('*')):
  if p.is_file() and p.name!='manifest.json':files.append({'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':sha(p)})
 meta['files']=files;out=OUT/'manifest.json';out.write_text(json.dumps(meta,indent=2)+'\n');print('FINISHED',len(meta['cases']),'cases',len(meta['commands']),'commands',len(files),'files','manifest_sha256',sha(out),flush=True)
if __name__=='__main__':main()
