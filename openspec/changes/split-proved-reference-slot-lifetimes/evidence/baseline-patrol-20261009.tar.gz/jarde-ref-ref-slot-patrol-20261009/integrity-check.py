import hashlib,json
from pathlib import Path
ROOT=Path('/private/tmp/jarde-ref-ref-slot-patrol-20261009')
manifest_paths=[ROOT/'attempt-2-proper-source-names/manifest.json',ROOT/'attempt-3-additional-four/manifest.json']
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
report={'manifests':[],'totals':{'inventoried_files':0,'commands':0,'empty_streams':0,'isolated_compile_commands':0,'verify_runtime_commands':0},'issues':[]}
for mp in manifest_paths:
 d=json.loads(mp.read_text()); base=mp.parent
 bad=[]
 for f in d['files']:
  p=base/f['path']
  if not p.is_file(): bad.append({'kind':'missing_inventory_file','path':str(p)}); continue
  got=sha(p); size=p.stat().st_size
  if got!=f['sha256'] or size!=f['bytes']: bad.append({'kind':'inventory_mismatch','path':str(p),'expected_sha':f['sha256'],'actual_sha':got,'expected_bytes':f['bytes'],'actual_bytes':size})
 for c in d['commands']:
  argv=c['argv']; label=c['label']; report['totals']['commands']+=1
  for stream in ('stdout','stderr'):
   p=Path(c[stream]); expected=c[stream+'_sha256']
   if not p.is_file(): bad.append({'kind':'missing_stream','label':label,'path':str(p)}); continue
   got=sha(p)
   if got!=expected: bad.append({'kind':'stream_hash_mismatch','label':label,'path':str(p),'expected':expected,'actual':got})
   if p.stat().st_size==0: report['totals']['empty_streams']+=1
  if 'isolated-javac' in label:
   report['totals']['isolated_compile_commands']+=1
   if '-classpath' not in argv or '-sourcepath' not in argv: bad.append({'kind':'missing_isolation_flags','label':label})
   for flag in ('-classpath','-sourcepath'):
    if flag in argv:
     q=Path(argv[argv.index(flag)+1])
     if not q.is_dir() or any(q.iterdir()): bad.append({'kind':'not_empty_isolation_dir','label':label,'flag':flag,'path':str(q)})
  if 'Xverify-runtime' in label:
   report['totals']['verify_runtime_commands']+=1
   if '-Xverify:all' not in argv: bad.append({'kind':'missing_verify_all','label':label})
   if '-cp' not in argv: bad.append({'kind':'missing_classpath','label':label}); continue
   cp=argv[argv.index('-cp')+1]
   if '.jar' in cp.lower(): bad.append({'kind':'runtime_jar_on_classpath','label':label,'cp':cp})
   if not Path(cp).is_dir(): bad.append({'kind':'runtime_class_dir_missing','label':label,'cp':cp})
  if label.endswith('class-source'):
   if argv[0] not in (d['baseline_cli'],d['candidate_cli']): bad.append({'kind':'cli_path_mismatch','label':label,'argv0':argv[0]})
   if not Path(argv[0]).is_file(): bad.append({'kind':'cli_missing','label':label,'path':argv[0]})
 report['totals']['inventoried_files']+=len(d['files'])
 entry={'manifest':str(mp),'manifest_sha256':sha(mp),'file_count':len(d['files']),'command_count':len(d['commands']),'case_count':len(d['cases']),'baseline_cli':d['baseline_cli'],'baseline_cli_sha256_recorded':d['baseline_cli_sha256'],'baseline_cli_sha256_actual':sha(d['baseline_cli']),'candidate_cli':d['candidate_cli'],'candidate_cli_sha256_recorded':d['candidate_cli_sha256'],'candidate_cli_sha256_actual':sha(d['candidate_cli']),'issues':bad}
 if entry['baseline_cli_sha256_recorded']!=entry['baseline_cli_sha256_actual']:bad.append({'kind':'baseline_cli_hash_mismatch'})
 if entry['candidate_cli_sha256_recorded']!=entry['candidate_cli_sha256_actual']:bad.append({'kind':'candidate_cli_hash_mismatch'})
 entry['issues']=bad; report['issues'].extend(bad);report['manifests'].append(entry)
report['totals']['inventory_claims_match']=not report['issues']
out=ROOT/'integrity-check.json';out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'sha256':sha(out),'totals':report['totals'],'issues':len(report['issues'])},indent=2))
