package defpackage;

import java.util.ArrayList;
import java.util.HashMap;

/* JADX INFO: loaded from: ListThenMap.jar:ListThenMap.class */
public class ListThenMap {
    static int run(int x) {
        ArrayList<Integer> v = new ArrayList<>();
        v.add(Integer.valueOf(x));
        v.add(Integer.valueOf(x + 1));
        int n = v.size();
        HashMap<String, Integer> v2 = new HashMap<>();
        v2.put("k", Integer.valueOf(n));
        return v2.size() + v2.get("k").intValue();
    }

    public static void main(String[] a) {
        System.out.println(run(4));
    }
}
