package defpackage;

import java.util.ArrayList;
import java.util.HashMap;

/* JADX INFO: loaded from: ListThenMap.jar:ListThenMap.class */
public class ListThenMap {
    static int run(int i) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(Integer.valueOf(i));
        arrayList.add(Integer.valueOf(i + 1));
        int size = arrayList.size();
        HashMap map = new HashMap();
        map.put("k", Integer.valueOf(size));
        return map.size() + ((Integer) map.get("k")).intValue();
    }

    public static void main(String[] strArr) {
        System.out.println(run(4));
    }
}
