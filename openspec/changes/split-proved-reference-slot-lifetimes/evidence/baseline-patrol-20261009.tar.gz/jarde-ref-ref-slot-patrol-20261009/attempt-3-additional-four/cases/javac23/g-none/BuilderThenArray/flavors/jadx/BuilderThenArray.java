package defpackage;

/* JADX INFO: loaded from: BuilderThenArray.jar:BuilderThenArray.class */
public class BuilderThenArray {
    static String run(String str) {
        int length = new StringBuilder(str).length();
        char[] cArr = new char[length];
        for (int i = 0; i < length; i++) {
            cArr[i] = str.charAt(i);
        }
        return new String(cArr);
    }

    public static void main(String[] strArr) {
        System.out.println(run("abc"));
    }
}
