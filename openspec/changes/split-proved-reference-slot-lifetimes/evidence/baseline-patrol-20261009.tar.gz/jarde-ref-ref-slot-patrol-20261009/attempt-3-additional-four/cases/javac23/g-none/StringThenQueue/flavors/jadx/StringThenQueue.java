package defpackage;

import java.util.ArrayDeque;

/* JADX INFO: loaded from: StringThenQueue.jar:StringThenQueue.class */
public class StringThenQueue {
    static String run(String str) {
        int length = str.trim().length();
        ArrayDeque arrayDeque = new ArrayDeque();
        arrayDeque.add(str);
        arrayDeque.add("!");
        return length + ":" + ((String) arrayDeque.removeFirst()) + ((String) arrayDeque.removeLast());
    }

    public static void main(String[] strArr) {
        System.out.println(run(" q "));
    }
}
