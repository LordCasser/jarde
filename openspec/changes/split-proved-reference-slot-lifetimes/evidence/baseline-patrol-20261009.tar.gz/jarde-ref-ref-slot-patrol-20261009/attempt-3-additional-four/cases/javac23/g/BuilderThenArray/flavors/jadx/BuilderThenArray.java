package defpackage;

/* JADX INFO: loaded from: BuilderThenArray.jar:BuilderThenArray.class */
public class BuilderThenArray {
    static String run(String x) {
        int n = new StringBuilder(x).length();
        char[] v = new char[n];
        for (int i = 0; i < n; i++) {
            v[i] = x.charAt(i);
        }
        return new String(v);
    }

    public static void main(String[] a) {
        System.out.println(run("abc"));
    }
}
