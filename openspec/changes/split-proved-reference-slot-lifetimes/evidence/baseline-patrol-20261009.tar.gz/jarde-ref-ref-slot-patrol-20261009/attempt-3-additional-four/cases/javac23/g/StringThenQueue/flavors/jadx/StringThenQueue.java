package defpackage;

import java.util.ArrayDeque;

/* JADX INFO: loaded from: StringThenQueue.jar:StringThenQueue.class */
public class StringThenQueue {
    static String run(String x) {
        int n = x.trim().length();
        ArrayDeque<String> v = new ArrayDeque<>();
        v.add(x);
        v.add("!");
        return n + ":" + v.removeFirst() + v.removeLast();
    }

    public static void main(String[] a) {
        System.out.println(run(" q "));
    }
}
