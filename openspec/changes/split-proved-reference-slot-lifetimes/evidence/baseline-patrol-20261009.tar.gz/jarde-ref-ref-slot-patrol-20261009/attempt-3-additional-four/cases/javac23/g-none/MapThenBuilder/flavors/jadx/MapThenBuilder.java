package defpackage;

import java.util.HashMap;

/* JADX INFO: loaded from: MapThenBuilder.jar:MapThenBuilder.class */
public class MapThenBuilder {
    static String run(int i) {
        HashMap map = new HashMap();
        map.put("k", Integer.valueOf(i));
        int iIntValue = ((Integer) map.get("k")).intValue();
        StringBuilder sb = new StringBuilder();
        sb.append(iIntValue).append(':').append(i);
        return sb.toString();
    }

    public static void main(String[] strArr) {
        System.out.println(run(6));
    }
}
