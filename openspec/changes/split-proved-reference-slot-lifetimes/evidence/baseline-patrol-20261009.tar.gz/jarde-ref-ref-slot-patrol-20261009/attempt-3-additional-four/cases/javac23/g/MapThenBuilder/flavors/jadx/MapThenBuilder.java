package defpackage;

import java.util.HashMap;

/* JADX INFO: loaded from: MapThenBuilder.jar:MapThenBuilder.class */
public class MapThenBuilder {
    static String run(int x) {
        HashMap<String, Integer> v = new HashMap<>();
        v.put("k", Integer.valueOf(x));
        int n = v.get("k").intValue();
        StringBuilder v2 = new StringBuilder();
        v2.append(n).append(':').append(x);
        return v2.toString();
    }

    public static void main(String[] a) {
        System.out.println(run(6));
    }
}
