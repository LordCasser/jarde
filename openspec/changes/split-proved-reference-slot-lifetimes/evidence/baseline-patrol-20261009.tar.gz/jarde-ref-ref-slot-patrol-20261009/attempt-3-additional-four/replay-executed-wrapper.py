from pathlib import Path
import importlib.util
modpath=Path('/private/tmp/jarde-ref-ref-slot-patrol-20261009/attempt-2-run-patrol.py')
spec=importlib.util.spec_from_file_location('patrol',modpath)
patrol=importlib.util.module_from_spec(spec);spec.loader.exec_module(patrol)
patrol.OUT=Path('/private/tmp/jarde-ref-ref-slot-patrol-20261009/attempt-3-additional-four')
patrol.SOURCES={
'ListThenMap': '''import java.util.ArrayList; import java.util.HashMap; public class ListThenMap { static int run(int x) { int n; { ArrayList<Integer> v=new ArrayList<>(); v.add(x); v.add(x+1); n=v.size(); } { HashMap<String,Integer> v=new HashMap<>(); v.put("k",n); return v.size()+v.get("k"); } } public static void main(String[] a){System.out.println(run(4));} }\n''',
'MapThenBuilder': '''import java.util.HashMap; public class MapThenBuilder { static String run(int x) { int n; { HashMap<String,Integer> v=new HashMap<>(); v.put("k",x); n=v.get("k"); } { StringBuilder v=new StringBuilder(); v.append(n).append(':').append(x); return v.toString(); } } public static void main(String[] a){System.out.println(run(6));} }\n''',
'StringThenQueue': '''import java.util.ArrayDeque; public class StringThenQueue { static String run(String x) { int n; { String v=x.trim(); n=v.length(); } { ArrayDeque<String> v=new ArrayDeque<>(); v.add(x); v.add("!"); return n+":"+v.removeFirst()+v.removeLast(); } } public static void main(String[] a){System.out.println(run(" q "));} }\n''',
'BuilderThenArray': '''public class BuilderThenArray { static String run(String x) { int n; { StringBuilder v=new StringBuilder(x); n=v.length(); } { char[] v=new char[n]; for(int i=0;i<n;i++) v[i]=x.charAt(i); return new String(v); } } public static void main(String[] a){System.out.println(run("abc"));} }\n'''}
patrol.main()
