import java.util.ArrayList;
public class ArrayThenList { static int run(int[] input) { int sum=0; { int[] values=input; for(int value:values) sum+=value; } { ArrayList<Integer> out=new ArrayList<>(); out.add(sum); out.add(9); return out.get(0)+out.size(); } } public static void main(String[] x){System.out.println(run(new int[]{2,4}));} }
