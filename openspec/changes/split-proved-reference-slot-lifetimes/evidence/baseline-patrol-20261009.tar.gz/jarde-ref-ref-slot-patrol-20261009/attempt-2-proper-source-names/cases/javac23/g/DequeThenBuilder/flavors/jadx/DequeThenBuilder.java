package defpackage;

import java.util.ArrayDeque;

/* JADX INFO: loaded from: DequeThenBuilder.jar:DequeThenBuilder.class */
public class DequeThenBuilder {
    static String run(int input) {
        ArrayDeque<Integer> queue = new ArrayDeque<>();
        queue.add(Integer.valueOf(input));
        queue.add(Integer.valueOf(input + 1));
        int size = queue.size();
        StringBuilder out = new StringBuilder();
        out.append(size).append(':').append(input);
        return out.toString();
    }

    public static void main(String[] x) {
        System.out.println(run(5));
    }
}
