package defpackage;

/* JADX INFO: loaded from: StringThenArray.jar:StringThenArray.class */
public class StringThenArray {
    static String run(String input) {
        String value = input.trim();
        int length = value.length();
        String[] out = new String[length + 1];
        out[0] = input;
        out[length] = "!";
        return out[0] + out[length];
    }

    public static void main(String[] x) {
        System.out.println(run(" abc "));
    }
}
