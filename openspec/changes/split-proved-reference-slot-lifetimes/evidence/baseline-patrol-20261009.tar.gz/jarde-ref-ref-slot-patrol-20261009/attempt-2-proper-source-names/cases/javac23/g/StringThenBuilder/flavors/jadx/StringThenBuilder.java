package defpackage;

/* JADX INFO: loaded from: StringThenBuilder.jar:StringThenBuilder.class */
public class StringThenBuilder {
    static String run(String input) {
        String value = input.trim();
        int length = value.length();
        StringBuilder out = new StringBuilder();
        out.append(length).append(':').append(input.length());
        return out.toString();
    }

    public static void main(String[] x) {
        System.out.println(run(" abc "));
    }
}
