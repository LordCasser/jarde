package defpackage;

/* JADX INFO: loaded from: StringThenArray.jar:StringThenArray.class */
public class StringThenArray {
    static String run(String str) {
        int length = str.trim().length();
        String[] strArr = new String[length + 1];
        strArr[0] = str;
        strArr[length] = "!";
        return strArr[0] + strArr[length];
    }

    public static void main(String[] strArr) {
        System.out.println(run(" abc "));
    }
}
