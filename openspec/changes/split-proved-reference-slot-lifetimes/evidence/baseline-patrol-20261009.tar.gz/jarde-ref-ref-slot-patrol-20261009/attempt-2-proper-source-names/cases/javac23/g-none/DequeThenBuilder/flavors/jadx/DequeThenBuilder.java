package defpackage;

import java.util.ArrayDeque;

/* JADX INFO: loaded from: DequeThenBuilder.jar:DequeThenBuilder.class */
public class DequeThenBuilder {
    static String run(int i) {
        ArrayDeque arrayDeque = new ArrayDeque();
        arrayDeque.add(Integer.valueOf(i));
        arrayDeque.add(Integer.valueOf(i + 1));
        int size = arrayDeque.size();
        StringBuilder sb = new StringBuilder();
        sb.append(size).append(':').append(i);
        return sb.toString();
    }

    public static void main(String[] strArr) {
        System.out.println(run(5));
    }
}
