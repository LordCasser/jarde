package defpackage;

import java.util.ArrayList;

/* JADX INFO: loaded from: ArrayThenList.jar:ArrayThenList.class */
public class ArrayThenList {
    static int run(int[] iArr) {
        int i = 0;
        for (int i2 : iArr) {
            i += i2;
        }
        ArrayList arrayList = new ArrayList();
        arrayList.add(Integer.valueOf(i));
        arrayList.add(9);
        return ((Integer) arrayList.get(0)).intValue() + arrayList.size();
    }

    public static void main(String[] strArr) {
        System.out.println(run(new int[]{2, 4}));
    }
}
