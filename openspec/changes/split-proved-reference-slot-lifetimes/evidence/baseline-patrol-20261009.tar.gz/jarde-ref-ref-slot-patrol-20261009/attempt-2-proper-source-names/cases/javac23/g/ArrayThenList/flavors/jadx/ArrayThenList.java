package defpackage;

import java.util.ArrayList;

/* JADX INFO: loaded from: ArrayThenList.jar:ArrayThenList.class */
public class ArrayThenList {
    static int run(int[] input) {
        int sum = 0;
        for (int value : input) {
            sum += value;
        }
        ArrayList<Integer> out = new ArrayList<>();
        out.add(Integer.valueOf(sum));
        out.add(9);
        return out.get(0).intValue() + out.size();
    }

    public static void main(String[] x) {
        System.out.println(run(new int[]{2, 4}));
    }
}
