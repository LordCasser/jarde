package defpackage;

/* JADX INFO: loaded from: StringThenBuilder.jar:StringThenBuilder.class */
public class StringThenBuilder {
    static String run(String str) {
        int length = str.trim().length();
        StringBuilder sb = new StringBuilder();
        sb.append(length).append(':').append(str.length());
        return sb.toString();
    }

    public static void main(String[] strArr) {
        System.out.println(run(" abc "));
    }
}
