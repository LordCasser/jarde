import java.util.ArrayDeque;
public class DequeThenBuilder { static String run(int input) { int size; { ArrayDeque<Integer> queue=new ArrayDeque<>(); queue.add(input); queue.add(input+1); size=queue.size(); } { StringBuilder out=new StringBuilder(); out.append(size).append(':').append(input); return out.toString(); } } public static void main(String[] x){System.out.println(run(5));} }
