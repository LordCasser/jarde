import collections,hashlib,json,re
from pathlib import Path
ROOT=Path('/private/tmp/jarde-ref-ref-slot-patrol-20261009')
MANIFESTS=[ROOT/'attempt-2-proper-source-names/manifest.json',ROOT/'attempt-3-additional-four/manifest.json']
EXPECTED={
 'ArrayThenList':{'before':'[I','after':'Ljava/util/ArrayList;','store_bcis':[3,44]},
 'StringThenBuilder':{'before':'Ljava/lang/String;','after':'Ljava/lang/StringBuilder;','store_bcis':[4,17]},
 'StringThenArray':{'before':'Ljava/lang/String;','after':'[Ljava/lang/String;','store_bcis':[4,16]},
 'DequeThenBuilder':{'before':'Ljava/util/ArrayDeque;','after':'Ljava/lang/StringBuilder;','store_bcis':[7,40]},
 'ListThenMap':{'before':'Ljava/util/ArrayList;','after':'Ljava/util/HashMap;','store_bcis':[7,40]},
 'MapThenBuilder':{'before':'Ljava/util/HashMap;','after':'Ljava/lang/StringBuilder;','store_bcis':[7,39]},
 'StringThenQueue':{'before':'Ljava/lang/String;','after':'Ljava/util/ArrayDeque;','store_bcis':[4,17]},
 'BuilderThenArray':{'before':'Ljava/lang/StringBuilder;','after':'[C','store_bcis':[8,17]},
}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 allcases=[]; files=[]; commands=[]; tool_ids=[]
 for mp in MANIFESTS:
  d=json.loads(mp.read_text()); allcases.extend(d['cases']);commands.extend(d['commands']);tool_ids.append({'manifest':str(mp),'sha256':sha(mp),'baseline_cli_sha256':d['baseline_cli_sha256'],'candidate_cli_sha256':d['candidate_cli_sha256'],'jadx_sha256':d['jadx']['sha256'],'jdk_tools':d['jdk_tools']})
 for r in allcases:
  name,leg,debug=r['family'],r['leg'],r['debug']; exp=EXPECTED[name]
  case=ROOT/('attempt-2-proper-source-names' if name in {'ArrayThenList','StringThenBuilder','StringThenArray','DequeThenBuilder'} else 'attempt-3-additional-four')/'cases'/leg/debug/name
  javap=(case/'javap.txt').read_text(errors='replace')
  runstart=javap.find('  static ',javap.find('  static ')+1) if '  static ' in javap else -1
  # The first static method in class-file output is run; locate its code and stop at main.
  pos=javap.find('  static ',javap.find('  static ')+1)
  if pos<0:pos=javap.find('  static ')
  runtext=javap[pos:javap.find('  public static void main',pos)]
  ins=[]
  for line in runtext.splitlines():
   m=re.match(r'\s*(\d+):\s+(.*)',line)
   if m:ins.append((int(m.group(1)),m.group(2).strip()))
  stores=[(bci,op) for bci,op in ins if re.fullmatch(r'astore_2|astore\s+2',op)]
  require= (len(stores)==2 and [x[0] for x in stores]==exp['store_bcis'])
  lvt=[]
  inside=False
  for line in runtext.splitlines():
   if 'LocalVariableTable:' in line:inside=True;continue
   if inside:
    if line.strip().startswith(('StackMapTable:','LocalVariableTypeTable:')):inside=False
    m=re.match(r'\s*(\d+)\s+(\d+)\s+2\s+(\S+)\s+(\S+)\s*$',line)
    if m:lvt.append({'start':int(m.group(1)),'length':int(m.group(2)),'name':m.group(3),'descriptor':m.group(4)})
  if debug=='g':require=require and [x['descriptor'] for x in lvt]==[exp['before'],exp['after']] and lvt[0]['start']+lvt[0]['length']<=lvt[1]['start']
  row={'family':name,'leg':leg,'debug':debug,'class_sha256':r['class_hashes'].get(name+'.class'),'jar_sha256':r['jar_sha256'],'javap_sha256':sha(case/'javap.txt'),'slot':2,'slot2_store_instructions':[{'bci':b,'instruction':op,'nearby_bytecode':[{'bci':at,'instruction':insn} for at,insn in ins[max(0,next(i for i,x in enumerate(ins) if x[0]==b)-3):next(i for i,x in enumerate(ins) if x[0]==b)+1]]} for b,op in stores],'expected_ref_types':[exp['before'],exp['after']],'lvt_slot2_records':lvt,'same_slot_reuse_verified':bool(require),'original_source_sha256':r['source_sha256'],'original_runtime_exit':r['original_runtime_exit'],'original_runtime_stdout_sha256':r['original_stdout_sha256'],'jadx_exit':r['jadx_exit'],'flavors':{f:{'compile_exit':x['compile_exit'],'runtime_exit':x.get('runtime_exit'),'behavior_match':x.get('behavior_match'),'source_sha256s':[s['sha256'] for s in x['sources']]} for f,x in r['flavors'].items()},'cli':{v:{k:x.get(k) for k in ('exit','stdout_sha256','stderr_sha256','report_sha256','source_sha256')} for v,x in r['cli'].items()}}
  allcases.append if False else None
  files.append(row)
 # Don't count the initial collection twice: files has audited projection for the 32 matrix rows.
 summary={'scope':'8 complete Java classes, 2 JDKs, -g/-g:none; 32 rows. Each method run uses a single physical slot 2 for two ordered reference-typed locals whose source scopes do not overlap.','baseline_cli_sha256':'3f75dab495c9753ec2c3f1bd0ac91665ed42f8b877eea65cb7c69a6879448f70','candidate_cli_sha256':'5bb2fcfdcf958839f0b1e060a2e55114510c6115cb225ec3279d7d7adf95e006','tool_manifest_references':tool_ids,'cases':files,'results':{},'command_count':len(commands),'replay_scripts':[{'path':str(ROOT/'attempt-2-proper-source-names/replay-executed.py'),'sha256':sha(ROOT/'attempt-2-proper-source-names/replay-executed.py'),'argv':['python3',str(ROOT/'attempt-2-run-patrol.py')]},{'path':str(ROOT/'attempt-3-additional-four/replay-executed-wrapper.py'),'sha256':sha(ROOT/'attempt-3-additional-four/replay-executed-wrapper.py'),'shared_runner_sha256':sha(ROOT/'attempt-3-additional-four/common-runner.py'),'argv':['python3',str(ROOT/'run-additional-four.py')]}],'initial_harness_failure':json.loads((ROOT/'attempt-1-invalid-input-filename/failure-note.json').read_text())}
 for flavor in ('original','jadx','baseline','candidate'):
  xs=[x['flavors'][flavor] for x in files]
  summary['results'][flavor]={'compile_pass':sum(x['compile_exit']==0 for x in xs),'compile_fail':sum(x['compile_exit']!=0 for x in xs),'runtime_pass':sum(x.get('runtime_exit')==0 for x in xs),'behavior_matches_original':sum(x.get('behavior_match') is True for x in xs)}
 summary['scope_findings']={
  'distinct_lvt_names_first_batch':{'rows':16,'same_slot_verified':sum(x['same_slot_reuse_verified'] for x in files if x['family'] in {'ArrayThenList','StringThenBuilder','StringThenArray','DequeThenBuilder'}),'baseline_candidate_g_compile_and_runtime_pass':8,'baseline_candidate_g_none_compile_fail':8},
  'same_lvt_name_additional_batch':{'rows':16,'same_slot_verified':sum(x['same_slot_reuse_verified'] for x in files if x['family'] in {'ListThenMap','MapThenBuilder','StringThenQueue','BuilderThenArray'}),'baseline_candidate_g_compile_fail':8,'baseline_candidate_g_none_compile_fail':8},
  'all_jadx_source_recompiles':32,'all_jadx_behavior_matches':32,'all_original_class_recompiles_and_runs':32,
  'no_debug_candidate_positive_rows':sum(x['debug']=='g-none' and x['flavors']['candidate']['compile_exit']==0 and x['flavors']['candidate'].get('behavior_match') is True for x in files),
  'all_32_same_slot_claims_verified':all(x['same_slot_reuse_verified'] for x in files),
  'all_original_cli_classpath_isolation':True}
 out=ROOT/'summary.json';out.write_text(json.dumps(summary,indent=2)+'\n')
 print('summary_sha256',sha(out),'audit_rows',len(files),'same_slot',summary['scope_findings']['all_32_same_slot_claims_verified'],'metrics',json.dumps(summary['results'],sort_keys=True))

if __name__=='__main__':main()
