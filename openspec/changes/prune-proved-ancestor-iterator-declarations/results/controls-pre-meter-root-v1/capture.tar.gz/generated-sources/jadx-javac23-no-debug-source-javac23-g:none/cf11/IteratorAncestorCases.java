package cf11;

import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.jar:cf11/IteratorAncestorCases.class */
public final class IteratorAncestorCases {
    public static int observed;

    public static int ancestor(List<String> list) {
        observed = 0;
        Iterator<String> it = list.iterator();
        while (it.hasNext()) {
            observed += it.next().length();
        }
        return observed;
    }

    public static int sameList(List<String> list) {
        observed = 0;
        for (String str : list) {
            for (String str2 : list) {
                observed += str.length();
                observed += str2.length();
            }
        }
        return observed;
    }

    public static int protectedPositive(List<String> list) {
        observed = 0;
        try {
            Iterator<String> it = list.iterator();
            while (it.hasNext()) {
                observed += it.next().length();
            }
        } catch (IllegalStateException e) {
            observed += 100;
        }
        return observed;
    }

    public static int protectedBeforeRead(List<String> list) {
        observed = 0;
        Iterator<String> it = list.iterator();
        if (it.hasNext()) {
            observed += 10;
        }
        while (it.hasNext()) {
            try {
                observed += it.next().length();
            } catch (IllegalStateException e) {
                observed += 100;
            }
        }
        return observed;
    }

    public static int protectedAfterRead(List<String> list) {
        observed = 0;
        Iterator<String> it = list.iterator();
        while (it.hasNext()) {
            try {
                observed += it.next().length();
            } catch (IllegalStateException e) {
                observed += 100;
            }
        }
        if (it.hasNext()) {
            observed += 10;
        }
        return observed;
    }

    public static int protectedAfterWrite(List<String> list, List<String> list2) {
        observed = 0;
        try {
            Iterator<String> it = list.iterator();
            while (it.hasNext()) {
                observed += it.next().length();
            }
        } catch (IllegalStateException e) {
            observed += 100;
        }
        if (list2.iterator().hasNext()) {
            observed += 10;
        }
        return observed;
    }

    public static int protectedCatchReadWrite(List<String> list, List<String> list2) {
        observed = 0;
        Iterator<String> it = list.iterator();
        while (it.hasNext()) {
            try {
                observed += it.next().length();
            } catch (IllegalStateException e) {
                if (it.hasNext()) {
                    observed += 10;
                }
                if (list2.iterator().hasNext()) {
                    observed += 20;
                }
            }
        }
        return observed;
    }

    public static int reusedSlots(List<String> list, List<String> list2) {
        observed = 0;
        Iterator<String> it = list.iterator();
        while (it.hasNext()) {
            observed += it.next().length();
        }
        Iterator<String> it2 = list2.iterator();
        while (it2.hasNext()) {
            observed += it2.next().length();
        }
        return observed;
    }

    public static int siblingNames(List<String> list, List<String> list2, boolean z) {
        observed = 0;
        if (z) {
            Iterator<String> it = list.iterator();
            while (it.hasNext()) {
                observed += it.next().length();
            }
        } else {
            Iterator<String> it2 = list2.iterator();
            while (it2.hasNext()) {
                observed += it2.next().length();
            }
        }
        return observed;
    }
}
