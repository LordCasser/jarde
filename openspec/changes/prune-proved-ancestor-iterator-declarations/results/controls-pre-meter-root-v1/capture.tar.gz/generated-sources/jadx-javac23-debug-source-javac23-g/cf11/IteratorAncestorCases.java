package cf11;

import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.jar:cf11/IteratorAncestorCases.class */
public final class IteratorAncestorCases {
    public static int observed;

    public static int ancestor(List<String> values) {
        observed = 0;
        for (String item : values) {
            observed += item.length();
        }
        return observed;
    }

    public static int sameList(List<String> values) {
        observed = 0;
        for (String outerValue : values) {
            for (String innerValue : values) {
                observed += outerValue.length();
                observed += innerValue.length();
            }
        }
        return observed;
    }

    public static int protectedPositive(List<String> values) {
        observed = 0;
        try {
            for (String item : values) {
                observed += item.length();
            }
        } catch (IllegalStateException e) {
            observed += 100;
        }
        return observed;
    }

    public static int protectedBeforeRead(List<String> values) {
        observed = 0;
        Iterator<String> iterator = values.iterator();
        if (iterator.hasNext()) {
            observed += 10;
        }
        while (iterator.hasNext()) {
            try {
                String item = iterator.next();
                observed += item.length();
            } catch (IllegalStateException e) {
                observed += 100;
            }
        }
        return observed;
    }

    public static int protectedAfterRead(List<String> values) {
        observed = 0;
        Iterator<String> iterator = values.iterator();
        while (iterator.hasNext()) {
            try {
                String item = iterator.next();
                observed += item.length();
            } catch (IllegalStateException e) {
                observed += 100;
            }
        }
        if (iterator.hasNext()) {
            observed += 10;
        }
        return observed;
    }

    public static int protectedAfterWrite(List<String> values, List<String> fallback) {
        observed = 0;
        try {
            for (String item : values) {
                observed += item.length();
            }
        } catch (IllegalStateException e) {
            observed += 100;
        }
        if (fallback.iterator().hasNext()) {
            observed += 10;
        }
        return observed;
    }

    public static int protectedCatchReadWrite(List<String> values, List<String> fallback) {
        observed = 0;
        Iterator<String> iterator = values.iterator();
        while (iterator.hasNext()) {
            try {
                String item = iterator.next();
                observed += item.length();
            } catch (IllegalStateException e) {
                if (iterator.hasNext()) {
                    observed += 10;
                }
                if (fallback.iterator().hasNext()) {
                    observed += 20;
                }
            }
        }
        return observed;
    }

    public static int reusedSlots(List<String> first, List<String> second) {
        observed = 0;
        for (String item : first) {
            observed += item.length();
        }
        for (String item2 : second) {
            observed += item2.length();
        }
        return observed;
    }

    public static int siblingNames(List<String> left, List<String> right, boolean useLeft) {
        observed = 0;
        if (useLeft) {
            for (String item : left) {
                observed += item.length();
            }
        } else {
            for (String item2 : right) {
                observed += item2.length();
            }
        }
        return observed;
    }
}
