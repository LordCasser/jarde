import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Iterator;
import java.util.List;

/** Parentless reflection harness. Compile independently from the target source. */
public final class IteratorAncestorDriver {
    private static final String TARGET = "cf11.IteratorAncestorCases";

    private static final class TraceList extends AbstractList<Object> {
        final List<Object> data = new ArrayList<Object>();
        final List<String> events = new ArrayList<String>();
        final String mode;
        int returned;

        TraceList(String mode, Object... values) {
            this.mode = mode;
            this.data.addAll(Arrays.asList(values));
        }

        private void event(String value) {
            if (events.size() >= 128) throw new AssertionError("iterator event budget");
            events.add(value);
        }

        public Object get(int index) { return data.get(index); }
        public int size() { return data.size(); }

        public Iterator<Object> iterator() {
            event("iterator");
            return new Iterator<Object>() {
                int index;
                public boolean hasNext() {
                    event("hasNext:" + index);
                    if (mode.equals("hasNextAfterOne") && returned > 0)
                        throw new IllegalStateException("hasNextAfterOne");
                    return index < data.size();
                }
                public Object next() {
                    event("next:" + index);
                    if (mode.equals("nextAfterOne") && returned > 0)
                        throw new IllegalStateException("nextAfterOne");
                    Object value = data.get(index++);
                    returned++;
                    return value;
                }
            };
        }
    }

    private static final class Case {
        final String name;
        final String method;
        final Class<?>[] parameterTypes;
        final Object[] arguments;
        Case(String name, String method, Class<?>[] parameterTypes, Object[] arguments) {
            this.name = name;
            this.method = method;
            this.parameterTypes = parameterTypes;
            this.arguments = arguments;
        }
    }

    private static TraceList trace(String mode, Object... values) {
        return new TraceList(mode, values);
    }

    private static Case one(String name, String method, String mode, Object... values) {
        return new Case(name, method, new Class<?>[] { List.class },
                new Object[] { trace(mode, values) });
    }

    private static Case two(String name, String method, TraceList first, TraceList second) {
        return new Case(name, method, new Class<?>[] { List.class, List.class },
                new Object[] { first, second });
    }

    private static String b64(String value) {
        return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private static String traceOf(Object[] arguments) {
        List<String> traces = new ArrayList<String>();
        for (Object argument : arguments) {
            if (argument instanceof TraceList) {
                TraceList list = (TraceList) argument;
                traces.add(String.join(",", list.events));
            }
        }
        return b64(String.join("|", traces));
    }

    private static void run(String actualRoot, String expectedRoot, Case c) throws Exception {
        URL actual = Paths.get(actualRoot).toRealPath().toUri().toURL();
        URL expected = Paths.get(expectedRoot).toRealPath().toUri().toURL();
        try (URLClassLoader loader = new URLClassLoader(new URL[] { actual }, null)) {
            Class<?> target = Class.forName(TARGET, true, loader);
            URL code = target.getProtectionDomain().getCodeSource().getLocation();
            if (target.getClassLoader() != loader || !code.toURI().normalize().equals(expected.toURI().normalize()))
                throw new IllegalStateException("wrong CodeSource: " + code + " expected " + expected);
            Field observed = target.getField("observed");
            observed.setInt(null, 0);
            Method method = target.getMethod(c.method, c.parameterTypes);
            String exception = "none";
            String returned = "unset";
            try {
                Object result = method.invoke(null, c.arguments);
                returned = String.valueOf(result);
            } catch (InvocationTargetException error) {
                Throwable cause = error.getCause();
                exception = cause == null ? "unknown" : cause.getClass().getName();
            }
            System.out.println("CASE name=" + c.name + " method=" + c.method
                    + " exception=" + exception + " returned=" + b64(returned)
                    + " observed=" + observed.getInt(null) + " trace=" + traceOf(c.arguments));
        }
    }

    private static List<Case> cases() {
        List<Case> result = new ArrayList<Case>();
        result.add(one("ancestor-empty", "ancestor", "normal"));
        result.add(one("ancestor-normal", "ancestor", "normal", "one", "two"));
        result.add(one("ancestor-null-element", "ancestor", "normal", "one", null));
        result.add(one("ancestor-wrong-after-success", "ancestor", "normal", "ok", Integer.valueOf(9)));
        result.add(new Case("ancestor-null-source", "ancestor", new Class<?>[] { List.class }, new Object[] { null }));
        result.add(one("same-list-empty", "sameList", "normal"));
        result.add(one("same-list-normal", "sameList", "normal", "a", "bb"));
        result.add(one("same-list-wrong-element", "sameList", "normal", "x", Integer.valueOf(2)));
        result.add(one("protected-normal", "protectedPositive", "normal", "a", "bb"));
        result.add(one("protected-hasNext-throws", "protectedPositive", "hasNextAfterOne", "a", "b"));
        result.add(one("protected-next-throws", "protectedPositive", "nextAfterOne", "a", "b"));
        result.add(one("protected-before-read", "protectedBeforeRead", "normal", "a", "bb"));
        result.add(one("protected-after-read", "protectedAfterRead", "normal", "a", "bb"));
        result.add(two("protected-after-write", "protectedAfterWrite",
                trace("normal", "a"), trace("normal", "fallback")));
        result.add(two("protected-catch-read-write", "protectedCatchReadWrite",
                trace("nextAfterOne", "a", "b"), trace("normal", "fallback")));
        result.add(two("reused-slots-both", "reusedSlots",
                trace("normal", "x"), trace("normal", "yz")));
        result.add(two("reused-slots-empty-left", "reusedSlots",
                trace("normal"), trace("normal", "right")));
        result.add(new Case("sibling-name-left", "siblingNames",
                new Class<?>[] { List.class, List.class, boolean.class },
                new Object[] { trace("normal", "left"), trace("normal", "right"), Boolean.TRUE }));
        result.add(new Case("sibling-name-right", "siblingNames",
                new Class<?>[] { List.class, List.class, boolean.class },
                new Object[] { trace("normal", "left"), trace("normal", "right"), Boolean.FALSE }));
        return result;
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("usage: actual-class-root expected-CodeSource-root");
        for (Case c : cases()) run(args[0], args[1], c);
    }
}
