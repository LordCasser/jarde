package cf11;

import java.util.Iterator;
import java.util.List;

/** Fresh source family for class-source and runtime controls around ancestor-owned Iterator locals. */
public final class IteratorAncestorCases {
    public static int observed;

    /** Blank declaration in the method owner; initialization and loop are nested below it. */
    public static int ancestor(List<String> values) {
        observed = 0;
        Iterator<String> iterator;
        iterator = values.iterator();
        {
            while (iterator.hasNext()) {
                String item = iterator.next();
                observed += item.length();
            }
        }
        return observed;
    }

    /** Two iterator locals over the identical source list, nested in one another. */
    public static int sameList(List<String> values) {
        observed = 0;
        Iterator<String> outer;
        outer = values.iterator();
        while (outer.hasNext()) {
            String outerValue = outer.next();
            Iterator<String> inner;
            inner = values.iterator();
            while (inner.hasNext()) {
                String innerValue = inner.next();
                observed += outerValue.length();
                observed += innerValue.length();
            }
        }
        return observed;
    }

    /** Ordinary protected loop: the handler records the exception but never reads the iterator. */
    public static int protectedPositive(List<String> values) {
        observed = 0;
        Iterator<String> iterator;
        String item;
        try {
            iterator = values.iterator();
            while (iterator.hasNext()) {
                item = iterator.next();
                observed += item.length();
            }
        } catch (IllegalStateException error) {
            observed += 100;
        }
        return observed;
    }

    /** A same-local read before the protected loop is an intentional closure refusal control. */
    public static int protectedBeforeRead(List<String> values) {
        observed = 0;
        Iterator<String> iterator;
        iterator = values.iterator();
        if (iterator.hasNext()) {
            observed += 10;
        }
        try {
            while (iterator.hasNext()) {
                String item = iterator.next();
                observed += item.length();
            }
        } catch (IllegalStateException error) {
            observed += 100;
        }
        return observed;
    }

    /** A same-local read after the protected loop is an intentional closure refusal control. */
    public static int protectedAfterRead(List<String> values) {
        observed = 0;
        Iterator<String> iterator;
        iterator = values.iterator();
        try {
            while (iterator.hasNext()) {
                String item = iterator.next();
                observed += item.length();
            }
        } catch (IllegalStateException error) {
            observed += 100;
        }
        if (iterator.hasNext()) {
            observed += 10;
        }
        return observed;
    }

    /** A later SSA version of the same Java local must keep the declaration available. */
    public static int protectedAfterWrite(List<String> values, List<String> fallback) {
        observed = 0;
        Iterator<String> iterator;
        String item;
        try {
            iterator = values.iterator();
            while (iterator.hasNext()) {
                item = iterator.next();
                observed += item.length();
            }
        } catch (IllegalStateException error) {
            observed += 100;
        }
        iterator = fallback.iterator();
        if (iterator.hasNext()) {
            observed += 10;
        }
        return observed;
    }

    /** Catch reads the original local, then writes a new iterator value into that same local. */
    public static int protectedCatchReadWrite(List<String> values, List<String> fallback) {
        observed = 0;
        Iterator<String> iterator;
        iterator = values.iterator();
        try {
            while (iterator.hasNext()) {
                String item = iterator.next();
                observed += item.length();
            }
        } catch (IllegalStateException error) {
            if (iterator.hasNext()) {
                observed += 10;
            }
            iterator = fallback.iterator();
            if (iterator.hasNext()) {
                observed += 20;
            }
        }
        return observed;
    }

    /** Disjoint lexical lifetimes encourage one slot to represent two LocalVariable identities. */
    public static int reusedSlots(List<String> first, List<String> second) {
        observed = 0;
        {
            Iterator<String> firstIterator;
            firstIterator = first.iterator();
            while (firstIterator.hasNext()) {
                String item = firstIterator.next();
                observed += item.length();
            }
        }
        {
            Iterator<String> secondIterator;
            secondIterator = second.iterator();
            while (secondIterator.hasNext()) {
                String item = secondIterator.next();
                observed += item.length();
            }
        }
        return observed;
    }

    /** Same spelling in mutually exclusive sibling scopes denotes two source lifetimes. */
    public static int siblingNames(List<String> left, List<String> right, boolean useLeft) {
        observed = 0;
        if (useLeft) {
            Iterator<String> iterator;
            iterator = left.iterator();
            while (iterator.hasNext()) {
                String item = iterator.next();
                observed += item.length();
            }
        } else {
            Iterator<String> iterator;
            iterator = right.iterator();
            while (iterator.hasNext()) {
                String item = iterator.next();
                observed += item.length();
            }
        }
        return observed;
    }
}
