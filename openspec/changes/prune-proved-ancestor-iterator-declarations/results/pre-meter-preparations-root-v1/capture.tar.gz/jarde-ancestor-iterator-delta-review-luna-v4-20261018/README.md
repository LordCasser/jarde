# Pairwise 20-cell API delta check

`check_smoke20_delta.py` is a read-only pairwise content checker for the recorded
20-cell API smoke. It accepts the smoke execution receipt, the matching pair ledger,
and an explicit expected new CLI SHA-256. It reads the prior pinned reports and
the new commands' pinned raw stdout; it does not invoke the CLI or toolchains.

For each of the eight `TestNestedLoops$TestCls.test` pairs and twelve
`IteratorAncestorCases.sameList` pairs, it allows only the one exact iterator
declaration line to disappear from whole-class, public-method, and raw-method text;
the corresponding direct store-origin map span to be removed with coordinate
shifts; the artifact binding's byte count and FNV-1a-128 digest to be recomputed;
and the single `jre_recovery_produced` diagnostic to change by exactly one
statement, one segment, and the removed UTF-8 byte count. Old diagnostic metrics
must agree with the old raw source-map segment count and UTF-8 text byte length.
All other JSON must match exactly after recursively omitting only `usage` keys.
The checker confirms direct store BCIs 33 (original class) or 36 (controls), new
foreach tests at BCIs 42 or 43 respectively, retained next@47 mapping, stable BCI
sets and method identity, and UTF-8-valid source-map byte coordinates.

Example invocation against the already-recorded smoke:

```sh
python3 -B check_smoke20_delta.py \
  --execution /path/to/execution.json \
  --pairs /path/to/pairs.json \
  --expected-cli-sha256 60e1b07691100a238c7462a400b381a2be923b366278349f1562f69d3d890ba5 \
  --out /path/to/new-private-result.json
```

The exact 20-pair comparison passed and is recorded at
`results/smoke20-utf8-validated.json`. This is only a pairwise API-output delta
check: the source receipt remains `commands_passed_pending_independent_acceptance`,
and this result does not establish full-matrix, runtime, or product acceptance.
Earlier rejected attempts in `results/` record checker setup errors and are not
acceptance results; the final script and output are the UTF-8-validated run above.

The earlier checker at `/private/tmp/jarde-ancestor-iterator-delta-review-luna-v3-20261018/check_same_list_delta.py`
is preserved unchanged.
