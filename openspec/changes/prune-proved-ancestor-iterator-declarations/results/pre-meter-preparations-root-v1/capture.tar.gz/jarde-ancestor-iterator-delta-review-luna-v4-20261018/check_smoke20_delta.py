#!/usr/bin/env python3
"""Exact old/new JSON delta checker for the frozen 20-cell API smoke."""
from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import sys

BASELINE_CLI_SHA256 = "c688920cac70ee9e46681672ebaaba5df2948c5ef5b5f262d006548ca1f83ebe"
FNV_OFFSET = 0x6C62272E07BB014262B821756295C58D
FNV_PRIME = 0x1000000000000000000013B
MASK128 = (1 << 128) - 1
METRICS = re.compile(
    r"(?P<regions>[0-9]+) region\(s\), (?P<statements>[0-9]+) statement\(s\), "
    r"(?P<segments>[0-9]+) segment\(s\), (?P<bytes>[0-9]+) byte\(s\) written from "
    r"(?P<blocks>[0-9]+) canonical block\(s\)"
)


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def fnv128(data: bytes) -> str:
    value = FNV_OFFSET
    for byte in data:
        value = ((value ^ byte) * FNV_PRIME) & MASK128
    return f"{value:032x}"


def remove_line(text: str, exact: bytes, label: str):
    raw = text.encode("utf-8")
    offset = 0
    matches = []
    for line in raw.splitlines(keepends=True):
        content = line[:-1] if line.endswith(b"\n") else line
        if content.endswith(b"\r"):
            content = content[:-1]
        if content.lstrip(b" \t") == exact:
            need(line.endswith(b"\n"), f"{label}: target line must end in newline")
            matches.append((offset, offset + len(line), line))
        offset += len(line)
    need(len(matches) == 1, f"{label}: expected one exact target declaration, got {len(matches)}")
    start, end, line = matches[0]
    return (raw[:start] + raw[end:]).decode("utf-8"), start, end, line


def method_identity(method: dict) -> dict:
    identity = method.get("item", {}).get("identity")
    need(isinstance(identity, dict), "method identity missing")
    return identity


def target_method(doc: dict, role: str) -> dict:
    if role == "original":
        name, descriptor = list(b"test"), list(b"(Ljava/util/List;Ljava/util/List;)V")
    else:
        name, descriptor = list(b"sameList"), list(b"(Ljava/util/List;)I")
    rows = [m for m in doc.get("methods", [])
            if method_identity(m).get("name") == name
            and method_identity(m).get("descriptor") == descriptor]
    need(len(rows) == 1, f"expected one target {role} physical method, got {len(rows)}")
    return rows[0]


def origin_is_target(origin: dict, identity: dict) -> bool:
    method = origin.get("method")
    return isinstance(method, dict) and all(
        method.get(key) == identity.get(key) for key in ("name", "descriptor", "owner")
    )


def bci_set(source_map: dict) -> set[int]:
    out = set()
    for segment in source_map["segments"]:
        origin = segment["origin"]
        out.add(origin["primary"]["bci"])
        out.update(row["bci"] for row in origin.get("derived", []))
    return out


def validate_utf8_map(text: str, source_map: dict, label: str) -> None:
    raw = text.encode("utf-8")
    segments = source_map.get("segments")
    need(isinstance(segments, list), f"{label}: source-map segments missing")
    for segment in segments:
        left, right = segment.get("start"), segment.get("end")
        need(isinstance(left, int) and isinstance(right, int) and 0 <= left <= right <= len(raw),
             f"{label}: invalid source-map byte interval {left}:{right}")
        try:
            raw[:left].decode("utf-8", "strict")
            raw[left:right].decode("utf-8", "strict")
            raw[right:].decode("utf-8", "strict")
        except UnicodeDecodeError as exc:
            raise ValueError(f"{label}: source-map coordinate is not a UTF-8 boundary: {left}:{right}") from exc


def shift_coord(value: int, start: int, end: int) -> int:
    if value <= start:
        return value
    if value >= end:
        return value - (end - start)
    raise ValueError(f"unrelated map coordinate {value} overlaps deleted declaration")


def transform_map(old_map: dict, start: int, end: int, identity: dict, store_bci: int) -> list[dict]:
    segments = old_map.get("segments")
    need(isinstance(segments, list), "target old raw source map missing segments")
    targets = [s for s in segments if (s.get("start"), s.get("end")) == (start, end)]
    need(len(targets) == 1, f"expected exact target line map span, got {len(targets)}")
    target = targets[0]
    origin = target.get("origin", {})
    primary = origin.get("primary", {})
    need(primary.get("bci") == store_bci and primary.get("provenance") == "Direct",
         f"deleted declaration is not direct store@{store_bci}")
    need(origin_is_target(primary, identity), "deleted declaration belongs to another physical method")
    need(origin.get("derived") == [], "deleted direct declaration unexpectedly has derived origins")
    expected = []
    for segment in segments:
        if segment is target:
            continue
        left, right = segment["start"], segment["end"]
        overlaps = left < end and right > start
        encloses = left <= start and right >= end
        need(not overlaps or encloses,
             f"non-enclosing source-map span overlaps the removed bytes: {left}:{right}")
        copied = deepcopy(segment)
        copied["start"] = shift_coord(left, start, end)
        copied["end"] = shift_coord(right, start, end)
        expected.append(copied)
    return expected


def parse_metrics(diagnostic: dict, label: str) -> dict[str, int]:
    match = METRICS.fullmatch(diagnostic.get("message", ""))
    need(match is not None, f"{label}: jre_recovery_produced message has unexpected form")
    return {key: int(value) for key, value in match.groupdict().items()}


def ignore_usage(value):
    if isinstance(value, list):
        return [ignore_usage(item) for item in value]
    if isinstance(value, dict):
        return {k: ignore_usage(v) for k, v in value.items() if k != "usage"}
    return value


def pin(path: Path, expected_bytes: int, expected_sha: str, label: str) -> bytes:
    data = path.read_bytes()
    need(len(data) == expected_bytes and sha(data) == expected_sha, f"{label}: byte/SHA pin mismatch")
    return data


def apply_expected_delta(old: dict, role: str, profile: str) -> tuple[dict, dict]:
    expected = deepcopy(old)
    if role == "original":
        method_name = "test(Ljava/util/List;Ljava/util/List;)V"
        target_line, store_bci, foreach_bci = b"java.util.Iterator local5;", 33, 42
    else:
        method_name = "sameList(Ljava/util/List;)I"
        if profile.endswith("debug") and not profile.endswith("no-debug"):
            target_line = b"java.util.Iterator inner;"
        else:
            target_line = b"java.util.Iterator local3;"
        store_bci, foreach_bci = 36, 43

    method = target_method(expected, role)
    identity = method_identity(method)
    raw = method.get("outcome", {}).get("report", {})
    need(isinstance(raw, dict), f"{method_name}: raw method report missing")
    raw_text = raw.get("text")
    need(isinstance(raw_text, str), f"{method_name}: raw method text missing")
    transformed_raw, start, end, removed = remove_line(raw_text, target_line, "old raw method")
    for label, container, key in (("whole-class text", expected, "text"),
                                  ("public method text", method, "text"),
                                  ("raw method text", raw, "text")):
        value = container.get(key)
        need(isinstance(value, str), f"{label} missing")
        container[key] = remove_line(value, target_line, label)[0]

    source_map = raw.get("source_map")
    need(isinstance(source_map, dict), f"{method_name}: raw source map missing")
    validate_utf8_map(raw_text, source_map, "old raw method")
    old_map_segments = source_map.get("segments")
    need(isinstance(old_map_segments, list), "old source map segments missing")
    old_bcis = bci_set(source_map)
    source_map["segments"] = transform_map(source_map, start, end, identity, store_bci)

    binding = raw.get("artifact", {}).get("binding")
    need(isinstance(binding, dict), f"{method_name}: artifact binding missing")
    old_bytes = raw_text.encode("utf-8")
    new_bytes = transformed_raw.encode("utf-8")
    need(binding.get("text_bytes") == len(old_bytes), "old artifact text_bytes differs from raw UTF-8")
    need(binding.get("text_digest") == fnv128(old_bytes), "old artifact text_digest differs from raw FNV-1a-128")
    binding["text_bytes"] = len(new_bytes)
    binding["text_digest"] = fnv128(new_bytes)

    diagnostics = raw.get("diagnostics")
    need(isinstance(diagnostics, list), "target report diagnostics missing")
    produced = [d for d in diagnostics if d.get("code") == "jre_recovery_produced"]
    need(len(produced) == 1, "expected one jre_recovery_produced diagnostic")
    metrics = parse_metrics(produced[0], "old")
    need(metrics["segments"] == len(old_map_segments), "diagnostic segment count differs from old map")
    need(metrics["bytes"] == len(old_bytes), "diagnostic byte count differs from old raw UTF-8")
    need(metrics["statements"] >= 1 and metrics["segments"] >= 1,
         "diagnostic counts cannot sustain exact one-statement/segment deletion")
    expected_metrics = dict(metrics)
    expected_metrics["statements"] -= 1
    expected_metrics["segments"] -= 1
    expected_metrics["bytes"] -= len(removed)
    produced[0]["message"] = (
        f"{expected_metrics['regions']} region(s), {expected_metrics['statements']} statement(s), "
        f"{expected_metrics['segments']} segment(s), {expected_metrics['bytes']} byte(s) written from "
        f"{expected_metrics['blocks']} canonical block(s)"
    )

    expected_map = raw["source_map"]
    need(len(expected_map["segments"]) == len(old_map_segments) - 1,
         "expected map did not remove exactly one span")
    return expected, {"method": method_name, "line": target_line.decode(), "span": [start, end],
        "bytes_removed": len(removed), "store_bci": store_bci, "foreach_bci": foreach_bci,
        "metrics_old": metrics, "metrics_expected_new": expected_metrics, "old_bcis": sorted(old_bcis)}


def validate_new_target(old: dict, new: dict, role: str, details: dict) -> None:
    om, nm = target_method(old, role), target_method(new, role)
    oi, ni = method_identity(om), method_identity(nm)
    need(oi == ni, "target physical method identity changed")
    old_raw = om["outcome"]["report"]
    new_raw = nm["outcome"]["report"]
    need(old_raw.get("quality") == new_raw.get("quality"), "target raw quality changed")
    need(old_raw.get("fallbacks") == new_raw.get("fallbacks"), "target raw fallback set changed")
    new_map = new_raw.get("source_map")
    need(isinstance(new_map, dict), "new target raw map missing")
    validate_utf8_map(new_raw.get("text", ""), new_map, "new raw method")
    need(bci_set(new_map) == set(details["old_bcis"]), "mapped physical BCI set changed")
    store, loop = details["store_bci"], details["foreach_bci"]
    loop_rows = [s for s in new_map["segments"]
                 if s["origin"]["primary"].get("bci") == loop
                 and store in {r.get("bci") for r in s["origin"].get("derived", [])}]
    need(len(loop_rows) == 1, f"foreach test@{loop} does not uniquely retain derived store@{store}")
    next_rows = [s for s in new_map["segments"] if s["origin"]["primary"].get("bci") == 47]
    need(len(next_rows) == 1, "physical next@47 lacks one direct source-map segment")
    for segment in new_map["segments"]:
        origin = segment["origin"]
        need(origin_is_target(origin["primary"], ni), "new map contains a foreign primary origin")
        for derived in origin.get("derived", []):
            need(origin_is_target(derived, ni), "new map contains a foreign derived origin")


def check_pair(pair: dict, execution: dict, expected_cli_sha: str) -> dict:
    index, role, profile, evidence = pair["index"], pair["role"], pair["profile"], pair["evidence"]
    old_argv, new_argv = pair.get("old_argv"), pair.get("new_argv")
    need(isinstance(old_argv, list) and isinstance(new_argv, list), f"pair {index}: argv missing")
    need(old_argv[1:] == new_argv[1:], f"pair {index}: old/new API argv differ beyond executable")
    need(sha(Path(old_argv[0]).read_bytes()) == BASELINE_CLI_SHA256, f"pair {index}: baseline CLI pin differs")
    need(sha(Path(new_argv[0]).read_bytes()) == expected_cli_sha, f"pair {index}: final CLI pin differs")
    old_input = Path(old_argv[old_argv.index("--input") + 1])
    new_input = Path(new_argv[new_argv.index("--input") + 1])
    need(old_input.resolve() == new_input.resolve() and old_input.is_file(), f"pair {index}: physical input differs/missing")

    old_pin = pair.get("old_report", {})
    old_bytes = pin(Path(old_pin["path"]), old_pin["bytes"], old_pin["sha256"], f"pair {index} old report")
    old_doc = json.loads(old_bytes.decode("utf-8", "strict"))
    commands = [c for c in execution.get("commands", []) if c.get("index") == index]
    need(len(commands) == 1, f"pair {index}: expected one actual smoke command")
    command = commands[0]
    need(command.get("argv") == new_argv and command.get("exit_code") == 0,
         f"pair {index}: actual command argv/exit differs from pair ledger")
    stdout = command.get("streams", {}).get("stdout", {})
    new_bytes = pin(Path(stdout["path"]), stdout["bytes"], stdout["sha256"], f"pair {index} stdout")
    need(not command.get("streams", {}).get("stderr", {}).get("bytes", -1), f"pair {index}: stderr is not empty")
    new_doc = json.loads(new_bytes.decode("utf-8", "strict"))
    need(new_doc.get("execution", {}).get("status") == "complete", f"pair {index}: API output incomplete")
    need(old_doc.get("class") == new_doc.get("class"), f"pair {index}: class identity changed")
    need(old_doc.get("view") == new_doc.get("view"), f"pair {index}: view changed")
    old_method, new_method = target_method(old_doc, role), target_method(new_doc, role)
    need(method_identity(old_method) == method_identity(new_method), f"pair {index}: target identity changed")

    expected, delta = apply_expected_delta(old_doc, role, profile)
    validate_new_target(old_doc, new_doc, role, delta)
    need(ignore_usage(expected) == ignore_usage(new_doc),
         f"pair {index}: unexplained non-usage JSON difference outside exact declaration/map/digest/diagnostic delta")
    return {"index": index, "role": role, "profile": profile, "evidence": evidence,
        "method": delta["method"], "removed_line": delta["line"], "removed_span": delta["span"],
        "removed_utf8_bytes": delta["bytes_removed"], "direct_store_bci": delta["store_bci"],
        "foreach_test_bci": delta["foreach_bci"], "diagnostic_old": delta["metrics_old"],
        "diagnostic_expected_new": delta["metrics_expected_new"],
        "compared": "full JSON exact after only specified one-line/map/binding-FNV/diagnostic transform and recursive usage omission"}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--execution", type=Path, required=True)
    ap.add_argument("--pairs", type=Path, required=True)
    ap.add_argument("--expected-cli-sha256", required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args(argv)
    if args.out.exists():
        raise SystemExit(f"refusing existing output: {args.out}")
    if not args.out.parent.exists():
        raise SystemExit("output parent must already exist")
    try:
        execution = read_json(args.execution)
        pairs = read_json(args.pairs)
        need(execution.get("status") == "commands_passed_pending_independent_acceptance",
             "unexpected smoke receipt state; this checker only consumes the recorded pending-acceptance smoke")
        need(isinstance(pairs, list) and len(pairs) == 20, "expected the frozen 20 API pair ledger")
        need([p.get("index") for p in pairs] == list(range(1, 21)), "pair ledger indices are not exactly 1..20")
        results = [check_pair(pair, execution, args.expected_cli_sha256) for pair in pairs]
        result = {"status": "pairwise_smoke_exact_delta_pass_not_product_acceptance",
            "execution": str(args.execution), "execution_sha256": sha(args.execution.read_bytes()),
            "pairs": str(args.pairs), "pairs_sha256": sha(args.pairs.read_bytes()),
            "expected_new_cli_sha256": args.expected_cli_sha256,
            "baseline_cli_sha256": BASELINE_CLI_SHA256, "checked_pairs": len(results),
            "results": results,
            "acceptance_note": "This is only a pairwise API-output delta check. It does not establish full matrix, runtime, source closure, or product acceptance."}
        args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(json.dumps({"status": result["status"], "checked_pairs": len(results),
                          "execution_sha256": result["execution_sha256"],
                          "new_cli_sha256": args.expected_cli_sha256}, indent=2))
        return 0
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        result = {"status": "rejected", "reason": str(exc), "execution": str(args.execution),
                  "pairs": str(args.pairs), "expected_new_cli_sha256": args.expected_cli_sha256}
        args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(result["reason"], file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
