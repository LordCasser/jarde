# Ancestor iterator cleanup test supplement (v6)

Test-only patch based on current shared `build.rs`; v5 is preserved. No shared source was edited and no toolchain was run.

Base SHA-256: `1748eee485dccaea29ac45c0098b2da064f9fe156fe8ee04beeaf55e57b1f5a6`.
Changed private file SHA-256: `e875ae418e0a3898959fa6efbbd0db6c2b33d098ef69bb7159d9cab2990db6b7`.
Patch SHA-256: `f05a62b6b42a47a675ebc704c15b15c98814301536b9d3464a8757bef3f32f29`.

This carries forward v5's AST/refusal/atomicity/checkpoint coverage. In `mixedIterator`, the extra-store assertion now passes the real `hasNext` and `next` load BCIs, so it isolates the second same-LocalVariable store. The `iinc` case now uses the existing `ForConditionReads.class` method `sumWithArrayLength([I)I`; it first asserts that the counter has exactly one store and two loads, passes those exact BCIs, then verifies the increment makes the gate refuse. These are physical-helper gate checks, not claims that either method reaches or passes the old foreach candidate. No tests were run.
