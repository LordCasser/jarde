# Follow-up: shared v3/focused-fix snapshot (static only)

Root reported the focused v1 build failure and applied a minimal correction. Current inspected `crates/jarde-java/src/build.rs` SHA-256 is `9625f60a081ecfed461214b9776c477769c2dcb93668c78f25efa1565682084f`; `tests/p3_hoisted_iterator_foreach.rs` remains `8a86063889dbff8a1b486e528bd6bde966bdcd37e935ed76dc6dcb092ae118c8`.

The prior candidate expression `OriginSet::mentions(anchor).is_some_and(...)` was wrong for the current API: `mentions` yields `Provenance`, not an `Origin`. The current code instead scans `statement.origin.derived()` and requires the anchor BCI, `Provenance::Derived`, and no foreign method (build.rs 8884-8889). Its preceding charge covers `derived.len()+1`; the outer AST visit polls before the statement. This matches the intended “foreach source retains the declaration store” check. The test Builder initializer now includes the consumer vector (build.rs 43221).

The physical-access helper remains as reviewed: per instruction poll and AnalysisSteps charge; complete Code and operand lockstep; load/store/iinc/ret slot opcodes; target LocalVariable mapping; exact three BCI closure. The revised “missing operation” regression now passes the original `code` together with `Operations::of(incomplete_code, ...)` after removing BCI 35 from the latter, so the original full Code reaches `operations.get(35) == None`; the separate misaligned Code test remains. This closes the v2 test gap statically.

No compiler or focused test was run by this reviewer. Root's guarded Cargo execution owns that result; this note is not a build-pass claim.
