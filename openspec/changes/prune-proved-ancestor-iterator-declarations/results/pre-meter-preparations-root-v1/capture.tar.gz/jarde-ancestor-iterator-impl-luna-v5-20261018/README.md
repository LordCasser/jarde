# Ancestor iterator cleanup test supplement (v5)

Test-only patch against the current shared `build.rs`; v4 remains frozen. No shared files were edited and no toolchain was run.

Base SHA-256: `1748eee485dccaea29ac45c0098b2da064f9fe156fe8ee04beeaf55e57b1f5a6`.
Changed private file SHA-256: `11b4653b8ec015af93b723d76e1046f7f102cc4ac8bd50067000b0f18ead2014`.
Patch SHA-256: `7c0eb54cb137e579c5cd330838c05259f86ffb72bfe03d260217135fd617930f`.

The patch includes v4's AST refusal cases, conflicting/unrelated relation cases, deadline/cancellation atomicity, and checkpoint prefix restoration. It removes the invalid two-element physical-access expectation. On the existing real `mixedIterator` class control, it now checks that both iterator stores resolve to the same physical LocalVariable and that the full-access gate refuses the extra write. It also locates the class's real `seen++` `iinc` and verifies the gate refuses that operation for its local. These are gate-level helper checks; they do not claim the old foreach candidate accepted the control.

The existing split-slot declaration-gate unit remains as-is and covers two different LocalVariable identities sharing slot 3. No new fixture was added. The patch has not been compiled or run.
