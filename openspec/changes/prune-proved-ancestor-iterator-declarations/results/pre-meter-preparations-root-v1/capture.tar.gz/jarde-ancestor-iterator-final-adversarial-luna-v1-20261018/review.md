# Ancestor iterator cleanup: final read-only adversarial review

This is a static code review only. No Cargo, Java, CLI, Git, or network command was run. The parent reported the completed broad gate (810 pass, 0 fail, 6 ignored); I did not rerun it and do not treat this review as test evidence.

## Source pins

- `crates/jarde-java/src/build.rs` — SHA-256 `1f8c39ada4667294a069785fdc3a64316dc812b04c63130bc8df83e9819a9a74`
- `tests/structured_list_generic_bodies.rs` — SHA-256 `2aa41c5c61addd03a65264703031c18be7c5dfd9e51786968627f84cd13c421b`
- `tests/p3_hoisted_iterator_foreach.rs` — SHA-256 `8a86063889dbff8a1b486e528bd6bde966bdcd37e935ed76dc6dcb092ae118c8`
- Physical control inputs: `HoistedIteratorPhiControls.class` — `31cd1bcbcd906ac5249ba6b917660774658b157964451136bbb3b86bc694ccda`; `ForConditionReads.class` — `7664451909614ce76d089ede2cac5b7529c939fc565d4aede24f419825c7925e`.

## Findings

I found no semantic false-removal path in the reviewed cleanup flow. The candidate records a `(LocalVariable, foreach test BCI)` only after the physical use gate passes and the `ForEach` push succeeds (`build.rs:24301-24323`, `21355-21368`). The physical gate scans decoded instructions and their aligned operands across the full method, uses effective opcodes, requires exactly one matching store and two matching loads at the expected anchors, and rejects local `iinc`, unknown/missing operations, and misaligned facts (`13645-13723`). `iterator_declaration_for_loop` verifies all three candidate BCIs resolve to the same `LocalVariable`, then requires a unique planned elevated owner/anchor and source-visible gap conditions (`13730-13919`). The final removal additionally requires a unique consumer relation by both variable and test BCI, unique direct own-origin declaration and loop anchors, matching Iterator type/name, lexical visibility in the actual statement tree, and the loop’s own derived source anchor (`8716-8978`).

The recursive inspection keeps visibility local to each child list: `If` branches, switch arms, try bodies/catches/finally, and loop bodies are visited independently; `For` init/update are inspected with declarations disallowed (`8913-8964`). Removal follows only a node proven removable by that full-tree inspection. It charges/polls each encountered statement and charges the shifted `Vec` tail before `remove`, then decrements the count only after success (`8982-9094`). A Stop during candidate proof propagates before the foreach is accepted (`24318-24340`); a Stop during final prune returns from `build` before `Program` is returned (`9642-9654`). Builder checkpoints restore the append-only relation vector to its captured length (`17960-17994`), and the consumer relation is charged before append (`21359-21367`).

The v6/v7 tests cover the core adversarial cases: distinct `LocalVariable`s sharing a slot (`39685-39720`); two real writes to one local with the real expected receiver-load BCIs and an exact one-store/two-load loop counter with `iinc` (`40021-40166`); conflicting versus unrelated consumer relations, same-anchor non-declaration, initialized declaration, sibling visibility, `for`-init visibility, derived-only/foreign-origin rejection, deadline, and cancellation immediately before removal (`38723-39079`); checkpoint prefix truncation (`43867-43875`). Public coverage checks both nested headers and preserved source behavior, and checks that the exact blank declaration is absent from projected and raw method text (`structured_list_generic_bodies.rs:1780-1865`; `p3_hoisted_iterator_foreach.rs:154-223`). The nested late-stop test binary-searches cancellation and analysis-budget boundaries around a run that folds both heads, then verifies no partial fold and raw source-map equality (`structured_list_generic_bodies.rs:2320-2460`).

One narrow accounting gap remains: the new tree walks charge/poll every statement, but the loops over `SwitchArm`s and try `catches` do not charge or poll for each container when its child body is empty (`build.rs:8933-8947`, `9051-9077`). Statement-heavy arms are paid by their children, and upstream AST construction has its own costs, but arbitrarily many empty arms/clauses add iteration work not directly accounted in this pass. It does not change removal eligibility, and a stop after a later non-empty node still aborts atomically; the concern is cancellation responsiveness and local work accounting for the empty-container path.

## Boundaries not directly exercised

- No new fixture forces a successful foreach relation to be appended inside a speculative finally child and then rolled back by a later child Stop. The checkpoint test directly verifies prefix preservation/truncation, while broader checkpoint and public late-stop tests cover rollback and publication behavior separately.
- Origin tests cover derived-only declarations and a foreign derived loop anchor; they do not synthesize a direct local declaration primary with an unrelated foreign derived origin attached.
- Switch/catch empty-container billing/responsiveness has no dedicated stress test.
