# Ancestor iterator cleanup acceptance preparation (pending)

This private bundle adapts existing acceptance tooling only; it contains no product run or acceptance result.

- CI collector and proof helper are byte-for-byte from `/private/tmp/jarde-foreach-local-bindings-own-ci-prep-luna-v2-20261018`. `verify-own-ci.py` preserves its 61 gates and adds exactly two `jarde_java` tests, for 63 total. It retains the existing 13-source/5-fixture inventory and all workflow/API/official ZIP, two-seed and named-outcome checks.
- Native wrapper is based on `/private/tmp/jarde-foreach-local-bindings-own-ci-prep-luna-v3-20261018/verify_typed_foreach.py`, whose pinned base checker has the corrected `jarde` root-library gate classification. It appends the same two exact `jarde_java` identities, for 18 gates, and preserves both named seed checks, 385-target baseline, metadata/Running binding, and per-target comparison.
- No fixture or Cargo target is added. Product SHA, CI run id, native receipt paths, actual pass totals, and final acceptance remain pending root collection/review.

The two added names are `build::tests::ancestor_iterator_cleanup_closes_the_complete_physical_local_variable` and `build::tests::ancestor_iterator_cleanup_requires_unique_direct_visible_iterator_row`. Other physical-local and same-BCI boundary assertions remain covered by existing tests; this bundle does not add gates for them.

`verify-own-ci.diff` and `verify-native.diff` are the only verifier changes. Base pin files and this README are provenance; the `native-v3-base-README.md` is an unchanged historical copy.
