# Final-capture API report binding reviewer

`review_final_bindings.py` is prepared for a read-only run after the final controls
capture reaches its terminal state. It aligns the accepted API smoke's 8 original
and 12 controls rows with the fresh complete captures by `(role, profile,
input_form, evidence)`, then checks the full API JSON for exact equality after
recursively omitting only `usage` keys. It independently reads each actual class
or class archive, verifies the extracted class against the capture's pinned
`source_profiles.class_tree` bytes, and requires those raw class bytes to equal
the corresponding smoke input bytes. It also verifies the fresh CLI pin, actual
command input/class, command stdout/report pins, and final source/target guards.

The smoke's complete API argv and the fresh capture's actual argv are both
recorded in the result, with an explicit `argv_identical` value. The checker does
not represent the fresh captures as same-argv reruns. Runtime/JDK checks remain
the responsibility of their separate full-capture reviews; this checker only
binds API reports and physical inputs.

Run after the controls receipt is terminal:

```sh
python3 -B review_final_bindings.py \
  --smoke-execution /private/tmp/jarde-ancestor-iterator-api-smoke-root-v1-20261018/execution.json \
  --smoke-pairs /private/tmp/jarde-ancestor-iterator-api-smoke-prep-root-v1-20261018/pairs.json \
  --smoke-result /private/tmp/jarde-ancestor-iterator-delta-review-luna-v4-20261018/results/smoke20-utf8-validated.json \
  --original-execution /private/tmp/jarde-ancestor-iterator-original-root-v1-20261018/execution.json \
  --controls-execution /private/tmp/jarde-ancestor-iterator-controls-final-root-v1-20261018/execution.json \
  --out /private/tmp/jarde-ancestor-iterator-final-bind-review-luna-v1-20261018/results/final-bindings.json
```

The checker requires the frozen final CLI SHA-256
`60e1b07691100a238c7462a400b381a2be923b366278349f1562f69d3d890ba5`, the accepted
v4 smoke result, the original final capture, all 20 unique selectors, and both
final guards. Only the original receipt and smoke artifacts were inspected while
preparing this script; the controls receipt was not read or evaluated. The script
has been syntax-parsed. An isolated 8-row preflight against the reviewed original
receipt passed; it is marked `original_8_row_preflight_pass_not_final_binding_acceptance`
in `results/original-8-preflight.json`. The controls receipt was not read, and no
20-row final binding result has been produced.

Prepared input pins:

- Smoke execution: SHA-256 `94c1e5187a38b4e098cd51198ccf2e85f68b3dbf481960f7341773009e245293`.
- Smoke selector ledger: SHA-256 `50256024f488b8cfd6961c3564d34f0e947217a5695b837ce407a41df4798753`.
- Accepted v4 pairwise result: SHA-256 `72cc6be55c5925b67f7166f3d04954a616586876af03d9b15a341a587c549701`.
- v4 pairwise checker: SHA-256 `133384dcb964dbf82ec52425ecaab0970a7e779888e1642de340333bd2211341`.
- Fresh original capture: SHA-256 `555507fc5e9c48b9feba1b62b8adb08d731f2d75547c857f2a942e54c71b006e`.
