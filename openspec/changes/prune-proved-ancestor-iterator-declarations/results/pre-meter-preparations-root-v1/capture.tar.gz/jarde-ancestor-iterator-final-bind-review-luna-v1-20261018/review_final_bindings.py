#!/usr/bin/env python3
"""Bind the accepted 20-pair API smoke reports to fresh full-run API reports."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
import zipfile

EXPECTED_CLI_SHA256 = "60e1b07691100a238c7462a400b381a2be923b366278349f1562f69d3d890ba5"
SMOKE_RESULT_SHA256 = "72cc6be55c5925b67f7166f3d04954a616586876af03d9b15a341a587c549701"
SMOKE_CHECKER_SHA256 = "133384dcb964dbf82ec52425ecaab0970a7e779888e1642de340333bd2211341"
SMOKE_EXECUTION_SHA256 = "94c1e5187a38b4e098cd51198ccf2e85f68b3dbf481960f7341773009e245293"
SMOKE_PAIRS_SHA256 = "50256024f488b8cfd6961c3564d34f0e947217a5695b837ce407a41df4798753"


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def read_pin(pin: dict, label: str) -> bytes:
    need(isinstance(pin, dict), f"{label}: missing file pin")
    path = Path(pin["path"])
    data = path.read_bytes()
    need(len(data) == pin["bytes"] and sha(data) == pin["sha256"], f"{label}: pin mismatch")
    return data


def strip_usage(value):
    if isinstance(value, list):
        return [strip_usage(item) for item in value]
    if isinstance(value, dict):
        return {key: strip_usage(item) for key, item in value.items() if key != "usage"}
    return value


def selector(role: str, profile: str, input_form, evidence: str) -> tuple:
    return role, profile, input_form, evidence


def target_class(role: str) -> str:
    if role == "original":
        return "jadx/tests/integration/loops/TestNestedLoops$TestCls.class"
    need(role == "controls", f"unknown role {role}")
    return "cf11/IteratorAncestorCases.class"


def class_from_input(path: Path, internal_name: str, label: str) -> bytes:
    need(path.is_file(), f"{label}: actual API input missing: {path}")
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as archive:
            names = archive.namelist()
            need(names.count(internal_name) == 1, f"{label}: expected exactly one {internal_name} in input archive")
            return archive.read(internal_name)
    return path.read_bytes()


def report_from_command(execution: dict, command_index: int, expected_argv: list, label: str) -> tuple[dict, dict]:
    rows = [c for c in execution.get("commands", []) if c.get("index") == command_index]
    need(len(rows) == 1, f"{label}: command index {command_index} missing/duplicated")
    command = rows[0]
    need(command.get("exit_code") == 0 and command.get("argv") == expected_argv,
         f"{label}: command argv or exit does not match its recorded selector")
    stream = command.get("streams", {}).get("stdout", {})
    raw = read_pin(stream, f"{label} stdout")
    need(not command.get("streams", {}).get("stderr", {}).get("bytes", -1),
         f"{label}: stdout command has nonempty stderr")
    return json.loads(raw.decode("utf-8", "strict")), command


def full_run_cells(receipt: dict, role: str, label: str) -> dict:
    cells = receipt.get("jarde_cells")
    need(isinstance(cells, list), f"{label}: jarde_cells missing")
    out = {}
    for cell in cells:
        key = selector(role, cell.get("profile"), cell.get("input_form"), cell.get("evidence"))
        need(key not in out, f"{label}: duplicate API selector {key}")
        out[key] = cell
    return out


def pair_smoke_records(pairs: list, smoke_execution: dict) -> dict:
    commands = {c.get("index"): c for c in smoke_execution.get("commands", [])}
    out = {}
    for pair in pairs:
        key = selector(pair["role"], pair["profile"], pair.get("input_form"), pair["evidence"])
        need(key not in out, f"smoke pair ledger: duplicate selector {key}")
        index = pair["index"]
        command = commands.get(index)
        need(command is not None, f"smoke pair {index}: command missing")
        report, _ = report_from_command(smoke_execution, index, pair["new_argv"], f"smoke pair {index}")
        out[key] = {"pair": pair, "command": command, "report": report,
                    "input_path": Path(pair["new_argv"][pair["new_argv"].index("--input") + 1]),
                    "argv": pair["new_argv"]}
    return out


def verify_receipt_cli(receipt: dict, label: str) -> dict:
    pin = receipt.get("cli")
    data = read_pin(pin, f"{label} CLI")
    digest = sha(data)
    need(digest == EXPECTED_CLI_SHA256, f"{label}: CLI hash {digest} differs from expected final CLI")
    return pin


def validate_cell(receipt: dict, cell: dict, role: str, selector_key: tuple, label: str) -> dict:
    need(cell.get("exit_code") == 0, f"{label}: API cell did not exit 0")
    internal = target_class(role)
    command_rows = [c for c in receipt.get("commands", []) if c.get("index") == cell.get("command")]
    need(len(command_rows) == 1, f"{label}: API command record missing")
    command = command_rows[0]
    argv = command.get("argv", [])
    need(command.get("exit_code") == 0, f"{label}: actual API command did not exit 0")
    need("--input" in argv, f"{label}: API command has no --input")
    input_path = Path(argv[argv.index("--input") + 1])
    need("--class" in argv and argv[argv.index("--class") + 1] == internal.removesuffix(".class"),
         f"{label}: command class does not match selector's physical target")
    source_rows = [row for row in receipt.get("source_profiles", []) if row.get("profile") == selector_key[1]]
    need(len(source_rows) == 1, f"{label}: unique physical source profile missing")
    class_pin = source_rows[0].get("class_tree", {}).get(internal)
    need(isinstance(class_pin, dict), f"{label}: source profile does not pin target class bytes")
    source_class = read_pin(class_pin, f"{label} physical target class")
    cell_input_pin = cell.get("input")
    if cell_input_pin is not None:
        read_pin(cell_input_pin, f"{label} CLI input")
        need(Path(cell_input_pin["path"]).resolve() == input_path.resolve(),
             f"{label}: command input differs from cell input pin")
    api_input_class = class_from_input(input_path, internal, f"{label} command input")
    need(api_input_class == source_class,
         f"{label}: API command's actual class bytes differ from pinned physical source profile")
    class_bytes = source_class
    report_raw = read_pin(cell.get("report"), f"{label} report")
    stdout_raw = read_pin(command.get("streams", {}).get("stdout", {}), f"{label} stdout")
    need(report_raw == stdout_raw, f"{label}: report pin is not exact API stdout")
    report = json.loads(report_raw.decode("utf-8", "strict"))
    need(report.get("execution", {}).get("status") == "complete", f"{label}: API report incomplete")
    class_identity = report.get("class", {}).get("class_bytes", {})
    need(class_identity.get("length") == len(class_bytes), f"{label}: report class byte length differs from physical input")
    return {"report": report, "report_pin": cell["report"], "input_pin": cell_input_pin,
            "class_pin": class_pin,
            "class_bytes": class_bytes, "class_sha256": sha(class_bytes), "argv": argv,
            "command_index": cell["command"], "selector": selector_key}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--smoke-execution", type=Path, required=True)
    ap.add_argument("--smoke-pairs", type=Path, required=True)
    ap.add_argument("--smoke-result", type=Path, required=True)
    ap.add_argument("--original-execution", type=Path, required=True)
    ap.add_argument("--controls-execution", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args(argv)
    if args.out.exists():
        raise SystemExit(f"refusing existing output {args.out}")
    if not args.out.parent.exists():
        raise SystemExit("output parent must exist")
    try:
        smoke_exec = load_json(args.smoke_execution)
        pairs = load_json(args.smoke_pairs)
        smoke_result = load_json(args.smoke_result)
        original_exec = load_json(args.original_execution)
        controls_exec = load_json(args.controls_execution)

        need(sha(args.smoke_execution.read_bytes()) == SMOKE_EXECUTION_SHA256, "smoke execution pin differs")
        need(sha(args.smoke_pairs.read_bytes()) == SMOKE_PAIRS_SHA256, "smoke pair-ledger pin differs")
        need(sha(args.smoke_result.read_bytes()) == SMOKE_RESULT_SHA256, "accepted v4 smoke result pin differs")
        need(smoke_result.get("status") == "pairwise_smoke_exact_delta_pass_not_product_acceptance"
             and smoke_result.get("checked_pairs") == 20, "v4 smoke checker result is not the accepted 20-pair result")
        need(smoke_result.get("execution_sha256") == SMOKE_EXECUTION_SHA256
             and smoke_result.get("expected_new_cli_sha256") == EXPECTED_CLI_SHA256,
             "v4 result is bound to a different smoke execution or CLI")
        need(len(pairs) == 20, "smoke pair ledger is not complete 20-cell set")
        need(smoke_exec.get("status") == "commands_passed_pending_independent_acceptance",
             "smoke receipt status changed; this checker expects the recorded pending-acceptance capture")

        original_cli = verify_receipt_cli(original_exec, "fresh original capture")
        controls_cli = verify_receipt_cli(controls_exec, "fresh controls capture")
        for label, receipt in (("fresh original capture", original_exec),
                               ("fresh controls capture", controls_exec)):
            need(receipt.get("source_unchanged_finally") is True,
                 f"{label}: final source closure guard is not true")
            need(receipt.get("target_absent_finally") is True,
                 f"{label}: final target-absent guard is not true")
        smoke_records = pair_smoke_records(pairs, smoke_exec)
        original_cells = full_run_cells(original_exec, "original", "fresh original capture")
        controls_cells = full_run_cells(controls_exec, "controls", "fresh controls capture")

        expected_original = {key for key in smoke_records if key[0] == "original"}
        expected_controls = {key for key in smoke_records if key[0] == "controls"}
        need(len(expected_original) == 8 and len(expected_controls) == 12,
             "smoke selector ledger no longer has the frozen 8+12 family counts")
        need(set(original_cells) == expected_original,
             f"fresh original selectors differ: missing={sorted(expected_original-set(original_cells))} extra={sorted(set(original_cells)-expected_original)}")
        need(set(controls_cells) == expected_controls,
             f"fresh controls selectors differ: missing={sorted(expected_controls-set(controls_cells))} extra={sorted(set(controls_cells)-expected_controls)}")

        results = []
        for key in sorted(smoke_records):
            smoke = smoke_records[key]
            role = key[0]
            final_receipt = original_exec if role == "original" else controls_exec
            final_cells = original_cells if role == "original" else controls_cells
            full = validate_cell(final_receipt, final_cells[key], role, key, f"final {key}")
            smoke_class = class_from_input(smoke["input_path"], target_class(role), f"smoke {key}")
            need(smoke_class == full["class_bytes"], f"{key}: raw class bytes differ between smoke and fresh full capture")
            need(strip_usage(smoke["report"]) == strip_usage(full["report"]),
                 f"{key}: full API JSON differs from smoke outside recursively omitted usage fields")
            # The command paths intentionally differ between smoke and complete collection.
            results.append({"role": role, "profile": key[1], "input_form": key[2], "evidence": key[3],
                "class_bytes": len(smoke_class), "class_sha256": sha(smoke_class),
                "smoke_argv": smoke["argv"], "fresh_argv": full["argv"],
                "argv_identical": smoke["argv"] == full["argv"],
                "smoke_report": smoke["command"]["streams"]["stdout"],
                "fresh_report": full["report_pin"],
                "comparison": "full JSON exactly equal after recursive usage-key omission"})

        result = {"status": "fresh_api_reports_bound_to_smoke_nonusage_exact_not_product_acceptance",
            "smoke_execution": str(args.smoke_execution), "smoke_execution_sha256": SMOKE_EXECUTION_SHA256,
            "smoke_pairs_sha256": SMOKE_PAIRS_SHA256, "smoke_v4_result_sha256": SMOKE_RESULT_SHA256,
            "smoke_checker_sha256": SMOKE_CHECKER_SHA256,
            "original_execution": str(args.original_execution),
            "original_execution_sha256": sha(args.original_execution.read_bytes()),
            "original_receipt_status": original_exec.get("status"), "original_cli": original_cli,
            "controls_execution": str(args.controls_execution),
            "controls_execution_sha256": sha(args.controls_execution.read_bytes()),
            "controls_receipt_status": controls_exec.get("status"), "controls_cli": controls_cli,
            "expected_cli_sha256": EXPECTED_CLI_SHA256, "checked_api_cells": len(results),
            "argv_identical_count": sum(row["argv_identical"] for row in results),
            "argv_different_count": sum(not row["argv_identical"] for row in results),
            "results": results,
            "acceptance_note": "This binds fresh full-run API reports to the already-checked smoke outputs and physical class bytes. It does not assert same argv for fresh captures or independently re-evaluate runtime semantics; Java/JADX runtime acceptance belongs to the separate full-capture reviewers."}
        args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(json.dumps({"status": result["status"], "checked_api_cells": len(results),
                          "argv_identical_count": result["argv_identical_count"],
                          "argv_different_count": result["argv_different_count"],
                          "original_status": result["original_receipt_status"],
                          "controls_status": result["controls_receipt_status"]}, indent=2))
        return 0
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError, zipfile.BadZipFile) as exc:
        result = {"status": "rejected", "reason": str(exc),
                  "smoke_execution": str(args.smoke_execution),
                  "original_execution": str(args.original_execution),
                  "controls_execution": str(args.controls_execution)}
        args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(result["reason"], file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
