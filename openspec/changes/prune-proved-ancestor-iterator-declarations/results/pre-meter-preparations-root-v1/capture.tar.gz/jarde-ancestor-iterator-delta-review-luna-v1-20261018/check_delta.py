#!/usr/bin/env python3
"""Read-only exact delta check for the TestNestedLoops ancestor iterator declaration."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

TARGET = b"java.util.Iterator local5;"
METHOD_NAME = list(b"test")
METHOD_DESC = list(b"(Ljava/util/List;Ljava/util/List;)V")
INIT_STORE_BCI = 33
INNER_TEST_BCI = 42


def need(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def read_json(path: Path) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    need(isinstance(data, dict), f"{path}: expected JSON object")
    return data


def remove_exact_line(text: str, label: str) -> tuple[str, int, int, bytes]:
    raw = text.encode("utf-8")
    lines = raw.splitlines(keepends=True)
    offset = 0
    matches: list[tuple[int, int, bytes]] = []
    for line in lines:
        content = line[:-1] if line.endswith(b"\n") else line
        if content.endswith(b"\r"):
            content = content[:-1]
        body = content.lstrip(b" \t")
        if body == TARGET:
            need(line.endswith(b"\n"), f"{label}: declaration line must end in newline")
            matches.append((offset, offset + len(line), line))
        offset += len(line)
    need(len(matches) == 1, f"{label}: expected exactly one declaration line, got {len(matches)}")
    start, end, removed = matches[0]
    changed = (raw[:start] + raw[end:]).decode("utf-8")
    return changed, start, end, removed


def method_identity(method: dict) -> dict:
    identity = method.get("item", {}).get("identity")
    need(isinstance(identity, dict), "method has no item.identity")
    return identity


def find_test_method(report: dict) -> dict:
    found = []
    for method in report.get("methods", []):
        identity = method_identity(method)
        name = identity.get("name", {}).get("raw")
        descriptor = identity.get("descriptor", {}).get("raw")
        if name == METHOD_NAME and descriptor == METHOD_DESC:
            found.append(method)
    need(len(found) == 1, f"expected one physical test method, got {len(found)}")
    return found[0]


def origin_method_matches(origin: dict, identity: dict) -> bool:
    method = origin.get("method")
    return (
        isinstance(method, dict)
        and method.get("name") == identity.get("name", {}).get("raw")
        and method.get("descriptor") == identity.get("descriptor", {}).get("raw")
        and method.get("owner") == identity.get("owner")
    )


def normalize_public(value):
    """Drop usage and text/map-derived presentation fields; retain all other JSON facts."""
    if isinstance(value, list):
        return [normalize_public(item) for item in value]
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            if key in {"usage", "text", "source_map", "text_bytes", "text_digest", "output_bytes"}:
                continue
            if key == "message" and "code" in value and "severity" in value:
                continue
            result[key] = normalize_public(item)
        return result
    return value


def map_bcis(source_map: dict) -> set[int]:
    result: set[int] = set()
    for segment in source_map.get("segments", []):
        origin = segment["origin"]
        result.add(origin["primary"]["bci"])
        result.update(row["bci"] for row in origin.get("derived", []))
    return result


def transformed_segments(old_map: dict, start: int, end: int, identity: dict) -> list[dict]:
    segments = old_map.get("segments")
    need(isinstance(segments, list), "raw method report has no source_map.segments")
    targets = [s for s in segments if s.get("start") == start and s.get("end") == end]
    need(len(targets) == 1, f"expected one map segment exactly covering removed declaration, got {len(targets)}")
    target = targets[0]
    primary = target["origin"]["primary"]
    need(primary.get("bci") == INIT_STORE_BCI and primary.get("provenance") == "Direct",
         "removed segment is not the direct init-store@33 declaration origin")
    need(origin_method_matches(primary, identity), "removed declaration origin belongs to another method")
    need(not target["origin"].get("derived"), "declaration segment unexpectedly has derived origins")

    width = end - start
    result = []
    for segment in segments:
        left, right = segment.get("start"), segment.get("end")
        need(isinstance(left, int) and isinstance(right, int) and 0 <= left <= right,
             "malformed source-map segment coordinates")
        if segment is target:
            continue
        # A segment may enclose the deleted statement, but no unrelated segment may partially
        # start or end inside the removed byte interval.
        need(not (start < left < end or start < right < end),
             f"unrelated map segment endpoint falls inside removed interval: {left}:{right}")
        adjusted = dict(segment)
        if left >= end:
            adjusted["start"] = left - width
        if right >= end:
            adjusted["end"] = right - width
        result.append(adjusted)
    return result


def check(old_path: Path, new_path: Path) -> dict:
    old, new = read_json(old_path), read_json(new_path)
    need(old.get("class") == new.get("class"), "input class identity changed")
    need(old.get("view") == new.get("view"), "class view changed")
    need(normalize_public(old) == normalize_public(new),
         "non-usage public report facts changed beyond text/map-derived fields")

    old_method, new_method = find_test_method(old), find_test_method(new)
    old_identity, new_identity = method_identity(old_method), method_identity(new_method)
    need(old_identity == new_identity, "test method identity changed")

    for label, a, b in (
        ("class projection", old.get("text"), new.get("text")),
        ("method projection", old_method.get("text"), new_method.get("text")),
        ("raw method", old_method.get("outcome", {}).get("report", {}).get("text"),
         new_method.get("outcome", {}).get("report", {}).get("text")),
    ):
        need(isinstance(a, str) and isinstance(b, str), f"missing {label} text")
        expected, _, _, _ = remove_exact_line(a, f"old {label}")
        need(b == expected, f"{label} changed beyond deleting the one Iterator local5 line")

    old_raw = old_method["outcome"]["report"]
    new_raw = new_method["outcome"]["report"]
    need(old_raw.get("quality") == new_raw.get("quality"), "method quality changed")
    need(old_raw.get("fallbacks") == new_raw.get("fallbacks"), "method fallback facts changed")
    old_raw_text = old_raw["text"]
    _, start, end, _ = remove_exact_line(old_raw_text, "old raw method")
    old_map, new_map = old_raw.get("source_map"), new_raw.get("source_map")
    need(isinstance(old_map, dict) and isinstance(new_map, dict), "missing raw method source map")
    expected_segments = transformed_segments(old_map, start, end, old_identity)
    need(new_map.get("segments") == expected_segments,
         "raw method map differs beyond deleting declaration span and shifting later coordinates")
    need(map_bcis(old_map) == map_bcis(new_map), "mapped physical BCI set changed")

    loop_segments = [
        segment for segment in new_map["segments"]
        if segment["origin"]["primary"].get("bci") == INNER_TEST_BCI
        and INIT_STORE_BCI in {row.get("bci") for row in segment["origin"].get("derived", [])}
    ]
    need(len(loop_segments) == 1,
         "inner foreach no longer uniquely retains the init-store@33 source origin")
    need(all(origin_method_matches(row, old_identity) for segment in loop_segments
             for row in [segment["origin"]["primary"], *segment["origin"].get("derived", [])]),
         "foreach source map contains a foreign method origin")
    return {
        "status": "exact_delta_pass",
        "old_report": str(old_path),
        "new_report": str(new_path),
        "method": "test(Ljava/util/List;Ljava/util/List;)V",
        "raw_method_removed_utf8_span": [start, end],
        "removed_bytes": end - start,
        "mapped_bci_count": len(map_bcis(new_map)),
        "foreach_test_bci": INNER_TEST_BCI,
        "retained_init_store_bci": INIT_STORE_BCI,
        "class_projection_map": "not exposed/checked; method raw map was checked only against raw method text",
        "acceptance_note": "This checks a supplied old/new pair only; it does not establish provenance, execution, or release acceptance."
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("old", type=Path)
    parser.add_argument("new", type=Path)
    parser.add_argument("reportout", type=Path)
    args = parser.parse_args(argv)
    try:
        result = check(args.old, args.new)
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        result = {"status": "rejected", "reason": str(exc), "old_report": str(args.old), "new_report": str(args.new)}
        args.reportout.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        print(result["reason"], file=sys.stderr)
        return 1
    args.reportout.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
