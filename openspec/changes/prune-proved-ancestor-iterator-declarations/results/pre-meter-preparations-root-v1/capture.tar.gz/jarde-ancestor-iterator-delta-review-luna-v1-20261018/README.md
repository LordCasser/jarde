# Ancestor iterator exact-delta checker (prepared, not run)

`check_delta.py OLD_REPORT.json NEW_REPORT.json REPORT_OUT.json` is a stdlib-only review helper for the fixed `TestNestedLoops$TestCls.test(List,List)` report pair.

It checks three separate text planes: the top-level complete class projection, the public method projection, and `methods[].outcome.report.text` (the raw method text). Each must equal the old text with exactly one `java.util.Iterator local5;` line removed and every other byte unchanged. It compares stable public JSON facts after excluding usage and text/map-derived fields, while separately requiring method quality and fallback facts to remain equal.

Only `outcome.report.source_map` is interpreted as the raw method map. The checker requires one direct init-store@33 segment exactly covering the removed raw line, removes that segment, applies the exact UTF-8 coordinate shift to remaining segments, and requires all origins to remain identical. It then verifies that the inner foreach segment (primary BCI 42) still carries BCI 33 as a derived origin and that the mapped BCI union is unchanged. It deliberately does not treat a raw method map as a map for the full class projection.

This is a narrow pairwise delta check. It does not validate receipt pins, command provenance, complete-class inventory, compilation/runtime behavior, or acceptance status. It was not run because no new final report was supplied; self-comparison would fail by design because it expects the old declaration to be removed.
