#!/usr/bin/env python3
"""Strict pairwise delta check for the fixed TestNestedLoops raw/class report."""
from __future__ import annotations

import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys

TARGET = b"java.util.Iterator local5;"
METHOD_NAME = list(b"test")
METHOD_DESC = list(b"(Ljava/util/List;Ljava/util/List;)V")
INIT_STORE_BCI = 33
INNER_TEST_BCI = 42


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def read_doc(path: Path) -> dict:
    obj = json.loads(path.read_text(encoding="utf-8"))
    need(isinstance(obj, dict), f"{path}: expected JSON object")
    return obj


def remove_one_line(text: str, label: str) -> tuple[str, int, int, bytes]:
    raw = text.encode("utf-8")
    offset = 0
    found = []
    for line in raw.splitlines(keepends=True):
        content = line[:-1] if line.endswith(b"\n") else line
        if content.endswith(b"\r"):
            content = content[:-1]
        if content.lstrip(b" \t") == TARGET:
            need(line.endswith(b"\n"), f"{label}: matching declaration must end in newline")
            found.append((offset, offset + len(line), line))
        offset += len(line)
    need(len(found) == 1, f"{label}: expected exactly one declaration line, got {len(found)}")
    start, end, line = found[0]
    return (raw[:start] + raw[end:]).decode("utf-8"), start, end, line


def identity_of(method: dict) -> dict:
    ident = method.get("item", {}).get("identity")
    need(isinstance(ident, dict), "method item.identity missing")
    need(isinstance(ident.get("name"), list) and isinstance(ident.get("descriptor"), list),
         "expected item.identity name/descriptor integer arrays")
    return ident


def test_method(doc: dict) -> dict:
    rows = []
    for method in doc.get("methods", []):
        ident = identity_of(method)
        if ident["name"] == METHOD_NAME and ident["descriptor"] == METHOD_DESC:
            rows.append(method)
    need(len(rows) == 1, f"expected exactly one test(List,List) method, got {len(rows)}")
    return rows[0]


def origin_belongs_to(origin: dict, ident: dict) -> bool:
    method = origin.get("method")
    return (
        isinstance(method, dict)
        and method.get("name") == ident["name"]
        and method.get("descriptor") == ident["descriptor"]
        and method.get("owner") == ident.get("owner")
    )


def bci_set(source_map: dict) -> set[int]:
    result = set()
    for segment in source_map.get("segments", []):
        origin = segment["origin"]
        result.add(origin["primary"]["bci"])
        result.update(row["bci"] for row in origin.get("derived", []))
    return result


def utf8_boundary(raw: bytes, pos: int) -> bool:
    if not 0 <= pos <= len(raw):
        return False
    try:
        raw[:pos].decode("utf-8")
        raw[pos:].decode("utf-8")
        return True
    except UnicodeDecodeError:
        return False


def validate_raw_map(text: str, source_map: dict, label: str) -> None:
    raw = text.encode("utf-8")
    segs = source_map.get("segments")
    need(isinstance(segs, list), f"{label}: source_map.segments missing")
    for segment in segs:
        left, right = segment.get("start"), segment.get("end")
        need(isinstance(left, int) and isinstance(right, int) and left <= right,
             f"{label}: malformed segment coordinates")
        need(utf8_boundary(raw, left) and utf8_boundary(raw, right),
             f"{label}: source-map endpoint is not a UTF-8 scalar boundary: {left}:{right}")
        raw[left:right].decode("utf-8")


def expected_raw_segments(old_map: dict, start: int, end: int, ident: dict) -> list[dict]:
    old_segments = old_map.get("segments")
    need(isinstance(old_segments, list), "old raw method map has no segments")
    target_rows = [s for s in old_segments if s.get("start") == start and s.get("end") == end]
    need(len(target_rows) == 1, f"expected one exact declaration map span, got {len(target_rows)}")
    target = target_rows[0]
    primary = target.get("origin", {}).get("primary", {})
    need(primary.get("bci") == INIT_STORE_BCI and primary.get("provenance") == "Direct",
         "deleted map span is not direct init-store@33")
    need(origin_belongs_to(primary, ident), "deleted declaration map span belongs to a different method")
    need(not target["origin"].get("derived"), "deleted declaration origin unexpectedly has derived sources")

    width = end - start

    def shifted(pos: int) -> int:
        if pos <= start:
            return pos
        if pos >= end:
            return pos - width
        raise ValueError(f"unrelated map endpoint {pos} lies inside removed line")

    result = []
    for segment in old_segments:
        if segment is target:
            continue
        left, right = segment["start"], segment["end"]
        # A composite segment may enclose the deleted statement; no other segment may partially
        # map the deleted bytes as if they survived.
        overlaps = left < end and right > start
        encloses = left <= start and right >= end
        need(not overlaps or encloses,
             f"unrelated map segment overlaps removed declaration: {left}:{right}")
        changed = deepcopy(segment)
        changed["start"] = shifted(left)
        changed["end"] = shifted(right)
        result.append(changed)
    return result


def prepare_expected(old: dict) -> tuple[dict, dict]:
    expected = deepcopy(old)
    method = test_method(expected)
    raw_method = method.get("outcome", {}).get("report", {})
    need(isinstance(raw_method, dict), "target method raw report missing")
    raw_text = raw_method.get("text")
    need(isinstance(raw_text, str), "target raw method text missing")
    changed_raw, start, end, removed = remove_one_line(raw_text, "old raw method")

    # Apply the one intended presentation edit to exactly the three report text planes.
    for label, container, key in (
        ("top-level class projection", expected, "text"),
        ("public method projection", method, "text"),
        ("raw method", raw_method, "text"),
    ):
        text = container.get(key)
        need(isinstance(text, str), f"{label}: text missing")
        changed, _, _, _ = remove_one_line(text, f"old {label}")
        container[key] = changed

    old_map = raw_method.get("source_map")
    need(isinstance(old_map, dict), "target raw method source map missing")
    expected_segments = expected_raw_segments(old_map, start, end, identity_of(method))
    raw_method["source_map"]["segments"] = expected_segments
    return expected, {
        "start": start,
        "end": end,
        "removed_bytes": len(removed),
        "changed_raw": changed_raw,
    }


def ignore_usage(value):
    if isinstance(value, list):
        return [ignore_usage(item) for item in value]
    if isinstance(value, dict):
        return {key: ignore_usage(item) for key, item in value.items() if key != "usage"}
    return value


def validate_binding_and_map(old: dict, new: dict, span: dict) -> dict:
    old_method, new_method = test_method(old), test_method(new)
    old_ident, new_ident = identity_of(old_method), identity_of(new_method)
    need(old_ident == new_ident, "physical method identity changed")
    old_raw = old_method["outcome"]["report"]
    new_raw = new_method["outcome"]["report"]
    need(old_raw.get("quality") == new_raw.get("quality"), "method quality changed")
    need(old_raw.get("fallbacks") == new_raw.get("fallbacks"), "method fallbacks changed")
    old_map, new_map = old_raw["source_map"], new_raw["source_map"]
    validate_raw_map(old_raw["text"], old_map, "old raw method")
    validate_raw_map(new_raw["text"], new_map, "new raw method")

    need(bci_set(old_map) == bci_set(new_map), "mapped physical BCI set changed")
    loops = [
        seg for seg in new_map["segments"]
        if seg["origin"]["primary"].get("bci") == INNER_TEST_BCI
        and INIT_STORE_BCI in {row.get("bci") for row in seg["origin"].get("derived", [])}
    ]
    need(len(loops) == 1, "inner foreach does not uniquely retain derived init-store@33")
    for segment in new_map["segments"]:
        origin = segment["origin"]
        need(origin_belongs_to(origin["primary"], new_ident), "raw map has a foreign primary method origin")
        for derived in origin.get("derived", []):
            need(origin_belongs_to(derived, new_ident), "raw map has a foreign derived method origin")
    return {
        "mapped_bci_count": len(bci_set(new_map)),
        "inner_foreach_test_bci": INNER_TEST_BCI,
        "retained_init_store_bci": INIT_STORE_BCI,
        "raw_utf8_bytes": len(new_raw["text"].encode("utf-8")),
    }


def write_result(path: Path, result: dict) -> None:
    path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("old", type=Path)
    parser.add_argument("new", type=Path)
    parser.add_argument("reportout", type=Path)
    parser.add_argument("--selftest-old", action="store_true",
                        help="parse a real old report twice and confirm old==old is rejected as a missing delta")
    args = parser.parse_args(argv)
    try:
        old, new = read_doc(args.old), read_doc(args.new)
        expected, span = prepare_expected(old)
        if args.selftest_old:
            need(old == new, "selftest requires identical old JSON inputs")
            need(ignore_usage(expected) != ignore_usage(new),
                 "selftest expected delta did not differ from unchanged old report")
            result = {
                "status": "old_json_parse_selftest_pass_not_delta_acceptance",
                "old_report": str(args.old),
                "same_old_input_rejected_as_missing_delta": True,
                "expected_removed_span_utf8": [span["start"], span["end"]],
                "note": "Schema/text/map parsing only; this is not a new-output delta pass.",
            }
            write_result(args.reportout, result)
            print(json.dumps(result, indent=2))
            return 0

        need(old.get("class") == new.get("class"), "input class identity changed")
        need(old.get("view") == new.get("view"), "class view changed")
        need(ignore_usage(expected) == ignore_usage(new),
             "old report transformed by the one declared-line/map delta differs elsewhere from new report")
        binding = validate_binding_and_map(old, new, span)
        result = {
            "status": "exact_delta_pass",
            "old_report": str(args.old),
            "new_report": str(args.new),
            "method": "test(Ljava/util/List;Ljava/util/List;)V",
            "removed_raw_utf8_span": [span["start"], span["end"]],
            "removed_bytes": span["removed_bytes"],
            **binding,
            "class_projection_map": "not exposed/checked; raw method map checked only against raw method text",
            "acceptance_note": "Pairwise content check only; receipt/source provenance and execution acceptance are separate.",
        }
        write_result(args.reportout, result)
        print(json.dumps(result, indent=2))
        return 0
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        result = {"status": "rejected", "reason": str(exc), "old_report": str(args.old), "new_report": str(args.new)}
        write_result(args.reportout, result)
        print(result["reason"], file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
