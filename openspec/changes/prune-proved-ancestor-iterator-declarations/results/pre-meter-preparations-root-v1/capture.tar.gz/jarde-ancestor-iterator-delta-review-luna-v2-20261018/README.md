# Ancestor iterator exact-delta checker v2

Run `check_delta.py OLD_REPORT.json NEW_REPORT.json REPORT_OUT.json`. It is stdlib-only and pairwise: the new report must equal the old JSON after exactly three text edits (top-level class projection, target public method projection, and target raw method text), one raw method source-map edit (remove the direct BCI 33 declaration segment and shift later UTF-8 byte coordinates), and recursive removal of `usage` fields only. Every other method, map, diagnostic message and public fact is compared exactly.

The parser uses the observed schema: `item.identity.name` and `.descriptor` are integer arrays. It checks target method binding; raw-map coordinate boundaries on UTF-8 scalar boundaries; exact old source-span transformation; unchanged mapped BCI union and method-local origins; and that the inner foreach at test BCI 42 still carries init-store BCI 33 as a derived origin. The method map is validated against the raw method text only. The checker does not invent a whole-class map.

`--selftest-old` accepts the same actual old report twice, parses and prepares the expected one-line/map transformation, then confirms unchanged old==old cannot satisfy the delta. Its status is explicitly a schema self-test, never delta acceptance. No new CLI/report was available, so v2 was not run against new output.
