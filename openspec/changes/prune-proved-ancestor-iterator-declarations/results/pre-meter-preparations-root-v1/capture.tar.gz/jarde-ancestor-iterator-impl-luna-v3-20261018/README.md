# Proved ancestor iterator declaration pruning — private v3

`changes.patch` contains the production change in `crates/jarde-java/src/build.rs` and focused coverage in `tests/p3_hoisted_iterator_foreach.rs`. It is based on the source copy under `a/`; edited copies are under `b/`.

- Base `build.rs` SHA-256: `e3f201df7bd01b9b0691d5f7229cbfd5efd82ce5b70fdd39f0f003170fe51b39`
- Edited `build.rs` SHA-256: `be2288e020343b311735f4cd0c5a389cde079cd1ad2843371a7d5ca4b6a0a88c`
- Edited public test SHA-256: `8a86063889dbff8a1b486e528bd6bde966bdcd37e935ed76dc6dcb092ae118c8`
- Patch SHA-256: `0864ad8ece5b2b8d47c2fb4b32184c869e98d988003cd3c4c4cae3ff6193b8b3`

The candidate gate scans the complete decoded physical instruction list with a per-instruction budget charge and poll, and requires exactly the expected store plus two loads for one reuse identity. It fails closed on missing local operands or Operations entries. Failed optional proof retains the existing foreach path; Stop propagates. Successful relations are recorded after push and truncated to the checkpoint length on rollback. Final cleanup confirms a unique consumer and planned `Iterator` declaration, a unique exact direct own-methodless AST anchor, actual ancestor visibility, and a direct own-methodless foreach primary whose origins carry the declaration anchor. Removal is charged for shifted rows before mutation. The final pass does not repeat the physical census.

Internal tests cover exact physical access closure, mismatched BCIs, missing operation/misaligned facts, Stop, AST direct-origin/foreign-origin/type/duplicate-plan refusals, and refusal before mutation on budget Stop. The public test strengthens the fixed nested-loop positive by requiring both blank declarations to be absent and checking that physical BCI 33 remains represented on the inner foreach segment, while retaining default/evidence-mode/map parity assertions.

No compiler, tests, formatter, JDK, or Jarde CLI was run under the private-task constraints. Root owns execution and broader control gates.
