#!/usr/bin/env python3
"""Exact sameList blank-local removal checker bound to equal profile/evidence receipts."""
from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

TARGET_BY_PROFILE = {
    "javac8-debug": b"java.util.Iterator inner;",
    "javac23-debug": b"java.util.Iterator inner;",
    "javac8-no-debug": b"java.util.Iterator local3;",
    "javac23-no-debug": b"java.util.Iterator local3;",
}
METHOD_NAME = list(b"sameList")
METHOD_DESC = list(b"(Ljava/util/List;)I")
INIT_STORE_BCI = 36
INNER_TEST_BCI = 43
INNER_NEXT_BCI = 47
PHYSICAL_PARSER = Path("/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py")
PHYSICAL_PARSER_SHA = "c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd"


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def read_doc(path: Path) -> dict:
    obj = json.loads(path.read_text(encoding="utf-8"))
    need(isinstance(obj, dict), f"{path}: expected JSON object")
    return obj


def remove_one_line(text: str, label: str, target: bytes) -> tuple[str, int, int, bytes]:
    raw = text.encode("utf-8")
    offset = 0
    found = []
    for line in raw.splitlines(keepends=True):
        content = line[:-1] if line.endswith(b"\n") else line
        if content.endswith(b"\r"):
            content = content[:-1]
        if content.lstrip(b" \t") == target:
            need(line.endswith(b"\n"), f"{label}: matching declaration must end in newline")
            found.append((offset, offset + len(line), line))
        offset += len(line)
    need(len(found) == 1, f"{label}: expected exactly one declaration line, got {len(found)}")
    start, end, line = found[0]
    return (raw[:start] + raw[end:]).decode("utf-8"), start, end, line


def identity_of(method: dict) -> dict:
    ident = method.get("item", {}).get("identity")
    need(isinstance(ident, dict), "method item.identity missing")
    need(isinstance(ident.get("name"), list) and isinstance(ident.get("descriptor"), list),
         "expected item.identity name/descriptor integer arrays")
    return ident


def same_list_method(doc: dict) -> dict:
    rows = []
    for method in doc.get("methods", []):
        ident = identity_of(method)
        if ident["name"] == METHOD_NAME and ident["descriptor"] == METHOD_DESC:
            rows.append(method)
    need(len(rows) == 1, f"expected exactly one sameList(List) method, got {len(rows)}")
    return rows[0]


def origin_belongs_to(origin: dict, ident: dict) -> bool:
    method = origin.get("method")
    return (
        isinstance(method, dict)
        and method.get("name") == ident["name"]
        and method.get("descriptor") == ident["descriptor"]
        and method.get("owner") == ident.get("owner")
    )


def bci_set(source_map: dict) -> set[int]:
    result = set()
    for segment in source_map.get("segments", []):
        origin = segment["origin"]
        result.add(origin["primary"]["bci"])
        result.update(row["bci"] for row in origin.get("derived", []))
    return result


def utf8_boundary(raw: bytes, pos: int) -> bool:
    if not 0 <= pos <= len(raw):
        return False
    try:
        raw[:pos].decode("utf-8")
        raw[pos:].decode("utf-8")
        return True
    except UnicodeDecodeError:
        return False


def validate_raw_map(text: str, source_map: dict, label: str) -> None:
    raw = text.encode("utf-8")
    segs = source_map.get("segments")
    need(isinstance(segs, list), f"{label}: source_map.segments missing")
    for segment in segs:
        left, right = segment.get("start"), segment.get("end")
        need(isinstance(left, int) and isinstance(right, int) and left <= right,
             f"{label}: malformed segment coordinates")
        need(utf8_boundary(raw, left) and utf8_boundary(raw, right),
             f"{label}: source-map endpoint is not a UTF-8 scalar boundary: {left}:{right}")
        raw[left:right].decode("utf-8")


def expected_raw_segments(old_map: dict, start: int, end: int, ident: dict) -> list[dict]:
    old_segments = old_map.get("segments")
    need(isinstance(old_segments, list), "old raw method map has no segments")
    target_rows = [s for s in old_segments if s.get("start") == start and s.get("end") == end]
    need(len(target_rows) == 1, f"expected one exact declaration map span, got {len(target_rows)}")
    target = target_rows[0]
    primary = target.get("origin", {}).get("primary", {})
    need(primary.get("bci") == INIT_STORE_BCI and primary.get("provenance") == "Direct",
         "deleted map span is not direct init-store@36")
    need(origin_belongs_to(primary, ident), "deleted declaration map span belongs to a different method")
    need(not target["origin"].get("derived"), "deleted declaration origin unexpectedly has derived sources")

    width = end - start

    def shifted(pos: int) -> int:
        if pos <= start:
            return pos
        if pos >= end:
            return pos - width
        raise ValueError(f"unrelated map endpoint {pos} lies inside removed line")

    result = []
    for segment in old_segments:
        if segment is target:
            continue
        left, right = segment["start"], segment["end"]
        # A composite segment may enclose the deleted statement; no other segment may partially
        # map the deleted bytes as if they survived.
        overlaps = left < end and right > start
        encloses = left <= start and right >= end
        need(not overlaps or encloses,
             f"unrelated map segment overlaps removed declaration: {left}:{right}")
        changed = deepcopy(segment)
        changed["start"] = shifted(left)
        changed["end"] = shifted(right)
        result.append(changed)
    return result


def prepare_expected(old: dict, profile: str) -> tuple[dict, dict]:
    expected = deepcopy(old)
    target = TARGET_BY_PROFILE[profile]
    method = same_list_method(expected)
    raw_method = method.get("outcome", {}).get("report", {})
    need(isinstance(raw_method, dict), "target method raw report missing")
    raw_text = raw_method.get("text")
    need(isinstance(raw_text, str), "target raw method text missing")
    changed_raw, start, end, removed = remove_one_line(raw_text, "old raw method", target)

    # Apply the one intended presentation edit to exactly the three report text planes.
    for label, container, key in (
        ("top-level class projection", expected, "text"),
        ("public method projection", method, "text"),
        ("raw method", raw_method, "text"),
    ):
        text = container.get(key)
        need(isinstance(text, str), f"{label}: text missing")
        changed, _, _, _ = remove_one_line(text, f"old {label}", target)
        container[key] = changed

    old_map = raw_method.get("source_map")
    need(isinstance(old_map, dict), "target raw method source map missing")
    expected_segments = expected_raw_segments(old_map, start, end, identity_of(method))
    raw_method["source_map"]["segments"] = expected_segments
    return expected, {
        "start": start,
        "end": end,
        "removed_bytes": len(removed),
        "changed_raw": changed_raw,
    }


def ignore_usage(value):
    if isinstance(value, list):
        return [ignore_usage(item) for item in value]
    if isinstance(value, dict):
        return {key: ignore_usage(item) for key, item in value.items() if key != "usage"}
    return value


def validate_binding_and_map(old: dict, new: dict, span: dict) -> dict:
    old_method, new_method = same_list_method(old), same_list_method(new)
    old_ident, new_ident = identity_of(old_method), identity_of(new_method)
    need(old_ident == new_ident, "physical method identity changed")
    old_raw = old_method["outcome"]["report"]
    new_raw = new_method["outcome"]["report"]
    need(old_raw.get("quality") == new_raw.get("quality"), "method quality changed")
    need(old_raw.get("fallbacks") == new_raw.get("fallbacks"), "method fallbacks changed")
    old_map, new_map = old_raw["source_map"], new_raw["source_map"]
    validate_raw_map(old_raw["text"], old_map, "old raw method")
    validate_raw_map(new_raw["text"], new_map, "new raw method")

    need(bci_set(old_map) == bci_set(new_map), "mapped physical BCI set changed")
    loops = [
        seg for seg in new_map["segments"]
        if seg["origin"]["primary"].get("bci") == INNER_TEST_BCI
        and INIT_STORE_BCI in {row.get("bci") for row in seg["origin"].get("derived", [])}
    ]
    need(len(loops) == 1, "inner foreach does not uniquely retain derived init-store@36")
    need(INNER_NEXT_BCI in bci_set(new_map), "inner next@47 is missing from the raw source map")
    next_rows=[seg for seg in new_map["segments"] if seg["origin"]["primary"].get("bci")==INNER_NEXT_BCI]
    need(len(next_rows)==1, "inner next@47 does not have one direct primary source-map segment")
    for segment in new_map["segments"]:
        origin = segment["origin"]
        need(origin_belongs_to(origin["primary"], new_ident), "raw map has a foreign primary method origin")
        for derived in origin.get("derived", []):
            need(origin_belongs_to(derived, new_ident), "raw map has a foreign derived method origin")
    return {
        "mapped_bci_count": len(bci_set(new_map)),
        "inner_foreach_test_bci": INNER_TEST_BCI,
        "retained_init_store_bci": INIT_STORE_BCI,
        "inner_next_bci": INNER_NEXT_BCI,
        "raw_utf8_bytes": len(new_raw["text"].encode("utf-8")),
    }


def write_result(path: Path, result: dict) -> None:
    path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def pin_bytes(pin: dict, label: str) -> bytes:
    need(isinstance(pin, dict) and {"path", "bytes", "sha256"} <= set(pin), f"{label}: malformed file pin")
    path=Path(pin["path"])
    data=path.read_bytes()
    need(len(data)==pin["bytes"] and __import__("hashlib").sha256(data).hexdigest()==pin["sha256"],
         f"{label}: file pin mismatch")
    return data


def load_cell(execution_path: Path, profile: str, evidence: str, label: str) -> tuple[dict, dict, dict]:
    receipt=read_doc(execution_path)
    need(receipt.get("phase") in ("baseline","final"), f"{label}: execution phase missing")
    rows=[c for c in receipt.get("jarde_cells",[]) if c.get("profile")==profile and c.get("evidence")==evidence]
    need(len(rows)==1, f"{label}: expected exactly one API cell for {profile}/{evidence}, got {len(rows)}")
    cell=rows[0]
    need(cell.get("exit_code")==0 and cell.get("source_ready") is True,
         f"{label}: API cell is not a successful complete source cell")
    report_pin=cell.get("report")
    raw=pin_bytes(report_pin, f"{label} API report")
    doc=json.loads(raw.decode("utf-8","strict"))
    commands={r.get("index"):r for r in receipt.get("commands",[])}
    command=commands.get(cell.get("command"))
    need(command is not None and command.get("label")==f"jarde-{profile}-{evidence}",
         f"{label}: API command ledger binding missing")
    need(command.get("exit_code")==0, f"{label}: API command did not exit 0")
    streams=command.get("streams",{})
    stdout_pin=streams.get("stdout")
    need(pin_bytes(stdout_pin,f"{label} API stdout")==raw, f"{label}: API report is not exact stdout")
    argv=command.get("argv",[])
    need("--input" in argv and "--class" in argv, f"{label}: API argv lacks explicit class input")
    input_path=Path(argv[argv.index("--input")+1])
    class_tree=next((r for r in receipt.get("source_profiles",[]) if r.get("profile")==profile),None)
    need(class_tree is not None, f"{label}: physical profile class facts missing")
    target_pin=class_tree.get("class_tree",{}).get("cf11/IteratorAncestorCases.class")
    need(target_pin is not None, f"{label}: target physical class pin missing")
    target_bytes=pin_bytes(target_pin,f"{label} physical class")
    need(input_path.resolve()==Path(target_pin["path"]).resolve(), f"{label}: API argv does not use the pinned original class")
    need(argv[argv.index("--class")+1]=="cf11/IteratorAncestorCases", f"{label}: API class identity differs")
    fact=class_tree.get("class_facts",{}).get("cf11/IteratorAncestorCases.class",{})
    physical=[m for m in fact.get("methods",[]) if (m.get("name"),m.get("descriptor"))==("sameList","(Ljava/util/List;)I")]
    need(len(physical)==1, f"{label}: physical sameList method missing/duplicated")
    bcis=set((physical[0].get("code") or {}).get("bcis",[]))
    need({INIT_STORE_BCI,INNER_TEST_BCI,INNER_NEXT_BCI} <= bcis,
         f"{label}: expected physical store/test/next BCIs 36/43/47 missing")
    parser_bytes=PHYSICAL_PARSER.read_bytes()
    need(hashlib.sha256(parser_bytes).hexdigest()==PHYSICAL_PARSER_SHA,"pinned independent class parser changed")
    spec=importlib.util.spec_from_file_location("same_list_delta_physical_parser",PHYSICAL_PARSER)
    need(spec is not None and spec.loader is not None,"cannot load pinned independent class parser")
    parser_module=importlib.util.module_from_spec(spec); spec.loader.exec_module(parser_module)
    actual_class=parser_module.parse_class_file(target_bytes)
    need(actual_class.get("class_name")=="cf11/IteratorAncestorCases" and actual_class.get("major")==52,
         f"{label}: independent parser class identity/version differs")
    actual_methods=[m for m in actual_class.get("methods",[]) if (m.get("name"),m.get("descriptor"))==("sameList","(Ljava/util/List;)I")]
    need(len(actual_methods)==1 and actual_methods[0].get("code")==physical[0].get("code"),
         f"{label}: receipt BCI facts differ from independent parse of actual class bytes")
    need(doc.get("execution",{}).get("status")=="complete", f"{label}: API report execution incomplete")
    need(cell.get("api_status")=="complete", f"{label}: receipt API status incomplete")
    cli_pin=receipt.get("cli")
    cli_data=pin_bytes(cli_pin,f"{label} CLI")
    if receipt.get("phase")=="baseline":
        need(cli_pin.get("sha256")=="c688920cac70ee9e46681672ebaaba5df2948c5ef5b5f262d006548ca1f83ebe",
             f"{label}: baseline CLI pin is not the frozen baseline")
    cbytes=doc.get("class",{}).get("class_bytes",{})
    need(cbytes.get("length")==len(target_bytes), f"{label}: API class byte length differs from physical input")
    return receipt,doc,{"report_pin":report_pin,"class_pin":target_pin,"class_facts":fact,
        "class_digest":cbytes.get("digest"),"cli_pin":cli_pin,"profile":profile,"evidence":evidence,
        "physical_bcis":sorted(bcis),"physical_parser_sha256":PHYSICAL_PARSER_SHA,
        "phase":receipt.get("phase"),"receipt_sha256":__import__("hashlib").sha256(execution_path.read_bytes()).hexdigest()}


def main(argv: list[str] | None = None) -> int:
    parser=argparse.ArgumentParser()
    parser.add_argument("--old-execution",type=Path,required=True)
    parser.add_argument("--new-execution",type=Path)
    parser.add_argument("--profile",choices=("javac8-debug","javac8-no-debug","javac23-debug","javac23-no-debug"),required=True)
    parser.add_argument("--evidence",choices=("default","all","source_map"),required=True)
    parser.add_argument("--out",type=Path,required=True)
    parser.add_argument("--selftest-old",action="store_true",
        help="parse a real old API report and confirm the declared delta would reject unchanged old output")
    args=parser.parse_args(argv)
    if args.out.exists(): raise SystemExit(f"refusing existing output {args.out}")
    if not args.out.parent.exists(): raise SystemExit("output parent directory must already exist")
    try:
        old_receipt,old,old_meta=load_cell(args.old_execution,args.profile,args.evidence,"old")
        need(old_meta["phase"]=="baseline", "old receipt must be baseline phase")
        expected,span=prepare_expected(old,args.profile)
        if args.selftest_old:
            need(args.new_execution is None,"selftest does not accept a new execution")
            need(ignore_usage(expected)!=ignore_usage(old),"selftest expected delta did not differ from unchanged old report")
            result={"status":"old_json_parse_selftest_pass_not_delta_acceptance",
                "old_receipt":str(args.old_execution),"old_receipt_sha256":old_meta["receipt_sha256"],
                "old_report":old_meta["report_pin"],"profile":args.profile,"evidence":args.evidence,
                "target_method":"sameList(Ljava/util/List;)I","expected_removed_span_utf8_bytes":[span["start"],span["end"]],
                "removed_bytes":span["removed_bytes"],
                "note":"Old API parsing, exact target line and direct store@36 map proof only; unchanged output is correctly rejected. Not a new-output delta pass."}
            args.out.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8")
            print(json.dumps(result,indent=2))
            return 0
        need(args.new_execution is not None,"new execution is required outside selftest")
        new_receipt,new,new_meta=load_cell(args.new_execution,args.profile,args.evidence,"new")
        need(new_meta["phase"]=="final", "new receipt must be final phase")
        need(old_meta["profile"]==new_meta["profile"] and old_meta["evidence"]==new_meta["evidence"],
             "old/new selectors differ")
        need(old_meta["class_pin"].get("bytes")==new_meta["class_pin"].get("bytes")
             and old_meta["class_pin"].get("sha256")==new_meta["class_pin"].get("sha256"),
             "old/new physical class input bytes differ")
        need(old_meta["class_digest"]==new_meta["class_digest"],"API report class identity digest changed")
        old_method_facts=next(m for m in old_meta["class_facts"]["methods"] if (m.get("name"),m.get("descriptor"))==("sameList","(Ljava/util/List;)I"))
        new_method_facts=next(m for m in new_meta["class_facts"]["methods"] if (m.get("name"),m.get("descriptor"))==("sameList","(Ljava/util/List;)I"))
        need(old_method_facts==new_method_facts,"old/new physical sameList Code facts differ")
        need(old.get("class")==new.get("class"),"API input class identity changed")
        need(old.get("view")==new.get("view"),"class view changed")
        need(ignore_usage(expected)==ignore_usage(new),
             "old report transformed by only the exact sameList declaration/map delta differs elsewhere from new report")
        binding=validate_binding_and_map(old,new,span)
        result={"status":"exact_delta_pass","old_receipt":str(args.old_execution),"new_receipt":str(args.new_execution),
            "old_receipt_sha256":old_meta["receipt_sha256"],"new_receipt_sha256":new_meta["receipt_sha256"],
            "old_cli_pin":old_meta["cli_pin"],"new_cli_pin":new_meta["cli_pin"],
            "old_report":old_meta["report_pin"],"new_report":new_meta["report_pin"],
            "physical_class_pin_old":old_meta["class_pin"],"physical_class_pin_new":new_meta["class_pin"],
            "physical_sameList_bcis":old_meta["physical_bcis"],"physical_parser_sha256":old_meta["physical_parser_sha256"],
            "profile":args.profile,"evidence":args.evidence,"method":"sameList(Ljava/util/List;)I",
            "removed_raw_utf8_span":[span["start"],span["end"]],"removed_bytes":span["removed_bytes"],**binding,
            "compared_nonusage_report_tree":"exactly equal after only the declared text/map delta",
            "acceptance_note":"Pairwise output delta only; full-matrix receipt/source provenance and execution acceptance are separate."}
        args.out.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8")
        print(json.dumps(result,indent=2))
        return 0
    except (OSError,ValueError,KeyError,TypeError,json.JSONDecodeError) as exc:
        result={"status":"rejected","reason":str(exc),"old_execution":str(args.old_execution),
            "new_execution":str(args.new_execution) if args.new_execution else None,
            "profile":args.profile,"evidence":args.evidence}
        args.out.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8")
        print(result["reason"],file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
