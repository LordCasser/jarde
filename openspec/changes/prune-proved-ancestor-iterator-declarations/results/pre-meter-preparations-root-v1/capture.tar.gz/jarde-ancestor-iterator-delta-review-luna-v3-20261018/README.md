# Exact sameList control delta checker

`check_same_list_delta.py` is a private pairwise checker for the narrowly authorized
sameList blank-iterator-declaration cleanup. It compares one matching profile and
evidence cell from a frozen `baseline` receipt and a `final` receipt.

The only accepted output change is removal of exactly one profile-specific blank
declaration (`Iterator inner;` with debug info, `Iterator local3;` without it) in the
whole class, the public method projection, and the raw method text, plus removal of
the exact corresponding direct source-map span for store@36 and coordinate shifts.
It requires the new foreach at test@43 to retain store@36 as a derived origin and
next@47 to remain mapped. All other report data must compare exactly after
recursively omitting keys named `usage`. The checker binds the API report to the
recorded command/stdout and pinned original class bytes, then checks sameList Code
facts against the separately pinned physical class parser.

Example acceptance invocation (only after a final receipt exists):

```sh
python3 -B check_same_list_delta.py \
  --old-execution /path/to/baseline/execution.json \
  --new-execution /path/to/final/execution.json \
  --profile javac8-debug --evidence default \
  --out /path/to/new-private-result.json
```

`--selftest-old` parses a baseline cell and proves that unchanged old output would
not satisfy the intended delta. The 12 generated `old-report-selftests` results
cover the four profiles by three evidence modes; these are parsing/contract
self-tests only, not acceptance of a final report. No new-output delta was run.

Template pin: `/private/tmp/jarde-ancestor-iterator-delta-review-luna-v2-20261018/check_delta.py`
SHA-256 `d4e1a55ffa118246148c6418cefe7d2188dc2b11195a0737b625324ba2c7ea02`.
Independent class-parser pin: `/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py`
SHA-256 `c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd`.
