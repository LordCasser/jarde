# Structured-list assertion update (v7)

Private test-only patch against `tests/structured_list_generic_bodies.rs`; all other assertions in the test remain unchanged. No shared file was edited and no toolchain was run.

Base SHA-256: `b2e63cdca972adc73cea137cd295292ec12f8af8c0e66039c4d192d65c085862`.
Changed file SHA-256: `2aa41c5c61addd03a65264703031c18be7c5dfd9e51786968627f84cd13c421b`.
Patch SHA-256: `f7c19a2e447c44c64c4cfd155dcb214670f2c452ad18835ba2c1ad2bffa8ead9`.

The projection assertion now expects the fully consumed `java.util.Iterator local5;` declaration to be absent. The raw-body assertion checks the same exact blank declaration is absent. Typed foreach, binding, physical-origin, overload-wrapper, post-loop, evidence-selection, and stop assertions are retained.
