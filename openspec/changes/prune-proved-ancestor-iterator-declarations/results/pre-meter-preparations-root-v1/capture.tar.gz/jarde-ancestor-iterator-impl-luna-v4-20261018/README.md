# Ancestor iterator cleanup test supplement (v4)

Test-only patch against the current formatted shared `build.rs` snapshot. No shared files were edited and no toolchain was run.

Base `crates/jarde-java/src/build.rs` SHA-256: `1748eee485dccaea29ac45c0098b2da064f9fe156fe8ee04beeaf55e57b1f5a6`.

Changed private `build.rs` SHA-256: `61e5c6f2c9b287a3952e6f5ce028c46b48e9efc10d70d6b2b25f5a397268134e`.

Patch SHA-256: `2aee1ce8e4e5339cb234ade3479135bfc815d50be12a1266c555ffe48b4087b0`.

The patch extends the AST cleanup unit coverage for initialized declarations, a same-anchor non-declaration node, sibling-branch visibility, `for`-header scope, conflicting versus unrelated consumer relations, an omitted physical access, deterministic elapsed-budget interruption, and cancellation on the final pre-removal charge. It also extends the existing checkpoint restoration test to show the appended consumer relation truncates back to its saved prefix. Existing malformed-operation and missing-operation cases remain intact.

The AST shapes and cancellation/deadline cases are internal metamorphic tests; they are not new JVM fixtures. No compile or test result is claimed. Remaining untested specific physical mutations include a second write/version and `iinc` on the same local.
