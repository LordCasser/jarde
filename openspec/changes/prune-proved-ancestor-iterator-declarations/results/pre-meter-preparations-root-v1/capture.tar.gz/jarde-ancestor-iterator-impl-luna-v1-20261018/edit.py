from pathlib import Path
p=Path('/private/tmp/jarde-ancestor-iterator-impl-luna-v1-20261018/b/crates/jarde-java/src/build.rs')
s=p.read_text()
# Add private relation type beside FinallyCheckpoint and Builder state.
s=s.replace('''struct FinallyCheckpoint {
    stmts: Vec<Stmt>,''','''struct FinallyCheckpoint {
    stmts: Vec<Stmt>,
    iterator_declaration_consumers: Vec<(LocalVariable, u32)>,''')
s=s.replace('''    /// The names of the locals whose declaration this build **refused** (P3 2b.2).''','''    /// Successful iterator foreach owners that may consume one Elevated ancestor declaration.
    /// Duplicates are retained so final validation can refuse ambiguous relations.
    iterator_declaration_consumers: Vec<(LocalVariable, u32)>,
    /// The names of the locals whose declaration this build **refused** (P3 2b.2).''')
s=s.replace('''            stmts: self.stmts.clone(),
            declared: self.declared.clone(),''','''            stmts: self.stmts.clone(),
            iterator_declaration_consumers: self.iterator_declaration_consumers.clone(),
            declared: self.declared.clone(),''')
s=s.replace('''        self.stmts = checkpoint.stmts;
        self.declared = checkpoint.declared;''','''        self.stmts = checkpoint.stmts;
        self.iterator_declaration_consumers = checkpoint.iterator_declaration_consumers;
        self.declared = checkpoint.declared;''')
s=s.replace('''        stmts: Vec::new(),
        statements: 0,''','''        stmts: Vec::new(),
        iterator_declaration_consumers: Vec::new(),
        statements: 0,''',1)
# Candidate returns an optional variable only when the exact ancestor declaration is eligible and all method accesses close.
s=s.replace('''    ) -> Result<Option<(StmtKind, OriginSet, Vec<usize>, String)>, StopReason> {''','''    ) -> Result<Option<(StmtKind, OriginSet, Vec<usize>, String, Option<LocalVariable>)>, StopReason> {''',1)
# Insert closure fact before the candidate tuple is returned.
old='''            let origin = bcis
                .into_iter()
                .fold(OriginSet::new(Origin::direct(test_bci)), |origin, bci| {
                    origin.plus_derived(Origin::derived(bci))
                });
            Some((
                label.clone(),
                iterable.clone(),
                body.to_vec(),
                next_bci,
                origin,
                declaration_index
                    .into_iter()
                    .chain(std::iter::once(init_index))
                    .collect(),
            ))'''
new='''            let origin = bcis
                .into_iter()
                .fold(OriginSet::new(Origin::direct(test_bci)), |origin, bci| {
                    origin.plus_derived(Origin::derived(bci))
                });
            let elevated_ancestor = declaration_index.is_none()
                && ancestor_owner
                && matches!(
                    self.declarations.placements.get(&iterator_variable),
                    Some(DeclarationPlacement::Elevated { owner }) if owner.len() < path.len()
                );
            let prune_variable = if elevated_ancestor {
                match iterator_variable_accesses_closed(
                    self.code,
                    self.operations,
                    self.reuse,
                    iterator_variable,
                    Some([init_store_bci, test_load_bci, next_load_bci]),
                    Some(&origin),
                    self.budget,
                    test_bci,
                ) {
                    Ok(true) => Some(iterator_variable),
                    Ok(false) => None,
                    Err(stop) => {
                        proof_stop = Some(stop);
                        return None;
                    }
                }
            } else {
                None
            };
            Some((
                label.clone(),
                iterable.clone(),
                body.to_vec(),
                next_bci,
                origin,
                declaration_index
                    .into_iter()
                    .chain(std::iter::once(init_index))
                    .collect(),
                prune_variable,
            ))'''
assert old in s
s=s.replace(old,new,1)
s=s.replace('''        let Some((label, iterable, mut body, next_bci, origin, remove)) = candidate else {''','''        let Some((label, iterable, mut body, next_bci, origin, remove, prune_variable)) = candidate else {''',1)
s=s.replace('''            origin,
            remove,
            name,
        )))''','''            origin,
            remove,
            name,
            prune_variable,
        )))''',1)
# Update caller tuple shape and remember relation only after successful push.
s=s.replace('''        let (kind, origin) = if let Some((kind, origin, removed_element, declarations)) = projected''','''        let mut iterator_prune = None;
        let (kind, origin) = if let Some((kind, origin, removed_element, declarations)) = projected''',1)
s=s.replace('''        } else if let Some((kind, origin, mut remove, name)) = iterable_projected {''','''        } else if let Some((kind, origin, mut remove, name, prune_variable)) = iterable_projected {''',1)
s=s.replace('''            self.synthetic_names.insert(name);
            (kind, origin)''','''            self.synthetic_names.insert(name);
            iterator_prune = prune_variable;
            (kind, origin)''',1)
s=s.replace('''        self.push(Stmt::new(kind, origin))
    }

    fn guard_region(''','''        self.push(Stmt::new(kind, origin))?;
        if let Some(variable) = iterator_prune {
            poll(self.budget, Some(first_test_bci))?;
            charge(self.budget, CountedBudgetDimension::IrItems, 1, Some(first_test_bci))?;
            self.iterator_declaration_consumers
                .push((variable, first_test_bci));
        }
        Ok(())
    }

    fn guard_region(''',1)
# Insert method-wide physical access verifier before iterator declaration function.
marker='''/// Finds a removable current-list declaration, or verifies the complete visible owner for an
/// already emitted ancestor declaration.'''
helper='''/// Closes every physical access to one reuse identity against the iterator foreach accesses.
/// A missing decode operation for a local opcode is absence of proof, never an ignored access.
fn iterator_variable_accesses_closed(
    code: &MethodCodeFacts,
    operations: &Operations,
    reuse: &reuse::Plan,
    variable: LocalVariable,
    expected: Option<[u32; 3]>,
    loop_origin: Option<&OriginSet>,
    budget: &mut Budget,
    at: u32,
) -> Result<bool, StopReason> {
    if code.stopped_at.is_some() {
        return Ok(false);
    }
    let operands = code.operands();
    if operands.len() != code.instructions.len() {
        return Ok(false);
    }
    let count = u64::try_from(code.instructions.len()).unwrap_or(u64::MAX);
    charge(budget, CountedBudgetDimension::AnalysisSteps, count, Some(at))?;
    for _ in 0..code.instructions.len() {
        poll(budget, Some(at))?;
    }

    let mut store_bci = None;
    let mut first_load_bci = None;
    let mut second_load_bci = None;
    let mut store_count = 0usize;
    let mut load_count = 0usize;
    for (instruction, operand) in code.instructions.iter().zip(operands) {
        let bci = instruction.bci;
        let opcode = operand.effective_opcode;
        let local_opcode = matches!(opcode, 0x15..=0x2d | 0x36..=0x4e | 0x84 | 0xa9);
        if !local_opcode {
            continue;
        }
        let Some(slot) = operand.local.map(|local| local.index) else {
            return Ok(false);
        };
        if slot != variable.slot() {
            continue;
        }
        let Some(at_variable) = reuse.variable_at(slot, bci) else {
            return Ok(false);
        };
        if at_variable != variable {
            continue;
        }
        let Some(operation) = operations.get(bci) else {
            return Ok(false);
        };
        match (opcode, operation) {
            (0x15..=0x2d, Operation::Load { slot: operation_slot })
                if *operation_slot == slot =>
            {
                load_count += 1;
                if load_count == 1 {
                    first_load_bci = Some(bci);
                } else if load_count == 2 {
                    second_load_bci = Some(bci);
                }
            }
            (0x36..=0x4e, Operation::Store { slot: operation_slot })
                if *operation_slot == slot =>
            {
                store_count += 1;
                store_bci = Some(bci);
            }
            (0x84, Operation::Increment { slot: operation_slot, .. })
                if *operation_slot == slot => return Ok(false),
            _ => return Ok(false),
        }
    }
    if store_count != 1 || load_count != 2 {
        return Ok(false);
    }
    let Some(store_bci) = store_bci else { return Ok(false) };
    let Some(first_load_bci) = first_load_bci else { return Ok(false) };
    let Some(second_load_bci) = second_load_bci else { return Ok(false) };
    if let Some([expected_store, expected_first, expected_second]) = expected {
        if store_bci != expected_store
            || first_load_bci != expected_first
            || second_load_bci != expected_second
        {
            return Ok(false);
        }
    }
    if let Some(origin) = loop_origin {
        if [store_bci, first_load_bci, second_load_bci]
            .into_iter()
            .any(|bci| origin.mentions(bci).is_none())
        {
            return Ok(false);
        }
    }
    Ok(true)
}

'''
assert marker in s
s=s.replace(marker,helper+marker,1)
# Add final pruning immediately after existing constructor reorder and before Program construction.
old='''    crate::ctor_order::present_prologue_first(
        &mut builder.stmts,
        builder.ssa,
        builder.operations,
        builder.fields,
        inputs.class_fields,
        inputs.class_methods,
        inputs.declaring_class,
        inputs.prologues,
        inputs.parameters,
        inputs.has_receiver,
        builder.budget,
    )?;
    Ok(Program {'''
new='''    crate::ctor_order::present_prologue_first(
        &mut builder.stmts,
        builder.ssa,
        builder.operations,
        builder.fields,
        inputs.class_fields,
        inputs.class_methods,
        inputs.declaring_class,
        inputs.prologues,
        inputs.parameters,
        inputs.has_receiver,
        builder.budget,
    )?;
    prune_proved_iterator_ancestor_declarations(
        &mut builder.stmts,
        &mut builder.statements,
        &builder.iterator_declaration_consumers,
        &builder.declarations,
        builder.names,
        builder.reuse,
        builder.code,
        builder.operations,
        builder.budget,
    )?;
    Ok(Program {'''
assert old in s
s=s.replace(old,new,1)
p.write_text(s)
