# Proved ancestor iterator declaration pruning (private task 2.1)

Patch: `changes.patch` (only `crates/jarde-java/src/build.rs`). The patch is based on the original source copied under `a/`; the edited copy is under `b/`.

Base `build.rs` SHA-256: `e3f201df7bd01b9b0691d5f7229cbfd5efd82ce5b70fdd39f0f003170fe51b39`
Edited `build.rs` SHA-256: `85d2a14d68290ba0dd73caec312d1d63f198b7b1c7f73f1cfc090672f87835cd`
Patch SHA-256: `36501134759cb9efbd56bf34fae76286097cf73bbe56374f91b1c964e7427c89`

The optional candidate proof closes every decoded physical local access for the exact reuse identity against the foreach init store, hasNext load, and next load. A failed optional proof leaves existing foreach admission intact; a budget Stop propagates. A relation is recorded only after the existing foreach push succeeds. After constructor ordering, pruning rechecks the exact relation against the declaration plan, full physical access set, unique AST anchors, declaration shape/name/type, actual preceding visibility, and carried loop origins before removing one declaration and decrementing the count. Checkpoint rollback truncates the private relation vector.

No compiler, tests, formatter, JDK, or Jarde CLI was run, per task constraints. Suggested root-owned validation: focused `p3_hoisted_iterator_foreach` tests and the full build/test gate; confirm protected/unknown local operations retain declarations and that the fixed TestNestedLoops source removes only the two proved ancestor declarations.
