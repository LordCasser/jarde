from pathlib import Path
p=Path('/private/tmp/jarde-ancestor-iterator-impl-luna-v1-20261018/b/crates/jarde-java/src/build.rs')
s=p.read_text()
s=s.replace('''fn iterator_variable_accesses_closed(
    code: &MethodCodeFacts,''','''#[derive(Clone, Copy, Debug)]
struct IteratorAccessBcis {
    store: u32,
    loads: [u32; 2],
}

fn iterator_variable_accesses_closed(
    code: &MethodCodeFacts,''',1)
s=s.replace(''') -> Result<bool, StopReason> {
    if code.stopped_at.is_some() {''',''') -> Result<Option<IteratorAccessBcis>, StopReason> {
    if code.stopped_at.is_some() {''',1)
# Within helper replace false returns and final true; scoped by substring.
start=s.index('fn iterator_variable_accesses_closed(')
end=s.index('\n}\n\n/// Finds a removable current-list declaration',start)+2
h=s[start:end]
h=h.replace('return Ok(false);','return Ok(None);')
h=h.replace('''    if let Some([expected_store, expected_first, expected_second]) = expected {
        if store_bci != expected_store
            || first_load_bci != expected_first
            || second_load_bci != expected_second
        {
            return Ok(false);
        }
    }
    if let Some(origin) = loop_origin {
        if [store_bci, first_load_bci, second_load_bci]
            .into_iter()
            .any(|bci| origin.mentions(bci).is_none())
        {
            return Ok(false);
        }
    }
    Ok(true)''','''    if let Some([expected_store, expected_first, expected_second]) = expected {
        if store_bci != expected_store
            || first_load_bci != expected_first
            || second_load_bci != expected_second
        {
            return Ok(None);
        }
    }
    if let Some(origin) = loop_origin {
        if [store_bci, first_load_bci, second_load_bci]
            .into_iter()
            .any(|bci| origin.mentions(bci).is_none())
        {
            return Ok(None);
        }
    }
    Ok(Some(IteratorAccessBcis {
        store: store_bci,
        loads: [first_load_bci, second_load_bci],
    }))''')
s=s[:start]+h+s[end:]
# Candidate optional verifier now tests Option.
s=s.replace('''                    Ok(true) => Some(iterator_variable),
                    Ok(false) => None,''','''                    Ok(Some(_)) => Some(iterator_variable),
                    Ok(None) => None,''',1)
# Insert final validation/removal helper before build().
marker='''/// Builds the statements of one method from its regions.'''
helper=r'''/// Removes only one exactly planned, actually visible ancestor iterator declaration per
/// successfully published foreach. Every refusal is local to this optional cleanup.
fn prune_proved_iterator_ancestor_declarations(
    statements: &mut Vec<Stmt>,
    statement_count: &mut usize,
    consumers: &[(LocalVariable, u32)],
    declarations: &Declarations,
    names: &NameTable,
    reuse: &reuse::Plan,
    code: &MethodCodeFacts,
    operations: &Operations,
    budget: &mut Budget,
) -> Result<(), StopReason> {
    for (consumer_index, &(variable, test_bci)) in consumers.iter().enumerate() {
        poll(budget, Some(test_bci))?;
        charge(budget, CountedBudgetDimension::AnalysisSteps, 1, Some(test_bci))?;
        let mut occurrences = 0usize;
        for (other_index, &(other_variable, other_test)) in consumers.iter().enumerate() {
            poll(budget, Some(test_bci))?;
            charge(budget, CountedBudgetDimension::AnalysisSteps, 1, Some(test_bci))?;
            if consumer_index != other_index
                && variable == other_variable
                && test_bci == other_test
            {
                occurrences += 1;
            }
        }
        if occurrences != 0 {
            continue;
        }
        let Some(DeclarationPlacement::Elevated { owner }) =
            declarations.placements.get(&variable)
        else {
            continue;
        };
        let Some(owner_declarations) = declarations.at_region.get(owner) else {
            continue;
        };
        let mut planned = None;
        let mut planned_count = 0usize;
        for declaration in owner_declarations {
            poll(budget, Some(declaration.at))?;
            charge(budget, CountedBudgetDimension::AnalysisSteps, 1, Some(declaration.at))?;
            if declaration.variable == variable {
                planned_count += 1;
                planned = Some((declaration.at, &declaration.ty));
            }
        }
        if planned_count != 1 {
            continue;
        }
        let Some((anchor, ty)) = planned else { continue };
        let Some(name) = names.text(variable) else { continue };
        charge(
            budget,
            CountedBudgetDimension::AnalysisSteps,
            u64::try_from(name.len()).unwrap_or(u64::MAX),
            Some(anchor),
        )?;
        let Some(accesses) = iterator_variable_accesses_closed(
            code,
            operations,
            reuse,
            variable,
            None,
            None,
            budget,
            test_bci,
        )? else {
            continue;
        };

        let mut loop_count = 0usize;
        let mut declaration_count = 0usize;
        let mut declaration_is_visible = false;
        let mut loop_origin_has_accesses = false;
        fn inspect(
            body: &[Stmt],
            inherited_visible: bool,
            variable: LocalVariable,
            test_bci: u32,
            anchor: u32,
            ty: &Type,
            name: &str,
            accesses: IteratorAccessBcis,
            reuse: &reuse::Plan,
            budget: &mut Budget,
            loop_count: &mut usize,
            declaration_count: &mut usize,
            visible_loop: &mut bool,
            loop_origin_has_accesses: &mut bool,
            allow_declaration: bool,
        ) -> Result<(), StopReason> {
            let mut visible = inherited_visible;
            for statement in body {
                let bci = statement.origin.primary().bci();
                poll(budget, Some(bci))?;
                charge(budget, CountedBudgetDimension::AnalysisSteps, 1, Some(bci))?;
                let matching_declaration = matches!(
                    &statement.kind,
                    StmtKind::Declare {
                        ty: declared_ty,
                        name: declared_name,
                        value: None,
                        ..
                    } if declared_ty == ty
                        && declared_name == name
                        && bci == anchor
                );
                if matching_declaration {
                    *declaration_count += 1;
                    if allow_declaration {
                        visible = true;
                    }
                }
                if matches!(
                    &statement.kind,
                    StmtKind::ForEach { .. }
                ) && bci == test_bci
                {
                    *loop_count += 1;
                    if visible {
                        *visible_loop = true;
                        *loop_origin_has_accesses = [
                            accesses.store,
                            accesses.loads[0],
                            accesses.loads[1],
                        ]
                        .into_iter()
                        .all(|origin_bci| statement.origin.mentions(origin_bci).is_some());
                    }
                }
                let child_visible = visible;
                let mut visit = |children: &[Stmt], allow| {
                    inspect(
                        children,
                        child_visible,
                        variable,
                        test_bci,
                        anchor,
                        ty,
                        name,
                        accesses,
                        reuse,
                        budget,
                        loop_count,
                        declaration_count,
                        visible_loop,
                        loop_origin_has_accesses,
                        allow,
                    )
                };
                match &statement.kind {
                    StmtKind::If { then_body, else_body, .. } => {
                        visit(then_body, true)?;
                        visit(else_body, true)?;
                    }
                    StmtKind::While { body, .. }
                    | StmtKind::DoWhile { body, .. }
                    | StmtKind::ForEach { body, .. }
                    | StmtKind::Synchronized { body, .. } => visit(body, true)?,
                    StmtKind::For { init, update, body, .. } => {
                        visit(std::slice::from_ref(init.as_ref()), false)?;
                        visit(std::slice::from_ref(update.as_ref()), false)?;
                        visit(body, true)?;
                    }
                    StmtKind::Switch { arms, .. } => {
                        for arm in arms {
                            visit(&arm.body, true)?;
                        }
                    }
                    StmtKind::Try { body, catches, finally_body, .. } => {
                        visit(body, true)?;
                        for catch in catches {
                            visit(&catch.body, true)?;
                        }
                        if let Some(finally_body) = finally_body {
                            visit(finally_body, true)?;
                        }
                    }
                    _ => {}
                }
                // `variable` is intentionally carried through this structural scan: the final
                // physical-access closure above is keyed by the full LocalVariable identity.
                let _ = variable;
                let _ = reuse;
            }
            Ok(())
        }
        inspect(
            statements,
            false,
            variable,
            test_bci,
            anchor,
            ty,
            name,
            accesses,
            reuse,
            budget,
            &mut loop_count,
            &mut declaration_count,
            &mut declaration_is_visible,
            &mut loop_origin_has_accesses,
            true,
        )?;
        if loop_count != 1
            || declaration_count != 1
            || !declaration_is_visible
            || !loop_origin_has_accesses
            || *statement_count == 0
        {
            continue;
        }
        fn remove_one(
            body: &mut Vec<Stmt>,
            anchor: u32,
            ty: &Type,
            name: &str,
            budget: &mut Budget,
        ) -> Result<bool, StopReason> {
            let mut index = 0usize;
            while index < body.len() {
                let bci = body[index].origin.primary().bci();
                poll(budget, Some(bci))?;
                charge(budget, CountedBudgetDimension::AnalysisSteps, 1, Some(bci))?;
                if bci == anchor
                    && matches!(
                        &body[index].kind,
                        StmtKind::Declare {
                            ty: declared_ty,
                            name: declared_name,
                            value: None,
                            ..
                        } if declared_ty == ty && declared_name == name
                    )
                {
                    charge(budget, CountedBudgetDimension::IrItems, 1, Some(anchor))?;
                    body.remove(index);
                    return Ok(true);
                }
                let found = match &mut body[index].kind {
                    StmtKind::If { then_body, else_body, .. } => {
                        remove_one(then_body, anchor, ty, name, budget)?
                            || remove_one(else_body, anchor, ty, name, budget)?
                    }
                    StmtKind::While { body, .. }
                    | StmtKind::DoWhile { body, .. }
                    | StmtKind::ForEach { body, .. }
                    | StmtKind::Synchronized { body, .. } => {
                        remove_one(body, anchor, ty, name, budget)?
                    }
                    StmtKind::For { body, .. } => remove_one(body, anchor, ty, name, budget)?,
                    StmtKind::Switch { arms, .. } => {
                        let mut removed = false;
                        for arm in arms {
                            if remove_one(&mut arm.body, anchor, ty, name, budget)? {
                                removed = true;
                                break;
                            }
                        }
                        removed
                    }
                    StmtKind::Try { body, catches, finally_body, .. } => {
                        let mut removed = remove_one(body, anchor, ty, name, budget)?;
                        if !removed {
                            for catch in catches {
                                if remove_one(&mut catch.body, anchor, ty, name, budget)? {
                                    removed = true;
                                    break;
                                }
                            }
                        }
                        if !removed {
                            if let Some(finally_body) = finally_body {
                                removed = remove_one(finally_body, anchor, ty, name, budget)?;
                            }
                        }
                        removed
                    }
                    _ => false,
                };
                if found {
                    return Ok(true);
                }
                index += 1;
            }
            Ok(false)
        }
        if remove_one(statements, anchor, ty, name, budget)? {
            *statement_count -= 1;
        }
    }
    Ok(())
}

'''
assert marker in s
s=s.replace(marker,helper+marker,1)
p.write_text(s)
