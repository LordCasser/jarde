#!/usr/bin/env python3
"""Review the real run_validation.py 21-command receipt for a 20-cell API replay."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

SMOKE_EXECUTION = Path("/private/tmp/jarde-ancestor-iterator-api-smoke-root-v1-20261018/execution.json")
SMOKE_EXECUTION_SHA256 = "94c1e5187a38b4e098cd51198ccf2e85f68b3dbf481960f7341773009e245293"
SMOKE_PAIRS = Path("/private/tmp/jarde-ancestor-iterator-api-smoke-prep-root-v1-20261018/pairs.json")
SMOKE_PAIRS_SHA256 = "50256024f488b8cfd6961c3564d34f0e947217a5695b837ce407a41df4798753"
SMOKE_RESULT = Path("/private/tmp/jarde-ancestor-iterator-delta-review-luna-v4-20261018/results/smoke20-utf8-validated.json")
SMOKE_RESULT_SHA256 = "72cc6be55c5925b67f7166f3d04954a616586876af03d9b15a341a587c549701"
PREMETER_BIND = Path("/private/tmp/jarde-ancestor-iterator-pre-meter-final-bind-root-v1-20261018.json")
PREMETER_BIND_SHA256 = "518aff2f2fd59008c43135ec5cf5371cc50a53e0ddb181b601f7e8900e5707f4"
SMOKE_CLI_SHA256 = "60e1b07691100a238c7462a400b381a2be923b366278349f1562f69d3d890ba5"
MAX_TARGET_BYTES = 1024**3
MIN_FREE_BYTES = 5 * 1024**3


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def pin_file(path: Path, label: str) -> dict:
    path = path.resolve(strict=True)
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": sha_path(path)}


def check_pin(pin: dict, label: str) -> bytes:
    need(isinstance(pin, dict) and {"path", "bytes", "sha256"} <= set(pin),
         f"{label}: malformed pin")
    path = Path(pin["path"])
    data = path.read_bytes()
    need(len(data) == pin["bytes"] and sha(data) == pin["sha256"], f"{label}: raw pin mismatch")
    return data


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def strip_usage(value):
    if isinstance(value, list):
        return [strip_usage(item) for item in value]
    if isinstance(value, dict):
        return {key: strip_usage(item) for key, item in value.items() if key != "usage"}
    return value


def target_class(role: str) -> str:
    if role == "original":
        return "jadx/tests/integration/loops/TestNestedLoops$TestCls.class"
    need(role == "controls", f"unknown role {role}")
    return "cf11/IteratorAncestorCases.class"


def class_bytes_from_input(path: Path, internal_name: str, label: str) -> bytes:
    need(path.is_file(), f"{label}: input missing: {path}")
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as archive:
            names = archive.namelist()
            need(names.count(internal_name) == 1, f"{label}: archive must contain one {internal_name}")
            return archive.read(internal_name)
    return path.read_bytes()


def command_map(receipt: dict, label: str, count: int, final_clean: bool = False) -> dict[int, dict]:
    rows = receipt.get("commands")
    need(isinstance(rows, list) and len(rows) == count, f"{label}: expected {count} command rows")
    commands = {}
    for row in rows:
        index = row.get("index")
        need(isinstance(index, int) and index not in commands, f"{label}: invalid/duplicate command index")
        commands[index] = row
    need(set(commands) == set(range(1, count + 1)), f"{label}: command indices not contiguous")
    if final_clean:
        clean = commands[count]
        need(clean.get("argv") == ["cargo", "clean"] and clean.get("exit_code") == 0,
             f"{label}: final command is not successful cargo clean")
        for stream_name in ("stdout", "stderr"):
            check_pin(clean.get("streams", {}).get(stream_name, {}), f"{label} clean {stream_name}")
    return commands


def validate_command_guard(command: dict, index: int, label: str, repo_root: Path) -> None:
    need(command.get("cwd") and Path(command["cwd"]).resolve() == repo_root.resolve(),
         f"{label} command {index}: cwd differs from repo root")
    need(command.get("exit_code") == 0, f"{label} command {index}: exit code is not 0")
    need(command.get("guard_stop") is None, f"{label} command {index}: disk guard stopped command")
    need(isinstance(command.get("peak_target_bytes"), int)
         and command["peak_target_bytes"] <= MAX_TARGET_BYTES,
         f"{label} command {index}: target exceeded 1 GiB ceiling")
    need(isinstance(command.get("free_bytes_after"), int)
         and command["free_bytes_after"] >= MIN_FREE_BYTES,
         f"{label} command {index}: free space below 5 GiB floor")
    for stream_name in ("stdout", "stderr"):
        check_pin(command.get("streams", {}).get(stream_name, {}),
                  f"{label} command {index} {stream_name}")


def validate_source_pins(rows: list, label: str, repo_root: Path) -> int:
    need(isinstance(rows, list), f"{label}: source closure pins must be a list")
    seen = set()
    for row in rows:
        need(isinstance(row, dict) and {"path", "bytes", "sha256"} <= set(row),
             f"{label}: malformed source pin")
        path = Path(row["path"]).resolve(strict=True)
        try:
            path.relative_to(repo_root.resolve())
        except ValueError as exc:
            raise ValueError(f"{label}: source path outside repository: {path}") from exc
        need(str(path) not in seen, f"{label}: duplicate source path {path}")
        seen.add(str(path))
        check_pin(row, f"{label} {path.relative_to(repo_root)}")
    return len(seen)


def validate_guard_receipt(receipt: dict, broad: dict, expected_cli_sha: str,
                           repo_root: Path) -> dict[int, dict]:
    need(receipt.get("status") == "commands_passed_pending_independent_acceptance",
         "replay receipt is not in the expected completed run_validation state")
    for key in ("source_unchanged", "source_changes_accepted", "default_stack", "target_absent"):
        need(receipt.get(key) is True, f"replay receipt guard {key} is not true")
    need(receipt.get("source_changes") == [] and receipt.get("allowed_source_changes") == [],
         "replay source changes/allowlist must both be empty")
    need(not (repo_root / "target").exists() and not (repo_root / "target").is_symlink(),
         "live repository target still exists after recorded cleanup")

    before, after = receipt.get("source_before"), receipt.get("source_after")
    broad_after = broad.get("source_after")
    need(isinstance(before, list) and before == after,
         "replay source_before and source_after differ")
    need(before == broad_after,
         "replay source closure is not exactly the broad-v3 final source closure")
    source_count = validate_source_pins(before, "replay source", repo_root)
    need(source_count == len(broad_after), "replay/broad source closure lengths differ")

    broad_cli = broad.get("cli")
    need(isinstance(broad_cli, dict), "broad-v3 CLI pin missing")
    check_pin(broad_cli, "broad-v3 final CLI")
    need(broad_cli.get("sha256") == expected_cli_sha,
         "caller CLI SHA does not match broad-v3 receipt's CLI pin")

    commands = command_map(receipt, "replay", 21, final_clean=True)
    for index, command in commands.items():
        if index != 21:  # Cleanup has the runner-specific minimal row, checked by command_map.
            validate_command_guard(command, index, "replay", repo_root)
    need(check_pin(commands[21]["streams"]["stderr"], "cleanup stderr") == b"",
         "cargo clean stderr is not empty")
    return commands


def validate_accepted_inputs(smoke: dict, pairs: list, smoke_result: dict, premeter: dict) -> dict:
    need(sha(SMOKE_EXECUTION.read_bytes()) == SMOKE_EXECUTION_SHA256,
         "accepted smoke receipt pin changed")
    need(sha(SMOKE_PAIRS.read_bytes()) == SMOKE_PAIRS_SHA256,
         "accepted pair ledger pin changed")
    need(sha(SMOKE_RESULT.read_bytes()) == SMOKE_RESULT_SHA256,
         "accepted v4 smoke delta result pin changed")
    need(sha(PREMETER_BIND.read_bytes()) == PREMETER_BIND_SHA256,
         "root pre-meter binding receipt pin changed")
    need(smoke.get("status") == "commands_passed_pending_independent_acceptance",
         "accepted smoke receipt status changed")
    need(smoke_result.get("status") == "pairwise_smoke_exact_delta_pass_not_product_acceptance"
         and smoke_result.get("checked_pairs") == 20
         and smoke_result.get("execution_sha256") == SMOKE_EXECUTION_SHA256,
         "accepted v4 20-pair delta result is invalid")
    need(premeter.get("status") == "fresh_api_reports_bound_to_smoke_nonusage_exact_not_product_acceptance"
         and premeter.get("checked_api_cells") == 20
         and premeter.get("argv_identical_count") == 0
         and premeter.get("argv_different_count") == 20
         and premeter.get("smoke_v4_result_sha256") == SMOKE_RESULT_SHA256,
         "root pre-meter complete-matrix binding is invalid")
    need(isinstance(pairs, list) and len(pairs) == 20
         and [pair.get("index") for pair in pairs] == list(range(1, 21)),
         "accepted pair ledger is not exactly 20 ordered entries")
    need(len(premeter.get("results", [])) == 20, "pre-meter receipt lacks 20 physical-input result pins")
    return {"smoke_execution_sha256": SMOKE_EXECUTION_SHA256,
            "smoke_pairs_sha256": SMOKE_PAIRS_SHA256,
            "smoke_result_sha256": SMOKE_RESULT_SHA256,
            "premeter_sha256": PREMETER_BIND_SHA256}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--replay-execution", type=Path, required=True)
    ap.add_argument("--broad-v3-receipt", type=Path, required=True)
    ap.add_argument("--expected-cli-sha256", required=True)
    ap.add_argument("--repo-root", type=Path, default=Path("/Users/lordcasser/workspace/projects/jarde"))
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args(argv)
    if args.out.exists():
        raise SystemExit(f"refusing existing output {args.out}")
    if not args.out.parent.exists():
        raise SystemExit("result parent must already exist")
    try:
        need(re.fullmatch(r"[0-9a-f]{64}", args.expected_cli_sha256) is not None,
             "--expected-cli-sha256 must be 64 lowercase hex digits")
        root = args.repo_root.resolve(strict=True)
        smoke = load(SMOKE_EXECUTION)
        pairs = load(SMOKE_PAIRS)
        smoke_result = load(SMOKE_RESULT)
        premeter = load(PREMETER_BIND)
        replay = load(args.replay_execution)
        broad = load(args.broad_v3_receipt)
        evidence = validate_accepted_inputs(smoke, pairs, smoke_result, premeter)
        for receipt in (replay, broad):
            for key in ("runner", "spec", "guard", "scanner"):
                check_pin(receipt[key], f"actual support tool {key}")
        need(sha_path(Path(smoke["commands"][0]["argv"][0])) == SMOKE_CLI_SHA256, "accepted smoke CLI changed")
        need(broad.get("status") == "commands_passed_pending_independent_acceptance",
             "broad-v3 receipt is not a completed build receipt")
        commands = validate_guard_receipt(replay, broad, args.expected_cli_sha256, root)
        old_commands = command_map(smoke, "accepted smoke", 21, final_clean=True)
        need(smoke.get("default_stack") is True and smoke.get("target_absent") is True,
             "accepted smoke did not record default-stack/target-cleanup success")
        need(smoke.get("source_unchanged") is True and smoke.get("source_changes") == []
             and smoke.get("allowed_source_changes") == [] and smoke.get("source_changes_accepted") is True,
             "accepted smoke source/cleanup guards are not intact")
        for index, command in old_commands.items():
            if index != 21:
                validate_command_guard(command, index, "accepted smoke", root)
        need(check_pin(old_commands[21]["streams"]["stderr"], "accepted smoke cleanup stderr") == b"",
             "accepted smoke cargo clean wrote stderr")
        premeter_rows = {}
        for row in premeter["results"]:
            key = (row.get("role"), row.get("profile"), row.get("input_form"), row.get("evidence"))
            need(key not in premeter_rows, f"pre-meter duplicate physical-input selector {key}")
            premeter_rows[key] = row
        need(len(premeter_rows) == 20, "pre-meter selector set is incomplete")

        result_rows = []
        for pair in pairs:
            index = pair["index"]
            old, new = old_commands[index], commands[index]
            old_argv, new_argv = old.get("argv", []), new.get("argv", [])
            need(old.get("exit_code") == 0, f"old smoke command {index} was not successful")
            need(len(old_argv) >= 2 and len(new_argv) == len(old_argv)
                 and old_argv[1:] == new_argv[1:],
                 f"pair {index}: command argv differs beyond argv[0]")
            need(old_argv == pair.get("new_argv"), f"pair {index}: smoke argv differs from accepted pair ledger")
            need("class-source" in old_argv and old_argv[1] == "class-source",
                 f"pair {index}: expected class-source CLI invocation")
            need(old.get("env_overrides") == new.get("env_overrides"), f"pair {index}: environment differs")
            input_pos = old_argv.index("--input")
            old_input_path, new_input_path = Path(old_argv[input_pos + 1]), Path(new_argv[input_pos + 1])
            need(old_input_path.resolve() == new_input_path.resolve(), f"pair {index}: input path changed")
            old_input_pin = pin_file(old_input_path, f"old input {index}")
            new_input_pin = pin_file(new_input_path, f"new input {index}")
            need(old_input_pin == new_input_pin, f"pair {index}: full input artifact changed")

            role = pair["role"]
            internal = target_class(role)
            class_bytes = class_bytes_from_input(old_input_path, internal, f"pair {index} input")
            key = (role, pair["profile"], pair.get("input_form"), pair["evidence"])
            physical = premeter_rows.get(key)
            need(physical is not None, f"pair {index}: pre-meter physical class pin missing")
            need(physical.get("class_bytes") == len(class_bytes)
                 and physical.get("class_sha256") == sha(class_bytes),
                 f"pair {index}: actual original class bytes differ from pre-meter's JDK-bound class pin")

            old_raw = check_pin(old.get("streams", {}).get("stdout", {}), f"old stdout {index}")
            new_raw = check_pin(new.get("streams", {}).get("stdout", {}), f"new stdout {index}")
            need(check_pin(old.get("streams", {}).get("stderr", {}), f"old stderr {index}") == b"",
                 f"old command {index}: stderr not empty")
            need(check_pin(new.get("streams", {}).get("stderr", {}), f"new stderr {index}") == b"",
                 f"new command {index}: stderr not empty")
            old_doc = json.loads(old_raw.decode("utf-8", "strict"))
            new_doc = json.loads(new_raw.decode("utf-8", "strict"))
            need(strip_usage(old_doc) == strip_usage(new_doc),
                 f"pair {index}: non-usage JSON differs from accepted smoke")
            report_class = new_doc.get("class", {}).get("class_bytes", {})
            need(report_class.get("length") == len(class_bytes),
                 f"pair {index}: API report class length differs from pinned raw class bytes")

            result_rows.append({"index": index, "role": role, "profile": pair["profile"],
                "input_form": pair.get("input_form"), "evidence": pair["evidence"],
                "old_argv": old_argv, "new_argv": new_argv, "argv_diff_only_executable": True,
                "full_input_pin": old_input_pin,
                "physical_class_pin": {"internal_name": internal, "bytes": len(class_bytes),
                                       "sha256": sha(class_bytes),
                                       "pre_meter_row_class_sha256": physical["class_sha256"]},
                "old_stdout": old["streams"]["stdout"], "new_stdout": new["streams"]["stdout"],
                "comparison": "full parsed JSON exactly equal after recursively omitting usage keys"})

        cli_paths = {Path(commands[i]["argv"][0]).resolve(strict=True) for i in range(1, 21)}
        need(len(cli_paths) == 1, "new replay commands did not all use a single CLI executable")
        new_cli_path = next(iter(cli_paths))
        actual_cli_sha = sha_path(new_cli_path)
        need(actual_cli_sha == args.expected_cli_sha256, "new CLI executable bytes differ from supplied hash")
        broad_cli = broad["cli"]
        need(new_cli_path == Path(broad_cli["path"]).resolve(),
             "replay argv[0] differs from broad-v3 receipt CLI path")
        need(len(result_rows) == 20, "not all 20 API cells were reviewed")

        result = {"status": "guarded_20_api_replay_exact_nonusage_pass_not_product_acceptance",
            "replay_execution": str(args.replay_execution),
            "replay_execution_sha256": sha(args.replay_execution.read_bytes()),
            "broad_v3_receipt": str(args.broad_v3_receipt),
            "broad_v3_receipt_sha256": sha(args.broad_v3_receipt.read_bytes()),
            "expected_cli_sha256": args.expected_cli_sha256,
            "actual_cli_sha256": actual_cli_sha, "actual_cli_path": str(new_cli_path),
            "repo_root": str(root), "source_closure_count": len(replay["source_before"]),
            "source_closure_matches_broad_v3_after": True,
            "command_count": len(commands), "api_cell_count": len(result_rows),
            "cleanup_command": commands[21]["argv"],
            "source_changes": [], "allowed_source_changes": [],
            "default_stack": True, "source_unchanged": True,
            "source_changes_accepted": True, "target_absent_after_cleanup": True,
            "physical_input_bindings": result_rows,
            "old_cli_api_rerun": False, "new_cli_api_commands_rerun": 20,
            "jdk_javac_java_jadx_runtime_rerun": False,
            "reused_evidence": evidence,
            "runtime_reuse_basis": "accepted v4 cleanup delta + root pre-meter 20-cell binding to the complete Java matrix; the new CLI replay changes no non-usage API output on the same physical class bytes",
            "acceptance_note": "This checks the actual 20-command run_validation receipt and API outputs. No old CLI or JDK/Javac/Java/JADX runtime was rerun here; the new CLI itself was run for 20 API commands. Full product acceptance remains separate."}
        args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(json.dumps({"status": result["status"], "api_cells": len(result_rows),
                          "commands": len(commands), "cli_sha256": actual_cli_sha,
                          "jdk_runtime_rerun": False}, indent=2))
        return 0
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError, zipfile.BadZipFile) as exc:
        result = {"status": "rejected", "reason": str(exc),
                  "replay_execution": str(args.replay_execution),
                  "broad_v3_receipt": str(args.broad_v3_receipt),
                  "expected_cli_sha256": args.expected_cli_sha256}
        args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(result["reason"], file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
