# Independent review for the existing run_validation.py replay

This v2 replaces the v1 preparation, whose imagined receipt schema did not match the selected runner. It accepts the actual 21-command receipt: 20 API invocations and a final successful `cargo clean`. It requires the real pending-independent-acceptance status and source guard fields, verifies every command's output/error stream pins, exit, working directory and disk guards, and requires the replay source closure to be byte-for-byte the supplied broad-v3 receipt's `source_after` closure. It also requires the live target directory to be absent.

For each API cell it aligns the existing accepted smoke command, pair ledger, physical input artifact, and pre-meter full-matrix class-byte pin. The replay command must differ from smoke only at `argv[0]`; its executable bytes and path must match both the caller-supplied SHA-256 and broad-v3 CLI pin. Parsed API JSON must be exactly equal after recursively omitting only `usage`. No compiler, VM, JADX, or old CLI is rerun by this reviewer.

Run after the root has completed the replay, supplying the broad-v3 receipt and its independently accepted CLI digest:

```sh
python3 -B review_replay20.py \
  --replay-execution /path/to/execution.json \
  --broad-v3-receipt /path/to/broad-v3/execution.json \
  --expected-cli-sha256 <sha256-from-broad-v3-cli-pin> \
  --repo-root /Users/lordcasser/workspace/projects/jarde \
  --out /path/to/new-review.json
```

The script and this README are private review preparation. Only Python AST parsing was performed; the reviewer was not run against the replay receipt. v1 remains preserved unchanged. This is an API replay integrity/equivalence check, not product acceptance.
