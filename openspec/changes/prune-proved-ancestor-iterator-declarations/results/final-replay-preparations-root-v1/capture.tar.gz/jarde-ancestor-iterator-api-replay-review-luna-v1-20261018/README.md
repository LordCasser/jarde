# Guarded 20-command API replay reviewer

`review_replay20.py` independently checks a completed API-only replay against the
accepted 20-cell smoke. It has no CLI/JDK invocation code. Pass the candidate CLI
SHA-256 explicitly from the broad-v3 build record; the checker does not pin or
guess the next CLI hash.

It requires commands 1–20 and their output cells to match the accepted smoke
ledger. For every command it verifies all stdout/stderr pins and exit/guard
fields, confirms argv differs only at argv[0], and requires the actual new CLI,
same cwd/environment, and same input path/bytes. It extracts each target `.class`
from the physical command input (including archive inputs), outputs its byte
length/SHA pin, and compares the full parsed API JSON recursively after removing
only keys named `usage`. When the receipt provides copied report/whole-source
files, it checks those pins against stdout and the report's complete `text`.

It rechecks source-closure pins and all protected-artifact pins against disk,
checks per-command 1 GiB / 5 GiB guards, CLI immutability, default stack, the
receipt's target-cleanup state, and the live absence of the repository `target`
directory. The smoke's extra command 21 must be the captured successful
`cargo clean`. The report records the new CLI's 20 API command reruns while
explicitly stating that Java/JDK/JADX runtimes were not rerun. It does not
recompute the earlier baseline-to-cleanup delta; that is bound through the
accepted v4 20-pair result and root's pre-meter full-matrix binding.

Run after the new guarded replay receipt is terminal:

```sh
python3 -B review_replay20.py \
  --replay-execution /path/to/guarded-replay/execution.json \
  --expected-cli-sha256 <sha256-from-broad-v3-final-cli-record> \
  --repo-root /Users/lordcasser/workspace/projects/jarde \
  --out /private/tmp/jarde-ancestor-iterator-api-replay-review-luna-v1-20261018/results/review.json
```

Prepared accepted evidence pins:

- Smoke execution SHA-256 `94c1e5187a38b4e098cd51198ccf2e85f68b3dbf481960f7341773009e245293`.
- Smoke pair ledger SHA-256 `50256024f488b8cfd6961c3564d34f0e947217a5695b837ce407a41df4798753`.
- Accepted v4 delta result SHA-256 `72cc6be55c5925b67f7166f3d04954a616586876af03d9b15a341a587c549701`.
- Root pre-meter 20-cell full-matrix binding SHA-256 `518aff2f2fd59008c43135ec5cf5371cc50a53e0ddb181b601f7e8900e5707f4`.

Only static receipt formats and those completed inputs were inspected while
preparing this reviewer. No replay receipt was opened, and this script has only
been syntax-parsed; no replay acceptance result exists yet.
