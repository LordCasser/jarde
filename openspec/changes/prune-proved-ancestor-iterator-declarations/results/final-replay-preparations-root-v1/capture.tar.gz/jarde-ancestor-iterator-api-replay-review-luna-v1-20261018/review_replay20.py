#!/usr/bin/env python3
"""Independently review a guarded 20-command API-only replay receipt."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

SMOKE_EXECUTION = Path("/private/tmp/jarde-ancestor-iterator-api-smoke-root-v1-20261018/execution.json")
SMOKE_EXECUTION_SHA256 = "94c1e5187a38b4e098cd51198ccf2e85f68b3dbf481960f7341773009e245293"
SMOKE_PAIRS = Path("/private/tmp/jarde-ancestor-iterator-api-smoke-prep-root-v1-20261018/pairs.json")
SMOKE_PAIRS_SHA256 = "50256024f488b8cfd6961c3564d34f0e947217a5695b837ce407a41df4798753"
SMOKE_RESULT = Path("/private/tmp/jarde-ancestor-iterator-delta-review-luna-v4-20261018/results/smoke20-utf8-validated.json")
SMOKE_RESULT_SHA256 = "72cc6be55c5925b67f7166f3d04954a616586876af03d9b15a341a587c549701"
PREMETER_BIND = Path("/private/tmp/jarde-ancestor-iterator-pre-meter-final-bind-root-v1-20261018.json")
PREMETER_BIND_SHA256 = "518aff2f2fd59008c43135ec5cf5371cc50a53e0ddb181b601f7e8900e5707f4"
OLD_SMOKE_CLI_SHA256 = "60e1b07691100a238c7462a400b381a2be923b366278349f1562f69d3d890ba5"
MAX_TARGET_BYTES = 1024**3
MIN_FREE_BYTES = 5 * 1024**3


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pin_file(path: Path, label: str) -> dict:
    path = path.resolve(strict=True)
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": sha(data)}


def check_pin(pin: dict, label: str) -> bytes:
    need(isinstance(pin, dict) and {"path", "bytes", "sha256"} <= set(pin),
         f"{label}: malformed pin")
    path = Path(pin["path"])
    data = path.read_bytes()
    need(len(data) == pin["bytes"] and sha(data) == pin["sha256"], f"{label}: raw pin mismatch")
    return data


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def strip_usage(value):
    if isinstance(value, list):
        return [strip_usage(item) for item in value]
    if isinstance(value, dict):
        return {key: strip_usage(item) for key, item in value.items() if key != "usage"}
    return value


def class_internal(role: str) -> str:
    if role == "original":
        return "jadx/tests/integration/loops/TestNestedLoops$TestCls.class"
    need(role == "controls", f"unknown pair role {role}")
    return "cf11/IteratorAncestorCases.class"


def class_bytes_from_input(path: Path, internal: str, label: str) -> bytes:
    need(path.is_file(), f"{label}: input missing: {path}")
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as archive:
            names = archive.namelist()
            need(names.count(internal) == 1, f"{label}: archive does not contain exactly one {internal}")
            return archive.read(internal)
    return path.read_bytes()


def validate_closure(root: Path, before: dict, after: dict, label: str) -> int:
    need(isinstance(before, dict) and isinstance(after, dict), f"{label}: closure pins missing")
    need(before == after, f"{label}: recorded source closure changed")
    for rel, recorded in before.items():
        path = root / rel
        need(Path(recorded.get("path", "")).resolve() == path.resolve(),
             f"{label}: source pin path is not rooted under repository: {rel}")
        check_pin(recorded, f"{label} source {rel}")
    return len(before)


def validate_protected(before: list, after: list, label: str) -> int:
    need(isinstance(before, list) and isinstance(after, list), f"{label}: protected pins missing")
    need(before == after, f"{label}: protected external artifacts changed")
    paths = set()
    for record in before:
        check_pin(record, f"{label} protected artifact")
        need(record["path"] not in paths, f"{label}: duplicate protected artifact pin")
        paths.add(record["path"])
    return len(paths)


def command_map(receipt: dict, label: str, allow_final_clean: bool = False) -> dict[int, dict]:
    rows = receipt.get("commands")
    expected_count = 21 if allow_final_clean else 20
    need(isinstance(rows, list) and len(rows) == expected_count,
         f"{label}: expected exactly {expected_count} command rows")
    result = {}
    for row in rows:
        index = row.get("index")
        need(isinstance(index, int) and index not in result, f"{label}: invalid/duplicate command index")
        result[index] = row
    expected_indices = set(range(1, expected_count + 1))
    need(set(result) == expected_indices, f"{label}: command indices are not contiguous 1..{expected_count}")
    if allow_final_clean:
        cleanup = result[21]
        need(cleanup.get("argv") == ["cargo", "clean"] and cleanup.get("exit_code") == 0,
             f"{label}: expected the recorded post-smoke cargo clean")
        check_pin(cleanup.get("streams", {}).get("stdout", {}), f"{label} cleanup stdout")
        clean_stderr = check_pin(cleanup.get("streams", {}).get("stderr", {}), f"{label} cleanup stderr")
        need(clean_stderr == b"", f"{label}: recorded cargo clean wrote stderr")
    return result


def validate_replay_guards(receipt: dict, expected_cli_sha: str, repo_root: Path) -> dict:
    need(receipt.get("status") == "captured-pending-independent-replay-review",
         "replay is not complete and awaiting independent review")
    need(receipt.get("default_stack") is True, "replay did not confirm default thread stack")
    need(receipt.get("source_unchanged") is True, "replay source closure guard failed")
    need(receipt.get("protected_unchanged") is True, "replay protected-artifact guard failed")
    need(receipt.get("target_absent") is True, "replay target cleanup flag is false")
    need(not (repo_root / "target").exists() and not (repo_root / "target").is_symlink(),
         "live repository target directory exists after replay")
    check_pin(receipt.get("runner", {}), "replay runner")
    tools = receipt.get("tools")
    need(isinstance(tools, list) and tools, "replay tool pins missing")
    for index, tool in enumerate(tools):
        check_pin(tool, f"replay support tool {index}")

    cli = receipt.get("cli")
    cli_bytes = check_pin(cli, "replay CLI")
    cli_sha = sha(cli_bytes)
    need(cli_sha == expected_cli_sha, f"replay CLI SHA-256 {cli_sha} differs from caller-supplied pin")
    need(receipt.get("cli_after") == cli, "CLI pin changed during replay")
    check_pin(receipt["cli_after"], "replay final CLI")

    source_count = validate_closure(repo_root, receipt.get("source_before"), receipt.get("source_after"), "replay")
    protected_count = validate_protected(receipt.get("protected_before"), receipt.get("protected_after"), "replay")

    rows = command_map(receipt, "replay")
    for index, row in rows.items():
        need(row.get("exit_code") == 0, f"replay command {index} exited {row.get('exit_code')}")
        need(row.get("guard_stop") is None, f"replay command {index} hit the disk guard")
        need(isinstance(row.get("peak_target_bytes"), int) and row["peak_target_bytes"] <= MAX_TARGET_BYTES,
             f"replay command {index} exceeded the 1 GiB target ceiling")
        need(isinstance(row.get("free_bytes_after"), int) and row["free_bytes_after"] >= MIN_FREE_BYTES,
             f"replay command {index} ended below the 5 GiB free-space floor")
        need(row.get("cwd") and Path(row["cwd"]).resolve() == repo_root.resolve(),
             f"replay command {index} ran outside the declared repository")
        streams = row.get("streams", {})
        check_pin(streams.get("stdout", {}), f"replay command {index} stdout")
        stderr = check_pin(streams.get("stderr", {}), f"replay command {index} stderr")
        need(stderr == b"", f"replay command {index} wrote stderr")
    return {"cli_sha256": cli_sha, "source_file_count": source_count,
            "protected_artifact_count": protected_count, "command_count": len(rows), "commands": rows}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--replay-execution", type=Path, required=True)
    ap.add_argument("--expected-cli-sha256", required=True)
    ap.add_argument("--repo-root", type=Path, default=Path("/Users/lordcasser/workspace/projects/jarde"))
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args(argv)
    if args.out.exists():
        raise SystemExit(f"refusing existing result {args.out}")
    if not args.out.parent.exists():
        raise SystemExit("result parent must already exist")
    try:
        need(re.fullmatch(r"[0-9a-f]{64}", args.expected_cli_sha256) is not None,
             "--expected-cli-sha256 must be 64 lowercase hex digits")
        root = args.repo_root.resolve(strict=True)
        smoke_raw = args.replay_execution  # keep all caller paths explicit in result
        smoke_exec = load(SMOKE_EXECUTION)
        pairs = load(SMOKE_PAIRS)
        smoke_result = load(SMOKE_RESULT)
        premeter = load(PREMETER_BIND)
        replay = load(args.replay_execution)

        need(sha(SMOKE_EXECUTION.read_bytes()) == SMOKE_EXECUTION_SHA256, "accepted smoke receipt pin changed")
        need(sha(SMOKE_PAIRS.read_bytes()) == SMOKE_PAIRS_SHA256, "accepted smoke pair ledger pin changed")
        need(sha(SMOKE_RESULT.read_bytes()) == SMOKE_RESULT_SHA256, "accepted smoke v4 result pin changed")
        need(sha(PREMETER_BIND.read_bytes()) == PREMETER_BIND_SHA256, "pre-meter full-matrix binding receipt pin changed")
        need(smoke_result.get("status") == "pairwise_smoke_exact_delta_pass_not_product_acceptance"
             and smoke_result.get("checked_pairs") == 20
             and smoke_result.get("execution_sha256") == SMOKE_EXECUTION_SHA256,
             "accepted v4 smoke delta result is invalid")
        need(premeter.get("status") == "fresh_api_reports_bound_to_smoke_nonusage_exact_not_product_acceptance"
             and premeter.get("checked_api_cells") == 20
             and premeter.get("argv_identical_count") == 0
             and premeter.get("argv_different_count") == 20
             and premeter.get("smoke_v4_result_sha256") == SMOKE_RESULT_SHA256,
             "root pre-meter binding receipt is not the accepted 20-cell binding")
        need(smoke_exec.get("status") == "commands_passed_pending_independent_acceptance",
             "accepted smoke receipt status changed")
        need(len(pairs) == 20 and [p.get("index") for p in pairs] == list(range(1, 21)),
             "accepted smoke pair ledger is not exactly 20 ordered rows")

        replay_guard = validate_replay_guards(replay, args.expected_cli_sha256, root)
        replay_commands = replay_guard["commands"]
        smoke_commands = command_map(smoke_exec, "accepted smoke", allow_final_clean=True)
        need(len(replay.get("cells", [])) == 20, "replay receipt must identify exactly 20 report cells")
        replay_cells = {cell.get("command"): cell for cell in replay["cells"]}
        need(set(replay_cells) == set(range(1, 21)), "replay report cell command bindings are not 1..20")

        smoke_cli_paths = {Path(smoke_commands[i]["argv"][0]).resolve(strict=True) for i in range(1, 21)}
        need(len(smoke_cli_paths) == 1, "accepted smoke did not use one CLI binary for all 20 cells")
        smoke_cli_pin = pin_file(next(iter(smoke_cli_paths)), "accepted smoke CLI")
        need(smoke_cli_pin["sha256"] == OLD_SMOKE_CLI_SHA256,
             "accepted smoke CLI binary no longer matches its frozen v4 result pin")
        replay_cli_path = Path(replay["cli"]["path"]).resolve(strict=True)
        input_pins = {}
        class_cache = {}

        results = []
        for pair in pairs:
            index = pair["index"]
            old = smoke_commands[index]
            new = replay_commands[index]
            old_argv, new_argv = old.get("argv", []), new.get("argv", [])
            need(old.get("exit_code") == 0, f"accepted smoke command {index} was not exit 0")
            need(len(old_argv) >= 2 and len(new_argv) == len(old_argv),
                 f"pair {index}: argv lengths differ")
            need(old_argv[1:] == new_argv[1:],
                 f"pair {index}: replay argv differs beyond executable path")
            need(old.get("cwd") == new.get("cwd") == str(root),
                 f"pair {index}: replay working directory differs from original smoke")
            need(old.get("env_overrides") == new.get("env_overrides"),
                 f"pair {index}: replay command environment differs from accepted smoke")
            need(Path(new_argv[0]).resolve() == Path(replay["cli"]["path"]).resolve(),
                 f"pair {index}: replay argv[0] does not bind to pinned new CLI")
            need(Path(old_argv[0]).resolve() == next(iter(smoke_cli_paths)),
                 f"pair {index}: smoke command used another CLI binary")
            need(Path(new_argv[0]).resolve() == replay_cli_path,
                 f"pair {index}: replay command used another CLI binary")
            need("--input" in old_argv and "--input" in new_argv,
                 f"pair {index}: --input missing")
            old_input_path = Path(old_argv[old_argv.index("--input") + 1])
            new_input_path = Path(new_argv[new_argv.index("--input") + 1])
            need(old_input_path.resolve() == new_input_path.resolve(),
                 f"pair {index}: physical API input path changed")
            cache_key = str(old_input_path.resolve())
            if cache_key not in input_pins:
                input_pins[cache_key] = pin_file(old_input_path, f"pair {index} old input")
            old_input_pin = input_pins[cache_key]
            new_input_pin = pin_file(new_input_path, f"pair {index} replay input")
            need(old_input_pin == new_input_pin, f"pair {index}: raw API input artifact bytes changed")

            stdout_old = check_pin(old.get("streams", {}).get("stdout", {}), f"smoke {index} stdout")
            stdout_new = check_pin(new.get("streams", {}).get("stdout", {}), f"replay {index} stdout")
            old_doc = json.loads(stdout_old.decode("utf-8", "strict"))
            new_doc = json.loads(stdout_new.decode("utf-8", "strict"))
            need(strip_usage(old_doc) == strip_usage(new_doc),
                 f"pair {index}: replay JSON differs from accepted smoke outside usage fields")

            role = pair["role"]
            internal = class_internal(role)
            class_key = (cache_key, internal)
            if class_key not in class_cache:
                class_cache[class_key] = class_bytes_from_input(old_input_path, internal, f"smoke {index}")
            old_class = class_cache[class_key]
            new_class = class_bytes_from_input(new_input_path, internal, f"replay {index}")
            need(old_class == new_class, f"pair {index}: physical target class bytes changed")
            old_class_identity = old_doc.get("class", {}).get("class_bytes", {})
            new_class_identity = new_doc.get("class", {}).get("class_bytes", {})
            need(old_class_identity == new_class_identity, f"pair {index}: report class identity changed")
            need(old_class_identity.get("length") == len(old_class),
                 f"pair {index}: report class length differs from actual class bytes")

            cell = replay_cells[index]
            need(cell.get("command") == index, f"pair {index}: output cell command mismatch")
            if "old_command" in cell:
                need(cell["old_command"] == index, f"pair {index}: cell points at a different old smoke command")
            if "selectors" in cell:
                selectors = cell["selectors"]
                for key in ("profile", "input_form", "evidence"):
                    if key in pair:
                        need(selectors.get(key) == pair[key], f"pair {index}: cell selector {key} differs")
            if "family" in cell:
                need(cell["family"] == role, f"pair {index}: replay cell family differs")
            if "old_report" in cell:
                old_pin = cell["old_report"]
                old_pin_raw = check_pin(old_pin, f"replay cell {index} prior report")
                need(old_pin.get("bytes") == len(stdout_old) and old_pin.get("sha256") == sha(stdout_old),
                     f"pair {index}: cell old-report pin differs from accepted smoke output")
                need(old_pin_raw == stdout_old,
                     f"pair {index}: cell prior report contents differ from accepted smoke output")
            if "report" in cell:
                report_raw = check_pin(cell["report"], f"replay cell {index} report")
                need(report_raw == stdout_new, f"pair {index}: replay report pin is not exact stdout")
            if "whole_source" in cell:
                whole = check_pin(cell["whole_source"], f"replay cell {index} whole source")
                need(whole == new_doc.get("text", "").encode("utf-8"),
                     f"pair {index}: whole-source pin differs from complete JSON text")

            results.append({"index": index, "role": role, "profile": pair["profile"],
                "input_form": pair.get("input_form"), "evidence": pair["evidence"],
                "old_argv": old_argv, "replay_argv": new_argv,
                "argv_diff_only_executable": True,
                "command_input_pin": old_input_pin,
                "physical_class_pin": {"internal_name": internal, "bytes": len(old_class),
                                        "sha256": sha(old_class)},
                "smoke_stdout": old["streams"]["stdout"], "replay_stdout": new["streams"]["stdout"],
                "comparison": "complete parsed JSON equal after recursively deleting only usage keys"})

        result = {"status": "guarded_20_api_replay_exact_nonusage_pass_not_product_acceptance",
            "replay_execution": str(smoke_raw), "replay_execution_sha256": sha(args.replay_execution.read_bytes()),
            "new_cli_expected_sha256": args.expected_cli_sha256,
            "accepted_smoke_execution_sha256": SMOKE_EXECUTION_SHA256,
            "accepted_smoke_pairs_sha256": SMOKE_PAIRS_SHA256,
            "accepted_smoke_result_sha256": SMOKE_RESULT_SHA256,
            "pre_meter_full_matrix_binding_path": str(PREMETER_BIND),
            "pre_meter_full_matrix_binding_sha256": PREMETER_BIND_SHA256,
            "repo_root": str(root), "source_closure_files": replay_guard["source_file_count"],
            "protected_artifacts": replay_guard["protected_artifact_count"],
            "checked_cells": len(results),
            "old_cli_rerun": False,
            "new_cli_api_commands_rerun": 20,
            "jdk_javac_java_jadx_runtime_rerun": False,
            "runtime_reuse_basis": "accepted smoke non-usage JSON was already bound to the complete final API matrix; exact 20-argv replay preserves these outputs while reusing separately accepted full JDK/runtime captures",
            "guards": {"default_stack": True, "per_command_target_ceiling_bytes": MAX_TARGET_BYTES,
                       "per_command_free_space_floor_bytes": MIN_FREE_BYTES,
                       "source_unchanged": True, "protected_unchanged": True,
                       "target_absent": True, "live_target_absent": True},
            "cells": results,
            "acceptance_note": "This verifies the API-only replay and its source/resource guards. It does not rerun Java/JDK/JADX runtime tests and does not independently recalculate the original baseline-to-cleanup declaration delta."}
        args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(json.dumps({"status": result["status"], "checked_cells": len(results),
                          "new_cli_sha256": args.expected_cli_sha256,
                          "jdk_javac_java_jadx_runtime_rerun": False}, indent=2))
        return 0
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError, zipfile.BadZipFile) as exc:
        result = {"status": "rejected", "reason": str(exc),
                  "replay_execution": str(args.replay_execution),
                  "expected_cli_sha256": args.expected_cli_sha256}
        args.out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(result["reason"], file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
