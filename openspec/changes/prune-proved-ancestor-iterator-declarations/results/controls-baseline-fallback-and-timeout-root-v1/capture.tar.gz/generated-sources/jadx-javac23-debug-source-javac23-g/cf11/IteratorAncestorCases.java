package cf11;

import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.jar:cf11/IteratorAncestorCases.class */
public final class IteratorAncestorCases {
    public static int observed;

    public static int ancestor(List<String> values) {
        observed = 0;
        Iterator<String> iterator = values.iterator();
        while (iterator.hasNext()) {
            String item = iterator.next();
            observed += item == null ? -1 : item.length();
        }
        return observed;
    }

    public static int sameList(List<String> values) {
        observed = 0;
        Iterator<String> outer = values.iterator();
        while (outer.hasNext()) {
            String outerValue = outer.next();
            Iterator<String> inner = values.iterator();
            while (inner.hasNext()) {
                String innerValue = inner.next();
                observed += outerValue == null ? -1 : outerValue.length();
                observed += innerValue == null ? -1 : innerValue.length();
            }
        }
        return observed;
    }

    public static int protectedPositive(List<String> values) {
        observed = 0;
        try {
            Iterator<String> iterator = values.iterator();
            while (iterator.hasNext()) {
                String item = iterator.next();
                observed += item == null ? -1 : item.length();
            }
        } catch (IllegalStateException e) {
            observed += 100;
        }
        return observed;
    }

    public static int protectedBeforeRead(List<String> values) {
        observed = 0;
        Iterator<String> iterator = values.iterator();
        if (iterator.hasNext()) {
            observed += 10;
        }
        while (iterator.hasNext()) {
            try {
                String item = iterator.next();
                observed += item == null ? -1 : item.length();
            } catch (IllegalStateException e) {
                observed += 100;
            }
        }
        return observed;
    }

    public static int protectedAfterRead(List<String> values) {
        observed = 0;
        Iterator<String> iterator = values.iterator();
        while (iterator.hasNext()) {
            try {
                String item = iterator.next();
                observed += item == null ? -1 : item.length();
            } catch (IllegalStateException e) {
                observed += 100;
            }
        }
        if (iterator.hasNext()) {
            observed += 10;
        }
        return observed;
    }

    public static int protectedAfterWrite(List<String> values, List<String> fallback) {
        observed = 0;
        try {
            Iterator<String> iterator = values.iterator();
            while (iterator.hasNext()) {
                String item = iterator.next();
                observed += item == null ? -1 : item.length();
            }
        } catch (IllegalStateException e) {
            observed += 100;
        }
        if (fallback.iterator().hasNext()) {
            observed += 10;
        }
        return observed;
    }

    public static int protectedCatchReadWrite(List<String> values, List<String> fallback) {
        observed = 0;
        Iterator<String> iterator = values.iterator();
        while (iterator.hasNext()) {
            try {
                String item = iterator.next();
                observed += item == null ? -1 : item.length();
            } catch (IllegalStateException e) {
                if (iterator.hasNext()) {
                    observed += 10;
                }
                if (fallback.iterator().hasNext()) {
                    observed += 20;
                }
            }
        }
        return observed;
    }

    public static int reusedSlots(List<String> first, List<String> second) {
        observed = 0;
        Iterator<String> firstIterator = first.iterator();
        while (firstIterator.hasNext()) {
            String item = firstIterator.next();
            observed += item == null ? -1 : item.length();
        }
        Iterator<String> secondIterator = second.iterator();
        while (secondIterator.hasNext()) {
            String item2 = secondIterator.next();
            observed += item2 == null ? -1 : item2.length();
        }
        return observed;
    }

    public static int siblingNames(List<String> left, List<String> right, boolean useLeft) {
        observed = 0;
        if (useLeft) {
            Iterator<String> iterator = left.iterator();
            while (iterator.hasNext()) {
                String item = iterator.next();
                observed += item == null ? -1 : item.length();
            }
        } else {
            Iterator<String> iterator2 = right.iterator();
            while (iterator2.hasNext()) {
                String item2 = iterator2.next();
                observed += item2 == null ? -1 : item2.length();
            }
        }
        return observed;
    }
}
