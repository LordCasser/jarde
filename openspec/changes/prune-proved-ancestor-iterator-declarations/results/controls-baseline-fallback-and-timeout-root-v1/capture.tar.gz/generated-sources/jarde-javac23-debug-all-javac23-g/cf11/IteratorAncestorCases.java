// jarde: presentation of `cf11/IteratorAncestorCases` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package cf11;

public final class IteratorAncestorCases extends java.lang.Object {
    public static int observed;

    public IteratorAncestorCases() {
        // @method <init>()V
        // @declaration a constructor of `cf11.IteratorAncestorCases`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    // jarde: generic Signature projection refused for `ancestor(Ljava/util/List;)I`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public static int ancestor(java.util.List values) {
        // @method ancestor(Ljava/util/List;)I
        // @declaration a static method of `cf11.IteratorAncestorCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        cf11.IteratorAncestorCases.observed = 0;
        for (java.lang.Object iteratorElement21 : values) {
            java.lang.String item = (java.lang.String) iteratorElement21;
            // @bytecode 30
            // the saved producer at BCI 30 has 3 consumers, so one local binding cannot prove its execution count
            // @bytecode 46 30
            // the value at BCI 46 was produced by a saved declaration this run could not commit
        }
        return cf11.IteratorAncestorCases.observed;
    }

    // jarde: generic Signature projection refused for `sameList(Ljava/util/List;)I`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public static int sameList(java.util.List values) {
        // @method sameList(Ljava/util/List;)I
        // @declaration a static method of `cf11.IteratorAncestorCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        cf11.IteratorAncestorCases.observed = 0;
        java.lang.String outerValue;
        java.util.Iterator inner;
        for (java.lang.Object iteratorElement21 : values) {
            outerValue = (java.lang.String) iteratorElement21;
            java.lang.String innerValue;
            for (java.lang.Object iteratorElement47 : values) {
                innerValue = (java.lang.String) iteratorElement47;
                // @bytecode 57
                // the saved producer at BCI 57 has 3 consumers, so one local binding cannot prove its execution count
                // @bytecode 73 57
                // the value at BCI 73 was produced by a saved declaration this run could not commit
                // @bytecode 76
                // the saved producer at BCI 76 has 3 consumers, so one local binding cannot prove its execution count
                // @bytecode 94 76
                // the value at BCI 94 was produced by a saved declaration this run could not commit
            }
        }
        return cf11.IteratorAncestorCases.observed;
    }

    // jarde: generic Signature projection refused for `protectedPositive(Ljava/util/List;)I`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public static int protectedPositive(java.util.List values) {
        // @method protectedPositive(Ljava/util/List;)I
        // @declaration a static method of `cf11.IteratorAncestorCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 11 20 37 41 45 55
        // local 2 escapes catch parameter scope at region [0, 1]; its catch header cannot declare a method-visible local
        return cf11.IteratorAncestorCases.observed;
    }

    // jarde: generic Signature projection refused for `protectedBeforeRead(Ljava/util/List;)I`: unsupported (ordinary_generic_source_unproved): method body or no-body declaration has no complete source proof
    public static int protectedBeforeRead(java.util.List values) {
        // jarde: not recovered: the recovery run for `protectedBeforeRead(Ljava/util/List;)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method protectedBeforeRead(Ljava/util/List;)I
        // @declaration a static method of `cf11.IteratorAncestorCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 20 29 38 55 59 63 70 73 83
        // local 1 crosses a quoted fallback region; its assignments and consumers cannot be presented as one lexically bound definition-use slice
    }

    // jarde: generic Signature projection refused for `protectedAfterRead(Ljava/util/List;)I`: unsupported (ordinary_generic_source_unproved): method body or no-body declaration has no complete source proof
    public static int protectedAfterRead(java.util.List values) {
        // jarde: not recovered: the recovery run for `protectedAfterRead(Ljava/util/List;)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method protectedAfterRead(Ljava/util/List;)I
        // @declaration a static method of `cf11.IteratorAncestorCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 11 20 37 41 45 52 55 65 74 83
        // local 1 crosses a quoted fallback region; its assignments and consumers cannot be presented as one lexically bound definition-use slice
    }

    // jarde: generic Signature projection refused for `protectedAfterWrite(Ljava/util/List;Ljava/util/List;)I`: unsupported (ordinary_generic_source_unproved): method body or no-body declaration has no complete source proof
    public static int protectedAfterWrite(java.util.List values, java.util.List fallback) {
        // jarde: not recovered: the recovery run for `protectedAfterWrite(Ljava/util/List;Ljava/util/List;)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method protectedAfterWrite(Ljava/util/List;Ljava/util/List;)I
        // @declaration a static method of `cf11.IteratorAncestorCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 11 20 37 41 45 52 55 65 81 90
        // local 2 crosses a protected region, but SSA does not prove that every path to its reads reaches a presented write
    }

    // jarde: generic Signature projection refused for `protectedCatchReadWrite(Ljava/util/List;Ljava/util/List;)I`: unsupported (ordinary_generic_source_unproved): method body or no-body declaration has no complete source proof
    public static int protectedCatchReadWrite(java.util.List values, java.util.List fallback) {
        // jarde: not recovered: the recovery run for `protectedCatchReadWrite(Ljava/util/List;Ljava/util/List;)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method protectedCatchReadWrite(Ljava/util/List;Ljava/util/List;)I
        // @declaration a static method of `cf11.IteratorAncestorCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 11 20 37 41 45 52 55 65 74 90 99
        // local 2 crosses a quoted fallback region; its assignments and consumers cannot be presented as one lexically bound definition-use slice
    }

    // jarde: generic Signature projection refused for `reusedSlots(Ljava/util/List;Ljava/util/List;)I`: unsupported (ordinary_generic_source_unproved): same-run Program/SSA cannot prove the body under parameterized types
    public static int reusedSlots(java.util.List first, java.util.List second) {
        // @method reusedSlots(Ljava/util/List;Ljava/util/List;)I
        // @declaration a static method of `cf11.IteratorAncestorCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        java.util.Iterator local2;
        java.lang.String item;
        cf11.IteratorAncestorCases.observed = 0;
        local2 = first.iterator();
        while (local2.hasNext()) {
            item = (java.lang.String) local2.next();
            // @bytecode 30
            // the saved producer at BCI 30 has 3 consumers, so one local binding cannot prove its execution count
            // @bytecode 46 30
            // the value at BCI 46 was produced by a saved declaration this run could not commit
        }
        local2 = second.iterator();
        while (local2.hasNext()) {
            item = (java.lang.String) local2.next();
            // @bytecode 78
            // the saved producer at BCI 78 has 3 consumers, so one local binding cannot prove its execution count
            // @bytecode 94 78
            // the value at BCI 94 was produced by a saved declaration this run could not commit
        }
        return cf11.IteratorAncestorCases.observed;
    }

    // jarde: generic Signature projection refused for `siblingNames(Ljava/util/List;Ljava/util/List;Z)I`: unsupported (ordinary_generic_source_unproved): method body or no-body declaration has no complete source proof
    public static int siblingNames(java.util.List left, java.util.List right, boolean useLeft) {
        // jarde: not recovered: the recovery run for `siblingNames(Ljava/util/List;Ljava/util/List;Z)I` produced no statement (explanation only); the artifact's own comment lines are below
        // @method siblingNames(Ljava/util/List;Ljava/util/List;Z)I
        // @declaration a static method of `cf11.IteratorAncestorCases`, member flags 0x0009
        // recovered from bytecode; presentation is not claimed to compile
        // @bytecode 0 8 15 24 43 47 52 59 62 69 78 97 101 106 113
        // local 3 crosses a quoted fallback region; its assignments and consumers cannot be presented as one lexically bound definition-use slice
    }
}
