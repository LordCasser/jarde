#!/usr/bin/env python3
"""Capture original/generated Iterator-ancestor controls. Preparation artifact; root must review before execution."""
from __future__ import annotations
import argparse, datetime, hashlib, importlib.util, json, os, re, shutil, sys, zipfile
from pathlib import Path
sys.dont_write_bytecode = True

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
BASE = Path('/private/tmp/jarde-foreach-fold-original-root-v1-20261018/execution.json')
BASE_SHA = '1fbc03d82b6255275d31e0ce75624ef896a73491a50e09670927062e4318a953'
SOURCE = Path(__file__).with_name('family') / 'IteratorAncestorCases.java'
DRIVER = Path(__file__).with_name('driver') / 'IteratorAncestorDriver.java'
RUNTIME = Path(__file__).with_name('runtime_timeout.py')
SOURCE_SHA = '77c6d999dec1ca32d69b4cac87a1f2a6e5d7ef2b5139cf155d016a942dff5aa0'
DRIVER_SHA = 'c404b4444940c65ac573d5f667e14f4c60660a66ec633df0d8bf8b7d5d7a51c9'
RUNTIME_SHA = '73d1bedf469b7bb87d6fc860b12660fd6f4834d022f72c88b6c093e98ce312ca'
INTERNAL = 'cf11/IteratorAncestorCases'
TARGET_DOT = INTERNAL.replace('/', '.')
DRIVER_NAME = 'IteratorAncestorDriver'
COMPARE = 'openspec/changes/recover-exception-only-finally-completion/tools/compare.py'
CH = '18bef8e21e525d61014c2c3419efdb5671120177a24fd41549935bd743bf18e6'
GUARD = 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GH = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER = 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SH = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
MANIFEST = 'openspec/changes/recover-nested-int-array-compound-updates/results/controls-v1/manifest.json'
MH = 'ec27b5a0e8a9d2345d289b4626bac516e055e0f86d70ab3b2f744c336f961aec'
PARSER = Path('/private/tmp/jarde-seq2-baseline-prep-root-v4-20261018/classfile_helpers.py')
PH = 'c9f064d714decd49f028e403709307106547aa2acc7462ed703aeaaf158766cd'
BASELINE_CLI_SHA = 'c688920cac70ee9e46681672ebaaba5df2948c5ef5b5f262d006548ca1f83ebe'
PROFILES = ('javac8-debug', 'javac8-no-debug', 'javac23-debug', 'javac23-no-debug')
LEGS = ('javac8', 'javac23')
VMS = LEGS
EVIDENCE = ('default', 'all', 'source_map')
CASE_NAMES = (
    'ancestor-empty', 'ancestor-normal', 'ancestor-null-element', 'ancestor-wrong-after-success',
    'ancestor-null-source', 'same-list-empty', 'same-list-normal', 'same-list-wrong-element',
    'protected-normal', 'protected-hasNext-throws', 'protected-next-throws', 'protected-before-read',
    'protected-after-read', 'protected-after-write', 'protected-catch-read-write',
    'reused-slots-both', 'reused-slots-empty-left', 'sibling-name-left', 'sibling-name-right',
)
EXPECTED_METHOD_ACCESS = {
    ('<init>', '()V'): 0x0001,
    ('ancestor', '(Ljava/util/List;)I'): 0x0009,
    ('sameList', '(Ljava/util/List;)I'): 0x0009,
    ('protectedPositive', '(Ljava/util/List;)I'): 0x0009,
    ('protectedBeforeRead', '(Ljava/util/List;)I'): 0x0009,
    ('protectedAfterRead', '(Ljava/util/List;)I'): 0x0009,
    ('protectedAfterWrite', '(Ljava/util/List;Ljava/util/List;)I'): 0x0009,
    ('protectedCatchReadWrite', '(Ljava/util/List;Ljava/util/List;)I'): 0x0009,
    ('reusedSlots', '(Ljava/util/List;Ljava/util/List;)I'): 0x0009,
    ('siblingNames', '(Ljava/util/List;Ljava/util/List;Z)I'): 0x0009,
}
EXPECTED_METHODS = set(EXPECTED_METHOD_ACCESS)
EXPECTED_FIELDS = {('observed', 'I', 9)}
ENV_STRIP = ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'CARGO_TARGET_DIR')


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load helper {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def classfacts(compare, physical, root: Path) -> dict:
    result = {}
    files = sorted(root.rglob('*.class'))
    for path in files:
        facts = compare.parse_class(path)
        independent = physical.parse_class_file(path.read_bytes())
        if (facts['class_name'] != independent['class_name'] or facts['major'] != independent['major']
                or facts['methods'] != independent['methods']
                or sorted((x['name'], x['descriptor'], x['access']) for x in independent['fields'])
                != sorted(facts['fields'])):
            raise RuntimeError(f'class parser disagreement: {path}')
        if facts['major'] != 52:
            raise RuntimeError(f'compiled class is not Java 8 classfile: {path}')
        for method in independent['methods']:
            code = method.get('code')
            if not code or physical.decode_bcis(bytes.fromhex(code['code_hex'])) != code['bcis']:
                raise RuntimeError(f'invalid/missing physical Code facts: {path}::{method.get("name")}')
        facts['access'] = independent['access']
        result[path.relative_to(root).as_posix()] = facts
    return result


def target_facts(compare, physical, root: Path) -> dict:
    facts = classfacts(compare, physical, root)
    expected_path = INTERNAL + '.class'
    if set(facts) != {expected_path}:
        raise RuntimeError(f'target class closure differs from one-class source family: {sorted(facts)}')
    target = facts[expected_path]
    methods = {(m['name'], m['descriptor']) for m in target['methods']}
    fields = {(f[0], f[1], f[2]) for f in target['fields']}
    access = physical.parse_class_file((root / expected_path).read_bytes())['access']
    method_access = {(m['name'], m['descriptor']): m['access'] for m in target['methods']}
    if access != 0x0031 or methods != EXPECTED_METHODS or fields != EXPECTED_FIELDS or method_access != EXPECTED_METHOD_ACCESS:
        raise RuntimeError(f'physical source member inventory/access differs: class={access:#x}, methods={method_access}, fields={fields}')
    return facts


def inventory(facts: dict) -> dict:
    return {path: (item['class_name'], item['major'], item['access'],
                   tuple(sorted(tuple(field) for field in item['fields'])),
                   tuple(sorted((m['name'], m['descriptor'], m['access']) for m in item['methods'])))
            for path, item in facts.items()}


def parse_cases(raw: bytes) -> list[dict]:
    lines = raw.decode('utf-8', 'strict').splitlines()
    pattern = re.compile(r'^CASE name=([a-z0-9-]+) method=([A-Za-z][A-Za-z0-9]*) exception=([^ ]+) returned=([^ ]+) observed=(-?\d+) trace=([^ ]*)$')
    rows = []
    for index, line in enumerate(lines):
        match = pattern.fullmatch(line)
        if match is None:
            raise ValueError(f'malformed driver case row: {line!r}')
        name, method, exception, returned, observed, trace = match.groups()
        rows.append({'index': index, 'name': name, 'method': method, 'exception_type': exception,
                     'returned_base64': returned, 'observed': int(observed), 'trace_base64': trace, 'raw': line})
    if [row['name'] for row in rows] != list(CASE_NAMES):
        raise ValueError(f'expected exact 19 ordered rows, got {[row["name"] for row in rows]}')
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=('baseline', 'final'), default='baseline')
    parser.add_argument('--cli', type=Path, required=True)
    parser.add_argument('--cli-sha256', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    root = ROOT.resolve(strict=True)
    out = args.out.resolve()
    cli = args.cli.resolve(strict=True)
    if out.exists():
        raise SystemExit(f'refusing existing output: {out}')
    if out == root or out.is_relative_to(root):
        raise SystemExit('capture output must be private and outside the repository')
    if re.fullmatch(r'[0-9a-f]{64}', args.cli_sha256) is None or sha(cli) != args.cli_sha256:
        raise SystemExit('CLI differs from explicitly supplied lowercase SHA-256')
    if args.phase == 'baseline' and args.cli_sha256 != BASELINE_CLI_SHA:
        raise SystemExit('baseline phase requires the pinned baseline CLI SHA')
    if (root / 'target').exists() or (root / 'target').is_symlink():
        raise SystemExit('repository target must be absent before capture')
    if shutil.disk_usage(root).free < 5 * 1024**3:
        raise SystemExit('less than 5 GiB free before capture')

    compare_path, guard_path, scanner_path, manifest_path = (root / COMPARE, root / GUARD, root / SCANNER, root / MANIFEST)
    for path, expected, label in ((compare_path, CH, 'compare'), (guard_path, GH, 'guard'),
                                  (scanner_path, SH, 'target scanner'), (manifest_path, MH, 'JDK manifest'),
                                  (PARSER, PH, 'physical parser'), (BASE, BASE_SHA, 'tool reference receipt'),
                                  (SOURCE, SOURCE_SHA, 'target Java source'), (DRIVER, DRIVER_SHA, 'reflection driver'),
                                  (RUNTIME, RUNTIME_SHA, 'timeout wrapper')):
        if not path.is_file() or sha(path) != expected:
            raise SystemExit(f'{label} pin mismatch: {path}')

    compare = load(compare_path, 'iterator_ancestor_compare')
    guard = load(guard_path, 'iterator_ancestor_guard')
    scanner = load(scanner_path, 'iterator_ancestor_scanner')
    physical = load(PARSER, 'iterator_ancestor_physical')
    jdks, manifest_record = compare.configured_jdks(manifest_path, MH)
    tool_reference = json.loads(BASE.read_text(encoding='utf-8'))
    if tool_reference.get('schema') != 'cf11-testnestedloops-current-full-source-baseline-v1':
        raise SystemExit('pinned tool-reference receipt schema differs')
    for key in ('jadx', 'jadx_jar', 'runtime_wrapper'):
        rec = tool_reference.get(key)
        if not isinstance(rec, dict) or compare.pin(Path(rec.get('path', ''))) != rec:
            raise SystemExit(f'tool reference pin mismatch: {key}')
    jadx = Path(tool_reference['jadx']['path'])
    jadx_jar = Path(tool_reference['jadx_jar']['path'])
    runtime_original = Path(tool_reference['runtime_wrapper']['path'])
    for spec in jdks.values():
        for tool in spec['tools'].values():
            if not Path(tool).is_file():
                raise SystemExit(f'configured JDK tool missing: {tool}')

    source_before = compare.source_closure(root)
    out.mkdir(parents=True)
    raw_dir = out / 'raw'
    raw_dir.mkdir()
    empty = out / 'empty-classpath'
    empty.mkdir()
    guard.ROOT = root
    guard.OUT = raw_dir
    guard.target_bytes = lambda: scanner.target_bytes(root)
    guard.command_stream = compare.pin
    guard.expected_test_summaries = lambda index, data: None

    copied_source = out / 'input' / SOURCE.name
    copied_source.parent.mkdir()
    copied_driver = out / 'input' / DRIVER.name
    shutil.copyfile(SOURCE, copied_source)
    shutil.copyfile(DRIVER, copied_driver)
    runtime_copy = out / 'runtime_timeout.py'
    shutil.copyfile(runtime_original, runtime_copy)
    if copied_source.read_bytes() != SOURCE.read_bytes() or copied_driver.read_bytes() != DRIVER.read_bytes() or runtime_copy.read_bytes() != runtime_original.read_bytes():
        raise RuntimeError('local input or timeout-wrapper copy differs')

    external = [BASE, compare_path, guard_path, scanner_path, manifest_path, PARSER, cli, jadx, jadx_jar,
                runtime_original, SOURCE, DRIVER, Path(__file__),
                *[Path(tool) for spec in jdks.values() for tool in spec['tools'].values()]]
    external_before = [compare.pin(path) for path in external]
    local_before = {str(path): compare.pin(path) for path in (copied_source, copied_driver, runtime_copy)}
    protected: dict[str, dict] = {str(p): compare.pin(p) for p in (copied_source, copied_driver, runtime_copy)}
    report = {
        'schema': 'cf11-iterator-ancestor-controls-matrix-v1', 'status': 'running', 'phase': args.phase,
        'root': str(root), 'output': str(out), 'cli': compare.pin(cli), 'expected_cli_sha256': args.cli_sha256,
        'tool_reference_receipt': compare.pin(BASE), 'tool_reference_jadx': tool_reference['jadx'],
        'tool_reference_jadx_jar': tool_reference['jadx_jar'], 'jdk_manifest': manifest_record,
        'compare': compare.pin(compare_path), 'guard': compare.pin(guard_path),
        'scanner': compare.pin(scanner_path), 'physical_parser': compare.pin(PARSER),
        'driver_source': compare.pin(DRIVER), 'target_source': compare.pin(SOURCE),
        'source_pins_before': source_before, 'external_pins_before': external_before,
        'local_copies_before': local_before, 'guard_limits': {'free_bytes': 5 * 1024**3, 'target_bytes': 1 << 30},
        'commands': [], 'source_profiles': [], 'original_runs': [], 'original_wrong_root': [],
        'jarde_cells': [], 'jadx_cells': [], 'generated_compiles': [], 'generated_runs': [],
        'generated_wrong_root': [], 'notes': [
            'All observations are captured from complete, unedited Java source/API/decompiler outputs; projection classifications are intentionally not hardcoded.',
            'API evidence axes are default, all, and one explicit source_map category; no essential/no-rule-details label is substituted.',
            'Generated compilation failures are retained as failed cells and have no runtime rows; runtime comparisons use exact ordered 19-row stdout oracles.',
            'The fixed class root contains one complete target class; the parentless driver is compiled separately and is the application classpath only.'
        ]}
    compare.write_json(out / 'execution.json', report)
    commands = report['commands']

    def command(argv, label, leg):
        if (root / 'target').exists() or (root / 'target').is_symlink():
            raise RuntimeError('repository target appeared during capture')
        env = compare.clean_env(dict(os.environ), jdks[leg])
        env.update(guard.ENV_VALUES)
        env.pop('RUST_MIN_STACK', None)
        result = guard.run_command(len(commands) + 1, [str(arg) for arg in argv], env)
        result['label'] = label
        result['tool_leg'] = leg
        commands.append(result)
        for channel in ('stdout', 'stderr'):
            raw_path = Path(result['streams'][channel]['path'])
            compare.command_artifact(result, channel)
            register(raw_path)
        compare.write_json(out / 'execution.json', report)
        if result.get('guard_stop') is not None or result.get('free_bytes_after', 0) < 5 * 1024**3 or result.get('peak_target_bytes', 0) > 1 << 30:
            raise RuntimeError(f'resource guard failed/stopped command {label}')
        return result

    def artifact(result, channel):
        return compare.command_artifact(result, channel)

    def stream_pins(result):
        return {channel: compare.pin(Path(result['streams'][channel]['path'])) for channel in ('stdout', 'stderr')}

    def register(path: Path):
        if path.is_file():
            protected[str(path)] = compare.pin(path)

    def run_driver(actual: Path, expected: Path, label: str, leg='javac23'):
        return command([sys.executable, '-B', runtime_copy, '30', jdks[leg]['tools']['java'],
                        '-Xverify:all', '-cp', driver_classes, DRIVER_NAME, actual.resolve(), expected.resolve()], label, leg)

    driver_classes = out / 'driver-classes'
    driver_classes.mkdir()
    try:
        compile_driver = command([jdks['javac8']['tools']['javac'], '-source', '8', '-target', '8', '-g',
                                 '-encoding', 'UTF-8', '-proc:none', '-classpath', empty, '-sourcepath', empty,
                                 '-d', driver_classes, copied_driver], 'compile-driver', 'javac8')
        driver_facts = classfacts(compare, physical, driver_classes) if compile_driver['exit_code'] == 0 else None
        report['driver_compile'] = {'command': compile_driver['index'], 'exit_code': compile_driver['exit_code'],
                                    'streams': stream_pins(compile_driver), 'class_tree': {p.relative_to(driver_classes).as_posix(): compare.pin(p) for p in sorted(driver_classes.rglob('*.class'))},
                                    'class_facts': driver_facts}
        for path in driver_classes.rglob('*.class'):
            register(path)
        compare.write_json(out / 'execution.json', report)
        if compile_driver['exit_code'] != 0:
            raise RuntimeError('reflection driver compilation failed; raw command remains recorded')

        original_oracles = {}
        profile_by_name = {}
        for profile in PROFILES:
            leg = 'javac8' if profile.startswith('javac8') else 'javac23'
            debug = '-g:none' if profile.endswith('no-debug') else '-g'
            target_root = out / 'original' / profile / 'classes'
            target_root.mkdir(parents=True)
            flags = ['-source', '8', '-target', '8'] if leg == 'javac8' else ['--release', '8']
            compiled = command([jdks[leg]['tools']['javac'], *flags, debug, '-encoding', 'UTF-8', '-proc:none',
                               '-classpath', empty, '-sourcepath', empty, '-d', target_root, copied_source],
                              'compile-original-' + profile, leg)
            rec = {'profile': profile, 'command': compiled['index'], 'exit_code': compiled['exit_code'],
                   'streams': stream_pins(compiled), 'class_root': str(target_root),
                   'class_tree': {p.relative_to(target_root).as_posix(): compare.pin(p) for p in sorted(target_root.rglob('*.class'))},
                   'class_facts': None, 'class_inventory': None}
            if compiled['exit_code'] == 0:
                try:
                    rec['class_facts'] = target_facts(compare, physical, target_root)
                    rec['class_inventory'] = inventory(rec['class_facts'])
                except Exception as error:
                    rec['class_facts_error'] = repr(error)
            for path in target_root.rglob('*'):
                register(path)
            report['source_profiles'].append(rec)
            compare.write_json(out / 'execution.json', report)
            if compiled['exit_code'] != 0 or rec['class_facts'] is None:
                raise RuntimeError(f'original Java source failed compilation or physical class validation: {profile}')
            profile_by_name[profile] = rec

            for vm in VMS:
                runtime = run_driver(target_root, target_root, 'original-' + profile + '-' + vm, vm)
                rows = []
                parse_error = None
                if runtime['exit_code'] == 0:
                    try:
                        rows = parse_cases(artifact(runtime, 'stdout'))
                    except Exception as error:
                        parse_error = repr(error)
                run_rec = {'profile': profile, 'vm': vm, 'command': runtime['index'],
                           'exit_code': runtime['exit_code'], 'streams': stream_pins(runtime),
                           'rows': rows, 'parse_error': parse_error, 'actual_root': str(target_root.resolve()),
                           'expected_root': str(target_root.resolve()), 'application_classpath': [str(driver_classes.resolve())]}
                report['original_runs'].append(run_rec)
                if runtime['exit_code'] == 0 and parse_error is None:
                    original_oracles[(profile, vm)] = [row['raw'] for row in rows]
                compare.write_json(out / 'execution.json', report)

            wrong = run_driver(target_root, empty, 'original-wrong-root-' + profile, 'javac23')
            rejected = wrong['exit_code'] == 1 and b'wrong CodeSource:' in artifact(wrong, 'stderr')
            report['original_wrong_root'].append({'profile': profile, 'command': wrong['index'],
                'exit_code': wrong['exit_code'], 'rejected': rejected, 'streams': stream_pins(wrong),
                'actual_root': str(target_root.resolve()), 'expected_root': str(empty.resolve()),
                'application_classpath': [str(driver_classes.resolve())]})
            compare.write_json(out / 'execution.json', report)

        report['original_oracles'] = {f'{profile}/{vm}': rows for (profile, vm), rows in original_oracles.items()}
        for profile in PROFILES:
            for evidence in EVIDENCE:
                target_root = Path(profile_by_name[profile]['class_root'])
                target_class = target_root / (INTERNAL + '.class')
                dest = out / 'jarde' / profile / evidence
                dest.mkdir(parents=True)
                argv = [cli, 'class-source', '--input', target_class, '--class', INTERNAL,
                        '--policy', 'single-class', '--release', '8', '--format', 'json']
                if evidence != 'default':
                    argv.extend(['--evidence', evidence])
                api = command(argv, f'jarde-{profile}-{evidence}', 'javac8' if profile.startswith('javac8') else 'javac23')
                raw = artifact(api, 'stdout')
                report_path = dest / 'report.json'
                report_path.write_bytes(raw)
                cell = {'profile': profile, 'evidence': evidence, 'command': api['index'],
                        'exit_code': api['exit_code'], 'streams': stream_pins(api), 'report': compare.pin(report_path),
                        'source_ready': False}
                try:
                    doc = json.loads(raw.decode('utf-8', 'strict'))
                    cell['api_status'] = doc.get('execution', {}).get('status')
                    cell['outcome'] = doc.get('outcome')
                    cell['method_identities'] = [
                        [bytes(m['item']['identity']['name']).decode('utf-8'),
                         bytes(m['item']['identity']['descriptor']).decode('utf-8')]
                        for m in doc.get('methods', [])]
                    cell['method_texts'] = [m.get('outcome', {}).get('report', {}).get('text') for m in doc.get('methods', [])]
                    cell['method_qualities'] = [m.get('outcome', {}).get('report', {}).get('quality') for m in doc.get('methods', [])]
                    cell['method_source_maps'] = [m.get('outcome', {}).get('report', {}).get('source_map') for m in doc.get('methods', [])]
                    if set(map(tuple, cell['method_identities'])) != EXPECTED_METHODS or len(cell['method_identities']) != len(EXPECTED_METHODS):
                        cell['method_inventory_matches_source'] = False
                    else:
                        cell['method_inventory_matches_source'] = True
                    text = doc.get('text')
                    if isinstance(text, str) and text.strip():
                        whole = dest / 'whole-source.java'
                        whole.write_bytes(text.encode('utf-8'))
                        cell['whole_source'] = compare.pin(whole)
                        cell['source_ready'] = True
                    else:
                        cell['source_error'] = 'API whole-source text missing or empty'
                except Exception as error:
                    cell['parse_error'] = repr(error)
                register(report_path)
                register(dest / 'whole-source.java')
                report['jarde_cells'].append(cell)
                compare.write_json(out / 'execution.json', report)

            bundle = out / 'bundles' / profile / 'classes.jar'
            bundle.parent.mkdir(parents=True)
            source_root = Path(profile_by_name[profile]['class_root'])
            with zipfile.ZipFile(bundle, 'w', zipfile.ZIP_DEFLATED) as archive:
                for class_file in sorted(source_root.rglob('*.class')):
                    archive.write(class_file, class_file.relative_to(source_root).as_posix())
            with zipfile.ZipFile(bundle) as archive:
                members = sorted(name for name in archive.namelist() if name.endswith('.class'))
                if members != sorted(profile_by_name[profile]['class_tree']):
                    raise RuntimeError('JADX archive member closure differs from complete original class tree')
                for member in members:
                    if archive.read(member) != (source_root / member).read_bytes():
                        raise RuntimeError('JADX archive class bytes differ: ' + member)
            register(bundle)
            jadx_dest = out / 'jadx' / profile
            decompile = command([jadx, '--threads-count', '1', '--no-res', '--config', 'none', '-d', jadx_dest, bundle],
                                'jadx-' + profile, 'javac23')
            java_sources = sorted(jadx_dest.rglob('*.java'))
            for path in java_sources:
                register(path)
            report['jadx_cells'].append({'profile': profile, 'command': decompile['index'],
                'exit_code': decompile['exit_code'], 'input_bundle': compare.pin(bundle),
                'streams': stream_pins(decompile), 'source_count': len(java_sources),
                'sources': [compare.pin(path) for path in java_sources],
                'complete_source_closure': bool(java_sources)})
            compare.write_json(out / 'execution.json', report)

        generated_sources = []
        for cell in report['jarde_cells']:
            if cell.get('source_ready'):
                generated_sources.append(('jarde', cell['profile'], cell['evidence'],
                                          [Path(cell['whole_source']['path'])], cell))
        for cell in report['jadx_cells']:
            paths = [Path(pin['path']) for pin in cell['sources']]
            if paths:
                generated_sources.append(('jadx', cell['profile'], 'source', paths, cell))

        for kind, profile, variant, sources, cell in generated_sources:
            leg_for_profile = 'javac8' if profile.startswith('javac8') else 'javac23'
            debug = '-g:none' if profile.endswith('no-debug') else '-g'
            if len({path.name for path in sources}) != len(sources):
                raise RuntimeError(f'duplicate Java source basename in complete closure: {kind}/{profile}/{variant}')
            for leg in LEGS:
                key = f'{kind}-{profile}-{variant}-{leg}-{debug[1:]}'
                source_root = out / 'generated-sources' / key
                source_root.mkdir(parents=True)
                source_copies = []
                for source_path in sources:
                    data = source_path.read_bytes()
                    package_match = re.search(rb'^\s*package\s+([A-Za-z_$][A-Za-z0-9_$.]*)\s*;', data, re.M)
                    package_path = package_match.group(1).decode('ascii').replace('.', '/') if package_match else ''
                    filename = 'IteratorAncestorCases.java' if kind == 'jarde' else source_path.name
                    if re.fullmatch(r'[A-Za-z_$][A-Za-z0-9_$]*\.java', filename) is None:
                        raise RuntimeError(f'illegal Java source basename: {filename}')
                    if kind == 'jarde' and (package_path != 'cf11' or not re.search(rb'public\s+final\s+class\s+IteratorAncestorCases\b', data)):
                        raise RuntimeError('Jarde whole source is not the exact complete public class source')
                    destination = source_root / package_path / filename if package_path else source_root / filename
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    if destination.exists():
                        raise RuntimeError(f'duplicate generated source destination: {destination}')
                    destination.write_bytes(data)
                    if destination.read_bytes() != data:
                        raise RuntimeError('generated source bytes changed during exact copy')
                    register(destination)
                    source_copies.append({'source': compare.pin(source_path), 'copy': compare.pin(destination)})
                output_root = out / 'generated-classes' / key
                output_root.mkdir(parents=True)
                flags = ['-source', '8', '-target', '8'] if leg == 'javac8' else ['--release', '8']
                javac = command([jdks[leg]['tools']['javac'], *flags, debug, '-encoding', 'UTF-8', '-proc:none',
                                 '-classpath', empty, '-sourcepath', empty, '-d', output_root,
                                 *sorted(source_root.rglob('*.java'))], 'compile-' + key, leg)
                class_tree = {path.relative_to(output_root).as_posix(): compare.pin(path)
                              for path in sorted(output_root.rglob('*.class'))}
                classfacts_result = None
                inventory_match = None
                facts_error = None
                if javac['exit_code'] == 0:
                    try:
                        classfacts_result = target_facts(compare, physical, output_root)
                        inventory_match = inventory(classfacts_result) == profile_by_name[profile]['class_inventory']
                    except Exception as error:
                        facts_error = repr(error)
                        inventory_match = False
                for path in output_root.rglob('*'):
                    register(path)
                compile_row = {'kind': kind, 'profile': profile, 'variant': variant, 'compiler': leg,
                               'debug': debug, 'source_copies': source_copies, 'command': javac['index'],
                               'exit_code': javac['exit_code'], 'streams': stream_pins(javac),
                               'class_root': str(output_root), 'class_tree': class_tree,
                               'class_facts': classfacts_result, 'class_facts_error': facts_error,
                               'class_inventory_matches_original': inventory_match}
                report['generated_compiles'].append(compile_row)
                compare.write_json(out / 'execution.json', report)
                if javac['exit_code'] != 0:
                    continue
                for vm in VMS:
                    run = run_driver(output_root, output_root, f'generated-{key}-{vm}', vm)
                    rows = []
                    parse_error = None
                    if run['exit_code'] == 0:
                        try:
                            rows = parse_cases(artifact(run, 'stdout'))
                        except Exception as error:
                            parse_error = repr(error)
                    expected = original_oracles.get((profile, vm))
                    matches = run['exit_code'] == 0 and parse_error is None and expected is not None and [r['raw'] for r in rows] == expected
                    report['generated_runs'].append({'kind': kind, 'profile': profile, 'variant': variant,
                        'compiler': leg, 'debug': debug, 'vm': vm, 'command': run['index'],
                        'exit_code': run['exit_code'], 'streams': stream_pins(run), 'rows': rows,
                        'parse_error': parse_error, 'matches_original': matches,
                        'actual_root': str(output_root.resolve()), 'expected_root': str(output_root.resolve()),
                        'application_classpath': [str(driver_classes.resolve())]})
                    compare.write_json(out / 'execution.json', report)
                wrong = run_driver(output_root, empty, f'generated-wrong-root-{key}', 'javac23')
                rejected = wrong['exit_code'] == 1 and b'wrong CodeSource:' in artifact(wrong, 'stderr')
                report['generated_wrong_root'].append({'kind': kind, 'profile': profile, 'variant': variant,
                    'compiler': leg, 'debug': debug, 'command': wrong['index'], 'exit_code': wrong['exit_code'],
                    'rejected': rejected, 'streams': stream_pins(wrong),
                    'actual_root': str(output_root.resolve()), 'expected_root': str(empty.resolve()),
                    'application_classpath': [str(driver_classes.resolve())]})
                compare.write_json(out / 'execution.json', report)

        report['generated_outputs_pins_before_final'] = {key: pin for key, pin in protected.items()}
        report['generated_outputs_pins_after_final'] = {key: compare.pin(Path(key)) for key in protected}
        report['generated_outputs_unchanged'] = report['generated_outputs_pins_before_final'] == report['generated_outputs_pins_after_final']
        report['source_pins_after'] = compare.source_closure(root)
        report['external_pins_after'] = [compare.pin(path) for path in external]
        report['local_copies_after'] = {str(path): compare.pin(path) for path in (copied_source, copied_driver, runtime_copy)}
        report['source_unchanged'] = report['source_pins_before'] == report['source_pins_after']
        report['external_inputs_unchanged'] = report['external_pins_before'] == report['external_pins_after']
        report['local_copies_unchanged'] = report['local_copies_before'] == report['local_copies_after']
        report['target_absent'] = not (root / 'target').exists() and not (root / 'target').is_symlink()
        report['target_absent_after_clean'] = report['target_absent']
        report['failed_cells'] = (
            [{'kind': 'api', 'profile': c.get('profile'), 'evidence': c.get('evidence'), 'exit_code': c.get('exit_code')}
             for c in report['jarde_cells'] if c.get('exit_code') != 0 or not c.get('source_ready')]
            + [{'kind': 'jadx', 'profile': c.get('profile'), 'exit_code': c.get('exit_code')}
               for c in report['jadx_cells'] if c.get('exit_code') != 0 or not c.get('complete_source_closure')]
            + [{'kind': 'compile', 'selector': [c['kind'], c['profile'], c['variant'], c['compiler'], c['debug']], 'exit_code': c['exit_code']}
               for c in report['generated_compiles'] if c['exit_code'] != 0 or c.get('class_inventory_matches_original') is not True]
            + [{'kind': 'runtime', 'selector': [r['kind'], r['profile'], r['variant'], r['compiler'], r['vm']], 'exit_code': r['exit_code'], 'matches_original': r.get('matches_original')}
               for r in report['generated_runs'] if r['exit_code'] != 0 or r.get('matches_original') is not True]
            + [{'kind': 'wrong-root', 'selector': [r.get('kind'), r.get('profile'), r.get('variant'), r.get('compiler')], 'exit_code': r['exit_code']}
               for r in [*report['original_wrong_root'], *report['generated_wrong_root']] if r.get('rejected') is not True]
            + [{'kind': 'original-runtime', 'profile': r['profile'], 'vm': r['vm'], 'exit_code': r['exit_code'], 'parse_error': r.get('parse_error')}
               for r in report['original_runs'] if r['exit_code'] != 0 or r.get('parse_error')]
        )
        if not all((report['generated_outputs_unchanged'], report['source_unchanged'], report['external_inputs_unchanged'],
                    report['local_copies_unchanged'], report['target_absent'])):
            raise RuntimeError('source/artifact/target closure changed')
        report['status'] = 'captured-pending-review'
    except BaseException as error:
        report['status'] = 'failed'
        report['error'] = repr(error)
        raise
    finally:
        try:
            report['generated_outputs_pins_after_finally'] = {key: compare.pin(Path(key)) for key in protected}
            report['generated_outputs_unchanged_finally'] = report.get('generated_outputs_pins_before_final', protected) == report['generated_outputs_pins_after_finally']
            report['source_pins_after_finally'] = compare.source_closure(root)
            report['external_pins_after_finally'] = [compare.pin(path) for path in external]
            report['local_copies_after_finally'] = {str(path): compare.pin(path) for path in (copied_source, copied_driver, runtime_copy)}
            report['source_unchanged_finally'] = report['source_pins_after_finally'] == source_before
            report['external_inputs_unchanged_finally'] = report['external_pins_after_finally'] == report.get('external_pins_before')
            report['local_copies_unchanged_finally'] = report['local_copies_after_finally'] == local_before
            report['target_absent_finally'] = not (root / 'target').exists() and not (root / 'target').is_symlink()
            if not all((report['generated_outputs_unchanged_finally'], report['source_unchanged_finally'],
                        report['external_inputs_unchanged_finally'], report['local_copies_unchanged_finally'],
                        report['target_absent_finally'])):
                report['status'] = 'failed'
                report['final_guard_error'] = 'final closure guard changed'
        except BaseException as error:
            report['status'] = 'failed'
            report['final_guard_error'] = repr(error)
        report['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        compare.write_json(out / 'execution.json', report)
        shutil.copy2(__file__, out / 'collector.py')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
