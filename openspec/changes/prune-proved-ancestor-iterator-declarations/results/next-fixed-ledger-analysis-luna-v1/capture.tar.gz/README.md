# CF-11 固定黄金之后的候选差距（只读）

状态：静态交接备忘；没有重跑 CLI/JDK/Cargo/JADX/Git/network，也没有修改共享文件。当前用户上下文说明祖先 Iterator 空声明 cleanup 的 v8 仍在运行中，故下面的“下一点”是基于最近已接受完整输出的候选，必须由该 leaf 最终当前 CLI/API 源码复核后再实施。

## 结论

在排除已经交付的 Seq1/Seq2、NL3/NL5、typed foreach、原名 binding fold 后，CF-11 没有理由再做同一个循环形态或新玩具循环。固定 `TestNestedLoops.java` 的五个文本断言中，最新已接受 fold 输出已具备两个 typed 原名 foreach 头和 `l2.add(s1)`；祖先 cleanup 当前 leaf 处理剩余 `Iterator local5;` 空声明。原始 golden 中另两条仍未追平的表达式是：

- `if (s1.equals(s2)) {`
- `l1.remove(s2);`

已接受的原名 fold 输出仍为 `if (s1.equals((java.lang.Object) s2))` 与 `l1.remove((java.lang.Object) s2)`，且仍有 `Iterator local5;`。因此，**若祖先 cleanup 当前最终 CLI 仍只删除该空声明，下一最小固定测试点应是这两处 `Object` upcast 呈现**。这是同一固定上游测试的剩余 golden，不是新探索 case，也不是重做 typed/fold。不要再改已匹配的 `add(E)`；其 cast 已在接受输出中消失。

## 精确上游断言与已有原始证据

固定 JADX source 为 `/Users/lordcasser/workspace/testzone/jadx/jadx-core/src/test/java/jadx/tests/integration/loops/TestNestedLoops.java`，SHA-256 `4897fd18a15fce6e0abb40dc8afc6c7a3fa9f16e617f3c7e5e88072f6a37309e`。其 `test()` 对方法正文要求两个 `for (String s1 : l1)` / `for (String s2 : l2)` 头、`if (s1.equals(s2))`、`l2.add(s1)` 和 `l1.remove(s2)` 各一个；没有行为型 `check()`。逐字断言在固定源约 33 行，循环正文在 14–20 行。固定 CF-11 文件状态仍是“部分已测”，不能因为这些点逐步闭合就标整 CF-11 已完成。

- typed 原始类最终收据：`openspec/changes/recover-typed-list-foreach-elements/results/original-final-root-v1`，receipt `433b6a723137adb4aed904b2c7935079821def5b1b91f1593630c224bc73f439`，20 commands/8 API/4 original JVM runs/32 cases。其 source 已提升为 String 头但保留 synthetic header 和原 body binding，不能作为原名 fold 或当前 ancestor leaf 的新结果。
- 原名 fold 最新已接受完整原始类矩阵：`openspec/changes/fold-proved-foreach-local-bindings/results/original-root-v1`；配套完整生成源码矩阵 `generated-root-v1`。在 `jarde/debug/child/default/whole-source.java`（以及对应 `report.json`）第 19–26 行，确实是空 Iterator 声明、两个原名 String foreach、两处 `Object` 包装与已无包装的 `l2.add(s1)`。该捕获与产品 c688 CLI 对应，当前头部任务之后的源码/CLI 不是此 CLI。
- 祖先声明现有静态分析：`openspec/evidence/java-syntax-2026-10-18/cf11-foreach-iterator-declaration-analysis-root-v1/README.md` 明确把 Object 包装另列，未称它们已修。原名 fold 结果 README 明确说明本片尚留冗余 iterator/Object wrappers。

## 建议的下一步边界

先由 root 在祖先 cleanup 最终候选完成后，取得实际当前 CLI 对固定 child/bundle-child、default/all 与适用 debug profiles 的新 API/source 输出，复核两个 Object cast 是否仍在，以及 ancestor cleanup 仅改变预期 declaration/map 坐标。旧 c688 与更早 d130 receipts只能定位历史差距，不能证明当前输出。若两个包装仍在，再考虑一个以现成固定 `TestNestedLoops` golden 为中心的小范围证明/测试：

- 只准移除这两个实际 `Object` 目标参数的语法 upcast；以 same-run String 元素 binding 与每个调用的确切 invocation owner/name/descriptor 绑定。`String.equals(Object)` 和 `List.remove(Object)` 的实际目标不同，不能把“看上去是 Object cast”当可删判据。
- 对 `remove` 额外证明最终仍绑定 `remove(Object)`，且 String 参数不会因打印省略 cast 改成别的 overload；对 `equals` 保持 String receiver 和现有调用身份。
- 不做全局 Object-cast erasure，不改 `add(E)`，不触碰物理 CheckCast/任意泛型 fallback；未知/Raw/控制形态继续保留 casts 或拒绝。输出验证需分别检查 raw method text/map 与 projected whole source；不要用投影文本坐标验证 raw map。
- 使用现有完整类、raw/refusal controls 和已接受矩阵做来源/行为闭环；若新源码真发生变化，根按其验收流程重新跑当前生成源码矩阵并绑定当前 CLI。旧 matrix/runtime 只能做历史参考。

这只是候选优先级，不是已证明的产品缺陷或新架构设计；`TestNestedLoops` 固定文本断言本身也不是运行 oracle。若祖先 cleanup 新 CLI 已自然满足这两条 golden，则此候选关闭，不要重复实现。

## 不选其它旧队列

CF-11 inventory 仍是 71/612 中的部分完成单元，七个已登记 nested/sequential 固定输入已有各自窄片；其笼统“其它出口/irreducible”残项没有新的固定原始测试和可接受 receipt，不应自行造样本。旧 `handoff.md` 的历次“下一项”段落已被后续产品记录覆盖；按本轮排除列表与当前真实 receipts 去重。已归档的 Test17 Java 8 双 catch 只剩 DX/D8 profile 未回放，属于 profile 扩验、不是 CF-11 的下一 syntax MVP，不优先于当前仍未匹配的精确 CF-11 golden。

## 禁止混淆

不更新 71/612/CF-11 完成数；不把 old c688 output 当当前 ancestor cleanup 产品结果；不把 JUnit 文本匹配单独当语义正确；不把局部 source cleanup 描述成 CF-11 全单元追平。
