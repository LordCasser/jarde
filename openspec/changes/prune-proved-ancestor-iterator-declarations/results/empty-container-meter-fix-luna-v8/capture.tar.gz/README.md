# Empty-container walk accounting fix (v8)

Private patch based on the pinned current `crates/jarde-java/src/build.rs`. No shared files were edited and no toolchain or Git command was run.

Base SHA-256: `1f8c39ada4667294a069785fdc3a64316dc812b04c63130bc8df83e9819a9a74`.
Changed private file SHA-256: `0279d82b4d813c3bac859cbfce836e8f5794acac6c1165d738d0de4cfb26c8f3`.
Patch SHA-256: `72fbf326ca4fd63da64f0bb025ecde50a8d92444ad6141ac81de2dca6cc5f8ec`.

The cleanup’s inspection and removal walks now poll and charge one `AnalysisSteps` unit before traversing each switch-arm and catch-clause container, including empty ones. The existing ancestor cleanup unit compares a no-empty baseline against ASTs with an added empty switch arm and empty catch, cuts the budget at the baseline work total, and asserts the cleanup returns `AnalysisSteps` Stop with the original tree and statement count intact. These are internal AST metamorphisms, not JVM fixtures. No tests were run.
