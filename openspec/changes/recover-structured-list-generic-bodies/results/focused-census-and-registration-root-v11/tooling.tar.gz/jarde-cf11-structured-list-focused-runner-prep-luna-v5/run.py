#!/usr/bin/env python3
"""执行 CF11 structured-list 首轮受 guard 约束的产品编译验证。"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tomllib

sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde').resolve()
GUARD_PATH = ROOT / 'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
SCANNER_PATH = ROOT / 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
CLOSURE_PATH = Path('/private/tmp/jarde-iterator-assignment-full-validation-prep-luna-v2/workspace_runner.py')
REFERENCE_WRAPPER_PATH = Path('/private/tmp/jarde-local-reference-write-focused-runner-root-v3.py')
PIN_PATH = Path(__file__).resolve().with_name('pins.json')
GUARD_SHA256 = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER_SHA256 = 'd954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
CLOSURE_SHA256 = '63e52b55fe5d20d5f2ece98ac80676ccdb2de8dfd33d7199b688e075fb1e9673'
REFERENCE_WRAPPER_SHA256 = '41d52db53da0462f3e2dc65c410f62ed20ed0aa57c28e1fe4b9b9da498adb327'
CLI_PATH = Path('/private/tmp/jarde-cf11-structured-list-candidate-cli-root-v3')
FREE_LIMIT = 5 * 1024**3
TARGET_LIMIT = 1024**3
EXPECTED_HEAD = None
OUT = None
CLOSURE_MODULE = None
CLOSURE_IMPORT_SNAPSHOTS = None
EXPECTED_NAMED_OUTCOMES = {
    'nearby_list_controls_refuse_only_unproved_generic_projections': 'ok',
    'inner_list_option_actual_uses_the_receiver_element_type': 'ok',
    'fixed_nested_string_body_projects_source_and_preserves_physical_origins': 'ok',
    'differently_named_string_and_integer_classes_follow_their_list_element_type': 'ok',
    'exact_list_null_add_removes_only_the_synthetic_object_wrapper': 'ok',
    'pre_cancel_does_not_install_a_partial_generic_declaration_or_method_projection': 'ok',
    'budget_stop_during_list_proof_keeps_raw_body_and_installs_no_projection': 'ok',
    'diagnose_late_analysis_stop_phase_without_assuming_raw_map_is_empty': 'ignored',
}
EXPECTED_CENSUS_TESTS = {
    'complete_fixed_void_census_keeps_phi_and_every_formal_read',
    'fixed_census_refuses_physical_inventory_and_operation_disagreements',
    'fixed_read_is_not_unread_when_the_invoke_target_is_unknown',
    'real_parameter_reassignment_and_handler_facts_refuse_the_list_census',
}
ENV_VALUES = {
    'CARGO_BUILD_JOBS': '1',
    'CARGO_INCREMENTAL': '0',
    'CARGO_PROFILE_DEV_DEBUG': '0',
    'CARGO_PROFILE_TEST_DEBUG': '0',
    'RUST_TEST_THREADS': '1',
    'CARGO_TERM_COLOR': 'always',
}
STRIPPED_ENV_KEYS = ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'CLASSPATH', 'RUST_MIN_STACK')
SUMMARY_RE = re.compile(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;')
ANSI_RE = re.compile(r'\x1b\[[0-9;]*m')
NAMED_TEST_RE = re.compile(r'^test (.+) \.\.\. (ok|ignored|FAILED)(?:, .*)?$', re.MULTILINE)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def file_pin(path: Path) -> dict:
    info = path.stat()
    return {'path': str(path.resolve()), 'bytes': info.st_size, 'sha256': sha256_file(path)}


def load_pinned_module(name: str, path: Path, expected_sha: str):
    if not path.is_file():
        raise FileNotFoundError(f'pinned dependency is missing: {path}')
    actual_sha = sha256_file(path)
    if actual_sha != expected_sha:
        raise RuntimeError(f'pinned dependency SHA-256 mismatch: {path}: {actual_sha}')
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load pinned dependency: {path}')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module, file_pin(path)


def source_manifest() -> list[dict]:
    """Pin every actual file in src/crates/tests/examples, Cargo manifests and .cargo config."""
    required = [ROOT / 'Cargo.toml', ROOT / 'Cargo.lock']
    for path in required:
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(f'required workspace source input is absent or linked: {path}')
    workspace = tomllib.loads((ROOT / 'Cargo.toml').read_text(encoding='utf-8'))
    members = workspace.get('workspace', {}).get('members', [])
    if not members:
        raise RuntimeError('workspace Cargo.toml has no explicit members')
    paths = set(required)
    for member in members:
        manifest = ROOT / member / 'Cargo.toml' if member != '.' else ROOT / 'Cargo.toml'
        if not manifest.is_file() or manifest.is_symlink():
            raise FileNotFoundError(f'workspace member manifest missing or linked: {manifest}')
        if not manifest.resolve().is_relative_to(ROOT):
            raise RuntimeError(f'workspace member manifest escapes source root: {manifest}')
        paths.add(manifest)

    def collect_tree(base: Path) -> set[Path]:
        found = set()
        def raise_walk_error(error: OSError) -> None:
            raise error
        for directory, dirnames, filenames in os.walk(base, topdown=True, followlinks=False,
                                                      onerror=raise_walk_error):
            parent = Path(directory)
            for name in list(dirnames):
                child = parent / name
                if child.is_symlink():
                    raise RuntimeError(f'source closure contains a linked directory: {child}')
            for name in filenames:
                child = parent / name
                if child.is_symlink() or not child.is_file():
                    raise RuntimeError(f'source closure contains a linked or non-file path: {child}')
                found.add(child)
        return found

    for name in ('src', 'crates', 'tests', 'examples'):
        base = ROOT / name
        if not base.is_dir() or base.is_symlink():
            if name == 'examples' and not base.exists():
                continue
            raise FileNotFoundError(f'required source directory is absent or linked: {base}')
        paths.update(collect_tree(base))
    if CLOSURE_MODULE is None:
        raise RuntimeError('pinned workspace source-closure module was not loaded')
    closure_paths = CLOSURE_MODULE.source_paths()
    if not closure_paths:
        raise RuntimeError('pinned workspace source-closure returned no paths')
    paths.update(closure_paths)
    cargo_config = ROOT / '.cargo'
    if cargo_config.exists():
        if cargo_config.is_symlink() or not cargo_config.is_dir():
            raise RuntimeError(f'.cargo must be a real directory: {cargo_config}')
        paths.update(collect_tree(cargo_config))
    for path in paths:
        if path.is_symlink() or not path.is_file():
            raise RuntimeError(f'source closure contains a linked or non-file path: {path}')
        if not path.resolve().is_relative_to(ROOT):
            raise RuntimeError(f'source closure escapes workspace: {path}')
    return [
        {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size,
         'sha256': sha256_file(path)}
        for path in sorted(paths, key=lambda item: item.relative_to(ROOT).as_posix())
    ]


def verify_project_target_config() -> list[dict]:
    checked = []
    for path in (ROOT / '.cargo/config', ROOT / '.cargo/config.toml'):
        if not path.exists():
            continue
        if not path.is_file() or path.is_symlink():
            raise RuntimeError(f'project Cargo config is not a regular file: {path}')
        config = tomllib.loads(path.read_text(encoding='utf-8'))
        target_dir = config.get('build', {}).get('target-dir')
        if target_dir is not None:
            resolved = Path(target_dir)
            if not resolved.is_absolute():
                resolved = path.parent / resolved
            if resolved.resolve() != (ROOT / 'target').resolve():
                raise RuntimeError(f'project Cargo config redirects target output outside guarded ROOT/target: {path}')
        checked.append({'path': str(path.resolve()), 'sha256': sha256_file(path),
                        'target_dir': target_dir})
    return checked


def verify_preparation_pins(expected_head: str, dependency_pins: dict) -> dict:
    if not PIN_PATH.is_file():
        raise FileNotFoundError(f'preparation pins are missing: {PIN_PATH}')
    pins = json.loads(PIN_PATH.read_text(encoding='utf-8'))
    if pins.get('schema') != 'cf11-structured-list-focused-runner-preparation-pins-v3' or \
            pins.get('status') != 'prepared_not_executed':
        raise RuntimeError('preparation pins schema/status differs')
    artifacts = pins.get('artifacts', {})
    if artifacts.get('run.py') != file_pin(Path(__file__).resolve()) or \
            artifacts.get('README.md') != file_pin(PIN_PATH.with_name('README.md')):
        raise RuntimeError('runner or README differs from preparation pins')
    if pins.get('expected_head') != expected_head or \
            pins.get('frozen_cli_destination') != str(CLI_PATH):
        raise RuntimeError('expected HEAD or CLI destination differs from preparation pins')
    if pins.get('pinned_inputs', {}).get('guard') != dependency_pins.get('guard') or \
            pins.get('pinned_inputs', {}).get('target_scanner') != dependency_pins.get('target_scanner') or \
            pins.get('pinned_inputs', {}).get('workspace_source_closure') != dependency_pins.get('workspace_source_closure') or \
            pins.get('pinned_inputs', {}).get('reference_focused_wrapper') != dependency_pins.get('reference_focused_wrapper'):
        raise RuntimeError('guard, scanner, or focused wrapper differs from preparation pins')
    expected_closure_snapshots = {**CLOSURE_IMPORT_SNAPSHOTS, 'after_run': file_pin(CLOSURE_PATH)}
    if pins.get('workspace_source_closure_snapshots') != expected_closure_snapshots:
        raise RuntimeError('workspace source-closure before/import-after/after-run pins differ')
    source_pins = pins.get('pinned_inputs', {}).get('focused_sources', {})
    expected_sources = {
        'focused_test_source': ROOT / 'tests/structured_list_generic_bodies.rs',
        'jarde_java_report_source': ROOT / 'crates/jarde-java/src/report.rs',
        'jarde_reader_classfile_source': ROOT / 'crates/jarde-reader/src/classfile.rs',
        'p5_fingerprint_source': ROOT / 'tests/p5_corpus_fingerprint.rs',
        'p5_fingerprint_manifest': ROOT / 'tests/fixtures/corpus-fingerprint.json',
    }
    actual_sources = {}
    for name, path in expected_sources.items():
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(f'pinned test source is missing or linked: {path}')
        actual_sources[name] = file_pin(path)
    if source_pins != actual_sources:
        raise RuntimeError('focused, census, or P5 fingerprint source differs from its preparation pins')
    return {'path': str(PIN_PATH.resolve()), 'bytes': PIN_PATH.stat().st_size,
            'sha256': sha256_file(PIN_PATH)}


def load_runtime_modules():
    global CLOSURE_MODULE, CLOSURE_IMPORT_SNAPSHOTS
    guard, guard_pin = load_pinned_module('cf11_focused_guard_v9', GUARD_PATH, GUARD_SHA256)
    scanner, scanner_pin = load_pinned_module('cf11_focused_target_scanner_v1', SCANNER_PATH, SCANNER_SHA256)
    closure_before_import = file_pin(CLOSURE_PATH)
    CLOSURE_MODULE, closure_pin = load_pinned_module(
        'cf11_focused_workspace_source_closure', CLOSURE_PATH, CLOSURE_SHA256)
    CLOSURE_MODULE.ROOT = ROOT
    closure_after_import = file_pin(CLOSURE_PATH)
    if closure_before_import != closure_after_import:
        raise RuntimeError('pinned workspace source-closure module changed during import')
    CLOSURE_IMPORT_SNAPSHOTS = {'before_import': closure_before_import,
                                'after_import': closure_after_import}
    if sha256_file(REFERENCE_WRAPPER_PATH) != REFERENCE_WRAPPER_SHA256:
        raise RuntimeError(f'latest focused wrapper SHA-256 mismatch: {REFERENCE_WRAPPER_PATH}')
    wrapper_pin = file_pin(REFERENCE_WRAPPER_PATH)
    guard.ROOT = ROOT
    guard.target_bytes = lambda: scanner.target_bytes(ROOT)
    guard.expected_test_summaries = lambda _index, _stdout: None
    guard.command_stream = lambda path: {
        'path': str(Path(path).resolve()), 'bytes': Path(path).stat().st_size,
        'sha256': sha256_file(Path(path)),
    }
    return guard, scanner, {
        'guard': guard_pin, 'target_scanner': scanner_pin,
        'workspace_source_closure': closure_pin,
        'reference_focused_wrapper': wrapper_pin,
    }


def test_summaries(stdout: bytes) -> tuple[list[dict], list[dict]]:
    text = ANSI_RE.sub('', stdout.decode('utf-8', errors='replace'))
    summaries = [
        {'status': status, 'passed': int(passed), 'failed': int(failed), 'ignored': int(ignored)}
        for status, passed, failed, ignored in SUMMARY_RE.findall(text)
    ]
    names = [{'name': name, 'status': status} for name, status in NAMED_TEST_RE.findall(text)]
    return summaries, names


def validate_test_result(label: str, row: dict, stdout_path: Path) -> dict:
    stdout = stdout_path.read_bytes()
    summaries, names = test_summaries(stdout)
    if row['exit_code'] != 0 or row['guard_stop'] is not None:
        raise RuntimeError(f'{label} failed or was stopped by resource guard')
    if not summaries:
        raise RuntimeError(f'{label} did not emit a Cargo test summary')
    if label == 'structured_list_generic_bodies':
        if summaries != [{'status': 'ok', 'passed': 7, 'failed': 0, 'ignored': 1}]:
            raise RuntimeError(f'{label} expected exactly 7 passed and 1 ignored, got {summaries}')
        counts = {name: sum(item['name'] == name for item in names) for name in EXPECTED_NAMED_OUTCOMES}
        actual_outcomes = {item['name']: item['status'] for item in names}
        if len(names) != 8 or any(count != 1 for count in counts.values()) or \
                actual_outcomes != EXPECTED_NAMED_OUTCOMES:
            raise RuntimeError(f'{label} named outcomes differ from the exact seven pass/one ignored set: {names}')
    elif label == 'jarde_java_lib':
        if summaries != [{'status': 'ok', 'passed': 375, 'failed': 0, 'ignored': 0}] or len(names) != 375:
            raise RuntimeError(f'{label} expected exactly 375 passed tests, got {summaries} and {len(names)} names')
        tails = [item['name'].rsplit('::', 1)[-1] for item in names]
        outcomes = {name: [item['status'] for item in names if item['name'].rsplit('::', 1)[-1] == name]
                    for name in EXPECTED_CENSUS_TESTS}
        if any(value != ['ok'] for value in outcomes.values()):
            raise RuntimeError(f'{label} exact census test set did not each pass once: {outcomes}')
    elif label == 'jarde_reader_census':
        if summaries != [{'status': 'ok', 'passed': 1, 'failed': 0, 'ignored': 0}] or len(names) != 1 or \
                names[0]['name'].rsplit('::', 1)[-1] != 'repository_class_fixtures_validate_without_false_target_rejections' or \
                names[0]['status'] != 'ok':
            raise RuntimeError(f'{label} reader fixture census gate differs: {summaries}, {names}')
    elif label == 'p5_corpus_fingerprint':
        if summaries != [{'status': 'ok', 'passed': 5, 'failed': 0, 'ignored': 1}] or len(names) != 6:
            raise RuntimeError(f'{label} expected exactly 5 passed and 1 ignored, got {summaries} and {len(names)} names')
        expected_p5 = {
            'corpus_files_match_the_recorded_fingerprint',
            'the_manifest_matches_its_rendered_classification',
            'every_dimension_is_carried_by_existing_corpus',
            'every_acceptance_row_is_indexed_against_existing_corpus',
            'the_indexed_rows_are_the_rows_the_acceptance_table_names',
            'regenerate_corpus_fingerprint',
        }
        by_leaf = {leaf: [item['status'] for item in names
                          if item['name'].rsplit('::', 1)[-1] == leaf]
                   for leaf in expected_p5}
        if len(names) != 6 or any(len(statuses) != 1 for statuses in by_leaf.values()) or \
                any(statuses[0] != ('ignored' if leaf == 'regenerate_corpus_fingerprint' else 'ok')
                    for leaf, statuses in by_leaf.items()):
            raise RuntimeError(f'{label} named outcomes differ from the exact P5 read-only set: {by_leaf}')
    else:
        if any(item['status'] != 'ok' or item['failed'] != 0 for item in summaries):
            raise RuntimeError(f'{label} has a failed test summary: {summaries}')
        if sum(item['passed'] for item in summaries) <= 0:
            raise RuntimeError(f'{label} emitted no passing tests')
        if len(names) != sum(item['passed'] + item['ignored'] + item['failed'] for item in summaries):
            raise RuntimeError(f'{label} named outcomes do not account for summary totals')
        if any(item['status'] == 'FAILED' for item in names):
            raise RuntimeError(f'{label} includes a named failed test')
    row['test_summaries'] = summaries
    row['named_test_outcomes'] = names
    return {'summaries': summaries, 'named_test_count': len(names), 'all_tests_passed': True}


def write_json(path: Path, value: dict) -> None:
    temp = path.with_name(path.name + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temp.replace(path)


def main() -> int:
    global EXPECTED_HEAD, OUT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True, help='new external directory for raw receipts')
    parser.add_argument('--expected-head', required=True, help='exact 40-character expected workspace HEAD')
    args = parser.parse_args()
    EXPECTED_HEAD = args.expected_head.lower()
    if not re.fullmatch(r'[0-9a-f]{40}', EXPECTED_HEAD):
        raise SystemExit('--expected-head must be a 40-character commit SHA')
    OUT = args.out.resolve()
    if OUT.exists():
        raise SystemExit(f'refusing to overwrite previous output: {OUT}')
    if OUT.is_relative_to(ROOT):
        raise SystemExit('output directory must be outside the shared workspace')
    if CLI_PATH.exists() or CLI_PATH.is_symlink():
        raise SystemExit(f'refusing to overwrite frozen candidate CLI: {CLI_PATH}')

    guard, scanner, dependency_pins = load_runtime_modules()
    preparation_pins = verify_preparation_pins(EXPECTED_HEAD, dependency_pins)
    guard.OUT = OUT
    env = os.environ.copy()
    stripped = [key for key in STRIPPED_ENV_KEYS if key in env]
    for key in STRIPPED_ENV_KEYS:
        env.pop(key, None)
    inherited_target_dir = env.pop('CARGO_TARGET_DIR', None)
    env.update(guard.ENV_VALUES)
    if env.get('RUST_MIN_STACK') is not None:
        raise RuntimeError('RUST_MIN_STACK must be absent for the default test-thread stack')
    if 'CARGO_TARGET_DIR' in guard.ENV_VALUES:
        raise RuntimeError('guard environment must not override CARGO_TARGET_DIR')

    OUT.mkdir(parents=True, exist_ok=False)
    record = {
        'schema': 'cf11-structured-list-focused-run-v3', 'status': 'running',
        'expected_head': EXPECTED_HEAD, 'workspace_root': str(ROOT),
        'output_root': str(OUT), 'runner': file_pin(Path(__file__).resolve()),
        'dependencies': dependency_pins, 'preparation_pins': preparation_pins,
        'environment': {
            'guard_overrides': dict(guard.ENV_VALUES), 'stripped_keys': stripped,
            'rust_min_stack': env.get('RUST_MIN_STACK'),
            'cargo_target_dir_inherited_and_removed': inherited_target_dir,
            'cargo_target_dir_override_by_runner': None,
        },
        'workspace_source_closure_import_snapshots': CLOSURE_IMPORT_SNAPSHOTS,
        'resource_guard': {'minimum_free_bytes': FREE_LIMIT, 'maximum_target_bytes': TARGET_LIMIT,
                           'poll_seconds': 1, 'process_group_termination': True},
        'source_manifest_before': [], 'source_manifest_after': [],
        'commands': [], 'cli_freeze': None, 'cleanup': None,
        'expected_reader_fixture_census': [1140, 5018, 474, 3141, 10],
    }
    next_index = 0
    source_baseline_ready = False

    def save() -> None:
        write_json(OUT / 'execution.json', record)

    def run(argv: list[str], label: str, *, cleanup: bool = False) -> dict:
        nonlocal next_index
        if cleanup:
            guard.FREE_LIMIT = 0
            guard.TARGET_LIMIT = sys.maxsize
        else:
            guard.FREE_LIMIT = FREE_LIMIT
            guard.TARGET_LIMIT = TARGET_LIMIT
        free_start = shutil.disk_usage(ROOT).free
        size_start = scanner.target_bytes(ROOT)
        row = guard.run_command(next_index, argv, env)
        next_index += 1
        row['label'] = label
        row['resource_samples'] = {
            'free_bytes_before': free_start, 'target_bytes_before': size_start,
            'free_bytes_after': shutil.disk_usage(ROOT).free,
            'target_bytes_after': scanner.target_bytes(ROOT),
            'sample_interval_seconds': 1,
        }
        if cleanup:
            row['resource_guard_exception'] = {
                'fixed_command': ['cargo', 'clean'], 'free_limit_bypassed': True,
                'target_limit_bypassed': True,
                'reason': 'cleanup is unconditional; guard.run_command still samples resources and preserves raw streams',
            }
        record['commands'].append(row)
        save()
        return row

    try:
        record['cargo_target_config'] = verify_project_target_config()
        required_test_source = ROOT / 'tests/structured_list_generic_bodies.rs'
        if not required_test_source.is_file() or required_test_source.is_symlink():
            raise FileNotFoundError(f'focused integration test source is missing or linked: {required_test_source}')
        source_before = source_manifest()
        source_baseline_ready = True
        record['source_manifest_before'] = source_before
        record['source_manifest_before_count'] = len(source_before)
        record['source_manifest_before_sha256'] = hashlib.sha256(
            json.dumps(source_before, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        if scanner.target_bytes(ROOT) > TARGET_LIMIT:
            raise RuntimeError('workspace target exceeds 1 GiB before validation')
        if shutil.disk_usage(ROOT).free < FREE_LIMIT:
            raise RuntimeError('workspace has less than 5 GiB free before validation')
        save()

        head_row = run(['git', 'rev-parse', 'HEAD'], 'expected-head-preflight')
        head = Path(head_row['streams']['stdout']['path']).read_text(encoding='ascii').strip()
        record['actual_head'] = head
        record['head_matches_expected'] = head_row['exit_code'] == 0 and head == EXPECTED_HEAD
        save()
        if not record['head_matches_expected'] or head_row['guard_stop'] is not None:
            raise RuntimeError(f'workspace HEAD does not match --expected-head: {head!r}')

        fmt = run(['cargo', 'fmt', '--all', '--', '--check'], 'cargo-fmt-check')
        if fmt['exit_code'] != 0 or fmt['guard_stop'] is not None:
            raise RuntimeError('cargo fmt --all -- --check failed or hit a resource guard')
        after_fmt = source_manifest()
        record['source_manifest_after_fmt'] = after_fmt
        if after_fmt != source_before:
            raise RuntimeError('source closure changed during cargo fmt check')

        cargo_checks = [
            (['cargo', 'test', '-p', 'jarde', '--test', 'structured_list_generic_bodies',
              '--locked', '--', '--nocapture'], 'structured_list_generic_bodies'),
            (['cargo', 'test', '-p', 'jarde-java', '--lib', '--locked'], 'jarde_java_lib'),
            (['cargo', 'test', '-p', 'jarde-reader', '--lib', '--locked',
              'repository_class_fixtures_validate_without_false_target_rejections', '--', '--nocapture'], 'jarde_reader_census'),
            (['cargo', 'test', '-p', 'jarde', '--test', 'p5_corpus_fingerprint',
              '--locked', '--', '--nocapture'], 'p5_corpus_fingerprint'),
            (['cargo', 'build', '-p', 'jarde-cli', '--locked'], 'jarde_cli_build'),
        ]
        for argv, label in cargo_checks:
            row = run(argv, label)
            stdout_path = Path(row['streams']['stdout']['path'])
            if label in {'structured_list_generic_bodies', 'jarde_java_lib', 'jarde_reader_census', 'p5_corpus_fingerprint'}:
                record.setdefault('validation', {})[label] = validate_test_result(label, row, stdout_path)
                save()
            elif row['exit_code'] != 0 or row['guard_stop'] is not None:
                raise RuntimeError('cargo build -p jarde-cli --locked failed or hit a resource guard')
            now = source_manifest()
            if now != source_before:
                raise RuntimeError(f'source closure changed during {label}')

        built = ROOT / 'target/debug/jarde-cli'
        if not built.is_file() or built.is_symlink():
            raise FileNotFoundError(f'successful CLI build did not produce a regular binary: {built}')
        temp_cli = CLI_PATH.with_name(CLI_PATH.name + f'.tmp-{os.getpid()}')
        if temp_cli.exists() or temp_cli.is_symlink():
            raise FileExistsError(f'refusing to overwrite CLI freeze temp path: {temp_cli}')
        CLI_PATH.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(built, temp_cli)
        os.chmod(temp_cli, 0o555)
        os.replace(temp_cli, CLI_PATH)
        cli_pin = file_pin(CLI_PATH)
        mode = stat.S_IMODE(CLI_PATH.stat().st_mode)
        if mode != 0o555:
            raise RuntimeError(f'frozen CLI mode differs from 0555: {oct(mode)}')
        record['cli_freeze'] = {'source_binary': str(built), 'path': cli_pin['path'],
                                'bytes': cli_pin['bytes'], 'sha256': cli_pin['sha256'],
                                'mode': oct(mode)}
        record['status'] = 'validation_passed_cli_frozen_clean_pending'
        save()
    except BaseException as error:
        record['status'] = 'failed_clean_pending'
        record['error'] = f'{type(error).__name__}: {error}'
        save()
    finally:
        cleanup_error = None
        try:
            clean_row = run(['cargo', 'clean'], 'cargo-clean-finally', cleanup=True)
            record['cleanup'] = {
                'attempted': True, 'status': 'passed' if clean_row['exit_code'] == 0 and clean_row['guard_stop'] is None else 'failed',
                'command_index': clean_row['index'], 'target_absent': not (ROOT / 'target').exists(),
                'source_manifest_after': source_manifest(),
            }
            record['source_manifest_after'] = record['cleanup']['source_manifest_after']
            record['source_manifest_after_count'] = len(record['source_manifest_after'])
            record['source_manifest_after_sha256'] = hashlib.sha256(
                json.dumps(record['source_manifest_after'], sort_keys=True, separators=(',', ':')).encode()).hexdigest()
            if source_baseline_ready and record['source_manifest_after'] != record['source_manifest_before']:
                record['cleanup']['status'] = 'failed'
                cleanup_error = 'source closure changed across the run'
            elif not source_baseline_ready:
                record['cleanup']['source_closure_comparison'] = 'not_available_before_preflight_failure'
            if not record['cleanup']['target_absent']:
                record['cleanup']['status'] = 'failed'
                cleanup_error = 'cargo clean did not remove the workspace target directory'
            if clean_row['exit_code'] != 0 or clean_row['guard_stop'] is not None:
                record['cleanup']['status'] = 'failed'
                cleanup_error = 'finally cargo clean failed or was guard-stopped'
        except BaseException as error:
            cleanup_error = f'{type(error).__name__}: {error}'
            record['cleanup'] = {'attempted': True, 'status': 'failed', 'error': cleanup_error}
        record['runner_after'] = file_pin(Path(__file__).resolve())
        record['preparation_pins_after'] = file_pin(PIN_PATH)
        record['dependencies_after'] = {
            'guard': file_pin(GUARD_PATH), 'target_scanner': file_pin(SCANNER_PATH),
            'workspace_source_closure': file_pin(CLOSURE_PATH),
            'reference_focused_wrapper': file_pin(REFERENCE_WRAPPER_PATH),
        }
        record['workspace_source_closure_after_run'] = file_pin(CLOSURE_PATH)
        record['workspace_source_closure_snapshots'] = {
            **CLOSURE_IMPORT_SNAPSHOTS, 'after_run': record['workspace_source_closure_after_run']}
        if any(row != record['workspace_source_closure_snapshots']['before_import']
               for row in record['workspace_source_closure_snapshots'].values()):
            cleanup_error = cleanup_error or 'pinned workspace source-closure module changed during runtime'
        if record['runner_after'] != record['runner']:
            cleanup_error = cleanup_error or 'runner source changed during execution'
        if record['preparation_pins_after'] != record['preparation_pins']:
            cleanup_error = cleanup_error or 'preparation pins changed during execution'
        for name, expected in dependency_pins.items():
            if record['dependencies_after'][name] != expected:
                cleanup_error = cleanup_error or f'pinned dependency changed during execution: {name}'
        if cleanup_error:
            record['status'] = 'failed'
            record.setdefault('error', cleanup_error)
        elif record.get('status') == 'validation_passed_cli_frozen_clean_pending':
            record['status'] = 'passed_initial_product_validation'
        elif record.get('status') == 'failed_clean_pending':
            record['status'] = 'failed'
        record['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()

    return 0 if record['status'] == 'passed_initial_product_validation' else 1


if __name__ == '__main__':
    raise SystemExit(main())
