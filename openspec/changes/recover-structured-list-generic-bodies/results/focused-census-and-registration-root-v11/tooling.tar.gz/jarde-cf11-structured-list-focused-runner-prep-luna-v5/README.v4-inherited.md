# CF11 structured-list 首轮 focused runner v4（私有准备）

v3 基于已准备的 v2 runner，保留 source closure、guard 和清理约束；按当前 focused test 源文件重新 pin 八个测试名与 7 passed / 1 ignored 结果，并将冻结 CLI 目标切换到新的 `candidate-cli-root-v2`。它加载 pinned 的 `/private/tmp/jarde-iterator-assignment-full-validation-prep-luna-v2/workspace_runner.py`，仅调用其 `source_paths()`，再与本 runner 递归枚举的 workspace 文件取并集。这样保留既有闭包发现的 634 个 literal include 及 frozen evidence 输入，也保留 `src/`、`crates/`、`tests/`、`examples/` 的所有实际文件、所有 workspace manifests 和项目 `.cargo` 配置。每条记录保存相对路径、字节数和 SHA-256，读取、walk、缺失、符号链接或越界错误都会中止；运行前、fmt 后、每个 Cargo 阶段后及 finally clean 后都核对完整清单。

closure helper 在导入前、导入后和运行结束时按完整路径、字节数和 SHA-256 检查，且必须与 `pins.json` 中的闭包 helper pin 一致。Guard v9、target scanner v1、focused wrapper v3 也按完整路径与 SHA-256 固定，并在 finally 后复核。Focused test 的八个 named outcomes 必须各出现一次且状态精确为七个 `ok` 和一个 `ignored`：

- `nearby_list_controls_refuse_only_unproved_generic_projections`
- `inner_list_option_actual_uses_the_receiver_element_type`
- `fixed_nested_string_body_projects_source_and_preserves_physical_origins`
- `differently_named_string_and_integer_classes_follow_their_list_element_type`
- `exact_list_null_add_removes_only_the_synthetic_object_wrapper`
- `pre_cancel_does_not_install_a_partial_generic_declaration_or_method_projection`
- `budget_stop_during_list_proof_keeps_raw_body_and_installs_no_projection`
- `diagnose_late_analysis_stop_phase_without_assuming_raw_map_is_empty`

执行顺序为受 guard 监控的 `git rev-parse HEAD` preflight、`cargo fmt --all -- --check`、focused integration test、`jarde-java --lib`、CLI build，然后 finally `cargo clean`。Focused integration summary 必须精确为 7 passed / 0 failed / 1 ignored；lib tests 要求有非零通过数且所有 summary 零失败。仅所有验证通过后，CLI 才冻结至 `/private/tmp/jarde-cf11-structured-list-candidate-cli-root-v2`。Cleanup 对磁盘阈值豁免，但仍复用 guard 的进程组执行器，保存原始 streams、起止资源及一秒采样峰值。

普通命令使用 guard 的 1 秒采样、5 GiB 最低空闲空间和 1 GiB target 上限；越界时终止整个子进程组。runner 移除 `RUST_MIN_STACK` 和继承的 `CARGO_TARGET_DIR`，自身不会设置 `CARGO_TARGET_DIR`，使 guard 观察默认 workspace `target/`。项目 `.cargo` config 若重定向到 guard 范围之外，会拒绝运行。CLI 与所有 raw receipts 都在 workspace 外。source manifest 和 receipt 只在 root 独立执行后生成，本 prep 不声称编译、测试、CI 或产品验收成功。

root 审核后可直接从此 prep 运行；输出目录必须不存在：

```sh
python3 -B /private/tmp/jarde-cf11-structured-list-focused-runner-prep-luna-v4/run.py \
  --out /private/tmp/jarde-cf11-structured-list-focused-run-root-v4 \
  --expected-head e9e3a0ec27e5bf7698bdf4817ff08d38bcb63374
```
