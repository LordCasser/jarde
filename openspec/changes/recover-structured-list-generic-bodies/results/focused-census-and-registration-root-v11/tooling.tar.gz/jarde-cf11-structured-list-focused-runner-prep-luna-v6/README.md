# CF11 structured-list focused runner v6（私有准备）

v6 从 v5 runner 派生，旧 prep 保留。它把冻结 CLI 目的地更新为 `candidate-cli-root-v3`，绑定当前 Java report 与 reader census 源、P5 指纹测试和 corpus manifest，并将四个真实 CF11 generic-void census 单测纳入 `jarde-java --lib` 的精确命名校验。source closure、1 秒 guard、5 GiB free-space 下限、1 GiB target 上限、默认线程栈、stop 处理、finally clean 和完整运行前后源码清单沿用 v4。

运行时顺序为：HEAD preflight、`cargo fmt --all -- --check`、focused API integration、完整 `jarde-java --lib`、reader 仓库 class census、P5 corpus fingerprint、CLI build，最后无论成功失败均执行 `cargo clean`。`jarde-java --lib` 必须精确为 375 passed、0 failed、0 ignored，且以下四个 census 测试各自只出现一次并通过：

- `complete_fixed_void_census_keeps_phi_and_every_formal_read`
- `fixed_census_refuses_physical_inventory_and_operation_disagreements`
- `fixed_read_is_not_unread_when_the_invoke_target_is_unknown`
- `real_parameter_reassignment_and_handler_facts_refuse_the_list_census`

Focused API integration 必须仍为 7 passed / 0 failed / 1 ignored，且 v4 的八个具名结果逐一精确匹配。Reader 门禁运行 `repository_class_fixtures_validate_without_false_target_rejections`，其源码固定了 CF11 fixtures 注册后的汇总 `(1140 classes, 5018 bodies, 474 handlers, 3141 branch/switch targets, 10 subroutines)`。P5 门禁运行 `cargo test -p jarde --test p5_corpus_fingerprint --locked`，使用 Cargo 默认捕获，避免该测试输出 manifest census 时打断测试名与结果之间的行格式。它要求五个只读指纹/分类测试通过、唯一忽略项为会写 manifest 的 `regenerate_corpus_fingerprint`。source pins 固定 `tests/fixtures/corpus-fingerprint.json` 当前 2164 条 files 记录及对应完整字节。

本 prep 不执行 Cargo/JDK、不生成 receipts，也不声称验证成功。所有来源在执行时还会由完整动态 manifest 再核一次；任何缺失、额外/改变文件、符号链接、manifest 偏移、guard stop 或 finally clean 失败都会让 runner 失败。CLI 只有所有检查通过后才冻结为 mode `0555`；输出目录必须预先不存在且位于共享 workspace 外。

root 审查后可用下列命令启动；root 应使用实际确认的 HEAD 并选择新的外部输出目录：

```sh
python3 -B /private/tmp/jarde-cf11-structured-list-focused-runner-prep-luna-v6/run.py \
  --out /private/tmp/jarde-cf11-structured-list-focused-run-root-v6 \
  --expected-head e9e3a0ec27e5bf7698bdf4817ff08d38bcb63374
```
