# CF11 own-product CI verifier prep v8

v8 保留 v7 的 normal passed receipt 路径，并只迁移三个 raw/metadata 语义修复：focused summary/names 按 tuple 保存；static manifest target inventory 用完整长度加集合比较以容忍排序差异；Cargo CI parser 给 ignored reason 返回的状态在跨收据比较前归一为 `ignored`。其余 CI jobs/steps、raw stream、每目标对比、源码 closure 和 final gate 均沿用 v7。

focused v12 已进行真实只读 `verify_focus` 预检；结果与所有真实 argv、stdout/stderr stream 引用在 `focused-v12-preflight.json`。workspace 仍在运行中，因此本包没有尝试其接受或 final/CI 验证。workspace prep v4 冻结，v8 不修改其任何文件。
