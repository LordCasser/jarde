# CF11 全工作区验证准备 v4

v4 使用 recovery prep 中含正确 ignored-test 语义的 workspace runner，要求那条 focused diagnostic 精确为 ignored；它不会把该 ignored 项当作通过测试。focused 输入绑定新 focused runner v7 / receipt v12，CLI freeze 固定 root-v4。Runner 保留动态 Cargo metadata target batches、两 seed 的逐目标原始 streams、全部 named outcomes、source closure、guard 与 finally-clean 检查。

`accept_workspace.py` 从已通过的 workspace receipt、metadata 和 raw stdout/stderr 独立重解析目标、summary、具名结果、focused gates、源码闭包、资源限制与清理状态。成功输出使用原有 `cf11-structured-list-full-workspace-acceptance-v2` schema。

使用前需 root 提供真实 focused receipt SHA 与 root-v4 CLI SHA；把输出写入新目录，禁止覆盖。此目录仅是准备包，未启动 workspace run 或工具链。


Final 阶段沿用正常通过链中的 v3 脚本结构，已绑定本目录 v4 workspace runner/acceptor 与 focused v7 输入契约。`final-build-runner.py` 要求真实 focused/workspace/acceptance 收据及 SHA 参数；完成格式、clippy、strict OpenSpec、CLI rebuild 与字节一致性检查后才写成功状态，始终执行 cleanup-only cargo clean。`accept-final.py` 独立核 raw streams 与 receipt binding，并明确要求 `candidate_byte_identity=true`。脚本已准备，尚未运行。
