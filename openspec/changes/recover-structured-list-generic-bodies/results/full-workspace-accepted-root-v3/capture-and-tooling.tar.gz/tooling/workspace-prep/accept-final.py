#!/usr/bin/env python3
"""Read-only acceptance of final same-source local gates and CLI byte identity."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/Users/lordcasser/workspace/projects/jarde').resolve()
PREP=Path('/private/tmp/jarde-cf11-full-workspace-prep-luna-v4')
RUNNER=PREP/'final-build-runner.py'
WORKSPACE_RUNNER=PREP/'workspace_runner.py'
WORKSPACE_ACCEPTOR=PREP/'accept_workspace.py'
GUARD=ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
GUARD_SHA='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
SCANNER=ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'
SCANNER_SHA='d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'
FREE,TARGET=5*1024**3,1024**3
ENV={'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','RUST_TEST_THREADS':'1','CARGO_TERM_COLOR':'always','PROPTEST_RNG_SEED':'5350648285461741569','CARGO_PROFILE_TEST_STRIP':'symbols'}
def sha(b):return hashlib.sha256(b).hexdigest()
def need(ok,msg):
 if not ok:raise ValueError(msg)
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def module(p):
 spec=importlib.util.spec_from_file_location('cf11_ws_closure',p);need(spec and spec.loader,'cannot load source closure helper');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 for n in ('final-receipt','focused-receipt','workspace-receipt','workspace-acceptance'):
  ap.add_argument('--'+n,type=Path,required=True);ap.add_argument('--'+n+'-sha256',required=True)
 ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
 paths={n:getattr(a,n.replace('-','_')).resolve(strict=True) for n in ('final-receipt','focused-receipt','workspace-receipt','workspace-acceptance')}
 for n,p in paths.items():need(not p.is_symlink() and sha(p.read_bytes())==getattr(a,n.replace('-','_')+'_sha256'),n+' SHA mismatch')
 f,focus,w,wa=[load(paths[n]) for n in ('final-receipt','focused-receipt','workspace-receipt','workspace-acceptance')]
 need(f.get('schema')=='cf11-structured-list-final-validation-root-v2' and f.get('status')=='passed_final_validation' and f.get('final_lint_strict_byte_identity_passed') is True and f.get('candidate_byte_identity') is True,'final validation did not pass or fresh CLI bytes differ from the frozen candidate')
 need(focus.get('source_manifest_before')==focus.get('source_manifest_after'),'focused source manifest changed')
 need(focus.get('schema')=='cf11-structured-list-focused-run-v4' and focus.get('status')=='passed_initial_product_validation' and focus.get('expected_head')=='e9e3a0ec27e5bf7698bdf4817ff08d38bcb63374' and focus.get('actual_head')==focus.get('expected_head'),'focused receipt not accepted for pinned source head')
 need(w.get('schema')=='cf11-structured-list-full-workspace-root-v2' and w.get('status')=='passed','workspace receipt not accepted')
 need(wa.get('schema')=='cf11-structured-list-full-workspace-acceptance-v2' and wa.get('status')=='accepted_local_workspace_only' and wa.get('execution_sha256')==a.workspace_receipt_sha256,'workspace acceptance not bound')
 need(f.get('focused_receipt')=={'path':str(paths['focused-receipt']),'sha256':a.focused_receipt_sha256,'schema':focus['schema'],'status':focus['status']},'final focused binding differs')
 need(f.get('workspace_receipt')=={'path':str(paths['workspace-receipt']),'sha256':a.workspace_receipt_sha256,'schema':w['schema'],'status':w['status']},'final workspace binding differs')
 need(f.get('workspace_acceptance')=={'path':str(paths['workspace-acceptance']),'sha256':a.workspace_acceptance_sha256,'schema':wa['schema'],'status':wa['status']},'final workspace acceptance binding differs')
 need(sha(GUARD.read_bytes())==GUARD_SHA and sha(SCANNER.read_bytes())==SCANNER_SHA,'guard or scanner pin differs')
 runpin=sha(RUNNER.read_bytes()); wspin=sha(WORKSPACE_RUNNER.read_bytes()); apin=sha(WORKSPACE_ACCEPTOR.read_bytes())
 refs={x.get('path'):x.get('sha256') for x in f.get('references',[])}
 need(refs.get(str(WORKSPACE_RUNNER))==wspin and refs.get(str(WORKSPACE_ACCEPTOR))==apin and refs.get(str(GUARD))==GUARD_SHA and refs.get(str(SCANNER))==SCANNER_SHA,'final receipt helper references differ')
 cl=module(WORKSPACE_RUNNER);live=cl.pin_sources(cl.source_paths()); fpins={x.get('path'):x.get('sha256') for x in focus.get('source_manifest_before',[])}
 need(live==fpins==w.get('source_pins_before')==w.get('source_pins_after')==f.get('source_pins_before')==f.get('source_pins_after'),'live source closure differs across runs')
 need(f.get('source_pin_count')==len(live)==wa.get('source_pin_count'),'source closure count differs')
 freeze=focus.get('cli_freeze',{}); candidate=f.get('candidate_cli',{})
 cli=Path(freeze.get('path','')).resolve(strict=True)
 need(candidate=={'path':str(cli),'bytes':freeze.get('bytes'),'sha256':freeze.get('sha256'),'mode':freeze.get('mode')} and cli.read_bytes() and sha(cli.read_bytes())==freeze.get('sha256') and cli.stat().st_mode&0o777==0o555,'candidate CLI freeze identity changed')
 rows=f.get('commands',[])
 need(not (ROOT/'target').exists() and f.get('target_absent') is True and f.get('cleanup',{}).get('status')=='passed' and f.get('cleanup',{}).get('command')==rows[-1],'target cleanup failed')
 need(f.get('fresh_target_preflight',{}).get('target_absent') is True and f.get('fresh_target_preflight',{}).get('free_bytes',0)>=FREE,'final fresh-target preflight differs')
 need(f.get('rust_min_stack') is None and f.get('environment_overrides')==ENV,'final environment/default stack differs')
 need(f.get('guard_limits')=={'minimum_free_bytes':FREE,'maximum_target_bytes':TARGET,'poll_interval_seconds':1},'resource guard limits differ')
 need(len(rows)==5 and [x.get('index') for x in rows]==list(range(5)),'final command count/order differs')
 ci=(ROOT/'.github/workflows/ci.yml').read_text(encoding='utf-8');start=ci.index('          cargo clippy');end=ci.index('\n\n',start);lint=ci[start:end].split()
 expected=[['cargo','fmt','--all','--','--check'],lint,['openspec','validate','--all','--strict','--no-interactive'],['cargo','build','-p','jarde-cli','--bin','jarde-cli','--locked'],['cargo','clean']]
 need(lint[:7]==['cargo','clippy','--workspace','--all-targets','--all-features','--locked','--'] and lint[-2:]==['-D','warnings'],'CI workflow clippy command differs')
 raw_paths=set()
 for i,(row,argv) in enumerate(zip(rows,expected)):
  need(row.get('argv')==argv and row.get('index')==i and row.get('cwd')==str(ROOT) and row.get('exit_code')==0 and row.get('guard_stop') is None,'final command evidence differs')
  need(row.get('env_overrides')==ENV,'final command environment differs')
  if i<4:need(row.get('cleanup_only') is None and row.get('peak_target_bytes',TARGET+1)<=TARGET and row.get('free_bytes_after',0)>=FREE,'guarded command exceeded configured limits')
  else:
   c=row.get('cleanup_only',{});need(c.get('exact_argv')==['cargo','clean'] and c.get('space_precheck_bypassed') is True and c.get('space_monitor_abort_bypassed') is True and row.get('free_bytes_after')==c.get('observed_after',{}).get('free_bytes'),'clean-only exception evidence differs')
  for ref in row.get('streams',{}).values():
   p=Path(ref['path']);need(not p.is_symlink() and p.is_file() and p.resolve().is_relative_to(paths['final-receipt'].parent),'final raw stream missing/escaped')
   raw_bytes=p.read_bytes();need(len(raw_bytes)==ref['bytes'] and sha(raw_bytes)==ref['sha256'],'final raw stream hash differs');raw_paths.add(p.resolve())
 need(len(raw_paths)==10,'final raw stream inventory differs')
 actual_raws={p.resolve() for p in paths['final-receipt'].parent.glob('*.raw') if p.is_file()}
 need(actual_raws==raw_paths,'final receipt directory contains missing or unreferenced raw streams')
 strict=rows[2];need(f.get('global_strict_observation')=={'stdout_sha256':strict['streams']['stdout']['sha256'],'stderr_sha256':strict['streams']['stderr']['sha256'],'exit_code':0},'strict observation does not bind raw streams')
 need(f.get('runner',{}).get('path')==str(RUNNER) and f['runner'].get('sha256_before')==runpin==f['runner'].get('sha256_after'),'final runner bytes changed')
 out=a.out.resolve();need(not out.exists(),'refusing to overwrite acceptance result')
 result={'schema':'cf11-structured-list-final-acceptance-v2','status':'accepted_local_final_validation_only','focused_receipt_sha256':a.focused_receipt_sha256,'workspace_receipt_sha256':a.workspace_receipt_sha256,'source_pin_count':len(live),'workspace_target_count':wa.get('target_count'),'candidate_cli_byte_identical':f.get('candidate_byte_identity') is True,'target_absent':True,'scope':'Local validation only; not CI or product completion acceptance.'}
 out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False,indent=2));return 0
if __name__=='__main__':
 try:raise SystemExit(main())
 except Exception as exc:print(f'final acceptance failed: {type(exc).__name__}: {exc}',file=sys.stderr);raise SystemExit(1)
