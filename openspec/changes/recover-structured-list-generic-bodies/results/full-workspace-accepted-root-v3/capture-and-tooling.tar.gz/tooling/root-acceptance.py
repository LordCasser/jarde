from pathlib import Path
import hashlib, importlib.util, json, subprocess, sys
sys.dont_write_bytecode=True
root=Path('/Users/lordcasser/workspace/projects/jarde')
prep=Path('/private/tmp/jarde-cf11-full-workspace-prep-luna-v4')
workspace=Path('/private/tmp/jarde-cf11-structured-list-full-workspace-root-v3')
focused=Path('/private/tmp/jarde-cf11-structured-list-focused-root-v12/execution.json')
out=Path('/private/tmp/jarde-cf11-structured-list-workspace-acceptance-root-v3')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def module(p):
 spec=importlib.util.spec_from_file_location('root_cf11_ci_readonly',p); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
assert not out.exists()
assert sha(prep/'accept_workspace.py')=='09d478dcfac1aa6df1335b0ef86b90a5b17315051c563167d73a32072ed9019d'
verifier=Path('/private/tmp/jarde-cf11-own-product-ci-verifier-prep-luna-v8/verify-own-ci.py')
assert sha(verifier)=='27af3f0f7d8534223392fb50bd72318fd462e80b6526994d458d02354bf2e17e'
ep=workspace/'execution.json'; e=json.loads(ep.read_text()); assert e['status']=='passed'
assert len(e['commands'])==195
assert all(row['exit_code']==0 and row.get('guard_stop') is None for row in e['commands'])
assert all(s['status']=='ok' and s['failed']==0 for row in e['commands'] for s in row.get('observed_summaries',[]))
assert all(n['status'] in ('ok','ignored') for row in e['commands'] for n in row.get('named_test_outcomes',[]))
assert e['commands'][-1]['argv']==['cargo','clean'] and not (root/'target').exists()
assert e['source_pins_before']==e['source_pins_after'] and len(e['source_pins_before'])==4822
out.mkdir()
record={'status':'running','wrapper_source_sha256':sha(Path(__file__)),'workspace_receipt_sha256':sha(ep),'commands':[]}
def save(): (out/'execution.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
argv=[sys.executable,'-B',str(prep/'accept_workspace.py'),'--execution',str(ep),'--execution-sha256',sha(ep),'--focused-receipt',str(focused),'--focused-receipt-sha256',sha(focused),'--metadata',str(workspace/'metadata.json'),'--out',str(out/'summary.json')]
row={'argv':argv,'cwd':str(root),'streams':{}}
record['commands'].append(row);save()
try:
 with (out/'accept.stdout.raw').open('xb') as stdout,(out/'accept.stderr.raw').open('xb') as stderr:
  row['exit_code']=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr).returncode
 for label in ('stdout','stderr'):
  p=out/('accept.'+label+'.raw');row['streams'][label]={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
 save();assert row['exit_code']==0, (out/'accept.stderr.raw').read_text()
 m=module(verifier); f,fi=m.verify_focus(focused,sha(focused),m.CANDIDATE_CLI_PATH)
 f['_path']=str(focused.resolve());f['_sha']=sha(focused)
 w,meta,observations,pins,info,required=m.verify_workspace(workspace,sha(ep),out/'summary.json',sha(out/'summary.json'),f,m.WORKSPACE_RUNNER_PATH,m.load_ci_helper())
 assert all(counts[1]==0 for counts in info['workspace_totals_by_seed'].values())
 record.update(status='accepted_two_independent_parsers',verifier_sha256=sha(verifier),acceptance_sha256=sha(out/'summary.json'),root_invariants={'all_195_exit_codes_zero':True,'all_summaries_ok_zero_failures':True,'all_names_ok_or_ignored':True,'target_absent':True,'source_closure_count':4822},own_ci_parser_preflight={'focused':fi,'workspace':info,'required_outcomes':required})
except BaseException as exc:
 record.update(status='failed',error=repr(exc));save();raise
save();print(json.dumps({'status':record['status'],'execution_sha256':sha(ep),'acceptance_sha256':record['acceptance_sha256'],'workspace_info':info},ensure_ascii=False,indent=2))
