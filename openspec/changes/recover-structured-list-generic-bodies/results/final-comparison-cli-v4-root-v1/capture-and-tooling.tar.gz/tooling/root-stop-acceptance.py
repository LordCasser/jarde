from pathlib import Path
import hashlib,json,sys
sys.dont_write_bytecode=True
source=Path('/private/tmp/jarde-cf11-structured-list-late-stop-cli-v4-root-v1')
out=Path('/private/tmp/jarde-cf11-structured-list-late-stop-independent-root-v4');assert not out.exists();out.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record={'schema':'cf11-cli-v4-late-stop-raw-acceptance-root-v1','status':'running','source_receipt_sha256':sha(source/'execution.json'),'checker_source_sha256':sha(Path(__file__)),'checks':{}}
def save():(out/'summary.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
save()
try:
 e=json.loads((source/'execution.json').read_text());assert e['status']=='preflight_or_runner_failure' and e['errors']==['ValueError: target test method missing']
 assert len(e['commands'])==2 and [r['exit_code'] for r in e['commands']]==[4,0]
 cli=Path(e['cli_before']['path']);assert sha(cli)=='d3d15d3dd875bc79410298e3ed1e56010fc39c1849e97dc893cadb49d8c65e6f' and cli.stat().st_mode&0o777==0o555
 assert e['cli_before']==e['cli_after'] and e['input_before']==e['input_after'] and e['source_binding_before']==e['source_binding_after']
 inp=Path(e['input_before']['path']);assert sha(inp)=='8ece89e4d38751c20529622b57417afc8601368fc20078656ea2b24c17ed8231'
 docs=[]
 for row in e['commands']:
  assert row.get('guard_stop') is None and row['artifact_stable'] is True and row['peak_target_bytes']<=1024**3 and row['free_bytes_after']>=5*1024**3
  for n,ref in row['streams'].items():
   p=Path(ref['path']);assert p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(source) and p.stat().st_size==ref['bytes'] and sha(p)==ref['sha256']
   if n=='stderr':assert p.read_bytes()==b''
  docs.append(json.loads(Path(row['streams']['stdout']['path']).read_bytes()))
 def method(d):
  matches=[m for m in d['methods'] if m['item']['name']['escaped']=='test' and m['item']['descriptor']['escaped']=='(Ljava/util/List;Ljava/util/List;)V']
  assert len(matches)==1
  m=matches[0];assert m['item']['identity']['name']==list(b'test') and m['item']['identity']['descriptor']==list(b'(Ljava/util/List;Ljava/util/List;)V')
  assert m['item']['identity']['owner']['class_bytes']['length']==1213
  return m
 partial,full=docs;pm,fm=map(method,docs);pr,fr=pm['outcome']['report'],fm['outcome']['report'];usage=partial['execution']['usage']['analysis_steps'];limit=e['budget_limit']
 assert usage==25299 and limit==32531 and usage<limit
 assert partial['execution']['status']=='partial' and partial['execution']['reason']=={'dimension':'analysis_steps','kind':'budget_exceeded'} and full['execution']['status']=='complete'
 diagnostics=[x for x in partial['diagnostics'] if x['code']=='budget_exceeded_analysis_steps'];assert len(diagnostics)==1 and diagnostics[0]['message']=='budget exceeded for AnalysisSteps: limit=32531, consumed=25299, requested=8112' and usage+8112>limit
 assert pm['item']==fm['item'] and pr['execution']['status']=='complete' and pr['content']=='contains_statements'
 assert pr['text']==fr['text'] and pr['source_map']==fr['source_map']
 assert 'l2.add((java.lang.Object) s1)' in pr['text'] and '<' not in pm['declaration'] and 'List<' not in pr['text']
 assert 'java.util.List<java.lang.String>' in fm['declaration'] and any('generic Signature projection refused' in x for x in pm['markers'])
 record.update(status='accepted_current_cli_raw_late_stop_only',analysis_steps=usage,budget_limit=limit,requested=8112,full_analysis_steps=full['execution']['usage']['analysis_steps'],method_identity=pm['item']['identity'],original_collection_status_preserved=e['status'],checks={'both_exit_codes_expected':True,'no_guard_stop_and_empty_stderr':True,'cli_input_binding_and_raw_hashes_stable':True,'exact_physical_method_identity':True,'raw_method_text_and_source_map_equal_complete_run':True,'no_partial_generic_declaration':True,'object_add_wrapper_retained':True,'complete_run_has_generic_declaration':True,'budget_stopped_before_atomic_generic_publish':True})
except BaseException as exc:
 record.update(status='failed',error=repr(exc));save();raise
save();print(json.dumps({'status':record['status'],'summary_sha256':sha(out/'summary.json'),'used':usage,'requested':record['requested'],'limit':limit,'full_used':record['full_analysis_steps']},ensure_ascii=False))
