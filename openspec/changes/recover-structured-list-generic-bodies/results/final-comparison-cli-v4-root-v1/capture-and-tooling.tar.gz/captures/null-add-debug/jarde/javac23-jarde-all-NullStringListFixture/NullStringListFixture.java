// jarde: presentation of `cf11/NullStringListFixture` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package cf11;

public class NullStringListFixture extends java.lang.Object {
    public static int effects;

    public NullStringListFixture() {
        // @method <init>()V
        // @declaration a constructor of `cf11.NullStringListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public void strings(java.util.List<java.lang.String> selected, java.util.List<java.lang.String> available) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/String;>;Ljava/util/List<Ljava/lang/String;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method strings(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.NullStringListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    java.lang.String value;
                    java.util.Iterator local5;
                    for (java.lang.Object iteratorElement17 : selected) {
                        value = (java.lang.String) iteratorElement17;
                        for (java.lang.Object iteratorElement47 : available) {
                            java.lang.String option = (java.lang.String) iteratorElement47;
                            if (value.equals((java.lang.Object) option)) {
                                if (value.length() == 5) {
                                    available.add(null);
                                    cf11.NullStringListFixture.effects = cf11.NullStringListFixture.effects + 1;
                                } else {
                                    selected.remove((java.lang.Object) option);
                                    cf11.NullStringListFixture.effects = cf11.NullStringListFixture.effects + 1;
                                }
                            }
                        }
                    }
                    if (available.size() > 0) {
                        selected.clear();
                        cf11.NullStringListFixture.effects = cf11.NullStringListFixture.effects + 1;
                    }
                    return;
    }
}
