package cf11;

import java.util.List;

/* JADX INFO: loaded from: for-condition-controls.jar:cf11/UpstreamNestedLoops.class */
public class UpstreamNestedLoops {
    public void test(List<String> list, List<String> list2) {
        for (String str : list) {
            for (String str2 : list2) {
                if (str.equals(str2)) {
                    if (str.length() == 5) {
                        list2.add(str);
                    } else {
                        list.remove(str2);
                    }
                }
            }
        }
        if (list2.size() > 0) {
            list.clear();
        }
    }
}
