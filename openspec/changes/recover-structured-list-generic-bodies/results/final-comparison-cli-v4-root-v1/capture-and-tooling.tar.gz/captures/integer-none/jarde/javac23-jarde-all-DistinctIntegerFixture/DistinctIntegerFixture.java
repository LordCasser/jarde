// jarde: presentation of `cf11/DistinctIntegerFixture` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package cf11;

public class DistinctIntegerFixture extends java.lang.Object {
    public static int effects;

    public DistinctIntegerFixture() {
        // @method <init>()V
        // @declaration a constructor of `cf11.DistinctIntegerFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    public void numbers(java.util.List<java.lang.Integer> arg1, java.util.List<java.lang.Integer> arg2) {
        // jarde: generic Signature `(Ljava/util/List<Ljava/lang/Integer;>;Ljava/util/List<Ljava/lang/Integer;>;)V` projected after descriptor erasure and same-run AST/Code/SSA complete void body proof; same-class call binding proved
        // @method numbers(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.DistinctIntegerFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
                    java.lang.Integer local4;
                    java.util.Iterator local5;
                    for (java.lang.Object iteratorElement17 : arg1) {
                        local4 = (java.lang.Integer) iteratorElement17;
                        for (java.lang.Object iteratorElement47 : arg2) {
                            java.lang.Integer local6 = (java.lang.Integer) iteratorElement47;
                            if (local4.equals((java.lang.Object) local6)) {
                                if (local4.intValue() == 5) {
                                    arg2.add(local4);
                                    cf11.DistinctIntegerFixture.effects = cf11.DistinctIntegerFixture.effects + 1;
                                } else {
                                    arg1.remove((java.lang.Object) local6);
                                    cf11.DistinctIntegerFixture.effects = cf11.DistinctIntegerFixture.effects + 1;
                                }
                            }
                        }
                    }
                    if (arg2.size() > 0) {
                        arg1.clear();
                        cf11.DistinctIntegerFixture.effects = cf11.DistinctIntegerFixture.effects + 1;
                    }
                    return;
    }
}
