from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
HERE=Path(__file__).resolve().parent
COLLECTOR=Path('/private/tmp/jarde-cf11-final-comparison-v11-prep-luna-v6/collect_controls.py')
SOURCE_BINDING_PATH=Path('/private/tmp/jarde-cf11-final-comparison-v11-prep-luna-v6/source_binding.json')
SOURCE_BINDING=json.loads(SOURCE_BINDING_PATH.read_text())
RECEIPT=Path(SOURCE_BINDING['focused_receipt']['path'])
CLI=Path(SOURCE_BINDING['cli']['path'])
TEST_INVENTORY=Path('/private/tmp/jarde-cf11-final-comparison-v11-prep-luna-v6/focused_v12_expected_test_names.json')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(COLLECTOR)=='65bee60a48d8be7984147eceb943fbf21a1cef7d5047006c5c7ad2cfec6cfbb5'
assert SOURCE_BINDING['status']=='root_pins_filled'
assert SOURCE_BINDING['focused_receipt']['bytes']==RECEIPT.stat().st_size and SOURCE_BINDING['focused_receipt']['sha256']==sha(RECEIPT)
assert SOURCE_BINDING['cli']['bytes']==CLI.stat().st_size and SOURCE_BINDING['cli']['sha256']==sha(CLI)
assert SOURCE_BINDING['cli']['mode']=='0o555' and (CLI.stat().st_mode&0o777)==0o555
assert sha(TEST_INVENTORY)=='bf3d8aad9dee1a9ee84f6985c71e4015932248c7d0be9d6cdc18be23fdc7ddd6'
record={'status':'running','collector_sha256':sha(COLLECTOR),'build_receipt_sha256':sha(RECEIPT),'cli_sha256':sha(CLI),'commands':[]}
def save():(HERE/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
save()
for family in ('inner-option','null-add','fixed','string','integer','controls'):
 seed=Path('/private/tmp/jarde-cf11-structured-list-current-'+family+'-debug-root-v1/execution.json')
 config=json.loads(seed.read_text())['collector_config']
 for mode in ('debug','none'):
  out=Path('/private/tmp/jarde-cf11-structured-list-final-v12v6-'+family+'-'+mode+'-root-v1')
  args={**config,'source_debug':mode,'out':str(out),'cli':str(CLI),'cli_sha256':sha(CLI),'build_receipt':str(RECEIPT),'build_receipt_sha256':sha(RECEIPT),'receipt_cli_object':'cli_freeze','receipt_accepted_value':'passed_initial_product_validation'}
  argv=[sys.executable,'-B',str(COLLECTOR)]
  for key,value in args.items():argv+=['--'+key.replace('_','-'),str(value)]
  label=family+'-'+mode;row={'label':label,'argv':argv,'capture':str(out),'status':'running'};record['commands'].append(row);save()
  with (HERE/(label+'.stdout.raw')).open('wb') as so,(HERE/(label+'.stderr.raw')).open('wb') as se:
   row['exit_code']=subprocess.run(argv,cwd=ROOT,stdout=so,stderr=se).returncode
  row['status']='terminal';row['streams']={}
  for name in ('stdout','stderr'):
   p=HERE/(label+'.'+name+'.raw');row['streams'][name]={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
  save();print(label,row['exit_code'],flush=True)
  if row['exit_code']!=0:record['status']='failed';save();raise SystemExit(row['exit_code'])
record['status']='captures_complete_not_independently_accepted';save()
