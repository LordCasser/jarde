# CF11 focused v12 / CLI v4 matrix v6 准备包

本包由 v5 派生，已把 focused receipt validator 的实际依赖改为 prep-luna-v7：runner SHA-256 `c8b1016eaf9506912876fd92e8544d5f78e472401beb99e3fd75b549607956bc`，pins SHA-256 `9d579a51425236d13673a1a70bef0e0b2908e56efae5ad3a7f63225d4677b942`。完整对照见 `collector-v5-v6.diff`。

focused v12 receipt 与 CLI root-v4 的确切字节数和 SHA 尚待 root 提供。`source_binding.json` 和 `pins.json` 中相应字段仍为空，runner 会在运行前拒绝未填的 pins；收到 root 收据后，应更新 source binding 与 pins 中的 receipt、CLI 和 source-binding 三个交叉项。

矩阵保留四组完整 raw test name/status census：8 个结构化 List API 测试、375 个 jarde-java 测试、reader census 的1个测试和 P5 census 的6个测试。acceptor 会逐名核对 stdout 与 receipt raw stream pins，并确认 375 项均为 `ok`。12组观察写入全新 `final-v12v6-*` 路径，覆盖6类输入的debug与none模式，并保留原41 labels、完整 class/map/Runner/oracle 验证、352条命令和704条raw stream。原5 GiB free / 1 GiB target / 1秒资源guard仍在每次采集执行。

root填写 pins 并确认fresh路径空闲后，运行矩阵：

```sh
python3 /private/tmp/jarde-cf11-final-comparison-v11-prep-luna-v6/run.py
```

矩阵终态后独立验收：

```sh
python3 /private/tmp/jarde-cf11-final-comparison-v11-prep-luna-v6/accept_final_comparisons.py --batch /private/tmp/jarde-cf11-final-comparison-v11-prep-luna-v6/execution.json --focused-receipt /private/tmp/jarde-cf11-structured-list-focused-root-v12/execution.json --out /private/tmp/jarde-cf11-final-comparison-v11-prep-luna-v6/acceptance.json
```

late-stop runner读取同一份 root-filled CLI v4 pin，使用新输出目录 `/private/tmp/jarde-cf11-structured-list-late-stop-cli-v4-root-v1`。它仍以旧root-v2的32531为请求限额，但新usage只以本次CLI实测为准；完整报告文本和source map相对full请求一致、raw方法保持Object add等条件由本次输出判定。保留两次stdout/stderr raw与已有5 GiB / 1 GiB / 1秒 guard。

```sh
python3 /private/tmp/jarde-cf11-final-comparison-v11-prep-luna-v6/late_stop_v4.py --out /private/tmp/jarde-cf11-structured-list-late-stop-cli-v4-root-v1
```

本次仅做私有脚本准备和语法/pin一致性检查；未运行矩阵、acceptor、late-stop、CLI、Cargo、JDK或Git。`*-v5-v6.diff`可审阅v5到v6的改动。
