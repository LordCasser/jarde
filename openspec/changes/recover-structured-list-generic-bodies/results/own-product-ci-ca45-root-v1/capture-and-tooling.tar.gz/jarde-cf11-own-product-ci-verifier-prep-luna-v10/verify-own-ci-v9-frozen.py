#!/usr/bin/env python3
"""Read-only acceptance of the current CF11 product CI against fresh local raw runs."""
from __future__ import annotations
import argparse, ast, gzip, hashlib, importlib.util, json, re, stat, sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde').resolve()
CI_HELPER_PATH = ROOT / 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/verify-conditional-ci-root-v5.py'
CI_HELPER_SHA256 = 'bea37c7d4d37182168a7c1cbbde3ee31c94d61f6bc32667bedbdd02ce7e5b0ca'
CAPTURE_COLLECTOR_PATH = ROOT / 'openspec/changes/recover-proved-conditional-switch-fallthrough/results/capture-conditional-ci-root-v3.py'
CAPTURE_COLLECTOR_SHA256 = 'ed889bf6af08247efcce3c889cd1c790d6829d0ea12e9c0d053bdef801994be3'
WORKSPACE_PREP = Path('/private/tmp/jarde-cf11-full-workspace-prep-luna-v4')
WORKSPACE_RUNNER_PATH = WORKSPACE_PREP / 'workspace_runner.py'
WORKSPACE_RUNNER_SHA256 = '91f8065cf3ab9cb0d8ad13e45d3ea5851f89547c738c8699db9ad1d004d136ca'
WORKSPACE_ACCEPTOR_PATH = WORKSPACE_PREP / 'accept_workspace.py'
WORKSPACE_ACCEPTOR_SHA256 = '09d478dcfac1aa6df1335b0ef86b90a5b17315051c563167d73a32072ed9019d'
FINAL_BUILD_RUNNER_PATH = WORKSPACE_PREP / 'final-build-runner.py'
FINAL_BUILD_RUNNER_SHA256 = '76443a49ce27ecdc6b3717609275a92d20ad47fe41c57056ad61e41c0824ddcb'
FINAL_ACCEPTOR_PATH = WORKSPACE_PREP / 'accept-final.py'
FINAL_ACCEPTOR_SHA256 = 'b730445a72d0a570305a969b30e33ec2129ec70e92065b977053c5eb1a68b9ff'
FOCUSED_RUNNER_PATH = Path('/private/tmp/jarde-cf11-structured-list-focused-runner-prep-luna-v7/run.py')
FOCUSED_RUNNER_SHA256 = 'c8b1016eaf9506912876fd92e8544d5f78e472401beb99e3fd75b549607956bc'
CANDIDATE_CLI_PATH = Path('/private/tmp/jarde-cf11-structured-list-candidate-cli-root-v4')
WORKSPACE_SCHEMA = 'cf11-structured-list-full-workspace-root-v2'
WORKSPACE_ACCEPTANCE_SCHEMA = 'cf11-structured-list-full-workspace-acceptance-v2'
FINAL_SCHEMA = 'cf11-structured-list-final-validation-root-v2'
FINAL_ACCEPTANCE_SCHEMA = 'cf11-structured-list-final-acceptance-v2'
FOCUSED_SCHEMA = 'cf11-structured-list-focused-run-v4'
SEEDS = ('5350648285461741569', '5350648285461741570')
EXPECTED_SOURCE_CLOSURE_COUNT = 4822
EXPECTED_CENSUS_TESTS = {
 'complete_fixed_void_census_keeps_phi_and_every_formal_read',
 'fixed_census_refuses_physical_inventory_and_operation_disagreements',
 'fixed_read_is_not_unread_when_the_invoke_target_is_unknown',
 'real_parameter_reassignment_and_handler_facts_refuse_the_list_census',
}
FOCUSED_API_EXPECTED = {
 'nearby_list_controls_refuse_only_unproved_generic_projections':'ok',
 'inner_list_option_actual_uses_the_receiver_element_type':'ok',
 'fixed_nested_string_body_projects_source_and_preserves_physical_origins':'ok',
 'differently_named_string_and_integer_classes_follow_their_list_element_type':'ok',
 'exact_list_null_add_removes_only_the_synthetic_object_wrapper':'ok',
 'pre_cancel_does_not_install_a_partial_generic_declaration_or_method_projection':'ok',
 'budget_stop_during_list_proof_keeps_raw_body_and_installs_no_projection':'ok',
 'diagnose_late_analysis_stop_phase_without_assuming_raw_map_is_empty':'ignored',
}
FOCUSED_COMMANDS = [
 ['git','rev-parse','HEAD'], ['cargo','fmt','--all','--','--check'],
 ['cargo','test','-p','jarde','--test','structured_list_generic_bodies','--locked','--','--nocapture'],
 ['cargo','test','-p','jarde-java','--lib','--locked'],
 ['cargo','test','-p','jarde-reader','--lib','--locked','repository_class_fixtures_validate_without_false_target_rejections','--','--nocapture'],
 ['cargo','test','-p','jarde','--test','p5_corpus_fingerprint','--locked'],
 ['cargo','build','-p','jarde-cli','--locked'], ['cargo','clean'],
]
BASE_ENV = {'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','RUST_TEST_THREADS':'1','CARGO_TERM_COLOR':'always'}
FINAL_ENV = {**BASE_ENV,'PROPTEST_RNG_SEED':SEEDS[0],'CARGO_PROFILE_TEST_STRIP':'symbols'}
FREE_LIMIT, TARGET_LIMIT = 5*1024**3, 1024**3
EXPECTED_JOBS = {'stable / test and specification','MSRV 1.88.0','supply chain','fuzz smoke'}
CAPTURE_SCHEMA = 'recover-proved-conditional-switch-fallthrough-ci-capture-root-v2'


def need(ok, message):
    if not ok: raise ValueError(message)

def sha(raw: bytes) -> str: return hashlib.sha256(raw).hexdigest()
def sha_file(path: Path) -> str: return sha(path.read_bytes())
def load_json(path: Path): return json.loads(Path(path).read_text(encoding='utf-8'))
def load_module(name: str, path: Path):
    spec=importlib.util.spec_from_file_location(name,path)
    need(spec is not None and spec.loader is not None,'cannot load pinned module: '+str(path))
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module

def load_ci_helper():
    need(CI_HELPER_PATH.is_file() and sha_file(CI_HELPER_PATH)==CI_HELPER_SHA256,'CI parser source pin differs')
    return load_module('cf11_ci_raw_parser',CI_HELPER_PATH)

def load_workspace_runner(path: Path):
    need(path.resolve()==WORKSPACE_RUNNER_PATH.resolve() and path.is_file() and sha_file(path)==WORKSPACE_RUNNER_SHA256,
         'CF11 workspace runner path/SHA differs from reviewed v3 source')
    return load_module('cf11_workspace_closure',path)

def load_focus_runner():
    need(FOCUSED_RUNNER_PATH.is_file() and sha_file(FOCUSED_RUNNER_PATH)==FOCUSED_RUNNER_SHA256,
         'focused v7 runner source pin differs')
    return load_module('cf11_focused_runner',FOCUSED_RUNNER_PATH)


def verify_stream(ref: dict, evidence_root: Path) -> bytes:
    path = Path(ref.get('path', ''))
    if not path.is_absolute():
        path = evidence_root / path
    need(not path.is_symlink(), 'raw command stream must not be a symlink: ' + str(path))
    resolved = path.resolve(strict=True)
    need(resolved.is_relative_to(evidence_root.resolve(strict=True)),
         'raw command stream escapes its evidence directory: ' + str(path))
    raw = resolved.read_bytes()
    need(len(raw) == ref.get('bytes') and sha(raw) == ref.get('sha256'),
         'raw command stream bytes/SHA mismatch: ' + str(path))
    return raw

def check_command(row: dict, index: int, argv: list[str], env_expected: dict[str, str], evidence_root: Path, *, cleanup_only: bool = False) -> None:
    need(row.get('index') == index and row.get('argv') == argv and row.get('cwd') == str(ROOT),
         f'command {index} index/argv/cwd mismatch')
    need(row.get('exit_code') == 0 and row.get('guard_stop') is None,
         f'command {index} failed or hit its resource guard')
    if cleanup_only:
        proof = row.get('cleanup_only', {})
        need(argv == ['cargo', 'clean'] and proof.get('exact_argv') == argv and
             proof.get('space_precheck_bypassed') is True and
             proof.get('space_monitor_abort_bypassed') is True and
             all(type(proof.get(side, {}).get(key)) is int and proof[side][key] >= 0
                 for side in ('observed_before', 'observed_after')
                 for key in ('target_bytes', 'free_bytes')) and
             row.get('free_bytes_after') == proof.get('observed_after', {}).get('free_bytes') and
             type(row.get('peak_target_bytes')) is int and
             row['peak_target_bytes'] >= max(proof.get('observed_before', {}).get('target_bytes', 0),
                                             proof.get('observed_after', {}).get('target_bytes', 0)),
             f'command {index} cleanup-only bypass is not scoped to exact cargo clean observations')
    else:
        need(row.get('cleanup_only') is None and
             type(row.get('peak_target_bytes')) is int and row['peak_target_bytes'] <= TARGET_LIMIT and
             type(row.get('free_bytes_after')) is int and row['free_bytes_after'] >= FREE_LIMIT,
             f'command {index} exceeded or omitted the resource guard')
    need(row.get('env_overrides') == env_expected, f'command {index} environment differs from the receipt contract')
    streams = row.get('streams', {})
    need(set(streams) == {'stdout', 'stderr'}, f'command {index} lacks complete raw streams')
    verify_stream(streams['stdout'], evidence_root)
    verify_stream(streams['stderr'], evidence_root)

def expected_workspace_commands(metadata: dict) -> tuple[list[list[str]], list[tuple[str, str, str]]]:
    members = set(metadata['workspace_members'])
    commands: list[list[str]] = []
    coverage: list[tuple[str, str, str]] = []
    for package in metadata['packages']:
        if package['id'] not in members:
            continue
        base = ['cargo', 'test', '-p', package['name'], '--all-features', '--locked', '--message-format', 'json']
        units = [target for target in package['targets']
                 if target['kind'][0] in ('lib', 'bin', 'example', 'bench')]
        if units:
            flags = []
            for kind, flag in (('lib', '--lib'), ('bin', '--bins'), ('example', '--examples'), ('bench', '--benches')):
                if any(target['kind'][0] == kind for target in units):
                    flags.append(flag)
            commands.append(base + flags)
            coverage.extend((package['name'], target['name'], target['kind'][0]) for target in units)
        tests = [target for target in package['targets'] if target['kind'][0] == 'test']
        for start in range(0, len(tests), 4):
            batch = tests[start:start + 4]
            commands.append(base + sum((['--test', target['name']] for target in batch), []))
            coverage.extend((package['name'], target['name'], 'test') for target in batch)
    expected = [(package['name'], target['name'], target['kind'][0])
                for package in metadata['packages'] if package['id'] in members
                for target in package['targets']]
    need(len(coverage) == len(set(coverage)) and set(coverage) == set(expected),
         'metadata batch planner did not cover all workspace targets exactly once')
    return commands, expected

def workflow_bytes(product: str, ci, pins: dict[str, str]) -> bytes:
    rel = '.github/workflows/ci.yml'
    raw = ci.git_blob(product, rel)
    digest = sha(raw)
    need(digest == pins.get(rel) == sha_file(ROOT / rel),
         'workflow source differs from selected product Git/live source closure')
    return raw

def workflow_clippy_argv(product: str, ci, pins: dict[str, str]) -> list[str]:
    text = workflow_bytes(product, ci, pins).decode('utf-8')
    start = text.index('          cargo clippy')
    end = text.index('\n\n', start)
    return text[start:end].split()

def verify_capture_record(capture_dir: Path, product: str, run_id: str, ci):
    need(not capture_dir.is_symlink(), 'CI capture directory must not be a symlink')
    capture_dir = capture_dir.resolve(strict=True)
    path = capture_dir / 'capture-execution-root-v2.json'
    need(not path.is_symlink(), 'CI capture receipt must not be a symlink')
    raw = path.read_bytes()
    doc = json.loads(raw)
    need(doc.get('schema') == 'recover-proved-conditional-switch-fallthrough-ci-capture-root-v2' and
         doc.get('status') == 'captured', 'CI capture receipt is incomplete or has an unexpected schema')
    need(doc.get('product_commit') == product and doc.get('run_id') == int(run_id),
         'captured CI evidence belongs to a different product commit or run')
    collector = doc.get('collector', {})
    collector_path = Path(collector.get('path', ''))
    need(collector_path.resolve() == CAPTURE_COLLECTOR_PATH.resolve() and
         collector_path.is_file() and sha_file(collector_path) == CAPTURE_COLLECTOR_SHA256 == collector.get('sha256') and
         sha(ci.git_blob(product, str(collector_path.relative_to(ROOT)))) == CAPTURE_COLLECTOR_SHA256,
         'CI capture collector does not match its live/product source pin')
    summary = doc.get('validated_run_summary', {})
    need(summary.get('headSha') == product and summary.get('status') == 'completed' and
         summary.get('conclusion') == 'success', 'CI summary head/status/conclusion mismatch')
    run_match = re.search(r'/actions/runs/(\d+)(?:$|[/?#])', summary.get('url', ''))
    need(run_match and int(run_match.group(1)) == int(run_id), 'CI summary URL does not identify the requested run')
    jobs = summary.get('jobs', [])
    need(len(jobs) == len(EXPECTED_JOBS) and {job.get('name') for job in jobs} == EXPECTED_JOBS,
         'CI job inventory does not include stable, MSRV, supply-chain and fuzz jobs exactly once')
    need(all(job.get('status') == 'completed' and job.get('conclusion') == 'success' and
             job.get('steps') and all(step.get('status') == 'completed' and step.get('conclusion') == 'success'
                                      for step in job['steps']) for job in jobs),
         'a CI job or step is failed, skipped, or incomplete')
    step_count = sum(len(job['steps']) for job in jobs)
    need(step_count == 52 and doc.get('jobs') == len(jobs) and doc.get('steps') == step_count,
         'CI capture job/step totals differ from the complete run summary')
    commands = doc.get('commands', [])
    need(len(commands) == 3, 'CI capture must bind summary, stable-job log, and supply-chain log commands')
    ids = {job['name']: str(job['databaseId']) for job in jobs}
    expected_argv = [
        ['gh', 'run', 'view', str(run_id), '--json', 'headSha,status,conclusion,jobs,url'],
        ['gh', 'run', 'view', str(run_id), '--job', ids['stable / test and specification'], '--log'],
        ['gh', 'run', 'view', str(run_id), '--job', ids['supply chain'], '--log'],
    ]
    stable_raw = supply_raw = None
    for index, (row, argv) in enumerate(zip(commands, expected_argv)):
        need(row.get('argv') == argv and row.get('cwd') == str(ROOT) and row.get('exit_code') == 0 and
             not row.get('timed_out') and row.get('spawn_error') is None,
             f'CI capture command {index} argv/cwd/status mismatch')
        env = row.get('environment_override', {})
        need(set(env) == {'NO_PROXY', 'no_proxy'} and
             all(item.get('appended') == ['results-receiver.actions.githubusercontent.com',
                                          'productionresultssa1.blob.core.windows.net'] and
                 re.fullmatch(r'[0-9a-f]{64}', item.get('final_value_sha256', ''))
                 for item in env.values()), 'CI capture proxy record is malformed')
        stdout = verify_stream(row['stdout'], capture_dir)
        verify_stream(row['stderr'], capture_dir)
        if index == 0:
            need(json.loads(stdout) == summary, 'captured summary stdout differs from API summary')
        else:
            filename = 'ci-stable-job-v2.log.gz' if index == 1 else 'ci-supply-job-v2.log.gz'
            packed_path = capture_dir / filename
            need(not packed_path.is_symlink(), 'captured compressed CI log must not be a symlink')
            packed = packed_path.read_bytes()
            rec = row['stdout']
            need(len(packed) == rec.get('bytes') and sha(packed) == rec.get('sha256'),
                 'captured compressed CI log length/SHA mismatch')
            decoded = gzip.decompress(packed)
            need(len(decoded) == rec.get('uncompressed_bytes') and sha(decoded) == rec.get('raw_sha256') and
                 gzip.compress(decoded, mtime=0) == packed,
                 'captured compressed CI log does not reproduce canonical raw bytes')
            raw_ref = row.get('stdout_raw', {})
            raw_path = capture_dir / raw_ref.get('path', '')
            need(not raw_path.is_symlink() and raw_path.resolve().parent == capture_dir and raw_path.read_bytes() == decoded and
                 raw_ref.get('bytes') == len(decoded) and raw_ref.get('sha256') == sha(decoded),
                 'captured decompressed CI log differs from its pinned raw stream')
            if index == 1:
                stable_raw = decoded
            else:
                supply_raw = decoded
    return doc, summary, step_count, stable_raw, supply_raw, sha(path.read_bytes())

def bind_ci_name(raw_name: str, status: str, target: dict) -> str:
    if '***' not in raw_name:
        return raw_name
    pieces = raw_name.split('***')
    pattern = '^' + '[^\\n]*'.join(re.escape(part) for part in pieces) + '$'
    choices = [name for name, actual_status in target['outcomes']
               if actual_status == status and re.fullmatch(pattern, name)]
    need(len(choices) == 1,
         'masked CI test label does not bind to exactly one same-status local outcome: ' + repr(raw_name))
    return choices[0]

def parse_ci_workspace(group: str, seed: str, targets: list[dict], ci) -> dict:
    need(seed in group, 'CI workspace group does not contain its workflow seed')
    headers = []
    for line in group.splitlines():
        if 'Running ' in ci.clean(line):
            item = ci.parse_ci_header(line, targets)
            if item is not None:
                headers.append(item)
    blocks = ci.stdout_blocks_cargo_json(group.encode())
    need(len(headers) == len(targets) == len(blocks),
         'CI group does not report one header and JSON result block per local target')
    keys = [row['key'] for row in headers]
    need(len(keys) == len(set(keys)) and set(keys) == {row['key'] for row in targets},
         'CI target headers omit, duplicate, or introduce a workspace target')
    local = {row['key']: row for row in targets}
    observed = []
    redactions = []
    for header, block in zip(headers, blocks):
        expected = local[header['key']]
        bound = []
        for raw_name, status in block['outcomes']:
            name = bind_ci_name(raw_name, status, expected)
            bound.append((name, status))
            if name != raw_name:
                redactions.append({'target': list(expected['key']), 'raw_label': raw_name,
                                   'bound_name': name, 'status': status})
        need(len(set(name for name, _ in bound)) == len(bound),
             'CI label binding introduces duplicate test names')
        need(block['counts'] == expected['counts'] and tuple(bound) == tuple(expected['outcomes']),
             'CI named outcomes and counts differ from local target: ' + repr(expected['key']))
        observed.append({'key': list(expected['key']), 'counts': list(block['counts']),
                         'outcomes': [{'name': name, 'status': status} for name, status in bound]})
    totals = [sum(row['counts'][i] for row in observed) for i in range(3)]
    return {'seed': seed, 'target_count': len(observed), 'workspace_totals': totals,
            'target_observations': observed, 'masked_public_label_mappings': redactions}


def test_stream(stdout: bytes):
    text=re.sub(r'\x1b\[[0-9;]*m','',stdout.decode('utf-8',errors='replace'))
    summaries=[{'status':a,'passed':int(b),'failed':int(c),'ignored':int(d)}
               for a,b,c,d in re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)]
    names=[{'name':a,'status':b} for a,b in re.findall(r'^test (.+) \.\.\. (ok|ignored|FAILED)(?:, .*)?$',text,re.M)]
    return summaries,names

def verify_focus(focused_path: Path, focused_sha: str, candidate_cli: Path):
    raw=focused_path.read_bytes(); need(sha(raw)==focused_sha,'focused receipt SHA differs')
    focus=load_json(focused_path)
    need(focus.get('schema')==FOCUSED_SCHEMA and focus.get('status')=='passed_initial_product_validation',
         'focused receipt did not pass v7 validation')
    need(focus.get('expected_head')==focus.get('actual_head') and focus.get('head_matches_expected') is True,
         'focused receipt is not bound to its recorded source HEAD')
    need(focus.get('source_manifest_before')==focus.get('source_manifest_after'),'focused source closure changed')
    need(len(focus.get('commands',[]))==len(FOCUSED_COMMANDS),'focused receipt command count differs')
    summaries_by_label={}; names_by_label={}
    for index,(row,argv) in enumerate(zip(focus['commands'],FOCUSED_COMMANDS)):
        need(row.get('index')==index and row.get('argv')==argv and row.get('exit_code')==0 and row.get('guard_stop') is None,
             f'focused command {index} order/status differs')
        for ref in row.get('streams',{}).values():
            path=Path(ref.get('path','')); need(not path.is_symlink() and path.is_file(),'focused raw stream missing or linked')
            stream=path.read_bytes(); need(len(stream)==ref.get('bytes') and sha(stream)==ref.get('sha256'),'focused raw stream pin differs')
        if index in (2,3,4,5):
            stdout=Path(row['streams']['stdout']['path']).read_bytes(); summaries,names=test_stream(stdout)
            label=('structured_list_generic_bodies' if index==2 else 'jarde_java_lib' if index==3 else
                   'jarde_reader_census' if index==4 else 'p5_corpus_fingerprint')
            summaries_by_label[label]=(summaries,names); names_by_label[label]=names
    summaries,names=summaries_by_label['structured_list_generic_bodies']
    need(summaries==[{'status':'ok','passed':7,'failed':0,'ignored':1}] and
         {x['name']:x['status'] for x in names}==FOCUSED_API_EXPECTED and len(names)==8,
         'focused API raw output is not the exact 7-pass/1-ignored set')
    summaries,names=summaries_by_label['jarde_java_lib']
    tails=[x['name'].rsplit('::',1)[-1] for x in names]
    need(summaries==[{'status':'ok','passed':375,'failed':0,'ignored':0}] and len(names)==375 and
         all(tails.count(name)==1 and names[tails.index(name)]['status']=='ok' for name in EXPECTED_CENSUS_TESTS),
         'focused Java library raw output is not the exact 375-test suite with all four census tests')
    summaries,names=summaries_by_label['jarde_reader_census']
    need(summaries==[{'status':'ok','passed':1,'failed':0,'ignored':0}] and len(names)==1 and
         names[0]['name'].rsplit('::',1)[-1]=='repository_class_fixtures_validate_without_false_target_rejections' and names[0]['status']=='ok',
         'focused reader census raw output differs')
    summaries,names=summaries_by_label['p5_corpus_fingerprint']
    p5={'corpus_files_match_the_recorded_fingerprint':'ok','the_manifest_matches_its_rendered_classification':'ok',
        'every_dimension_is_carried_by_existing_corpus':'ok','every_acceptance_row_is_indexed_against_existing_corpus':'ok',
        'the_indexed_rows_are_the_rows_the_acceptance_table_names':'ok','regenerate_corpus_fingerprint':'ignored'}
    actual={x['name'].rsplit('::',1)[-1]:x['status'] for x in names}
    need(summaries==[{'status':'ok','passed':5,'failed':0,'ignored':1}] and len(names)==6 and actual==p5,
         'focused P5 raw output differs from the exact read-only set')
    freeze=focus.get('cli_freeze',{}); candidate_cli=candidate_cli.resolve(strict=True)
    need(candidate_cli==CANDIDATE_CLI_PATH and not candidate_cli.is_symlink() and
         candidate_cli.stat().st_mode & 0o777==0o555 and freeze.get('path')==str(candidate_cli) and
         isinstance(freeze.get('sha256'),str) and len(freeze['sha256'])==64 and freeze.get('sha256')==sha_file(candidate_cli) and
         freeze.get('mode')=='0o555' and freeze.get('bytes')==candidate_cli.stat().st_size,
         'focused frozen CLI is not the exact root-v4 candidate executable')
    need(focus.get('cleanup',{}).get('status')=='passed' and focus.get('cleanup',{}).get('target_absent') is True,
         'focused finally-clean postcondition failed')
    return focus, {'sha256':focused_sha,'path':str(focused_path),'cli':freeze}

def required_tests_from_runner(path: Path):
    tree=ast.parse(path.read_text(encoding='utf-8'),filename=str(path))
    focused=None; final_expr=None
    for node in tree.body:
        if not isinstance(node,ast.Assign): continue
        names={target.id for target in node.targets if isinstance(target,ast.Name)}
        if 'FOCUSED_EXPECTED_OUTCOMES' in names:
            focused=ast.literal_eval(node.value)
        if 'REQUIRED_NAMED_TESTS' in names:
            final_expr=node.value
    need(isinstance(focused,dict) and final_expr is not None,
         'workspace runner lacks its focused outcome map or final named-test expression')
    need(isinstance(final_expr,ast.BinOp) and isinstance(final_expr.op,ast.BitOr) and
         isinstance(final_expr.left,ast.SetComp) and len(final_expr.left.generators)==1,
         'workspace runner required-name expression has an unexpected shape')
    comp=final_expr.left; gen=comp.generators[0]
    need(isinstance(comp.elt,ast.Name) and comp.elt.id=='name' and
         isinstance(gen.target,ast.Tuple) and [x.id for x in gen.target.elts if isinstance(x,ast.Name)]==['name','state'] and
         isinstance(gen.iter,ast.Call) and isinstance(gen.iter.func,ast.Attribute) and gen.iter.func.attr=='items' and
         isinstance(gen.iter.func.value,ast.Name) and gen.iter.func.value.id=='FOCUSED_EXPECTED_OUTCOMES' and
         len(gen.ifs)==1 and isinstance(gen.ifs[0],ast.Compare) and isinstance(gen.ifs[0].left,ast.Name) and
         gen.ifs[0].left.id=='state' and len(gen.ifs[0].ops)==1 and isinstance(gen.ifs[0].ops[0],ast.Eq) and
         len(gen.ifs[0].comparators)==1 and isinstance(gen.ifs[0].comparators[0],ast.Constant) and
         gen.ifs[0].comparators[0].value=='ok',
         'workspace runner focused required-name comprehension differs')
    literal=ast.literal_eval(final_expr.right)
    need(isinstance(literal,(set,list,tuple)) and all(isinstance(x,str) for x in literal),
         'workspace runner required named tests are not a literal name set')
    value={name for name,state in focused.items() if state=='ok'} | set(literal)
    need(value and len(value)==len(set(value)) and all(isinstance(x,str) for x in value),
         'workspace runner final required names are not a unique string set')
    return value

def verify_workspace(workspace: Path, workspace_sha: str, acceptance_path: Path, acceptance_sha: str,
                     focused: dict, runner_path: Path, ci):
    workspace=workspace.resolve(strict=True); ex_path=workspace/'execution.json'; meta_path=workspace/'metadata.json'
    ex_raw=ex_path.read_bytes(); need(sha(ex_raw)==workspace_sha,'workspace receipt SHA differs'); ex=json.loads(ex_raw)
    need(ex.get('schema')==WORKSPACE_SCHEMA and ex.get('status')=='passed' and ex.get('no_carried_execution') is True,
         'fresh CF11 full-workspace receipt is not complete/passing')
    need(ex.get('rust_min_stack') is None and ex.get('guard_limits')=={'minimum_free_bytes':FREE_LIMIT,'maximum_target_bytes':TARGET_LIMIT,'poll_interval_seconds':1},
         'workspace guard/default stack contract differs')
    need(ex.get('seeds')==list(SEEDS),'workspace seeds differ from current workflow contract')
    need(ex.get('source_pins_before')==ex.get('source_pins_after') and isinstance(ex.get('source_pins_before'),dict),
         'workspace source closure changed or is missing')
    runner=load_workspace_runner(runner_path)
    paths=runner.source_paths(); live=runner.pin_sources(paths)
    need(len(live)==EXPECTED_SOURCE_CLOSURE_COUNT,'live dynamic source closure count differs from the frozen CF11 scope')
    need(live==ex['source_pins_before'],'workspace receipt does not match complete live 4822-input dynamic source closure')
    focus_pins={row.get('path'):row.get('sha256') for row in focused.get('source_manifest_before',[]) if isinstance(row,dict)}
    need(len(focus_pins)==len(focused.get('source_manifest_before',[])) and focus_pins==live,
         'focused source manifest differs from the full dynamic live source closure')
    need(ex.get('source_closure_count_at_start')==len(live),'workspace closure count differs from dynamically enumerated inputs')
    need(ex.get('focused_input_receipt')=={'path':str(Path(focused['_path']).resolve()),'sha256':focused['_sha'],
                                           'schema':focused['schema'],'status':focused['status']},
         'workspace receipt is not bound to the selected focused receipt')
    freeze=focused.get('cli_freeze',{})
    need(ex.get('candidate_cli')=={k:freeze.get(k) for k in ('path','bytes','sha256','mode')},
         'workspace CLI differs from focused CLI freeze')
    acceptance_path=acceptance_path.resolve(strict=True); acceptance_raw=acceptance_path.read_bytes()
    need(sha(acceptance_raw)==acceptance_sha,'workspace acceptance SHA differs'); accepted=json.loads(acceptance_raw)
    need(accepted.get('schema')==WORKSPACE_ACCEPTANCE_SCHEMA and accepted.get('status')=='accepted_local_workspace_only' and
         accepted.get('not_ci_or_product_release_acceptance') is True and accepted.get('execution_sha256')==workspace_sha and
         accepted.get('focused_receipt_sha256')==focused['_sha'] and accepted.get('source_pin_count')==len(live) and
         accepted.get('target_absent') is True and accepted.get('target_count')==ex.get('expected_target_count') and
         accepted.get('batch_count_per_seed')==ex.get('expected_batch_count') and accepted.get('seeds')==list(SEEDS),
         'workspace acceptance is not bound to this fresh receipt/closure')
    metadata_raw=meta_path.read_bytes(); metadata=json.loads(metadata_raw)
    commands=ex.get('commands',[]); planned,inventory=expected_workspace_commands(metadata); batches=len(planned)
    by_id,by_named,metadata_inventory=ci.metadata_targets(metadata)
    need(len(inventory)==len(metadata_inventory) and set(inventory)==set(metadata_inventory) and
         len(metadata_inventory)==ex.get('expected_target_count')==ex.get('metadata',{}).get('target_count') and
         ex.get('metadata',{}).get('batch_count')==batches and
         [tuple(x) for x in ex.get('target_inventory',[])]==metadata_inventory and
         len(ex.get('static_manifest_target_inventory',[]))==len(metadata_inventory) and
         set(tuple(x) for x in ex.get('static_manifest_target_inventory',[]))==set(metadata_inventory),
         'dynamic Cargo metadata target inventory differs from the full-workspace receipt')
    need(ex.get('expected_command_count_including_clean')==2+2*batches+1 and len(commands)==2+2*batches+1,
         'workspace command count does not match two metadata-derived full target sweeps')
    need(commands[0].get('argv')==['cargo','fmt','--all','--','--check'] and
         commands[1].get('argv')==['cargo','metadata','--no-deps','--format-version','1','--locked'],
         'workspace fmt/metadata preflight command order differs')
    need(verify_stream(commands[1]['streams']['stdout'],workspace)==metadata_raw,
         'saved metadata differs from exact raw cargo metadata stdout')
    observations={seed:[] for seed in SEEDS}; seen={seed:set() for seed in SEEDS}
    all_raw=set(); base_env={**BASE_ENV,'PROPTEST_RNG_SEED':SEEDS[0],'CARGO_PROFILE_TEST_STRIP':'symbols'}
    check_command(commands[0],0,['cargo','fmt','--all','--','--check'],base_env,workspace)
    check_command(commands[1],1,['cargo','metadata','--no-deps','--format-version','1','--locked'],base_env,workspace)
    need(ex.get('format_check')=={'exit_code':0,'guard_stop':None},'workspace format check did not pass')
    for index,row in enumerate(commands[:-1]):
        for ref in row.get('streams',{}).values(): all_raw.add(Path(ref['path']).resolve())
        if index<2: continue
        seed=row.get('proptest_seed'); need(seed in SEEDS,'workspace test command has an unknown seed')
        offset=index-2; expected_seed=SEEDS[offset//batches]; batch=offset%batches
        need(seed==expected_seed and row.get('argv')==planned[batch],
             f'workspace batch {index} is not in metadata-derived seed/batch order')
        env={**BASE_ENV,'PROPTEST_RNG_SEED':seed,'CARGO_PROFILE_TEST_STRIP':'symbols'}
        check_command(row,index,planned[batch],env,workspace)
        obs=ci.local_command_observation(row,by_id,by_named); ci.check_workspace_argv(row.get('argv',[]),obs,by_named)
        for suite in obs:
            suite['outcomes']=[(name,'ignored' if state.startswith('ignored') else state) for name,state in suite['outcomes']]
        need(len(obs)==len(row.get('executed_targets',[]))==len(row.get('observed_summaries',[])),
             f'workspace batch {index} executed target/result record counts differ')
        actual_names=[(name,state) for item in obs for name,state in item['outcomes']]
        stored_names=[(item.get('name'),item.get('status')) for item in row.get('named_test_outcomes',[])]
        need(actual_names==stored_names and row.get('named_test_outcome_count')==len(actual_names),
             f'workspace batch {index} named outcomes differ from exact raw stdout')
        actual_summaries=[('ok' if item['counts'][1]==0 else 'FAILED',*item['counts']) for item in obs]
        stored_summaries=[(item.get('status'),item.get('passed'),item.get('failed'),item.get('ignored')) for item in row.get('observed_summaries',[])]
        need(actual_summaries==stored_summaries,f'workspace batch {index} summary rows differ from raw output')
        for item in obs:
            key=item['key']; need(key not in seen[seed],'workspace target executed twice in one seed')
            seen[seed].add(key); observations[seed].append(item)
    totals_by_seed={}
    for seed in SEEDS:
        need(seen[seed]==set(metadata_inventory),'workspace target inventory is incomplete for '+seed)
        need(len(observations[seed])==len(inventory),'workspace observation count differs from metadata for '+seed)
        totals_by_seed[seed]=[sum(item['counts'][i] for item in observations[seed]) for i in range(3)]
    aggregate_totals=[sum(totals_by_seed[seed][i] for seed in SEEDS) for i in range(3)]
    aggregate_summary_count=sum(len(observations[seed]) for seed in SEEDS)
    need(ex.get('workspace_totals')==aggregate_totals and
         ex.get('workspace_summary_count')==aggregate_summary_count,
         'workspace aggregate totals differ from independently parsed raw target summaries')
    expected_acceptance_totals={'passed':aggregate_totals[0],'failed':aggregate_totals[1],
        'ignored':aggregate_totals[2],'target_summary_count':aggregate_summary_count,
        'named_test_outcome_count':sum(len(item['outcomes']) for seed in SEEDS for item in observations[seed])}
    need(accepted.get('test_totals')==expected_acceptance_totals,
         'workspace acceptance totals differ from independently parsed raw target observations')
    clean_index=len(commands)-1; clean=commands[clean_index]
    clean_env={**BASE_ENV,'PROPTEST_RNG_SEED':SEEDS[-1],'CARGO_PROFILE_TEST_STRIP':'symbols'}
    check_command(clean,clean_index,['cargo','clean'],clean_env,workspace,cleanup_only=True)
    for ref in clean.get('streams',{}).values(): all_raw.add(Path(ref['path']).resolve())
    raw_files={path.resolve() for path in workspace.glob('*.raw') if path.is_file()}
    need(raw_files==all_raw and len(all_raw)==len(commands)*2,'workspace raw stream inventory is incomplete or has unreferenced files')
    cleanup=ex.get('cleanup',{})
    need(cleanup.get('status')=='passed' and cleanup.get('target_absent_after') is True and cleanup.get('pins_unchanged') is True and
         cleanup.get('command')==clean and not (ROOT/'target').exists(),'workspace finally-clean did not preserve inputs and remove target')
    required=required_tests_from_runner(runner_path)
    required_outcomes={}
    for seed in SEEDS:
        matches=[]
        for name in sorted(required):
            found=[(target,item_state) for target in observations[seed] for item_name,item_state in target['outcomes']
                   if item_name==name or item_name.endswith('::'+name)]
            need(len(found)==1 and found[0][1]=='ok',f'required local named test did not pass exactly once for {seed}: {name}')
            matches.append(name)
        required_outcomes[seed]=matches
    ci_result=accepted.get('matched_focused_gates_per_seed',{})
    need(set(ci_result)==set(SEEDS) and all(ci_result[s]=={'structured_list_generic_bodies':'7 passed / 1 ignored',
         'jarde_java_lib':'375 passed','reader_census':'passed once','p5_corpus_fingerprint':'5 passed / 1 ignored'} for s in SEEDS),
         'workspace acceptance omits one exact focused gate for either seed')
    local_info={'execution':str(ex_path),'execution_sha256':workspace_sha,'metadata':str(meta_path),
                'metadata_sha256':sha(metadata_raw),'seed_target_counts':{s:len(observations[s]) for s in SEEDS},
                'target_count':len(inventory),'batch_count_per_seed':batches,'source_pin_count':len(live),
                'source_closure_count_at_start':len(live),'workspace_acceptance':str(acceptance_path),
                'workspace_acceptance_sha256':acceptance_sha,'workspace_totals_by_seed':totals_by_seed,
                'workspace_totals':aggregate_totals,'workspace_summary_count':aggregate_summary_count}
    return ex,metadata,observations,live,local_info,required_outcomes

def verify_final(product: str, final_path: Path, final_sha: str, final_acceptance_path: Path, final_acceptance_sha: str,
                 focused: dict, focused_info: dict, workspace: dict, workspace_info: dict, pins: dict[str,str],
                 final_runner: Path, ci):
    final_path=final_path.resolve(strict=True); raw=final_path.read_bytes(); need(sha(raw)==final_sha,'final receipt SHA differs')
    build=json.loads(raw)
    need(build.get('schema')==FINAL_SCHEMA and build.get('status')=='passed_final_validation' and
         build.get('final_lint_strict_byte_identity_passed') is True and build.get('candidate_byte_identity') is True,
         'final CF11 fmt/clippy/strict/build receipt did not pass')
    need(build.get('source_pins_before')==pins==build.get('source_pins_after') and
         build.get('source_pin_count')==len(pins),'final receipt source closure differs from the complete live/product closure')
    need(build.get('target_absent') is True and not (ROOT/'target').exists() and
         build.get('cleanup',{}).get('status')=='passed' and build.get('cleanup',{}).get('target_absent_after') is True,
         'final receipt finally-clean postcondition failed')
    need(build.get('focused_receipt')=={'path':focused_info['path'],'sha256':focused_info['sha256'],
         'schema':focused['schema'],'status':focused['status']},'final receipt focused input binding differs')
    need(build.get('workspace_receipt')=={'path':workspace_info['execution'],'sha256':workspace_info['execution_sha256'],
         'schema':workspace['schema'],'status':workspace['status']},'final receipt workspace input binding differs')
    acceptance_path=Path(workspace_info['workspace_acceptance'])
    need(build.get('workspace_acceptance')=={'path':str(acceptance_path),'sha256':workspace_info['workspace_acceptance_sha256'],
         'schema':WORKSPACE_ACCEPTANCE_SCHEMA,'status':'accepted_local_workspace_only'},'final receipt local acceptance binding differs')
    focus_cli=focused.get('cli_freeze',{}); final_cli=build.get('candidate_cli',{})
    need(build.get('focused_build_candidate_cli')=={'path':focus_cli['path'],'bytes':focus_cli['bytes'],
         'sha256':focus_cli['sha256'],'mode':focus_cli['mode']},
         'final receipt focused-build CLI input binding is inconsistent')
    candidate_path=Path(focus_cli.get('path','')).resolve(strict=True)
    need(candidate_path==CANDIDATE_CLI_PATH and final_cli.get('path')==str(candidate_path) and
         final_cli.get('sha256')==focus_cli.get('sha256')==sha_file(candidate_path) and
         final_cli.get('bytes')==focus_cli.get('bytes') and final_cli.get('mode')=='0o555' and
         candidate_path.read_bytes() and stat.S_IMODE(candidate_path.stat().st_mode)==0o555,
         'final CLI differs from the focused root-v4 frozen executable')
    need(final_runner.is_file() and sha_file(final_runner)==FINAL_BUILD_RUNNER_SHA256 and
         build.get('runner',{}).get('path')==str(final_runner) and
         build.get('runner',{}).get('sha256_before')==FINAL_BUILD_RUNNER_SHA256==build.get('runner',{}).get('sha256_after'),
         'final build runner changed or is not the pinned CF11 runner')
    need(build.get('rust_min_stack') is None and build.get('environment_overrides')==FINAL_ENV and
         build.get('guard_limits')=={'minimum_free_bytes':FREE_LIMIT,'maximum_target_bytes':TARGET_LIMIT,'poll_interval_seconds':1} and
         build.get('fresh_target_preflight',{}).get('target_absent') is True and build.get('fresh_target_preflight',{}).get('free_bytes',0)>=FREE_LIMIT,
         'final guard/default-stack/fresh-target contract differs')
    need(sha_file(CI_HELPER_PATH)==CI_HELPER_SHA256 and sha_file(CAPTURE_COLLECTOR_PATH)==CAPTURE_COLLECTOR_SHA256,
         'CI helper/collector changed during final verification')
    expected_argvs=[['cargo','fmt','--all','--','--check'],workflow_clippy_argv(product,ci,pins),
      ['openspec','validate','--all','--strict','--no-interactive'],
      ['cargo','build','-p','jarde-cli','--bin','jarde-cli','--locked'],['cargo','clean']]
    commands=build.get('commands',[]); need(len(commands)==len(expected_argvs),'final receipt command inventory differs')
    final_dir=final_path.parent
    for index,(row,argv) in enumerate(zip(commands,expected_argvs)):
        check_command(row,index,argv,FINAL_ENV,final_dir,cleanup_only=(index==len(commands)-1))
    raw_streams={Path(ref['path']).resolve() for row in commands for ref in row.get('streams',{}).values()}
    raw_files={p.resolve() for p in final_dir.glob('*.raw') if p.is_file()}
    need(raw_streams==raw_files and len(raw_streams)==10,'final-build raw stream inventory differs')
    refs={x.get('path'):x.get('sha256') for x in build.get('references',[])}
    expected_refs={str(WORKSPACE_RUNNER_PATH):WORKSPACE_RUNNER_SHA256,
                   str(WORKSPACE_ACCEPTOR_PATH):WORKSPACE_ACCEPTOR_SHA256,
                   str(ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'):'51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33',
                   str(ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py'):'d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7'}
    need(refs==expected_refs and len(build.get('references',[]))==len(expected_refs),
         'final receipt references differ from pinned workspace/acceptor/guard/scanner')
    acc_path=final_acceptance_path.resolve(strict=True); acc_raw=acc_path.read_bytes()
    need(sha(acc_raw)==final_acceptance_sha,'final acceptance SHA differs'); acc=json.loads(acc_raw)
    need(acc.get('schema')==FINAL_ACCEPTANCE_SCHEMA and acc.get('status')=='accepted_local_final_validation_only' and
         acc.get('focused_receipt_sha256')==focused_info['sha256'] and
         acc.get('workspace_receipt_sha256')==workspace_info['execution_sha256'] and
         acc.get('source_pin_count')==len(pins) and acc.get('workspace_target_count')==workspace_info['target_count'] and
         acc.get('candidate_cli_byte_identical') is True and acc.get('target_absent') is True,
         'independent final acceptor output does not bind this focused/workspace/final closure')
    return {'record':str(final_path),'record_sha256':final_sha,'acceptance':str(acc_path),
            'acceptance_sha256':final_acceptance_sha,'commands':len(commands),'target_absent':True,
            'candidate_cli_sha256':focus_cli.get('sha256')}

def verify_product_ci(capture_dir: Path, product: str, run_id: str, observations_by_seed: dict,
                      product_pins: dict[str,str], ci):
    capture,summary,steps,stable_raw,supply_raw,capture_sha=verify_capture_record(capture_dir,product,run_id,ci)
    workflow=workflow_bytes(product,ci,product_pins).decode('utf-8'); seeds=ci.CI_SEEDS_RE.findall(workflow)
    need(tuple(seeds)==SEEDS and workflow.count('run: '+ci.WORKSPACE_CMD)==2,
         'selected product workflow does not preserve the two exact current CF11 seed runs')
    lines=ci.strip_log(stable_raw).splitlines(); groups=ci.command_groups(lines,ci.WORKSPACE_CMD)
    need(len(groups)==2,'stable job log does not contain both complete workspace runs')
    seed_runs=[]; unused=list(groups)
    for seed in seeds:
        targets=observations_by_seed[seed]
        matches=[group for group in unused if seed in group]
        need(len(matches)==1,'cannot uniquely bind one CI workspace group to seed '+seed)
        group=matches[0]; unused.remove(group)
        result=parse_ci_workspace(group,seed,targets,ci)
        expected_totals=[sum(row['counts'][i] for row in targets) for i in range(3)]
        need(result['workspace_totals']==expected_totals and result['target_count']==len(targets),
             'CI seed target outcomes differ from the matching fresh local seed')
        seed_runs.append(result)
    need(not unused and seed_runs[0]['target_observations']==seed_runs[1]['target_observations'],
         'CI seed groups are unbound or their full target observations differ')
    need(supply_raw is not None and len(supply_raw)>0,'supply-chain job raw log is absent')
    return {'capture_sha256':capture_sha,'summary':summary,'jobs':len(summary['jobs']),'steps':steps,
            'seed_runs':seed_runs,'matched_local_seed_targets':{s:len(observations_by_seed[s]) for s in SEEDS}}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    for flag in ('product-commit','run-id','capture','capture-receipt-sha256','focused-receipt',
                 'focused-receipt-sha256','candidate-cli','workspace','workspace-receipt-sha256',
                 'workspace-acceptance','workspace-acceptance-sha256','final-receipt','final-receipt-sha256',
                 'final-acceptance','final-acceptance-sha256','out'):
        ap.add_argument('--'+flag,type=Path if flag in ('capture','focused-receipt','candidate-cli','workspace',
                    'workspace-acceptance','final-receipt','final-acceptance','out') else str,required=True)
    ap.add_argument('--workspace-runner',type=Path,default=WORKSPACE_RUNNER_PATH)
    ap.add_argument('--final-runner',type=Path,default=FINAL_BUILD_RUNNER_PATH)
    args=ap.parse_args()
    need(re.fullmatch(r'[0-9a-f]{40}',args.product_commit) is not None and args.run_id.isdecimal(),
         'product commit or run ID format is invalid')
    for value in (args.capture_receipt_sha256,args.focused_receipt_sha256,args.workspace_receipt_sha256,
                  args.workspace_acceptance_sha256,args.final_receipt_sha256,args.final_acceptance_sha256):
        need(re.fullmatch(r'[0-9a-f]{64}',value) is not None,'receipt SHA must be lowercase 64-hex')
    paths=[args.capture,args.focused_receipt,args.candidate_cli,args.workspace,args.workspace_acceptance,
           args.final_receipt,args.final_acceptance,args.workspace_runner,args.final_runner]
    need(all(not path.is_symlink() for path in paths),'receipt, runner, capture and CLI inputs must not be symlinks')
    out=args.out.resolve(); need(not out.exists() and not out.is_relative_to(ROOT),'refusing overwrite or workspace-local acceptance output')
    ci=load_ci_helper(); runner=load_workspace_runner(args.workspace_runner.resolve(strict=True))
    need(args.final_runner.resolve(strict=True)==FINAL_BUILD_RUNNER_PATH and
         sha_file(args.final_runner)==FINAL_BUILD_RUNNER_SHA256,'final build runner path/SHA differs')
    focused_path=args.focused_receipt.resolve(strict=True)
    focused,focused_info=verify_focus(focused_path,args.focused_receipt_sha256,args.candidate_cli)
    focused['_path']=str(focused_path); focused['_sha']=args.focused_receipt_sha256
    ex,metadata,local_by_seed,pins,local_info,required=verify_workspace(
        args.workspace,args.workspace_receipt_sha256,args.workspace_acceptance,args.workspace_acceptance_sha256,
        focused,args.workspace_runner,ci)
    # Every live closure byte must be present at the exact selected product commit; no historical CI HEAD is used.
    product_blobs=ci.blob_sha256s(args.product_commit,pins)
    need(product_blobs==pins,'selected product HEAD does not contain every byte in the current 4822-input source closure')
    need('.github/workflows/ci.yml' in pins and ci.blob_sha256s(args.product_commit,{'.github/workflows/ci.yml':pins['.github/workflows/ci.yml']})=={'.github/workflows/ci.yml':pins['.github/workflows/ci.yml']},
         'current workflow is not the exact selected product/live source')
    final=verify_final(args.product_commit,args.final_receipt,args.final_receipt_sha256,
        args.final_acceptance,args.final_acceptance_sha256,focused,focused_info,ex,local_info,pins,
        args.final_runner.resolve(strict=True),ci)
    ci_result=verify_product_ci(args.capture.resolve(strict=True),args.product_commit,args.run_id,local_by_seed,pins,ci)
    refs={
        'ci_parser':{'path':str(CI_HELPER_PATH),'sha256':CI_HELPER_SHA256},
        'capture_collector':{'path':str(CAPTURE_COLLECTOR_PATH),'sha256':CAPTURE_COLLECTOR_SHA256},
        'workspace_runner':{'path':str(args.workspace_runner.resolve()),'sha256':WORKSPACE_RUNNER_SHA256},
        'workspace_acceptor':{'path':str(WORKSPACE_ACCEPTOR_PATH),'sha256':WORKSPACE_ACCEPTOR_SHA256},
        'final_runner':{'path':str(args.final_runner.resolve()),'sha256':FINAL_BUILD_RUNNER_SHA256},
        'final_acceptor':{'path':str(FINAL_ACCEPTOR_PATH),'sha256':FINAL_ACCEPTOR_SHA256},
    }
    private_refs=((WORKSPACE_RUNNER_PATH,WORKSPACE_RUNNER_SHA256),
                  (WORKSPACE_ACCEPTOR_PATH,WORKSPACE_ACCEPTOR_SHA256),
                  (FINAL_BUILD_RUNNER_PATH,FINAL_BUILD_RUNNER_SHA256),
                  (FINAL_ACCEPTOR_PATH,FINAL_ACCEPTOR_SHA256),
                  (FOCUSED_RUNNER_PATH,FOCUSED_RUNNER_SHA256))
    for path,want in private_refs:
        need(path.is_file() and not path.resolve().is_relative_to(ROOT) and sha_file(path)==want,
             'pinned private verifier dependency changed or crossed into the product tree: '+str(path))
    for path,want in ((CI_HELPER_PATH,CI_HELPER_SHA256),(CAPTURE_COLLECTOR_PATH,CAPTURE_COLLECTOR_SHA256)):
        need(path.is_file() and path.resolve().is_relative_to(ROOT) and sha_file(path)==want,
             'pinned repository CI source changed or left the product tree: '+str(path))
        rel=path.resolve().relative_to(ROOT).as_posix()
        need(sha(ci.git_blob(args.product_commit,rel))==want,'pinned CI source is absent from product HEAD: '+rel)
    result={'schema':'cf11-structured-list-own-ci-acceptance-v3',
       'status':'accepted_local_own_ci_observation','product_commit':args.product_commit,'run_id':int(args.run_id),
       'ci':{'capture_sha256':ci_result['capture_sha256'],'jobs':ci_result['jobs'],'steps':ci_result['steps'],
             'seed_runs':ci_result['seed_runs'],'all_jobs_and_steps_succeeded':True},
       'fresh_local_workspace':local_info,'required_named_tests_per_seed':required,
       'final_local_validation':final,'source_closure':{'count':len(pins),'complete_dynamic_pins_match_focused_workspace_final_and_product_git':True},
       'references':refs,'acceptance_scope':'Exact selected product commit and actual CI run; both product CI seed runs compared target-by-target, with named outcomes/counts matched against the corresponding fresh local seed raw streams. Full dynamic workspace closure, metadata target inventory, focused gates, final build and all raw streams independently checked.'}
    out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('x',encoding='utf-8') as stream: stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'product_commit':args.product_commit,'run_id':int(args.run_id),
                      'jobs':ci_result['jobs'],'steps':ci_result['steps'],'target_count':local_info['target_count'],
                      'batch_count_per_seed':local_info['batch_count_per_seed'],'source_closure_count':len(pins),
                      'workspace_totals_by_seed':local_info['workspace_totals_by_seed']},ensure_ascii=False))
    return 0

if __name__=='__main__':
    try: raise SystemExit(main())
    except Exception as exc:
        print('CF11 own-CI verification failed: '+str(exc),file=sys.stderr)
        raise SystemExit(1)
