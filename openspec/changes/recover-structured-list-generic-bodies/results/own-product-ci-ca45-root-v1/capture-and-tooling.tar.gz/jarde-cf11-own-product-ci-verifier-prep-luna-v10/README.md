# Own-CI verifier v10 private preparation

Status: `prepared_not_executed`. This package freezes v8 and v9 and contains v10. No verifier rerun or passing receipt was produced.

The root reported that the actual v9 run at `/private/tmp/jarde-cf11-own-product-ci-acceptance-root-v3` failed on `d5_process_release`. The two-seed mismatch analysis is saved at `/private/tmp/jarde-cf11-own-ci-v9-mismatch-root-v1.json` (SHA-256 `9a95db6597bd7920a193bd50c6c57e6e9229f5b0d2dc8bace951b57cb8fb323f`): 138 target mismatches (69 targets per seed), with 194 CI raw ignored-reason rows. Counts and the ordered names/statuses match after normalizing CI reasons; CI renders statuses as `ignored, <reason>`, while local workspace verification normalizes them to `ignored`.

v10 preserves v9's tuple fix. In `parse_ci_workspace`, it keeps `raw_status`, and normalizes only `raw_status == 'ignored'` or `raw_status.startswith('ignored, ')` to `ignored` before label binding and exact outcome comparison. `FAILED` and unknown values remain unchanged. Each raw reason is recorded in `raw_ignored_reason_observations` with target, raw label, bound name, raw status, and normalized status; normalized target outcomes remain the comparison surface across the two CI seeds. Redaction mappings retain the existing normalized status. Counts, target selection, outcome counts, name binding, filters, and acceptance criteria remain unchanged.

The v8-to-v9 diff records the earlier tuple fix. The v9-to-v10 diff contains only the status normalization and raw-reason evidence field. Static Python AST parsing passed. No verifier, Git, Cargo, product CLI, JDK, or JADX command was run.

Artifacts:

- Frozen v8: `/private/tmp/jarde-cf11-own-product-ci-verifier-prep-luna-v10/verify-own-ci-v8-frozen.py` SHA-256 `27af3f0f7d8534223392fb50bd72318fd462e80b6526994d458d02354bf2e17e`.
- Frozen v9: `/private/tmp/jarde-cf11-own-product-ci-verifier-prep-luna-v10/verify-own-ci-v9-frozen.py` SHA-256 `fd890eae020f07f6e5033588b375490b5d2e561b66afd08fab2d1699b1d8093b`.
- Prepared v10: `/private/tmp/jarde-cf11-own-product-ci-verifier-prep-luna-v10/verify-own-ci.py` SHA-256 `02d3241c9f9ca26b4fe68d8b8ce7415dee0772cad649feb028fbe68c3a5389c4`.
- v8-to-v9 diff: `/private/tmp/jarde-cf11-own-product-ci-verifier-prep-luna-v10/verify-own-ci-v8-to-v9.diff` SHA-256 `ee12849a0b6b943530a485f7fd27dfeffe04484082f937b2f31e051cc97188fa`.
- v9-to-v10 diff: `/private/tmp/jarde-cf11-own-product-ci-verifier-prep-luna-v10/verify-own-ci-v9-to-v10.diff` SHA-256 `a921bf50d757f37beacd6464074f6fb67e79443ec98e07a536fa7af1978514a9`.

Root should inspect and execute v10 against the actual inputs. The prior failed v9 run and this preparation do not count as acceptance.
