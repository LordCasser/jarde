# Own-CI verifier v9 private preparation

Status: `prepared_not_executed`. This package contains a frozen v8 verifier and exactly one source change in v9. No verifier rerun or passing receipt was produced. The root reported that an actual v8 run was rejected at the first target `('jarde','jarde','lib')`: both CI and local observations had counts `(224, 0, 0)` and all 224 name/status outcomes in identical order, but the comparison still failed.

The failure is a container-type mismatch. In `parse_ci_workspace`, `bound` is accumulated as a list of `(name, status)` tuples, then converted to a tuple. `expected['outcomes']` comes from `verify_workspace` normalization and remains a list of tuples. v9 changes only the comparison to `tuple(bound) == tuple(expected['outcomes'])`. It does not alter test-name binding, counts, target selection, filtering, or acceptance conditions.

I reviewed the other comparisons in `parse_ci_workspace`: `block['counts'] == expected['counts']` compares the same parsed count representation (root observed tuples on both sides); target key and duplicate checks intentionally compare sets; the appended output explicitly converts counts and outcomes to JSON lists/dicts. No parallel container mismatch is present in this function. Other occurrences elsewhere normalize explicitly where containers differ (for example, inventory rows use `[tuple(x) ...]`, and stored outcome maps compare list comprehensions).

Files and pins:

- Frozen v8: `/private/tmp/jarde-cf11-own-product-ci-verifier-prep-luna-v9/verify-own-ci-v8-frozen.py` (SHA-256 `27af3f0f7d8534223392fb50bd72318fd462e80b6526994d458d02354bf2e17e`; expected original v8 SHA `27af3f0f7d8534223392fb50bd72318fd462e80b6526994d458d02354bf2e17e`).
- v9 verifier: `/private/tmp/jarde-cf11-own-product-ci-verifier-prep-luna-v9/verify-own-ci.py` (SHA-256 `fd890eae020f07f6e5033588b375490b5d2e561b66afd08fab2d1699b1d8093b`).
- Minimal diff: `/private/tmp/jarde-cf11-own-product-ci-verifier-prep-luna-v9/verify-own-ci-v8-to-v9.diff` (SHA-256 `90da7dd747a21c5b1ca6cf4e0a36ec12198f009bf96ba1c953408507d6569ec4`).

The root should inspect this diff and then perform the actual rerun. Do not treat preparation or the prior failed v8 run as acceptance.
