#!/usr/bin/env python3
"""Read-only acceptance of the guarded CF11 full-workspace receipt."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, re, sys
from pathlib import Path
sys.dont_write_bytecode = True
ROOT = Path('/Users/lordcasser/workspace/projects/jarde').resolve()
RUNNER = Path('/private/tmp/jarde-cf11-final-validation-prep-luna-v1/workspace_runner.py')
SEEDS = ('5350648285461741569', '5350648285461741570')
BASE_ENV = {'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','RUST_TEST_THREADS':'1','CARGO_TERM_COLOR':'always','CARGO_PROFILE_TEST_STRIP':'symbols'}
FREE_LIMIT, TARGET_LIMIT = 5 * 1024**3, 1024**3
SUMMARY = re.compile(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', re.M)
OUTCOME = re.compile(r'^test (.+) \.\.\. (ok|ignored|FAILED)(?:, .*)?$', re.M)
FOCUSED_OK = {
 'nearby_list_controls_refuse_only_unproved_generic_projections',
 'inner_list_option_actual_uses_the_receiver_element_type',
 'fixed_nested_string_body_projects_source_and_preserves_physical_origins',
 'differently_named_string_and_integer_classes_follow_their_list_element_type',
 'exact_list_null_add_removes_only_the_synthetic_object_wrapper',
 'pre_cancel_does_not_install_a_partial_generic_declaration_or_method_projection',
 'budget_stop_during_list_proof_keeps_raw_body_and_installs_no_projection',
}
FOCUSED_EXPECTED = {
 'nearby_list_controls_refuse_only_unproved_generic_projections':'ok',
 'inner_list_option_actual_uses_the_receiver_element_type':'ok',
 'fixed_nested_string_body_projects_source_and_preserves_physical_origins':'ok',
 'differently_named_string_and_integer_classes_follow_their_list_element_type':'ok',
 'exact_list_null_add_removes_only_the_synthetic_object_wrapper':'ok',
 'pre_cancel_does_not_install_a_partial_generic_declaration_or_method_projection':'ok',
 'budget_stop_during_list_proof_keeps_raw_body_and_installs_no_projection':'ok',
 'diagnose_late_analysis_stop_phase_without_assuming_raw_map_is_empty':'ignored',
}
def sha(b): return hashlib.sha256(b).hexdigest()
def need(ok, msg):
 if not ok: raise ValueError(msg)
def load_module(path):
 spec=importlib.util.spec_from_file_location('cf11_workspace_runner',path); need(spec and spec.loader,'cannot load pinned workspace runner')
 mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--execution',type=Path,required=True); ap.add_argument('--execution-sha256',required=True)
 ap.add_argument('--focused-receipt',type=Path,required=True); ap.add_argument('--focused-receipt-sha256',required=True)
 ap.add_argument('--metadata',type=Path,required=True); ap.add_argument('--out',type=Path,required=True)
 a=ap.parse_args(); ep=a.execution.resolve(strict=True); fp=a.focused_receipt.resolve(strict=True); mp=a.metadata.resolve(strict=True); op=a.out.resolve()
 need(not op.exists(),'refusing to overwrite acceptance output')
 eraw=ep.read_bytes(); fraw=fp.read_bytes(); mraw=mp.read_bytes()
 need(sha(eraw)==a.execution_sha256 and sha(fraw)==a.focused_receipt_sha256,'receipt hash mismatch')
 e=json.loads(eraw); f=json.loads(fraw); metadata=json.loads(mraw)
 need(e.get('schema')=='cf11-structured-list-full-workspace-root-v1' and e.get('status')=='passed','workspace receipt not successful')
 need(f.get('schema')=='cf11-structured-list-focused-run-v2' and f.get('status')=='passed_initial_product_validation','focused receipt not successful')
 need(f.get('expected_head')=='e9e3a0ec27e5bf7698bdf4817ff08d38bcb63374' and f.get('actual_head')==f.get('expected_head') and f.get('head_matches_expected') is True,'focused receipt source head differs')
 need(e.get('focused_input_receipt')=={'path':str(fp),'sha256':a.focused_receipt_sha256,'schema':f['schema'],'status':f['status']},'focused receipt binding differs')
 cli=f.get('cli_freeze',{}); need(e.get('candidate_cli')=={k:cli.get(k) for k in ('path','bytes','sha256','mode')},'workspace candidate CLI differs from focused freeze')
 need(f.get('source_manifest_before')==f.get('source_manifest_after'),'focused source closure changed')
 runner=load_module(RUNNER); live=runner.pin_sources(runner.source_paths())
 need(live==e.get('source_pins_before')==e.get('source_pins_after'),'live full source closure differs from workspace receipt')
 focused_pins={x.get('path'):x.get('sha256') for x in f['source_manifest_before']}
 need(focused_pins==live and len(focused_pins)==len(f['source_manifest_before']),'focused manifest is not the same exact source closure')
 need(e.get('source_closure_count_at_start')==len(live),'source count differs from dynamic closure')
 need(e.get('guard_limits')=={'minimum_free_bytes':FREE_LIMIT,'maximum_target_bytes':TARGET_LIMIT,'poll_interval_seconds':1},'guard limits differ')
 need(e.get('rust_min_stack') is None,'default Rust stack was overridden')
 need(e.get('seeds')==list(SEEDS),'the two CI Proptest seeds differ')
 need(not (ROOT/'target').exists(),'workspace target remains after cleanup')
 cleanup=e.get('cleanup',{}); need(cleanup.get('status')=='passed' and cleanup.get('target_absent_after') is True and cleanup.get('pins_unchanged') is True,'finally-clean postcondition failed')
 need(cleanup.get('command',{}).get('argv')==['cargo','clean'] and cleanup.get('command',{}).get('cleanup_only',{}).get('exact_argv')==['cargo','clean'],'cleanup exception is not exact cargo clean')
 inventory=[tuple(x) for x in e.get('target_inventory',[])]
 members=set(metadata.get('workspace_members',[]))
 planned=[(p['name'],t['name'],t['kind'][0]) for p in metadata['packages'] if p['id'] in members for t in p['targets']]
 id_to_name={p['id']:p['name'] for p in metadata['packages'] if p['id'] in members}
 need(len(inventory)==len(set(inventory)) and set(inventory)==set(planned),'recorded target inventory differs from raw Cargo metadata')
 need(e.get('metadata',{}).get('target_count')==len(planned),'metadata target count differs')
 batches=e.get('expected_batch_count'); need(type(batches) is int and batches>0,'invalid dynamic batch count')
 members=set(metadata['workspace_members']); planned_batches=[]
 for package in metadata['packages']:
  if package['id'] not in members: continue
  base=['cargo','test','-p',package['name'],'--all-features','--locked','--message-format','json']
  units=[target for target in package['targets'] if target['kind'][0] in ('lib','bin','example','bench')]
  if units:
   flags=[]
   for kind,flag in (('lib','--lib'),('bin','--bins'),('example','--examples'),('bench','--benches')):
    if any(target['kind'][0]==kind for target in units): flags.append(flag)
   planned_batches.append(base+flags)
  tests=[target for target in package['targets'] if target['kind'][0]=='test']
  for offset in range(0,len(tests),4):
   planned_batches.append(base+sum((['--test',target['name']] for target in tests[offset:offset+4]),[]))
 need(len(planned_batches)==batches,'dynamic Cargo target batch plan differs from receipt')
 commands=e.get('commands'); want_count=2+2*batches+1
 need(isinstance(commands,list) and len(commands)==want_count==e.get('expected_command_count_including_clean')==e.get('observed_command_count_including_clean'),'command count differs from dynamic two-seed plan')
 need(e.get('runner',{}).get('sha256_before')==e.get('runner',{}).get('sha256_after')==sha(RUNNER.read_bytes()),'workspace runner changed')
 need(commands[0].get('argv')==['cargo','fmt','--all','--','--check'] and commands[0].get('exit_code')==0,'fmt check failed')
 need(commands[1].get('argv')==['cargo','metadata','--no-deps','--format-version','1','--locked'] and commands[1].get('exit_code')==0,'metadata command failed')
 md_raw=Path(mp).read_bytes(); md_stream=commands[1]['streams']['stdout']; md_path=Path(md_stream['path'])
 need(not md_path.is_symlink() and md_path.read_bytes()==md_raw and sha(md_raw)==md_stream['sha256'],'metadata file differs from raw stdout')
 seen=[]; raw_paths=set(); named_by_seed={s:[] for s in SEEDS}; observed_targets={s:[] for s in SEEDS}; totals=[0,0,0]; summary_count=0; outcome_count=0
 for index,row in enumerate(commands[:-1]):
  need(row.get('index')==index and row.get('exit_code')==0 and row.get('guard_stop') is None,'command failed or indices have a gap')
  expected_env={**BASE_ENV,'PROPTEST_RNG_SEED':row.get('proptest_seed',SEEDS[0])}
  need(row.get('env_overrides')==expected_env,'workspace command environment differs')
  need(row.get('cleanup_only') is None and row.get('peak_target_bytes',TARGET_LIMIT+1)<=TARGET_LIMIT and row.get('free_bytes_after',0)>=FREE_LIMIT,'guarded workspace command exceeded resource limits')
  if index>=2:
   seed=row.get('proptest_seed'); need(seed in SEEDS,'test batch lacks approved seed')
   seed_index=SEEDS.index(seed); batch_index=index-2-seed_index*batches
   need(0<=batch_index<batches and row.get('argv')==planned_batches[batch_index],'workspace batch argv/order differs from metadata plan')
   named=[(x.get('name'),x.get('status')) for x in row.get('named_test_outcomes',[])]
   named_by_seed[seed].extend(named)
   for target in row.get('executed_targets',[]): observed_targets[seed].append((id_to_name.get(target[0],''),target[1],target[2]))
   need(row.get('argv',[])[:2]==['cargo','test'],'non-test command in workspace batch sequence')
   need(row.get('env_overrides',{}).get('PROPTEST_RNG_SEED')==seed,'batch environment seed mismatch')
   need(row.get('peak_target_bytes',TARGET_LIMIT+1)<=TARGET_LIMIT and row.get('free_bytes_after',0)>=FREE_LIMIT and row.get('cleanup_only') is None,'test batch exceeded guarded resource limits')
   outref=row['streams']['stdout']; raw_path=Path(outref['path']); raw=raw_path.read_bytes()
   need(sha(raw)==outref['sha256'] and len(raw)==outref['bytes'],'test stdout hash mismatch')
   raw_outcomes=[(m.group(1),m.group(2)) for m in OUTCOME.finditer(raw.decode('utf-8','replace'))]
   need(raw_outcomes==named and row.get('named_test_outcome_count')==len(named),'named test outcomes differ from raw stdout')
   raw_summaries=[(m.group(1),int(m.group(2)),int(m.group(3)),int(m.group(4))) for m in SUMMARY.finditer(raw.decode('utf-8','replace'))]
   stored=[(x.get('status'),x.get('passed'),x.get('failed'),x.get('ignored')) for x in row.get('observed_summaries',[])]
   need(raw_summaries==stored and len(raw_summaries)==len(row.get('executed_targets',[])),'summary rows differ from raw stdout or target artifacts')
   for _,passed,failed,ignored in raw_summaries: totals[0]+=passed;totals[1]+=failed;totals[2]+=ignored
   summary_count+=len(raw_summaries);outcome_count+=len(raw_outcomes)
  for name,ref in row.get('streams',{}).items():
   path=Path(ref['path']); need(not path.is_symlink() and path.is_file(),'raw stream missing or symlink')
   raw=path.read_bytes(); need(len(raw)==ref['bytes'] and sha(raw)==ref['sha256'],'raw stream pin mismatch')
   need(path.resolve().is_relative_to(ep.parent),'raw stream escaped execution directory')
   raw_paths.add(path.resolve())
 for seed in SEEDS:
  outcomes=named_by_seed[seed]
  focus_outcomes=[(name,state) for name,state in outcomes if name in FOCUSED_EXPECTED]
  need(len(focus_outcomes)==len(FOCUSED_EXPECTED) and dict(focus_outcomes)==FOCUSED_EXPECTED,'focused named outcomes differ for '+seed)
  need(set(name for name,state in outcomes if state=='ok') >= FOCUSED_OK,'focused passing names absent for '+seed)
  need(len(observed_targets[seed])==len(set(observed_targets[seed])) and set(observed_targets[seed])==set(tuple(x) for x in e['target_inventory']),'targets not run exactly once for '+seed)
 clean=commands[-1]; need(clean.get('env_overrides')=={**BASE_ENV,'PROPTEST_RNG_SEED':SEEDS[-1]},'cleanup environment differs')
 need(clean.get('index')==want_count-1 and clean.get('argv')==['cargo','clean'] and clean.get('cleanup_only',{}).get('space_precheck_bypassed') is True and clean.get('cleanup_only',{}).get('space_monitor_abort_bypassed') is True,'cleanup markers differ')
 for ref in clean.get('streams',{}).values():
  path=Path(ref['path']); need(not path.is_symlink() and path.is_file() and path.resolve().is_relative_to(ep.parent),'cleanup raw stream missing or escaped')
  raw=path.read_bytes(); need(len(raw)==ref['bytes'] and sha(raw)==ref['sha256'],'cleanup raw stream pin mismatch'); raw_paths.add(path.resolve())
 need(len(raw_paths)==want_count*2,'raw stream inventory differs')
 actual_raws={p.resolve() for p in ep.parent.glob('*.raw') if p.is_file()}
 need(actual_raws==raw_paths,'execution directory contains missing or unreferenced raw streams')
 need(e.get('workspace_totals')==totals and e.get('workspace_summary_count')==summary_count,'workspace aggregate test totals differ from raw summaries')
 result={'schema':'cf11-structured-list-full-workspace-acceptance-v1','status':'accepted_local_workspace_only','not_ci_or_product_release_acceptance':True,'execution_sha256':a.execution_sha256,'focused_receipt_sha256':a.focused_receipt_sha256,'source_pin_count':len(live),'target_count':len(planned),'batch_count_per_seed':batches,'seeds':list(SEEDS),'test_totals':{'passed':totals[0],'failed':totals[1],'ignored':totals[2],'target_summary_count':summary_count,'named_test_outcome_count':outcome_count},'raw_stream_count':len(raw_paths),'target_absent':True}
 op.parent.mkdir(parents=True,exist_ok=True); op.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
 print(json.dumps(result,indent=2,ensure_ascii=False)); return 0
if __name__=='__main__':
 try: raise SystemExit(main())
 except Exception as exc: print(f'acceptance failed: {type(exc).__name__}: {exc}',file=sys.stderr); raise SystemExit(1)
