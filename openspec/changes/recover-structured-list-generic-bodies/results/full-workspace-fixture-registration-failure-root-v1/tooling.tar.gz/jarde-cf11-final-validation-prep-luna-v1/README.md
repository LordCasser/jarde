# CF11 final local validation preparation v1

This is a private, unexecuted validation package for the current focused CF11 work. It reuses the accepted workspace target planner and the archived final-validation command flow. It does not certify product completion, CI, release, or publication.

The workspace runner requires the successful focused-v4 receipt and its frozen CLI as inputs. It checks that the focused receipt has schema `cf11-structured-list-focused-run-v2`, status `passed_initial_product_validation`, the exact same complete source manifest before and after, and a successful final clean. The workspace source closure is recomputed dynamically and matched byte-for-byte against the focused receipt. A read-only check while preparing this package found 4,822 files in that closure; the runner does not hard-code that count. It includes all actual files below `src`, `crates`, `tests`, `examples`, `.cargo`, the existing source-path helper closure, manifests, lockfile, CI workflow, and frozen evidence.

The runner obtains Cargo metadata under `--locked`, cross-checks its target inventory against current manifests and source files, and derives test batches from that metadata. It executes each discovered target exactly once for each CI Proptest seed (`5350648285461741569` and `5350648285461741570`), recording every command's raw streams and resource samples. The eight focused test names are checked on both passes: seven must be `ok`, and `diagnose_late_analysis_stop_phase_without_assuming_raw_map_is_empty` must remain `ignored`. The 5 GiB free-space and 1 GiB target-size guards poll at one-second intervals. `RUST_MIN_STACK` is removed so the normal Rust test-thread stack remains in force. A `finally` cleanup invokes only exact `cargo clean` through the cleanup-only path, retaining its before/after resource observations and raw streams.

After the workspace run, execute `accept_workspace.py` with the actual receipt and metadata hashes. It independently checks the live source closure, dynamic metadata target set, one-run-per-target-per-seed evidence, focused outcomes, raw summaries and streams, resource limits, and clean postcondition.

The final runner follows the archived order and reads the live workflow to obtain its exact Clippy command, including its configured lint allowances:

1. `cargo fmt --all -- --check`
2. the current `.github/workflows/ci.yml` Clippy command
3. `openspec validate --all --strict --no-interactive`
4. `cargo build -p jarde-cli --bin jarde-cli --locked`, byte-compared with the focused frozen CLI
5. finally, exact `cargo clean`

The first four commands retain both resource guards; only the final exact clean bypasses their thresholds and monitor abort. The final runner pins and rechecks the live source closure around each command. `accept-final.py` verifies the raw command evidence and receipt bindings. Both acceptance results are explicitly local observations only.

No Cargo, JDK, Git, network, or shared-source command was run while preparing this package. The only dynamic preparation check was read-only source-closure parity against focused-v4; Python syntax was checked without executing a runner's `main`.

After the focused run and final 12-capture comparison are independently accepted, pass the actual focused receipt path/SHA and CLI SHA from its `cli_freeze` record. Then run the workspace runner, its acceptor, the final runner, and the final acceptor in that order. Each output directory must be new. The default output paths are under this preparation directory; keep actual run evidence in separate fresh roots if preferred.

The runner interfaces are:

```text
workspace_runner.py --focused-receipt PATH --focused-receipt-sha256 SHA --candidate-cli /private/tmp/jarde-cf11-structured-list-candidate-cli-root-v2 --candidate-cli-sha256 SHA --out NEW_DIRECTORY
accept_workspace.py --execution PATH --execution-sha256 SHA --focused-receipt PATH --focused-receipt-sha256 SHA --metadata WORKSPACE_DIRECTORY/metadata.json --out NEW_JSON
final-build-runner.py --focused-receipt PATH --focused-receipt-sha256 SHA --workspace-receipt PATH --workspace-receipt-sha256 SHA --workspace-acceptance PATH --workspace-acceptance-sha256 SHA --out NEW_DIRECTORY
accept-final.py --final-receipt PATH --final-receipt-sha256 SHA --focused-receipt PATH --focused-receipt-sha256 SHA --workspace-receipt PATH --workspace-receipt-sha256 SHA --workspace-acceptance PATH --workspace-acceptance-sha256 SHA --out NEW_JSON
```

Use the exact paths and hashes from the completed focused, workspace, and acceptance receipts. The frozen candidate hash is the `cli_freeze.sha256` field in the focused receipt. The final acceptance result reports only these local checks.
