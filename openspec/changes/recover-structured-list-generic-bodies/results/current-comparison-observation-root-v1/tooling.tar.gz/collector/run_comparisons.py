from pathlib import Path
import hashlib, json, subprocess, sys

ROOT = Path('/Users/lordcasser/workspace/projects/jarde')
HERE = Path(__file__).resolve().parent
COLLECTOR = HERE / 'collect_controls.py'
RECEIPT = Path('/private/tmp/jarde-cf11-structured-list-focused-root-v6/execution.json')
CLI = Path('/private/tmp/jarde-cf11-structured-list-candidate-cli-root-v1')
OUT = Path('/private/tmp/jarde-cf11-structured-list-current-comparison-batch-root-v1')
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(COLLECTOR) == json.loads((HERE / 'pins.json').read_text())['collector_sha256']
assert sha(RECEIPT) == 'd99d6cafb0401ebe64f9e598d41a3b95606cb050b0dc5fff9964f1db879871b1'
assert sha(CLI) == 'beb4c3e747512be55a1d657726f8c8382c462376eb39ca8011941cbae5c03879'
bases = {
    'fixed': ROOT / 'openspec/evidence/java-syntax-2026-10-12/cf11-testnestedloops-baseline-root-v1/capture/execution.json',
    'string': Path('/private/tmp/jarde-cf11-structured-list-isolated-string-baseline-root-v1/execution.json'),
    'integer': Path('/private/tmp/jarde-cf11-structured-list-isolated-integer-baseline-root-v1/execution.json'),
    'controls': Path('/private/tmp/jarde-cf11-structured-list-controls-baseline-root-v1/execution.json'),
}
OUT.mkdir(exist_ok=False)
record = {'status': 'running', 'collector_sha256': sha(COLLECTOR), 'build_receipt_sha256': sha(RECEIPT), 'cli_sha256': sha(CLI), 'commands': []}
def save():
    (OUT / 'execution.json').write_text(json.dumps(record, indent=2) + '\n')
save()
for family, baseline in bases.items():
    config = json.loads(baseline.read_text())['collector_config']
    for debug in ('debug', 'none'):
        capture = Path(f'/private/tmp/jarde-cf11-structured-list-current-{family}-{debug}-root-v1')
        args = {**config, 'out': str(capture), 'source_debug': debug, 'cli': str(CLI), 'cli_sha256': sha(CLI), 'build_receipt': str(RECEIPT), 'build_receipt_sha256': sha(RECEIPT), 'receipt_cli_object': 'cli_freeze', 'receipt_accepted_value': 'passed_initial_product_validation'}
        argv = [sys.executable, '-B', str(COLLECTOR)]
        for key, value in args.items():
            argv.extend(['--' + key.replace('_', '-'), str(value)])
        label = f'{family}-{debug}'
        row = {'label': label, 'argv': argv, 'capture': str(capture), 'status': 'running'}
        record['commands'].append(row)
        save()
        stdout, stderr = OUT / f'{label}.stdout.raw', OUT / f'{label}.stderr.raw'
        with stdout.open('wb') as so, stderr.open('wb') as se:
            row['exit_code'] = subprocess.run(argv, cwd=ROOT, stdout=so, stderr=se).returncode
        row['status'] = 'terminal'
        row['streams'] = {name: {'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)} for name, p in [('stdout', stdout), ('stderr', stderr)]}
        save()
        print(label, row['exit_code'], flush=True)
        if row['exit_code'] != 0:
            record['status'] = 'failed'
            save()
            raise SystemExit(row['exit_code'])
record['status'] = 'captures_complete_not_independently_accepted'
save()
