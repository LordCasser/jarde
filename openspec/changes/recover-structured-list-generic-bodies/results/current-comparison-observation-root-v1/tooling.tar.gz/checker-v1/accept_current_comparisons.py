#!/usr/bin/env python3
"""Independently verify the eight saved current CF11 debug/-g:none captures against frozen old oracles."""
from __future__ import annotations
import argparse
import hashlib
import importlib
import importlib.util
import json
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
PIN_PATH = Path(__file__).resolve().with_name('pins.json')
BLAKE3_ROOT = Path('/private/tmp/jarde-fingerprint-python-v1')
PARSER_PATH = Path('/private/tmp/jarde-computed-for-cf07-final-replay-verifier-root-v4.py')
PARSER_SHA256 = 'f30754e1e52403713a671ce38f274b772f188583df6c4a1bc6b4400937233469'
ROOT = Path('/Users/lordcasser/workspace/projects/jarde').resolve()
BATCH_PATH = Path('/private/tmp/jarde-cf11-structured-list-current-comparison-batch-root-v1/execution.json')
TOOLING_COLLECTOR = Path('/private/tmp/jarde-cf11-structured-list-current-comparison-tooling-root-v1/collect_controls.py')
EXPECTED_CLI = {'path':'/private/tmp/jarde-cf11-structured-list-candidate-cli-root-v1','bytes':61922512,'sha256':'beb4c3e747512be55a1d657726f8c8382c462376eb39ca8011941cbae5c03879'}
FOCUSED_RECEIPT = {'path':'/private/tmp/jarde-cf11-structured-list-focused-root-v6/execution.json','bytes':4324933,'sha256':'d99d6cafb0401ebe64f9e598d41a3b95606cb050b0dc5fff9964f1db879871b1'}
MIN_FREE, MAX_TARGET = 5 * 1024**3, 1024**3

EXPECTED_LABELS = {
    'fixed': {'both-empty','unmatched','five-character-match-add','non-five-match-remove','non-five-match-continues-and-clears','null-first-list','null-second-list','null-element'},
    'string': {'string-isolated-empty','string-isolated-add-cme','string-isolated-remove-object-cme','string-isolated-null-element','string-isolated-null-list'},
    'integer': {'integer-isolated-empty','integer-isolated-add-cme','integer-isolated-remove-object-cme','integer-isolated-null-element','integer-isolated-null-list','integer-isolated-heap-pollution'},
    'controls': {'baseline-both-empty','baseline-unmatched','baseline-five-character-match-add','baseline-non-five-match-remove','baseline-remove-continues-and-clears','baseline-null-first-list','baseline-null-second-list','baseline-null-element','renamed-string-positive','integer-nested-add-positive','explicit-cast-object-boundary','raw-list-method-control','raw-alias-heap-pollution','parameter-reassignment','wildcard-null-write','try-catch-handler','remove-object-and-index-overloads'},
}
CAPTURES = {
    'fixed_debug': ('fixed','debug','/private/tmp/jarde-cf11-structured-list-current-fixed-debug-root-v1',29),
    'fixed_none': ('fixed','none','/private/tmp/jarde-cf11-structured-list-current-fixed-none-root-v1',29),
    'string_debug': ('string','debug','/private/tmp/jarde-cf11-structured-list-current-string-debug-root-v1',29),
    'string_none': ('string','none','/private/tmp/jarde-cf11-structured-list-current-string-none-root-v1',29),
    'integer_debug': ('integer','debug','/private/tmp/jarde-cf11-structured-list-current-integer-debug-root-v1',29),
    'integer_none': ('integer','none','/private/tmp/jarde-cf11-structured-list-current-integer-none-root-v1',29),
    'controls_debug': ('controls','debug','/private/tmp/jarde-cf11-structured-list-current-controls-debug-root-v1',25),
    'controls_none': ('controls','none','/private/tmp/jarde-cf11-structured-list-current-controls-none-root-v1',25),
}
ORACLE_ANCHORS = {
    'fixed': '/Users/lordcasser/workspace/projects/jarde/openspec/evidence/java-syntax-2026-10-12/cf11-testnestedloops-baseline-root-v1/capture/execution.json',
    'string': '/private/tmp/jarde-cf11-structured-list-isolated-string-baseline-root-v1/execution.json',
    'integer': '/private/tmp/jarde-cf11-structured-list-isolated-integer-baseline-root-v1/execution.json',
    'controls': '/private/tmp/jarde-cf11-structured-list-controls-baseline-root-v1/execution.json',
}
EXPECTED_MAP_GAP = {
    'method': 'handled', 'descriptor': '(Ljava/util/List;Ljava/util/List;)V',
    'exception_table': [{'start_pc':0,'end_pc':47,'handler_pc':50,'catch_type':'java/lang/RuntimeException'}],
}
BLAKE3 = None
PARSER = None
PIN_DATA = None


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def digest_file(path: Path) -> dict:
    h=hashlib.sha256(); size=0
    with Path(path).open('rb') as f:
        while block:=f.read(1024*1024): h.update(block); size+=len(block)
    return {'path':str(Path(path).resolve()),'bytes':size,'sha256':h.hexdigest()}

def load_json(path: Path) -> dict:
    return json.loads(Path(path).read_text(encoding='utf-8'))

def pinned_module(name: str, path: Path, expected: str):
    need(digest_file(path)['sha256']==expected, f'{name} SHA differs: {path}')
    spec=importlib.util.spec_from_file_location(name,path); need(spec is not None and spec.loader is not None,f'cannot load {name}')
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module

def blake3_inventory() -> list[dict]:
    root=BLAKE3_ROOT.resolve(); rows=[digest_file(p) for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
    need(rows,'private blake3 package files are absent'); return rows

def load_blake3():
    before=blake3_inventory(); sys.path.insert(0,str(BLAKE3_ROOT)); module=importlib.import_module('blake3'); after=blake3_inventory()
    need(before==after,'blake3 package changed during import')
    need(Path(module.__file__).resolve().is_relative_to((BLAKE3_ROOT/'blake3').resolve()),'blake3 came from outside pinned private package')
    need(before==PIN_DATA['blake3_dependency']['files_before_import'] and after==PIN_DATA['blake3_dependency']['files_after_import'],'blake3 inventory differs from pins')
    return module,before

def physical_class(run: dict, run_root: Path, jdk: str, class_name: str) -> tuple[Path,dict]:
    path=run_root/'legs'/f'{jdk}-original'/'classes'/Path(class_name.replace('.','/')+'.class')
    need(path.is_file(),f'original class file absent: {path}')
    row=next((x for x in run.get('original_compile_rows',[]) if x.get('label')==f'{jdk}-original'),None)
    need(row is not None and row.get('compile_exit')==0,f'{jdk} original class compile missing')
    pin=next((x for x in row.get('classes',[]) if Path(x['path']).resolve()==path.resolve()),None)
    need(pin is not None and digest_file(path)==pin,f'physical class SHA differs from compile receipt: {path}')
    return path,pin

def verify_rendered_class_b3(run: dict, run_root: Path, profile: dict) -> dict:
    report_path=Path(profile['report_pin']['path']).resolve(); source_path=Path(profile['source_pin']['path']).resolve()
    need(report_path.is_relative_to(run_root.resolve()) and source_path.is_relative_to(run_root.resolve()),f"profile report/source escaped capture root: {profile['label']}")
    need(digest_file(report_path)==profile['report_pin'],f"report pin differs: {profile['label']}")
    doc=load_json(report_path)
    need(digest_file(source_path)==profile['source_pin'] and source_path.read_bytes()==doc['text'].encode(),f"rendered source differs from report: {profile['label']}")
    class_file,physical_pin=physical_class(run,run_root,profile['jdk'],profile['class']); data=class_file.read_bytes(); b3=BLAKE3.blake3(data).hexdigest()
    identity=doc.get('class')
    expected={'class_bytes':{'digest':b3,'length':len(data)},'location':{'kind':'standalone_root','snapshot':b3},'variant':{'kind':'base'}}
    need(identity==expected,f"report class identity differs from physical class: {profile['label']}")
    methods=doc.get('methods'); need(isinstance(methods,list) and methods,f"method reports absent: {profile['label']}")
    origins=0
    for method in methods:
        item=method.get('item',{}); ident=item.get('identity')
        need(isinstance(ident,dict) and ident.get('owner')==identity,f"method owner differs from class identity: {profile['label']}")
        name=bytes(ident['name']).decode('ascii'); desc=bytes(ident['descriptor']).decode('ascii')
        rec=method.get('outcome',{}).get('report')
        need(isinstance(rec,dict) and rec.get('method')==name+desc and rec.get('artifact',{}).get('binding',{}).get('method')==ident,f"recovery method identity differs: {profile['label']} {name}{desc}")
        segments=rec.get('source_map',{}).get('segments'); need(isinstance(segments,list),f"source-map segments absent: {profile['label']} {name}{desc}")
        for seg in segments:
            origin=seg.get('origin',{}); facts=([origin['primary']] if origin.get('primary') is not None else [])+origin.get('derived',[])
            for fact in facts:
                need(fact.get('method')==ident,f"source-map origin identity differs: {profile['label']} {name}{desc}")
                origins+=1
    return {'label':profile['label'],'class':profile['class'],'jdk':profile['jdk'],'mode':profile['mode'],'physical_class':physical_pin,'physical_class_blake3':b3,'physical_class_length':len(data),'report_class_identity_exact':True,'method_item_owner_exact':True,'raw_recovery_method_identity_exact':True,'source_map_origin_owner_exact':True,'method_count':len(methods),'source_map_origin_count':origins}

def verify_raw_streams(run: dict, run_root: Path) -> dict[int,dict[str,bytes]]:
    commands=run.get('commands',[]); need(len(commands)==run.get('actual_command_count'),'actual command count differs')
    need([x.get('index') for x in commands]==list(range(1,len(commands)+1)),'command indexes not contiguous')
    result={}; expected_names=[]
    for row in commands:
        idx=row['index']; need(row.get('state')=='observed' and row.get('guard_stop') is None,f"incomplete/guard-stopped command {row.get('label')}")
        need(Path(row.get('cwd','')).resolve()==ROOT,f"wrong command cwd: {row.get('label')}")
        result[idx]={}
        for stream in ('stdout','stderr'):
            path=run_root/'raw'/f'{idx}.{stream}.raw'; meta=row.get('streams',{}).get(stream,{})
            need(Path(meta.get('path','')).resolve()==path.resolve(),f"raw path mismatch {row.get('label')}/{stream}")
            need(digest_file(path)=={'path':str(path.resolve()),'bytes':meta.get('bytes'),'sha256':meta.get('sha256')},f"raw stream pin mismatch {row.get('label')}/{stream}")
            result[idx][stream]=path.read_bytes(); expected_names.append(path.name)
    names=sorted(p.name for p in (run_root/'raw').iterdir() if p.is_file())
    need(names==sorted(expected_names),'raw inventory has gaps or extras')
    return result

def verify_source_tool_pins(run: dict) -> None:
    before=run.get('source_tool_pins_before'); after=run.get('source_tool_pins_after')
    need(isinstance(before,list) and before and before==after and run.get('source_tool_inputs_unchanged') is True,'source/tool pins changed')
    seen=set()
    for pin in before:
        path=Path(pin['path']).resolve(); need(str(path) not in seen,f'duplicate source/tool pin {path}'); seen.add(str(path))
        need(digest_file(path)==pin,f'source/tool file changed after capture: {path}')
    need(run.get('cli')==EXPECTED_CLI,'CLI pin differs from focused-v6 product binary')
    cli=next((x for x in before if Path(x['path']).resolve()==Path(EXPECTED_CLI['path']).resolve()),None)
    need(cli==EXPECTED_CLI,'CLI absent from source/tool pins')
    need(run.get('cli_mode')=='0o555','captured CLI mode differs from 0555')
    rec_path=Path(FOCUSED_RECEIPT['path']); need(digest_file(rec_path)==FOCUSED_RECEIPT,'focused build receipt pin differs')
    receipt=load_json(rec_path)
    need(receipt.get('schema')=='cf11-structured-list-focused-run-v2' and receipt.get('status')=='passed_initial_product_validation','focused v6 receipt schema/status mismatch')
    need(run.get('build_receipt')==FOCUSED_RECEIPT and run.get('build_receipt_cli_binding')==receipt.get('cli_freeze'),'capture does not bind focused receipt and CLI')
    need(run.get('build_receipt_validation',{}).get('source_manifest',{}).get('count')==4805,'capture lacks complete focused source closure validation')

def original_rows(run:dict,raw:dict[int,dict[str,bytes]],family:str,oracle:bytes):
    labels={x['label']:x for x in run['commands']}; output=[]
    for jdk in ('javac8','javac23'):
        comp=labels.get(f'{jdk}-original-compile'); rr=labels.get(f'{jdk}-original-run')
        need(comp is not None and comp.get('exit_code')==0 and rr is not None and rr.get('exit_code')==0,f'{family}/{jdk} original compile/run failed')
        need(raw[rr['index']]['stderr']==b'',f'{family}/{jdk} oracle wrote stderr')
        stdout=raw[rr['index']]['stdout'];need(stdout==oracle,f'{family}/{jdk} original output differs byte-for-byte from frozen oracle')
        output.append(stdout)
    need(output[0]==output[1],'JDK8/JDK23 original oracle outputs differ')
    lines=output[0].decode('utf-8').splitlines(); actual=[]
    for line in lines:
        fields=line.split('|'); label=fields[0] if fields else ''
        need(bool(label),f'{family} oracle row has empty label');actual.append(label)
        need(fields[1].startswith('exception=') and fields[1].split('=',1)[1],f'{family} oracle exception field absent')
        if family=='fixed':
            need(len(fields)==4 and fields[2].startswith('l1=') and fields[3].startswith('l2='),f'{family} row must contain exact l1/l2 state fields')
        else:
            need(len(fields)==5 and fields[2].startswith('left=') and fields[3].startswith('right=') and fields[4].startswith('effects=') and fields[4][8:].isdigit(),f'{family} row must contain exact left/right/effects fields')
    need(len(actual)==len(set(actual)) and set(actual)==EXPECTED_LABELS[family],f'{family} oracle label set differs from frozen fixture')
    return actual

def verify_compile_groups(run:dict,raw:dict[int,dict[str,bytes]],family:str,class_name:str,mode:str,oracle:bytes):
    mapped={x['label']:x for x in run['commands']}; need(len(mapped)==len(run['commands']),'duplicate command labels')
    rows=run.get('jarde_compile_rows',[])+run.get('jadx_compile_rows',[])
    if family!='controls':
        expected=set()
        for jdk in ('javac8','javac23'):
            expected.update({f'{jdk}-jarde-default-combined',f'{jdk}-jarde-all-combined',f'{jdk}-jadx-default',f'{jdk}-jadx-none'})
        by={x['label']:x for x in rows};need(len(rows)==8 and set(by)==expected,f'{family} generated compile/run inventory differs from eight fixed legs')
        for label,item in by.items():
            need(item.get('compile_exit')==0 and item.get('class_set_exact') is True and item.get('run_exit')==0,f'{family} generated output did not compile/run exactly: {label}')
            comp=mapped.get(item.get('compile_command')); runrow=mapped.get(item.get('run_command'))
            need(comp is not None and comp.get('exit_code')==0 and runrow is not None and runrow.get('exit_code')==0,f'{family} command receipts missing: {label}')
            need(raw[runrow['index']]['stdout']==oracle and raw[runrow['index']]['stderr']==b'',f'{family}/{label} generated runtime differs from frozen oracle bytes')
            cls_paths=sorted(c['path'] for c in item.get('classes',[]))
            need(item.get('class_paths')==sorted([class_name.replace('.','/')+'.class','cf11/Runner.class']),f'{family}/{label} generated class inventory differs')
            for c in item.get('classes',[]): need(digest_file(Path(c['path']))==c,f'{family}/{label} generated class SHA differs')
            flags=[x for x in comp['argv'] if x in ('-g','-g:none')]
            need(flags==(['-g:none'] if mode=='none' else ['-g']),f'{family}/{label} compile debug option differs')
        jarde=[x for x in rows if x['label'].find('-jarde-')>=0]
        for row in jarde:
            src=Path(row['source_pins'][0]['path']); text=src.read_text(encoding='utf-8')
            element='Integer' if family=='integer' else 'String'
            need(re.search(r'java\.util\.List<java\.lang\.'+element+r'>',text) is not None,f'{family}/{row["label"]} generic List element type missing')
            need(re.search(r'\.add\(\s*[A-Za-z_$][\w$]*\s*\)',text) is not None,f'{family}/{row["label"]} does not emit a legal typed add operand')
            need(re.search(r'\.remove\(\s*\(java\.lang\.Object\)\s*[A-Za-z_$][\w$]*\s*\)',text) is not None,f'{family}/{row["label"]} Object remove overload/cast missing')
            need(re.search(r'\(java\.lang\.'+element+r'\)\s*iteratorElement',text) is not None,f'{family}/{row["label"]} physical element cast missing')
        return {'positive_compile_run_pairs':8,'all_runtime_bytes_equal_frozen_oracle':True,'jarde_typed_add_object_remove_and_physical_cast_checked':True}
    need(family=='controls','unknown family')
    expected=set(); suffix=class_name.split('.')[-1]
    for jdk in ('javac8','javac23'):
        for style in ('default','all'):
            expected.add(f'{jdk}-jarde-{style}-combined');expected.add(f'{jdk}-jarde-{style}-isolated-{suffix}')
        expected.update({f'{jdk}-jadx-default',f'{jdk}-jadx-none'})
    by={x['label']:x for x in rows};need(len(rows)==12 and set(by)==expected,'controls must retain exactly four JADX and eight Jarde failed compiles')
    for label,item in by.items():
        need(item.get('compile_exit')==1 and item.get('class_set_exact') is None and item.get('run_command') is None and item.get('run_exit') is None,f'controls failure/runtime receipt differs: {label}')
        comp=mapped.get(item.get('compile_command'));need(comp is not None and comp.get('exit_code')==1 and label+'-run' not in mapped,f'controls failed compile missing or fabricated runtime: {label}')
        stderr=raw[comp['index']]['stderr'];stdout=raw[comp['index']]['stdout'];need(stderr or stdout,f'controls compile failure has no raw diagnostic: {label}')
    need(all(x.get('compile_exit')==1 and x.get('run_command') is None for x in run.get('jarde_compile_rows',[])+run.get('jadx_compile_rows',[])),'controls compile failures were not preserved without runtime')
    return {'negative_compile_groups':12,'jadx_failures':4,'jarde_failures':8,'all_runtime_absent':True,'raw_diagnostics_retained':True}

def verify_debug_javap(run,raw,mode,run_root):
    if mode!='none': return []
    items=run.get('javap',[]);need(len(items)==2,'no-debug javap inventory must include both JDKs');out=[]
    for item in items:
        row=next((x for x in run['commands'] if x.get('label')==item.get('command')),None);need(row is not None and row.get('exit_code')==0,'no-debug javap command absent or failed')
        data=raw[row['index']]['stdout']; pin=item['stdout_pin']; path=Path(pin['path']);need(path.resolve()==(run_root/'legs'/f"{item['jdk']}-original"/'javap-UpstreamNestedLoops.txt').resolve() or path.resolve().is_relative_to((run_root/'legs'/f"{item['jdk']}-original").resolve()),'javap output path escaped original class capture')
        need(digest_file(path)==pin and path.read_bytes()==data,'saved javap output differs from captured raw stdout')
        text=data.decode('utf-8');need(re.search(r'^\s*(?:LineNumberTable|LocalVariableTable|LocalVariableTypeTable):',text,re.M) is None,'-g:none javap contains debug tables')
        need(re.search(r'^\s*Signature:',text,re.M) is not None,'-g:none javap lost generic Signature')
        out.append({'jdk':item['jdk'],'class':item['class'],'debug_tables_absent':True,'signature_present':True,'javap_sha256':pin['sha256']})
    return out

def oracle_for(family:str):
    anchor=PIN_DATA['oracle_anchors'][family]
    path=Path(anchor['execution']['path']);need(digest_file(path)==anchor['execution'],f'{family} frozen oracle receipt pin differs')
    run=load_json(path);need(run.get('status')=='observed',f'{family} baseline receipt is incomplete')
    manifest_path=Path(run['inputs_manifest_path']);need(digest_file(manifest_path)==anchor['inputs_manifest'],f'{family} baseline input manifest changed')
    need(run.get('input_entries')==anchor['input_entries'],f'{family} baseline input entries changed')
    inputs=Path(run.get('collector_config',{}).get('inputs_dir',''))
    for entry in anchor['input_entries'].get('target_classes',[])+[anchor['input_entries'].get('runner',{})]:
        source=inputs/entry['source'];need(source.is_file() and digest_file(source)['bytes']==entry['bytes'] and digest_file(source)['sha256']==entry['sha256'],f'{family} frozen baseline input source changed: {source}')
    need(run.get('classes')==[anchor['class']],f'{family} baseline target class differs')
    out=[]
    for jdk in ('javac8','javac23'):
        comp=next((x for x in run['original_compile_rows'] if x['label']==f'{jdk}-original'),None);need(comp is not None and comp.get('compile_exit')==0,f'{family} baseline {jdk} compile missing')
        row=next((x for x in run['commands'] if x['label']==comp['run_command']),None);need(row is not None and row.get('exit_code')==0,f'{family} baseline {jdk} run failed')
        pin=row['streams']['stdout']; raw_path=Path(pin['path']);need(digest_file(raw_path)==pin,f'{family} baseline raw oracle changed')
        err=Path(row['streams']['stderr']['path']);need(digest_file(err)==row['streams']['stderr'] and err.read_bytes()==b'',f'{family} baseline stderr changed/nonempty')
        out.append(raw_path.read_bytes())
    need(out[0]==out[1],f'{family} frozen baseline Java 8/23 stdout differs')
    need(sha(out[0])==anchor['oracle_stdout_sha256'],f'{family} frozen baseline stdout SHA differs from pins')
    return run,out[0]

def verify_physical_body_maps(run,run_root,profiles,family):
    all_rows=[]
    class_name=run['classes'][0]
    for profile in profiles:
        doc=load_json(Path(profile['report_pin']['path']))
        class_path,_=physical_class(run,run_root,profile['jdk'],class_name)
        gaps=[]
        for method in doc.get('methods',[]):
            identity=method.get('item',{}).get('identity',{})
            name=bytes(identity.get('name',[])).decode('ascii'); desc=bytes(identity.get('descriptor',[])).decode('ascii')
            parsed=PARSER.parse_method(class_path.read_bytes(),name,desc)
            physical={pc for pc,_,_ in PARSER.decode(parsed['code'])}
            segments=method.get('outcome',{}).get('report',{}).get('source_map',{}).get('segments')
            need(isinstance(segments,list),f'{profile["label"]} {name}{desc} source map absent')
            mapped=set()
            for seg in segments:
                origin=seg.get('origin',{});facts=([origin['primary']] if origin.get('primary') is not None else [])+origin.get('derived',[])
                for fact in facts:
                    need(fact.get('method')==identity,f'{profile["label"]} {name}{desc} source map binds another method')
                    bci=fact.get('bci');need(bci in physical,f'{profile["label"]} {name}{desc} source map includes nonphysical BCI {bci}')
                    mapped.add(bci)
            missing=sorted(physical-mapped)
            if missing:
                gaps.append({'name':name,'descriptor':desc,'physical_instruction_count':len(physical),'mapped_bci_count':len(mapped),'missing_physical_bcis':missing,'exception_handler_count':parsed['exception_count']})
        if family in {'fixed','string','integer'}:
            need(not gaps,f'{family} generated body maps have physical coverage gaps: {profile["label"]} {gaps}')
        else:
            need(len(gaps)==1 and gaps[0]['name']=='handled' and gaps[0]['exception_handler_count']==1,f'controls physical map gap set differs: {profile["label"]} {gaps}')
        all_rows.append({'label':profile['label'],'method_count':len(doc.get('methods',[])),'physical_coverage_complete':not gaps,'gaps':gaps})
    return all_rows

def verify_source_map_gaps(run,run_root,profiles,raw,mode):
    rows=[]
    class_name=run['classes'][0]
    for profile in profiles:
        report=load_json(Path(profile['report_pin']['path']))
        target=next((m for m in report['methods'] if bytes(m['item']['identity']['name']).decode()=='handled'),None)
        need(target is not None,'controls recovered report is missing handled method')
        identity=target['item']['identity']; desc=bytes(identity['descriptor']).decode('ascii')
        need(desc==EXPECTED_MAP_GAP['descriptor'],'controls handled descriptor differs')
        class_path,_=physical_class(run,run_root,profile['jdk'],class_name); parsed=PARSER.parse_method(class_path.read_bytes(),'handled',desc)
        physical={pc for pc,_,_ in PARSER.decode(parsed['code'])}
        mapped=set(); rec=target.get('outcome',{}).get('report',{}); segments=rec.get('source_map',{}).get('segments',[])
        for seg in segments:
            origin=seg.get('origin',{});facts=([origin['primary']] if origin.get('primary') is not None else [])+origin.get('derived',[])
            for fact in facts:
                need(fact.get('method')==identity,'controls map fact does not bind handled physical method')
                mapped.add(fact.get('bci'))
        missing=sorted(physical-mapped)
        need(parsed.get('exception_count')==1 and missing,'controls handled handler/source-map gap was not observed from raw report and class')
        javap=next((x for x in run['javap'] if x.get('jdk')==profile['jdk'] and x.get('class')==class_name),None);need(javap is not None,'controls original javap absent')
        command=next(x for x in run['commands'] if x['label']==javap['command']); text=raw[command['index']]['stdout'].decode('utf-8')
        start=text.find('handled('); stop=text.find('\n  public ',start+1)
        section=text[start:stop if stop!=-1 else None]
        need('Exception table:' in section and re.search(r'\b0\s+47\s+50\s+Class\s+java/lang/RuntimeException\b',section),f"controls handled physical RuntimeException table differs: {profile['jdk']}")
        rows.append({'label':profile['label'],'jdk':profile['jdk'],'mode':profile['mode'],'method':'handled','descriptor':desc,'physical_instruction_count':len(physical),'source_origin_bci_count':len(mapped),'missing_physical_bcis':missing,'exception_handler_count':parsed['exception_count'],'runtime_exception_handler_verified':True})
    need(len(rows)==4,'controls expected four default/all x JDK handler maps')
    return rows

def verify_default_all(profiles):
    out=[]
    for jdk in ('javac8','javac23'):
        left=next(x for x in profiles if x['jdk']==jdk and x['mode']=='default');right=next(x for x in profiles if x['jdk']==jdk and x['mode']=='all')
        a=load_json(Path(left['report_pin']['path']));b=load_json(Path(right['report_pin']['path']))
        sig=lambda doc:[(m.get('item',{}).get('identity'),m.get('text'),m.get('outcome',{}).get('report',{}).get('source_map',{}).get('segments')) for m in doc.get('methods',[])]
        need(a.get('text')==b.get('text') and sig(a)==sig(b),f'{jdk} Jarde default/all source or physical maps differ')
        out.append({'jdk':jdk,'class':left['class'],'text_and_source_maps_equal':True})
    return out

def verify_generic_source(family,profiles):
    if family not in {'fixed','string','integer'}: return []
    element='Integer' if family=='integer' else 'String';results=[]
    for profile in profiles:
        path=Path(profile['source_pin']['path']); text=path.read_text(encoding='utf-8')
        need(re.search(r'java\.util\.List<java\.lang\.'+element+r'>',text),f'{family} {profile["label"]}: generic List<{element}> missing')
        need(re.search(r'\.add\(\s*[A-Za-z_$][\w$]*\s*\)',text),f'{family} {profile["label"]}: typed add operand missing')
        need(re.search(r'\.remove\(\s*\(java\.lang\.Object\)\s*[A-Za-z_$][\w$]*\s*\)',text),f'{family} {profile["label"]}: Object remove overload cast missing')
        need(re.search(r'\(java\.lang\.'+element+r'\)\s*iteratorElement',text),f'{family} {profile["label"]}: physical element cast missing')
        results.append({'label':profile['label'],'generic_element':element,'typed_add':True,'object_remove':True,'physical_cast':True})
    return results

def verify_batch():
    batch=load_json(BATCH_PATH); need(batch.get('status')=='captures_complete_not_independently_accepted', 'comparison batch is not terminal/complete')
    tool_pin=PIN_DATA['comparison_tooling']['collector']
    need(digest_file(TOOLING_COLLECTOR)==tool_pin and tool_pin['sha256']==batch.get('collector_sha256'),'batch collector source SHA differs')
    toolpins=load_json(Path(PIN_DATA['comparison_tooling']['collector_pins']['path']))
    need(digest_file(Path(PIN_DATA['comparison_tooling']['collector_pins']['path']))==PIN_DATA['comparison_tooling']['collector_pins'],'collector tooling pins file changed')
    need(toolpins.get('base_collector_sha256')==PIN_DATA['artifacts']['accept_current_comparisons.py'].get('base_collector_sha256', 'a1ed0e68563f09f00b84a509c7caa4595fa6ffb35c4482f875daf97fbec38097'),'comparison collector is not based on prepared v4')
    need(digest_file(Path(PIN_DATA['comparison_tooling']['batch_runner']['path']))==PIN_DATA['comparison_tooling']['batch_runner'],'batch runner source changed')
    rows=batch.get('commands');need(isinstance(rows,list) and len(rows)==8,'batch must contain exactly eight comparison invocations')
    mapped={x.get('label'):x for x in rows};need(len(mapped)==8 and set(mapped)==set(CAPTURES),'batch invocation labels differ from exact 8-capture matrix')
    for key,(family,mode,path,count) in CAPTURES.items():
        row=mapped[key.replace('_','-')];need(row.get('status')=='terminal' and row.get('exit_code')==0 and Path(row.get('capture','')).resolve()==Path(path).resolve(),f'{key} batch invocation failed or capture path differs')
        streams=row.get('streams',{})
        for name in ('stdout','stderr'):
            pin=streams.get(name);need(isinstance(pin,dict) and digest_file(Path(pin['path']))==pin,f'{key} batch {name} raw pin mismatch')
        argv=row.get('argv',[])
        pairs={'--out':path,'--cli':EXPECTED_CLI['path'],'--cli-sha256':EXPECTED_CLI['sha256'],'--build-receipt':FOCUSED_RECEIPT['path'],'--build-receipt-sha256':FOCUSED_RECEIPT['sha256'],'--source-debug':mode}
        for flag,value in pairs.items():
            need(flag in argv and argv[argv.index(flag)+1]==value,f'{key} invocation {flag} differs')
        need(str(TOOLING_COLLECTOR) in argv,f'{key} collector path differs')
    return batch,rows

def verify_original_class_anchor(run,run_root,family,mode):
    entry=PIN_DATA.get('compiled_class_anchors',{}).get(family,{}).get(mode)
    if entry is None:
        need((family,mode)==('fixed','none'),'missing original class compilation anchor')
        return {'anchor_bound':False,'reason':'no separate frozen fixed -g:none baseline was supplied'}
    path=Path(entry['execution']['path']);need(digest_file(path)==entry['execution'],f'{family}/{mode} old compiler class anchor receipt changed')
    old=load_json(path);need(old.get('status')=='observed' and old.get('compiler_debug_info',mode)==mode,f'{family}/{mode} old class anchor is not observed in requested mode')
    need(old.get('classes')==run.get('classes') and old.get('input_entries')==run.get('input_entries'),f'{family}/{mode} class anchor fixture differs')
    checked=[];name=run['classes'][0].split('.')[-1]+'.class'
    for jdk in ('javac8','javac23'):
        current,_=physical_class(run,run_root,jdk,run['classes'][0])
        oldrow=next((x for x in old['original_compile_rows'] if x['label']==f'{jdk}-original'),None)
        pin=next((x for x in oldrow.get('classes',[]) if Path(x['path']).name==name),None) if oldrow else None
        need(pin is not None,f'{family}/{mode}/{jdk} old original class pin absent')
        frozen_pin=entry.get('physical_class_pins',{}).get(jdk);need(isinstance(frozen_pin,dict) and digest_file(Path(frozen_pin['path']))==frozen_pin and frozen_pin['bytes']==pin['bytes'] and frozen_pin['sha256']==pin['sha256'],f'{family}/{mode}/{jdk} frozen original class bytes changed')
        actual=digest_file(current);need(actual['bytes']==pin['bytes'] and actual['sha256']==pin['sha256'],f'{family}/{mode}/{jdk} original class differs from frozen baseline')
        b3=BLAKE3.blake3(current.read_bytes()).hexdigest();expected=entry['physical_class_blake3'][jdk]
        need(b3==expected,f'{family}/{mode}/{jdk} original physical class BLAKE3 differs from pins')
        checked.append({'jdk':jdk,'bytes':actual['bytes'],'sha256':actual['sha256'],'blake3':b3})
    return {'anchor_bound':True,'execution':entry['execution'],'physical_classes':checked}

def verify_capture(key,spec,anchor_run,oracle):
    family,mode,root_text,expected_count=spec; root=Path(root_text); execution=root/'execution.json'
    run=load_json(execution);need(run.get('schema')=='cf11-target-full-source-capture-v2' and run.get('status')=='observed',f'{key} capture not observed')
    need(run.get('compiler_debug_info')==mode and run.get('collector_config',{}).get('source_debug')==mode,f'{key} debug mode differs')
    need(run.get('classes')==anchor_run.get('classes'),f'{key} target class differs from frozen baseline family')
    need(run.get('input_entries')==anchor_run.get('input_entries'),f'{key} input manifest differs from exact baseline fixture')
    need(run.get('inputs_manifest_path')==anchor_run.get('inputs_manifest_path'),f'{key} input manifest path differs from frozen baseline')
    need(digest_file(Path(run['inputs_manifest_path']))==run['inputs_manifest'],f'{key} inputs manifest pin differs')
    cfg=run.get('collector_config',{}); base_cfg=anchor_run.get('collector_config',{})
    for field in ('inputs_dir','inputs_manifest','jdk_manifest','jdk_manifest_sha256','jadx','jadx_sha256','jadx_jar','jadx_jar_sha256','guard','guard_sha256','scanner','scanner_sha256','classfile_parser','classfile_parser_sha256'):
        need(cfg.get(field)==base_cfg.get(field),f'{key} frozen collector input/tool pin differs: {field}')
    need(cfg.get('cli')==EXPECTED_CLI['path'] and cfg.get('cli_sha256')==EXPECTED_CLI['sha256'],f'{key} selected CLI configuration differs')
    need(cfg.get('build_receipt')==FOCUSED_RECEIPT['path'] and cfg.get('build_receipt_sha256')==FOCUSED_RECEIPT['sha256'],f'{key} selected focused build receipt differs')
    need(cfg.get('receipt_cli_object')=='cli_freeze' and cfg.get('receipt_accepted_value')=='passed_initial_product_validation',f'{key} focused receipt binding options differ')
    need([x.get('label') for x in run.get('commands',[])]==[x.get('label') for x in anchor_run.get('commands',[])],f'{key} command label sequence differs from baseline collector matrix')
    need(len(run.get('commands',[]))==expected_count and run.get('actual_command_count')==expected_count,f'{key} command count differs')
    need(run.get('resource_guard')=={'minimum_free_bytes':MIN_FREE,'maximum_target_bytes':MAX_TARGET,'poll_seconds':1,'peak_target_sampled':True},f'{key} resource guard differs')
    verify_source_tool_pins(run);raw=verify_raw_streams(run,root)
    for row in run['commands']:
        if row['label'].endswith('-compile'):
            flags=[x for x in row['argv'] if x in ('-g','-g:none')]
            need(flags==(['-g:none'] if mode=='none' else ['-g']),f'{key} javac debug compile flag differs: {row["label"]}')
    labels=original_rows(run,raw,family,oracle)
    original_class_anchor=verify_original_class_anchor(run,root,family,mode)
    need(len(run.get('original_compile_rows',[]))==2,f'{key} original JDK inventory differs')
    for row in run['original_compile_rows']:
        need(row.get('class_set_exact') is True and row.get('run_exit')==0,f'{key} original compile/run class inventory differs')
    profiles=run.get('jarde_profiles',[]);need(len(profiles)==4 and {(x.get('jdk'),x.get('mode')) for x in profiles}=={(j,m) for j in ('javac8','javac23') for m in ('default','all')},f'{key} Jarde profile inventory differs')
    class_name=run['classes'][0]
    fingerprints=[verify_rendered_class_b3(run,root,x) for x in profiles]
    for profile in profiles:
        command=next((x for x in run['commands'] if x.get('label')==profile.get('render_command')),None)
        need(profile.get('render_exit')==0 and command is not None and command.get('exit_code')==0,f'{key} Jarde render command failed: {profile.get("label")}')
        need(profile.get('render_stdout_sha256')==sha(raw[command['index']]['stdout']) and profile.get('render_stderr_sha256')==sha(raw[command['index']]['stderr']),f'{key} Jarde render raw stream hash differs: {profile.get("label")}')
    default_all=verify_default_all(profiles)
    compile=verify_compile_groups(run,raw,family,class_name,mode,oracle)
    body_maps=verify_physical_body_maps(run,root,profiles,family)
    gaps=verify_source_map_gaps(run,root,profiles,raw,mode) if family=='controls' else []
    source_types=verify_generic_source(family,profiles)
    javap=verify_debug_javap(run,raw,mode,root) if mode=='none' else []
    return {'key':key,'family':family,'mode':mode,'execution':digest_file(execution),'class':class_name,'command_count':expected_count,'raw_stream_count':expected_count*2,'original_oracle_labels':labels,'original_oracle_sha256':sha(oracle),'original_oracle_bytes':len(oracle),'original_oracle_rows':oracle.decode('utf-8').splitlines(),'original_class_anchor':original_class_anchor,'source_tool_pin_count':len(run['source_tool_pins_before']),'source_tool_pins_stable_and_live':True,'physical_class_b3_and_body_maps':fingerprints,'default_all':default_all,'compile_observation':compile,'generic_source_checks':source_types,'physical_body_maps':body_maps,'handler_source_map_gaps':gaps,'no_debug_javap':javap}

def verify_all():
    global PIN_DATA,BLAKE3,PARSER
    PIN_DATA=load_json(PIN_PATH)
    need(PIN_DATA.get('schema')=='cf11-current-comparison-acceptance-preparation-pins-v1' and PIN_DATA.get('status')=='prepared_not_executed','preparation pins schema/status differs')
    need(PIN_DATA.get('captures')=={k:{'family':v[0],'mode':v[1],'path':v[2],'commands':v[3]} for k,v in CAPTURES.items()},'capture matrix differs from pins')
    need(PIN_DATA.get('expected_oracle_labels')=={k:sorted(v) for k,v in EXPECTED_LABELS.items()},'exact expected oracle labels differ from pins')
    need(PIN_DATA.get('expected_totals')=={'oracle_labels':{'fixed':8,'string':5,'integer':6,'controls':17,'distinct_union':36},'command_count':224,'raw_stream_count':448,'positive_compile_run_pairs':48,'controls_negative_compile_groups':24,'controls_handler_gaps_per_mode':4},'acceptance totals differ from pins')
    script_pin=PIN_DATA.get('artifacts',{}).get('accept_current_comparisons.py');need(isinstance(script_pin,dict) and digest_file(Path(__file__))==script_pin,'acceptance script differs from its pins')
    for key,entry in PIN_DATA.get('baseline_provenance',{}).items():
        if key=='six_capture_summary' or key=='baseline_summary_checker' or key=='baseline_summary_prep_pins':
            need(digest_file(Path(entry['path']))==entry,f'baseline provenance pin changed: {key}')
        else:
            for field in ('observation','execution'):
                if field in entry: need(digest_file(Path(entry[field]['path']))==entry[field],f'baseline provenance pin changed: {key}/{field}')
    need(digest_file(PARSER_PATH)['sha256']==PARSER_SHA256 and digest_file(PARSER_PATH)==PIN_DATA.get('classfile_parser'),'pinned classfile parser differs')
    need(digest_file(TOOLING_COLLECTOR)==PIN_DATA.get('comparison_tooling',{}).get('collector'),'comparison collector source differs from pins')
    PARSER=pinned_module('cf11_current_comparison_classfile_parser',PARSER_PATH,PARSER_SHA256)
    BLAKE3,b3before=load_blake3()
    batch,batch_rows=verify_batch()
    anchors={family:oracle_for(family) for family in ORACLE_ANCHORS}
    results={key:verify_capture(key,spec,*anchors[spec[0]]) for key,spec in CAPTURES.items()}
    # All eight original-JDK executions match the external frozen baseline bytes. The pair check is explicit too.
    for family in EXPECTED_LABELS:
        left=results[family+'_debug'];right=results[family+'_none']
        need(left['original_oracle_labels']==right['original_oracle_labels'] and left['original_oracle_sha256']==right['original_oracle_sha256'],f'{family} debug/no-debug oracle differs')
        need(set(left['original_oracle_labels'])==EXPECTED_LABELS[family],f'{family} exact labels differ')
    need(len(set().union(*(EXPECTED_LABELS[x] for x in EXPECTED_LABELS)))==36,'expected family label union differs')
    need(sum(x['command_count'] for x in results.values())==224,'eight-capture command count differs from 224')
    need(sum(x['raw_stream_count'] for x in results.values())==448,'eight-capture raw stream count differs from 448')
    positives=sum(x['compile_observation'].get('positive_compile_run_pairs',0) for x in results.values())
    negatives=sum(x['compile_observation'].get('negative_compile_groups',0) for x in results.values())
    need(positives==48 and negatives==24,'positive/negative compile totals differ')
    debug_gaps=results['controls_debug']['handler_source_map_gaps'];none_gaps=results['controls_none']['handler_source_map_gaps']
    gap_key=lambda x:(x['jdk'],x['label'],tuple(x['missing_physical_bcis']),x['exception_handler_count'])
    need(sorted(map(gap_key,debug_gaps))==sorted(map(gap_key,none_gaps)),'controls debug/no-debug handler map gaps differ')
    b3after=blake3_inventory();need(b3after==PIN_DATA['blake3_dependency']['files_after_check'] and b3after==b3before,'blake3 package inventory changed during verification')
    return {'schema':'cf11-current-comparison-observation-acceptance-v1','status':'verified_current_saved_comparison_observations','product_acceptance':False,'task1_2_complete':False,'acceptance_scope':'integrity, exact frozen-oracle equality, body-map and generated-class comparison evidence only','batch_execution':digest_file(BATCH_PATH),'batch_terminal_invocations':len(batch_rows),'capture_count':len(results),'actual_command_count':224,'raw_stream_count':448,'oracle_labels':{k:sorted(v) for k,v in EXPECTED_LABELS.items()},'oracle_label_counts':{k:len(v) for k,v in EXPECTED_LABELS.items()},'oracle_family_union_count':36,'debug_none_oracles_equal':True,'positive_compile_run_pairs':48,'combined_failed_compile_groups':24,'controls_compile_failures_without_runtime':True,'controls_handler_gap_count_per_mode':4,'blake3_package_files_unchanged':True,'captures':list(results.values()),'remaining_limitations':['This check does not establish task 1.2 completion or product acceptance.','Stopping/negative-SSA attribution remains outside this comparison batch.']}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
    out=args.out.resolve();need(not out.exists(),f'refuse overwrite: {out}')
    result=verify_all();out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':result['status'],'out':str(out),'captures':result['capture_count'],'commands':result['actual_command_count'],'product_acceptance':False,'task1_2_complete':False},ensure_ascii=False))

if __name__=='__main__':
    try: main()
    except (ValueError,KeyError,OSError,TypeError) as error:
        print(f'REJECTED: {type(error).__name__}: {error}',file=sys.stderr);raise SystemExit(1)
