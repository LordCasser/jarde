# 当前 CF11 对照批次独立验收器（准备版）

`accept_current_comparisons.py` 是只读验收脚本，面向 root 串行运行的 8 份 fixed、String、Integer、controls 的 debug / `-g:none` 完整类采集。它不调用 Cargo、JDK、Git 或网络，也不改写 capture。只有在 batch receipt 已记录 8 次命令 terminal/exit 0、8 份 capture 均为 `observed` 后才会接受观察材料。

脚本复用上一轮已独立验收的六份 baseline pins、原始 JDK stdout、输入 manifest 和 frozen source files。新 capture 的 JDK8/JDK23 原始输出会与对应旧 oracle 逐字节比较，因此每一行 label、异常、列表状态及 effects 都有外部锚点。它也检查 source/tool before/after pin、CLI 和 focused receipt、完整 command/raw inventory、JDK8/23、debug flags、原始 class SHA-256 与 BLAKE3、每个方法的真实 class identity、recovery method identity、所有 source-map origin owner，以及 default/all 报告稳定性。

fixed、String、Integer 的每组 8 个 Jarde/JADX 生成类都必须完整编译和运行，输出与旧 oracle 原字节一致。Jarde source 另检查对应 `List<String>` / `List<Integer>`、类型正确的 `add` operand、保留 `remove((Object)...)` 重载，以及由原始 iterator value 到元素类型的物理 cast。controls 仍要求恰好 12 个编译失败、零失败后运行命令；handler map gaps 从原始报告和 classfile BCI 独立计算，并与真实异常表核对。`-g:none` 的 javap 必须没有行号/局部变量表，同时保留泛型 Signature。

准备目录没有把数 MB 的 source manifests/raw files复制进来。pins 只冻结旧 oracle execution/manifest/stdout、基线验收 provenance、BLAKE3 包清单和运行工具路径；验收时脚本从原路径逐项读取并重算 SHA。当前批次的最终执行 receipt 在验收时读取并由结果摘要绑定。

root 审阅后可运行：

```sh
python3 -B /private/tmp/jarde-cf11-structured-list-current-comparison-accept-prep-luna-v1/accept_current_comparisons.py \
  --out /private/tmp/jarde-cf11-structured-list-current-comparison-acceptance-root-v1.json
```

即使全部检查通过，输出也明确保持 `product_acceptance=false`、`task1_2_complete=false`。该脚本只核实已保存对照证据，不替代产品验收或停止/negative-SSA 归因。
