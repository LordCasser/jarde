# Structured-list final main audit v2

Private read-only audit preparation. Status is `prepared_not_executed`; no Git command was run here. The script is intended to run only after final documentation is pushed, with the actual product commit and final docs HEAD supplied as arguments.

It checks: exact `HEAD == main == origin/main == git ls-remote origin/main`; only local branch `main`; product commit `ca45c0ed2193fa8709eeba1196ef325f1804f63e` is an ancestor of docs HEAD; exactly 15 physical worktrees (root plus 14 auxiliary), with all auxiliary worktrees detached; all worktrees clean, ancestors of main, and without `target` or `fuzz/target`; and all 4,822 source paths from the pinned focused v12 receipt have identical SHA-256 bytes in the focused manifest, selected product commit, docs HEAD, and live repository.

Source closure field names were checked against v8 verifier source. The focused v12 execution uses `source_manifest_before` / `source_manifest_after`, a list of `{path, bytes, sha256}` rows, and `source_manifest_before_count`; this script checks the two manifests match and contain 4,822 distinct paths. It independently reads Git tree entries and hashes blob contents through `git cat-file --batch`.

The own-CI v8 acceptance and final-validation chain are not re-parsed here. Their actual summary SHA-256 values are required as argv references and recorded in the output so the final main audit can point back to those independently accepted results. They are not treated as proof that those chains passed by this script.

The v1 directory contains an old-product reference copy and is not an executable audit. Use only this v2 script after the root agent reviews it and supplies actual final docs HEAD, final receipt SHA, and own-CI summary SHA. Output must be a new directory outside the repository.

```text
python3 /private/tmp/jarde-structured-list-clean-main-audit-prep-luna-v2/audit-clean-main.py \
  <NEW_OUTSIDE_REPO_DIR> ca45c0ed2193fa8709eeba1196ef325f1804f63e <ACTUAL_FINAL_DOCS_HEAD> \
  --focused-receipt /private/tmp/jarde-cf11-structured-list-focused-root-v12/execution.json \
  --focused-receipt-sha256 74350dfc154c2fd77aa8a9636dd8d29b301eb119e167be56a0f18af011996a73 \
  --final-receipt-sha256 <ACTUAL_ACCEPTED_FINAL_RECEIPT_SHA256> \
  --own-ci-summary-sha256 <ACTUAL_OWN_CI_V8_ACCEPTANCE_SHA256>
```

`accepted_clean_main` can only be emitted by executing against current Git and filesystem state. Preparation and old audits do not count as acceptance.
