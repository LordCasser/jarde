# CF11 local initializer inventory candidate

Candidate is based on shared `crates/jarde-java/src/report.rs` SHA-256 `9cb61aa15ea2a86a4e1d5421f95e3456c3119ff0a0ad3bd9ecdc4a63bdf33b82`. It changes only the existing `class_source_local_assignments` retained-AST inventory. Shared files were not edited; no formatter, Rust build, JDK, or JADX was run.

The collector now records `Declare { value: Some(..) }` and `Assign` through the same `ClassSourceAstLocalAssignment` fields (`bci`, `name`, `value_bci`, `cast_type`, and lexical `scope_anchors`). It preserves the existing explicit stack traversal, per-statement polling, and metadata charging. Initializers are not filtered to preserve usage counts; the inventory cardinality and the caller's existing proof-work bound naturally include them. It does not expand the body-consumer allowlist or add an AST/carrier.

Root's API regression test is already present in the current test file and references repository-relative frozen fixture `tests/fixtures/cf11-structured-list-inner-option/DistinctIntegerFixture.class`; therefore this candidate leaves the test file unchanged. Its documented inner value has physical `checkcast` BCI 52 and store BCI 55. This patch reports `statement.origin.primary().bci()` as the initializer/store statement BCI and `value.origin.primary().bci()` as the cast BCI, so the serial API run will confirm the AST origins join exactly to 55 and 52. If declaration origin differs from the physical store, the production proof should conservatively refuse and root should inspect that origin rather than weakening the BCI join.

No test or runtime result is claimed here. The permanent API inner-option test is prepared in the existing root test file; root must apply this patch and run its serial v8 checks.
