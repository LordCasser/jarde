from pathlib import Path
import json,hashlib,importlib.util,sys,re,collections
sys.dont_write_bytecode=True
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');IN=Path('/private/tmp/jarde-cf11-list-ssa-diagnostic-root-v3');PREP=Path('/private/tmp/jarde-cf11-list-ssa-diagnostic-root-v3-review-v1');OUT=Path(__file__).parent

def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(name,p,h):
 assert sha(p)==h,(p,sha(p));s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
p=load('facts_parser',PREP/'parse_facts.py','ed7c46b2a4fee55444f141394e10fc11e9beae7b6aef94ce2824832103755f4c')
c=load('class_parser',Path('/private/tmp/jarde-computed-for-cf07-final-replay-verifier-root-v4.py'),'f30754e1e52403713a671ce38f274b772f188583df6c4a1bc6b4400937233469')
d=json.loads((IN/'execution.json').read_text());assert d['status']=='captured_same_run_facts_pending_review';assert len(d['commands'])==7
assert d['commands'][0]['exit_code']==101 and [x['exit_code'] for x in d['commands'][1:]]==[0]*6
assert d['source_pins_before']==d['source_pins_restored']==d['source_pins_after_clean'] and len(d['source_pins_before'])==4822
assert d['source_restored'] and d['cleanup']=={'status':'passed','target_absent':True}
assert d['rust_min_stack'] is None and d['guard_limits']=={'minimum_free_bytes':5*1024**3,'maximum_target_bytes':1024**3,'poll_interval_seconds':1}
assert [k for k in d['source_pins_before'] if d['source_pins_before'][k]!=d['source_pins_instrumented'][k]]==['crates/jarde-java/src/report.rs']
focused=json.loads(Path('/private/tmp/jarde-cf11-structured-list-focused-root-v9/execution.json').read_text());assert {x['path']:x['sha256'] for x in focused['source_manifest_after']}==d['source_pins_before']
for row in d['commands']:
 assert row['guard_stop'] is None
 for stream in row['streams'].values():
  f=Path(stream['path']);assert f.stat().st_size==stream['bytes'] and sha(f)==stream['sha256']
for i in range(1,6):assert re.search(r'test result: ok\. 1 passed; 0 failed; 0 ignored;',Path(d['commands'][i]['streams']['stdout']['path']).read_text())
files={('fixed','cf11/UpstreamNestedLoops'):'cf11-structured-list-api/UpstreamNestedLoops.class',('controls','cf11/UpstreamNestedLoops'):'cf11-structured-list-controls/UpstreamNestedLoops.class',('distinct','cf11/DistinctStringFixture'):'cf11-structured-list-api/DistinctStringFixture.class',('distinct','cf11/DistinctIntegerFixture'):'cf11-structured-list-api/DistinctIntegerFixture.class',('inner','cf11/DistinctIntegerFixture'):'cf11-structured-list-inner-option/DistinctIntegerFixture.class',('null','cf11/NullStringListFixture'):'cf11-structured-list-null-api/NullStringListFixture.class',('null','cf11/NullIntegerListFixture'):'cf11-structured-list-null-api/NullIntegerListFixture.class'}
events=[];rawlines=[]
for i in range(1,6):
 for line in (IN/f'{i}.stderr.raw').read_text().splitlines():
  if line.startswith('JARDE_LIST_SSA event=structured_facts '):events.append(p.parse_event(line,f'{i}.stderr.raw'));rawlines.append(line)
assert len(events)==18
assert events==json.loads((PREP/'facts.json').read_text())['events']
expected=collections.Counter({('controls',n):1 for n in ['test','renamed','numbers','castBoundary','rawLists','rawAliasEscape','reassigned','wildcardNull','handled','indexOverload']});expected.update({('fixed','test'):3,('distinct','renamed'):1,('distinct','numbers'):1,('inner','numbers'):1,('null','strings'):1,('null','integers'):1});assert collections.Counter((e['label'],e['method']) for e in events)==expected
checks=['ssa_definitions_all_parsed','ssa_local_effect_accesses_match','census_exact_code_bci_set','one_ssa_row_per_code_bci','one_effect_row_per_code_bci','one_operation_per_code_bci','no_extra_ssa_rows','no_extra_effect_rows','no_missing_operations']
accepted=[]
for e,line in zip(events,rawlines):
 assert all(e['checks'][k] for k in checks)
 path=ROOT/'tests/fixtures'/files[(e['label'],e['class'])];rel=str(path.relative_to(ROOT));assert sha(path)==d['source_pins_before'][rel]
 physical=c.parse_method(path.read_bytes(),e['method'],e['descriptor']);raw=c.decode(physical['code']);assert physical['owner']==e['class']
 assert [(r['bci'],r['opcode']) for r in e['code_instructions']]==[(b,o) for b,o,_ in raw]
 assert e['checks']['code_instruction_rows']==e['checks']['code_unique_bcis']==len(raw)==len(e['census_rows'])==len(e['operations'])
 assert e['checks']['handler_present']==(physical['exception_count']!=0)
 bciset={b for b,_,_ in raw};rows={r['bci']:r for r in e['census_rows']};slots={1,2,3,4} if e['method']=='indexOverload' else {1,2}
 assert sorted(int(x) for x in re.findall(r'\d+',p.field_value(line,'parameter_slots','{')))==sorted(slots)
 all_access=[]
 for r in e['census_rows']:
  sf=p.split_tuple(r['ssa_rows'][0]);ef=p.split_tuple(r['effect_rows'][0]);assert int(sf[0])==int(ef[0])==r['bci'];assert int(sf[2])==int(ef[2])==r['opcode']==r['effective_opcode'];assert sf[1]==ef[1]
  accesses=[]
  for f in sf[3:5]:
   rr=[{'slot':int(a),'value':int(v)} for a,v in re.findall(r'Local\((\d+)\), ValueId\((\d+)\)',f) if int(a) in slots];accesses.append(rr)
   assert all(int(v)<len(e['ssa_values']) for v in re.findall(r'ValueId\((\d+)\)',f))
  if any(accesses):all_access.append({'bci':r['bci'],'opcode':r['opcode'],'reads':accesses[0],'writes':accesses[1]})
  op=next(x['operation'] for x in e['operations'] if x['bci']==r['bci']);assert r['operation']=='Some('+op+')'
 assert sorted(all_access,key=lambda r:r['bci'])==sorted(e['parameter_accesses'],key=lambda r:r['bci'])
 for v in e['ssa_values']:
  assert all(u['bci'] is None or u['bci'] in bciset for u in v['uses'])
  if v['definition'].startswith('Instruction'):
   b=int(re.findall(r'\bbci: (\d+)',v['definition'])[-1]);assert b in bciset
 if e['method']=='rawAliasEscape':assert e['direct_load_values'][0]['direct_receiver_calls']==[] and [u['bci'] for u in e['direct_load_values'][0]['uses']]==[1] and rows[1]['operation']=='Some(Store { slot: 3 })'
 if e['method']=='reassigned':assert all_access[1]['writes']==[{'slot':1,'value':8}] and all_access[2]['reads']==[{'slot':1,'value':8}]
 if e['method']=='handled':assert physical['exception_count']==1 and 'start_bci: 0, end_bci: 47, handler_bci: 50' in p.field_value(line,'code_handlers','[') and any(v['definition'].startswith('Caught') for v in e['ssa_values'])
 if e['method']=='indexOverload':assert [(x['bci'],x['descriptor']) for x in e['invokes'] if x['name']=='remove']==[(2,'(Ljava/lang/Object;)Z'),(11,'(I)Ljava/lang/Object;')]
 if e['label']=='null' or e['method']=='wildcardNull':
  b=77 if e['label']=='null' else 28;assert rows[b]['opcode']==1;sf=p.split_tuple(rows[b]['ssa_rows'][0]);vid=int(re.search(r'ValueId\((\d+)\)',sf[4]).group(1));assert [u['bci'] for u in e['ssa_values'][vid]['uses']]==[b+1];assert f'Stack(1), ValueId({vid})' in p.split_tuple(rows[b+1]['ssa_rows'][0])[3];assert 'name: "add", descriptor: "(Ljava/lang/Object;)Z"' in rows[b+1]['operation']
 accepted.append({'label':e['label'],'class':e['class'],'method':e['method'],'class_path':rel,'class_sha256':sha(path),'code_instructions':len(raw),'ssa_values':len(e['ssa_values']),'physical_cast_bcis':[b for b,o,_ in raw if o==192],'formal_accesses':all_access})
javap=Path('/private/tmp/jarde-cf11-structured-list-current-controls-debug-root-v1/legs/javac23-original/javap-UpstreamNestedLoops.txt');assert sha(javap)=='be9ab52548fd4088dc7248591bfcf200058ca178e02e6c16bbda2085da44d760';text=javap.read_text();wild=text[text.index('public void wildcardNull('):text.index('public void handled(')];assert '// (Ljava/util/List<+Ljava/lang/Number;>;Ljava/util/List<Ljava/lang/Number;>;)V' in wild
summary={'status':'accepted_same_run_physical_and_ssa_observations','scope':'Code/SSA/effects/operations plus physical javap Signature supplement; not a workspace or product delivery pass','capture_sha256':sha(IN/'execution.json'),'review_parser_sha256':sha(PREP/'parse_facts.py'),'root_acceptor_sha256':sha(Path(__file__)),'restored_source_count':4822,'events':accepted,'wildcard_signature_javap':{'path':str(javap),'sha256':sha(javap),'signature':'(Ljava/util/List<+Ljava/lang/Number;>;Ljava/util/List<Ljava/lang/Number;>;)V'},'reader_census_independent_attribution':json.loads(Path('/private/tmp/jarde-cf11-reader-census-attribution-root-v1/summary.json').read_text())}
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print('Accepted 18 same-run fact records, 7 frozen class inputs, exact physical Code inventories, explicit SSA refusal controls, and wildcard Signature supplement.')
