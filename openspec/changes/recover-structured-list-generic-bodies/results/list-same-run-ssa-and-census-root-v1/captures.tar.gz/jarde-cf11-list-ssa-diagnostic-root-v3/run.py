from pathlib import Path
import json,hashlib,importlib.util,os,subprocess,datetime,time,shutil
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');OUT=Path(__file__).resolve().parent
PREP=Path('/private/tmp/jarde-cf11-list-ssa-diagnostic-prep-luna-v2')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def module(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
closure=module('workspace_closure',Path('/private/tmp/jarde-cf11-final-validation-prep-luna-v1/workspace_runner.py'))
guard=module('diagnostic_guard',ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py')
scan=module('diagnostic_scan',ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py')
guard.ROOT=ROOT;guard.OUT=OUT;guard.FREE_LIMIT=5*1024**3;guard.TARGET_LIMIT=1024**3;guard.target_bytes=lambda:scan.target_bytes(ROOT)
guard.expected_test_summaries=lambda i,raw:None
guard.command_stream=lambda p:{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
assert not (ROOT/'target').exists() and shutil.disk_usage(ROOT).free>=guard.FREE_LIMIT
pins=json.loads((PREP/'pins.json').read_text());report=ROOT/'crates/jarde-java/src/report.rs';base=report.read_bytes()
for relative,pin in pins['source_before'].items():
 p=ROOT/relative;assert p.stat().st_size==pin['bytes'] and sha(p)==pin['sha256'],relative
assert base==(PREP/'report.rs.base').read_bytes()
source_before=closure.pin_sources(closure.source_paths());env=os.environ.copy()
for k in ('RUST_MIN_STACK','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH'):env.pop(k,None)
env.update(guard.ENV_VALUES)
record={'schema':'cf11-list-same-run-ssa-diagnostic-root-v1','status':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_pins_before':source_before,'diagnostic_patch_sha256':sha(PREP/'diagnostic.patch'),'prep_pins_sha256':sha(PREP/'pins.json'),'commands':[],'rust_min_stack':env.get('RUST_MIN_STACK'),'guard_limits':{'minimum_free_bytes':guard.FREE_LIMIT,'maximum_target_bytes':guard.TARGET_LIMIT,'poll_interval_seconds':1}}
def save():
 p=OUT/'execution.json.tmp';p.write_text(json.dumps(record,indent=2)+'\n');p.replace(OUT/'execution.json')
def run(argv,label,allowed):
 env['JARDE_LIST_SSA_DIAGNOSTIC_LABEL']=label;guard.ENV_VALUES={**guard.ENV_VALUES,'JARDE_LIST_SSA_DIAGNOSTIC_LABEL':label}
 row=guard.run_command(len(record['commands']),argv,env);record['commands'].append(row);save()
 assert row['guard_stop'] is None and row['exit_code'] in allowed,(label,row['exit_code'],row['guard_stop'])
 print(json.dumps({'label':label,'exit_code':row['exit_code'],'index':row['index']}),flush=True)
try:
 save()
 run(['cargo','test','-p','jarde-reader','--lib','--locked','repository_class_fixtures_validate_without_false_target_rejections','--','--nocapture'],'reader-census-before-registration',{101})
 raw=(OUT/'0.stdout.raw').read_text()+(OUT/'0.stderr.raw').read_text()
 import re
 match=re.search(r'left: \((\d+), (\d+), (\d+), (\d+), (\d+)\)',raw);assert match
 actual=[int(x) for x in match.groups()];assert actual[:3]==[1140,5018,474] and actual[4]==10
 assert 'right: (1133, 4995, 473, 3048, 10)' in raw
 record['reader_census_observation']={'measured':actual,'old_expected':[1133,4995,473,3048,10],'status':'actual_expected_registration_failure','branch_delta_pending_independent_attribution':True};save()
 report.write_bytes((PREP/'report.rs.candidate').read_bytes());record['source_pins_instrumented']=closure.pin_sources(closure.source_paths());save()
 expected=dict(source_before);expected['crates/jarde-java/src/report.rs']=sha(report);assert record['source_pins_instrumented']==expected
 for label,name in [('controls','nearby_list_controls_refuse_only_unproved_generic_projections'),('fixed','fixed_nested_string_body_projects_source_and_preserves_physical_origins'),('distinct','differently_named_string_and_integer_classes_follow_their_list_element_type'),('inner','inner_list_option_actual_uses_the_receiver_element_type'),('null','exact_list_null_add_removes_only_the_synthetic_object_wrapper')]:
  run(['cargo','test','--test','structured_list_generic_bodies','--locked',name,'--','--exact','--nocapture'],label,{0})
  text=(OUT/f'{len(record["commands"])-1}.stdout.raw').read_text();assert f'test {name} ... ok' in text and '1 passed; 0 failed;' in text
  assert closure.pin_sources(closure.source_paths())==expected
 record['status']='captured_same_run_facts_pending_review'
except BaseException as e:
 record['status']='failed';record['error']=f'{type(e).__name__}: {e}'
finally:
 report.write_bytes(base);record['source_pins_restored']=closure.pin_sources(closure.source_paths());record['source_restored']=record['source_pins_restored']==source_before;save()
 index=len(record['commands']);start=time.monotonic();before={'free_bytes':shutil.disk_usage(ROOT).free,'target_bytes':guard.target_bytes()}
 with (OUT/f'{index}.stdout.raw').open('xb') as o,(OUT/f'{index}.stderr.raw').open('xb') as e:r=subprocess.run(['cargo','clean'],cwd=ROOT,env=env,stdout=o,stderr=e)
 row={'index':index,'argv':['cargo','clean'],'exit_code':r.returncode,'guard_stop':None,'duration_seconds':time.monotonic()-start,'streams':{k:guard.command_stream(OUT/f'{index}.{k}.raw') for k in ['stdout','stderr']},'cleanup_only':{'exact_argv':['cargo','clean'],'space_precheck_bypassed':True,'space_monitor_abort_bypassed':True,'observed_before':before,'observed_after':{'free_bytes':shutil.disk_usage(ROOT).free,'target_bytes':guard.target_bytes()}}};record['commands'].append(row)
 record['cleanup']={'status':'passed' if r.returncode==0 and not (ROOT/'target').exists() else 'failed','target_absent':not (ROOT/'target').exists()};record['source_pins_after_clean']=closure.pin_sources(closure.source_paths());record['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 if not record['source_restored'] or record['source_pins_after_clean']!=source_before or record['cleanup']['status']!='passed':record['status']='failed';record.setdefault('error','restore/clean postcondition failed')
 save()
print(json.dumps({'status':record['status'],'error':record.get('error'),'command_count':len(record['commands']),'source_restored':record['source_restored'],'cleanup':record['cleanup']}),flush=True)
raise SystemExit(0 if record['status']=='captured_same_run_facts_pending_review' else 1)
