from pathlib import Path
import sys,os,json,importlib.util,hashlib,subprocess,datetime,re
sys.dont_write_bytecode=True
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');OUT=Path(__file__).parent

def h(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(name,p,want):
 assert h(p)==want
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
G=ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py';S=ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py';W=Path('/private/tmp/jarde-cf11-final-validation-prep-luna-v1/workspace_runner.py')
g=load('guard',G,'51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33');s=load('scanner',S,'d954cd53555e261b2033ead9fa601db51ef24a0a2602d2cb770a5413dbf0a8a7');w=load('closure',W,'9829756111034ec84d1fb48c2d9481c4081b85740902d00c019f969be3bdc36f')
g.ROOT=ROOT;g.OUT=OUT;g.FREE_LIMIT=5*1024**3;g.TARGET_LIMIT=1024**3;g.target_bytes=lambda:s.target_bytes(ROOT);g.expected_test_summaries=lambda i,raw:None;g.command_stream=lambda p:{'path':str(p),'bytes':p.stat().st_size,'sha256':h(p)}
env=os.environ.copy()
for k in ('RUST_MIN_STACK','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','CARGO_TARGET_DIR'):env.pop(k,None)
env.update(g.ENV_VALUES);d={'status':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runner_sha256':h(Path(__file__)),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'commands':[],'guard_limits':[5*1024**3,1024**3,1],'source_before_fmt':w.pin_sources(w.source_paths()),'rust_min_stack':env.get('RUST_MIN_STACK')}
def save():(OUT/'execution.json').write_text(json.dumps(d,indent=2)+'\n')
def run(argv):
 row=g.run_command(len(d['commands']),argv,env);d['commands'].append(row);save();print(row['index'],row['exit_code'],argv,flush=True);assert row['exit_code']==0 and row['guard_stop'] is None;return row
save()
try:
 run(['cargo','fmt','--all']);d['source_after_fmt']=w.pin_sources(w.source_paths());save()
 for argv,expected in [(['cargo','test','-p','jarde-java','--lib','--locked','generic_void_parameter_census_tests','--','--nocapture'],(4,0,0)),(['cargo','test','-p','jarde-reader','--lib','--locked','repository_class_fixtures_validate_without_false_target_rejections','--','--nocapture'],(1,0,0)),(['cargo','test','-p','jarde','--test','p5_corpus_fingerprint','--locked','--','--nocapture'],(5,0,1))]:
  row=run(argv);raw=Path(row['streams']['stdout']['path']).read_text();results=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw);assert [tuple(map(int,x)) for x in results]==[expected],results
  assert w.pin_sources(w.source_paths())==d['source_after_fmt']
 d['status']='passed_clean_pending'
except BaseException as e:d['status']='failed';d['error']=repr(e)
finally:
 g.FREE_LIMIT=0;g.TARGET_LIMIT=2**63
 try:
  row=run(['cargo','clean']);d['source_after_clean']=w.pin_sources(w.source_paths());d['cleanup']={'exit_code':row['exit_code'],'target_absent':not (ROOT/'target').exists(),'source_unchanged':d['source_after_clean']==d.get('source_after_fmt')};assert d['cleanup']['target_absent'] and d['cleanup']['source_unchanged']
  if d['status']=='passed_clean_pending':d['status']='passed'
 except BaseException as e:d['status']='failed';d['cleanup_error']=repr(e)
 d['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
raise SystemExit(0 if d['status']=='passed' else 1)
