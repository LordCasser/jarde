# CF11 corpus fingerprint registration prep

This private preparation contains a minimal proposed update to `tests/fixtures/corpus-fingerprint.json`. The live manifest had 2,134 records, while the failed `p5_corpus_fingerprint` run reported exactly 30 unlisted fixture files from `cf11-structured-list-api`, `cf11-structured-list-controls`, `cf11-structured-list-inner-option`, and `cf11-structured-list-null-api`. The after-file adds those 30 records in path order; all previous rows and every non-`files` field remain unchanged.

`registration.diff` is the proposed diff. `corpus-fingerprint.before.json` and `corpus-fingerprint.after.json` preserve the exact source and proposed manifest bytes. `pins.json` binds the raw failed test output, source and proposed manifest hashes, and every reported file's bytes, BLAKE3, and SHA-256. The four directory provenance records were checked against their destinations; source availability and source-pin match status are recorded individually.

The reader fixture test automatically walks all `.class` files under `tests/fixtures`, so the seven new class files already enter its census. Its pinned aggregate tuple `(1133, 4995, 473, 3048, 10)` is now stale and needs a measured value from a later authorized test run. This prep does not guess or change that tuple, nor change fingerprint thresholds or Rust code.

No Cargo, JDK, Git, or network command was run. No shared file was modified. This is a proposed registration, not a product acceptance result.
