# Private runner update plan — awaiting root source freeze

The old focused/final/workspace runner v9 source binding (4,822-file closure) is stale after the pending repository changes: four tests, the reader census tuple, and the corpus-fingerprint manifest. Do not execute or copy that runner as if it validates the new source.

After root provides the exact post-registration/post-tuple source state:

1. Read the exact test file list and names from that frozen source; pin its SHA-256, exact pass/ignored expectations, and the corpus manifest SHA/count.
2. Recompute the full dynamic workspace closure from the pinned source-closure helper, preserving the existing guard policy and source before/after snapshots. Do not assume the resulting file count.
3. Update the private focused runner's expected census and CLI freeze path only from root's explicit source/receipt inputs. Keep its cargo clean and raw receipts behavior unchanged.
4. Rebase the private final/workspace runner pins on that exact focused-run receipt and exact source manifest. Keep workflow commands, seed/proptest settings, resource guard, and finally-clean flow from the already-reviewed runner.
5. Run only static source/pin checks in prep. Root performs the actual Rust/workspace run against the frozen source.

This is a pending procedure, not a new source freeze, runner executable, or acceptance claim. Await root's exact source state before writing any updated runner bytes or hashes.
