# CF11 reader branch-target inventory

Read-only inventory for `repository_class_fixtures_validate_without_false_target_rejections` in `crates/jarde-reader/src/classfile.rs`. The actual failed run in `0.stderr.raw` reports `(1140, 5018, 474, 3141, 10)` against the old tuple `(1133, 4995, 473, 3048, 10)`. Thus the measured delta is 7 classes, 23 Code methods, 1 exception-table record, 93 branch/switch targets, and 0 jsr/jsr_w instructions.

`branch-targets.json` lists every method in the seven classes, the BCI of each branch instruction, its signed offset and target BCI. It also pins each class file and the saved Java 23 `javap -c -v` capture. The bytecode parser's per-class counts are `[8, 8, 8, 45, 8, 8, 8]`; every `(instruction BCI, mnemonic, target BCI)` multiset matches the saved javap output. These classes have no switches, so each target row corresponds to one branch instruction. Reader `control_flow_targets` counts branch offsets and would separately count a switch default and each switch case; the aggregate test excludes handler targets from the branch count.

The first handwritten scan produced 83 because it omitted the three-byte lengths of field/method/class-reference instructions. That shifted instruction boundaries and skipped ten branch opcodes: one in each of the six two-body classes, and four in the controls class. Correct instruction lengths give 93 and match the live reader failure tuple and saved javap captures.

No Rust test or toolchain was run for this inventory. No shared files were changed. The runner update plan remains pending the exact post-registration source freeze from root; this inventory does not bind a new runner source closure.
