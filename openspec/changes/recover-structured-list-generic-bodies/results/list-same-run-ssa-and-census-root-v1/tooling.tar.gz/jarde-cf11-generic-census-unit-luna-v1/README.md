# CF11 generic-void census unit candidate

This is a private test-only patch for `crates/jarde-java/src/report.rs`. It adds focused checks for `generic_void_unread_parameter_slots` using the committed fixed CF11 class and the retained Code, SSA, and Operations produced from the same class bytes. The positive case asserts the body remains multi-block with a real phi and checks the full six-read physical inventory separately from the six direct receiver edges.

Adversarial copies remove an instruction, duplicate a BCI, move a BCI, and change an opcode while leaving the original SSA facts in place. A second copy removes the `List.add` target identity: the source parameter still counts as physically read, while the census declines to claim a receiver edge. Real `reassigned` and handler-bearing control methods exercise the formal-write and handler refusals. This follows the layer boundary: alias or non-invoke reads remain reads at census time; the class-source List proof owns the requirement that every List read closes through a valid receiver/foreach consumer. Existing API tests already cover `rawAliasEscape`, so this candidate does not duplicate that facade-level case.

No production API or solver changes are proposed. The patch and source were not compiled or executed under this task's constraints.
