
#[cfg(test)]
mod generic_void_parameter_census_tests {
    use super::*;
    use jarde_jvm::engine::analyze_method_ir;
    use jarde_jvm::environment::ResolutionEnvironment;
    use jarde_jvm::ir::{AnalysisStage, MethodAnalysisRequest};
    use jarde_reader::artifact::{ArtifactInput, ArtifactSnapshot};
    use jarde_reader::budget::{Budget, Limits};
    use jarde_reader::classfile::{InstructionFact, InstructionOperands, MethodCodeFacts};
    use jarde_reader::model::{
        ClassBytesId, Digest, JvmBytes, PhysicalClassLocation, PhysicalDefinitionId,
        PhysicalMethodId, PhysicalVariant,
    };
    use jarde_reader::view::{
        DelegationPolicy, LayoutMode, LoadDomain, LoadRoot, LoaderId, ModuleMode,
        MultiReleasePolicy, PhysicalScope, PhysicalView, RuntimeProfile, RuntimeUncertainty,
        RuntimeView,
    };
    use std::collections::BTreeSet;

    const FIXED: &[u8] = include_bytes!(
        "../../../tests/fixtures/cf11-structured-list-api/UpstreamNestedLoops.class"
    );
    const CONTROLS: &[u8] = include_bytes!(
        "../../../tests/fixtures/cf11-structured-list-controls/UpstreamNestedLoops.class"
    );

    fn limits() -> Limits {
        Limits {
            class_bytes: 1 << 20,
            attribute_bytes: 1 << 20,
            code_bytes: 1 << 20,
            result_items: 1 << 20,
            ir_items: 1 << 20,
            ir_edges: 1 << 20,
            analysis_steps: 1 << 20,
            normalization_clones: 1 << 20,
            elapsed_millis: u64::MAX,
            ..Limits::default()
        }
    }

    fn analyzed(
        bytes: &[u8],
        name: &str,
        descriptor: &str,
        parameter_slots: u16,
    ) -> (jarde_jvm::method_ir::MethodIrAnalysis, BTreeSet<u16>) {
        let mut budget = Budget::new(limits());
        let snapshot = ArtifactSnapshot::open(
            ArtifactInput::bytes(bytes.to_vec()),
            &mut budget,
        )
        .expect("the frozen CF11 class opens");
        let domain = LoadDomain {
            loader: LoaderId("app".to_owned()),
            parent_loader: None,
            delegation: DelegationPolicy::ParentFirst,
            roots: vec![LoadRoot::StandaloneClass {
                snapshot: snapshot.id().clone(),
            }],
            module_mode: ModuleMode::ClassPath,
            external_override: RuntimeUncertainty::None,
            runtime_transformation: RuntimeUncertainty::None,
        };
        let method = PhysicalMethodId {
            owner: PhysicalDefinitionId {
                location: PhysicalClassLocation::StandaloneRoot {
                    snapshot: snapshot.id().clone(),
                },
                class_bytes: ClassBytesId {
                    digest: Digest(blake3::hash(bytes).to_hex().to_string()),
                    length: u64::try_from(bytes.len()).expect("fixture length fits"),
                },
                variant: PhysicalVariant::Base,
            },
            name: JvmBytes(name.as_bytes().to_vec()),
            descriptor: JvmBytes(descriptor.as_bytes().to_vec()),
        };
        let analysis = analyze_method_ir(
            &[snapshot],
            &MethodAnalysisRequest {
                environment: ResolutionEnvironment {
                    runtime: RuntimeView {
                        physical: PhysicalView {
                            snapshot: method.owner.location.snapshot().clone(),
                            scope: PhysicalScope::SnapshotAll,
                        },
                        profile: RuntimeProfile {
                            java_release: 8,
                            multi_release: MultiReleasePolicy::Disabled,
                            layout: LayoutMode::Generic,
                        },
                        load_domain: domain.clone(),
                    },
                    domains: vec![domain],
                    providers: Vec::new(),
                },
                method,
                stages: AnalysisStage::ALL.to_vec(),
            },
            &mut budget,
        )
        .expect("the frozen CF11 method analyzes");
        let slots = crate::facts::MethodFacts::new(name, descriptor, parameter_slots)
            .with_access_flags(0x0001)
            .parameter_types()
            .into_keys()
            .collect();
        (analysis, slots)
    }

    fn rebuilt_code(
        code: &MethodCodeFacts,
        pairs: Vec<(InstructionFact, InstructionOperands)>,
        exception_handlers: Vec<jarde_reader::classfile::ExceptionHandlerFact>,
        exception_handler_count: u32,
    ) -> MethodCodeFacts {
        MethodCodeFacts::from_parts(
            code.max_stack,
            code.max_locals,
            code.code_span.clone(),
            pairs,
            exception_handlers,
            exception_handler_count,
            code.execution.clone(),
            code.stopped_at.clone(),
            code.debug().clone(),
        )
    }

    fn code_pairs(code: &MethodCodeFacts) -> Vec<(InstructionFact, InstructionOperands)> {
        code.instructions
            .iter()
            .cloned()
            .zip(code.operands().iter().cloned())
            .collect()
    }

    fn refused(
        code: &MethodCodeFacts,
        ssa: &SsaTable,
        operations: &Operations,
        slots: &BTreeSet<u16>,
    ) {
        assert!(
            generic_void_unread_parameter_slots(code, ssa, operations, slots, &mut Budget::new(limits()))
                .expect("a conservative refusal is not a stop")
                .is_none()
        );
    }

    #[test]
    fn complete_fixed_void_census_keeps_phi_and_every_formal_read() {
        let (analysis, parameter_slots) = analyzed(
            FIXED,
            "test",
            "(Ljava/util/List;Ljava/util/List;)V",
            3,
        );
        let ir = analysis.ir();
        let code = ir.code().expect("the fixed method has Code");
        let ssa = ir.ssa().expect("the fixed method has SSA");
        let operations = Operations::of(code, ir.constant_pool());
        assert!(ssa.blocks().len() > 1, "fixture must stay multi-block");
        assert!(!ssa.phis().is_empty(), "fixture must retain a real SSA phi");
        assert_eq!(parameter_slots, BTreeSet::from([1, 2]));

        let (unread, reads, receivers) = generic_void_unread_parameter_slots(
            code,
            ssa,
            &operations,
            &parameter_slots,
            &mut Budget::new(limits()),
        )
        .expect("the census completes")
        .expect("the complete physical body is internally closed");
        assert!(unread.is_empty(), "all exact List formals have physical reads");
        assert_eq!(
            reads,
            vec![(1, 0), (2, 27), (2, 76), (1, 88), (2, 103), (1, 112)],
            "parameter reads retain their physical occurrences"
        );
        assert_eq!(
            receivers
                .iter()
                .map(|call| (call.parameter_slot, call.load_bci, call.call_bci))
                .collect::<Vec<_>>(),
            vec![
                (1, 0, 1),
                (2, 27, 28),
                (2, 76, 79),
                (1, 88, 91),
                (2, 103, 104),
                (1, 112, 113),
            ],
            "only direct single-use List receiver loads enter the receiver subset"
        );
    }

    #[test]
    fn fixed_census_refuses_physical_inventory_and_operation_disagreements() {
        let (analysis, slots) = analyzed(
            FIXED,
            "test",
            "(Ljava/util/List;Ljava/util/List;)V",
            3,
        );
        let ir = analysis.ir();
        let code = ir.code().unwrap();
        let ssa = ir.ssa().unwrap();
        let pool = ir.constant_pool();

        let mut missing = code_pairs(code);
        missing.pop();
        let missing = rebuilt_code(
            code,
            missing,
            code.exception_handlers.clone(),
            code.exception_handler_count,
        );
        let missing_ops = Operations::of(&missing, pool);
        refused(&missing, ssa, &missing_ops, &slots);

        let mut duplicate = code_pairs(code);
        duplicate.push(duplicate[0].clone());
        let duplicate = rebuilt_code(
            code,
            duplicate,
            code.exception_handlers.clone(),
            code.exception_handler_count,
        );
        let duplicate_ops = Operations::of(&duplicate, pool);
        refused(&duplicate, ssa, &duplicate_ops, &slots);

        let mut wrong_bci = code_pairs(code);
        wrong_bci[0].0.bci = u32::MAX;
        let wrong_bci = rebuilt_code(
            code,
            wrong_bci,
            code.exception_handlers.clone(),
            code.exception_handler_count,
        );
        let wrong_bci_ops = Operations::of(&wrong_bci, pool);
        refused(&wrong_bci, ssa, &wrong_bci_ops, &slots);

        let mut wrong_opcode = code_pairs(code);
        wrong_opcode[0].0.opcode = 0x19;
        wrong_opcode[0].1.effective_opcode = 0x19;
        let wrong_opcode = rebuilt_code(
            code,
            wrong_opcode,
            code.exception_handlers.clone(),
            code.exception_handler_count,
        );
        let wrong_opcode_ops = Operations::of(&wrong_opcode, pool);
        refused(&wrong_opcode, ssa, &wrong_opcode_ops, &slots);
    }

    #[test]
    fn fixed_read_is_not_unread_when_the_invoke_target_is_unknown() {
        let (analysis, slots) = analyzed(
            FIXED,
            "test",
            "(Ljava/util/List;Ljava/util/List;)V",
            3,
        );
        let ir = analysis.ir();
        let code = ir.code().unwrap();
        let ssa = ir.ssa().unwrap();
        let pool = ir.constant_pool();
        let mut pairs = code_pairs(code);
        let call = pairs
            .iter_mut()
            .find(|(instruction, _)| instruction.bci == 79)
            .expect("the List.add invoke is at BCI 79");
        call.0.constant_pool_index = None;
        call.1.constant_pool_index = None;
        let unknown_target = rebuilt_code(
            code,
            pairs,
            code.exception_handlers.clone(),
            code.exception_handler_count,
        );
        let operations = Operations::of(&unknown_target, pool);
        let (unread, reads, receivers) = generic_void_unread_parameter_slots(
            &unknown_target,
            ssa,
            &operations,
            &slots,
            &mut Budget::new(limits()),
        )
        .expect("the operation inventory remains complete")
        .expect("unknown call identity does not falsify physical read evidence");
        assert!(unread.is_empty());
        assert!(reads.contains(&(2, 76)), "the formal read remains counted");
        assert!(
            !receivers.iter().any(|call| call.parameter_slot == 2 && call.load_bci == 76),
            "unknown invoke identity cannot be claimed as a proved receiver edge"
        );
    }

    #[test]
    fn real_parameter_reassignment_and_handler_facts_refuse_the_list_census() {
        for (name, descriptor) in [
            ("reassigned", "(Ljava/util/List;Ljava/util/List;)V"),
            ("handled", "(Ljava/util/List;Ljava/util/List;)V"),
        ] {
            let (analysis, slots) = analyzed(
                CONTROLS,
                name,
                descriptor,
                3,
            );
            let ir = analysis.ir();
            let code = ir.code().expect("control method has Code");
            let ssa = ir.ssa().expect("control method has SSA");
            let operations = Operations::of(code, ir.constant_pool());
            refused(code, ssa, &operations, &slots);
        }
    }
}

