#!/usr/bin/env python3
"""Read root-v3 Rust Debug events; never alters the source receipts."""
from pathlib import Path
import hashlib, json, re, sys

ROOT = Path('/private/tmp/jarde-cf11-list-ssa-diagnostic-root-v3')
OUT = Path('/private/tmp/jarde-cf11-list-ssa-diagnostic-root-v3-review-v1')


def balanced(s, start):
    pairs = {'[':']', '{':'}', '(':')'}
    opener = s[start]
    if opener not in pairs: raise ValueError((start, opener))
    stack=[]; quote=False; esc=False
    for i in range(start,len(s)):
        c=s[i]
        if quote:
            if esc: esc=False
            elif c=='\\': esc=True
            elif c=='"': quote=False
            continue
        if c=='"': quote=True; continue
        if c in pairs: stack.append(pairs[c])
        elif c in ']} )'.replace(' ',''):
            if not stack or stack.pop()!=c: raise ValueError(f'unbalanced at {i}')
            if not stack: return s[start:i+1],i+1
    raise ValueError('unterminated container')


def field_value(s,key,opener=None):
    marker=key+'='
    i=s.find(marker)
    if i<0: raise KeyError(key)
    i+=len(marker)
    if opener is None: return s[i:].split(' ',1)[0]
    while i<len(s) and s[i].isspace(): i+=1
    if s[i]!=opener:
        j=s.find(opener,i)
        if j<0: raise ValueError((key,s[i:i+40]))
        i=j
    return balanced(s,i)[0]


def split_top(container):
    assert container[0]=='[' and container[-1]==']'
    s=container[1:-1]; out=[]; start=0; stack=[]; pairs={'[':']','{':'}','(':')'}; quote=False; esc=False
    for i,c in enumerate(s):
        if quote:
            if esc: esc=False
            elif c=='\\': esc=True
            elif c=='"': quote=False
            continue
        if c=='"': quote=True; continue
        if c in pairs: stack.append(pairs[c])
        elif c in ']} )'.replace(' ',''):
            if not stack or stack.pop()!=c: raise ValueError(f'split unbalanced {i}')
        elif c==',' and not stack:
            out.append(s[start:i].strip()); start=i+1
    tail=s[start:].strip()
    if tail: out.append(tail)
    return out


def split_tuple(t):
    t=t.strip()
    assert t.startswith('(') and t.endswith(')')
    s=t[1:-1]; out=[]; start=0; stack=[]; pairs={'[':']','{':'}','(':')'}; quote=False; esc=False
    for i,c in enumerate(s):
        if quote:
            if esc: esc=False
            elif c=='\\': esc=True
            elif c=='"': quote=False
            continue
        if c=='"': quote=True; continue
        if c in pairs: stack.append(pairs[c])
        elif c in ']} )'.replace(' ',''):
            if not stack or stack.pop()!=c: raise ValueError(f'tuple unbalanced {i}')
        elif c==',' and not stack:
            out.append(s[start:i].strip()); start=i+1
    out.append(s[start:].strip()); return out


def debug_container_after(s, key, opener):
    i=s.find(key)
    if i<0: raise KeyError(key)
    i=s.find(opener,i+len(key))
    return balanced(s,i)[0]


def parse_ssa_values(table):
    values=debug_container_after(table,'values:', '[')
    rows=split_top(values); out=[]
    for ix,row in enumerate(rows):
        definition='?'
        m=re.search(r'\bdef: (Entry|Instruction|Phi|Caught) ',row)
        if m:
            brace=row.find('{',m.start(1))
            if brace>=0: definition=row[m.start(1):balanced(row,brace)[1]]
            else: definition=m.group(1)
        uses_container=debug_container_after(row,'uses:', '[')
        uses=[]
        for use in split_top(uses_container):
            bci=re.search(r'\bbci: (Some\((\d+)\)|None)',use)
            uses.append({'bci':int(bci.group(2)) if bci and bci.group(2) else None,'raw':use})
        out.append({'id':ix,'definition':definition,'uses':uses,'replaced_by':(re.search(r'replaced_by: (None|Some\(ValueId\(\d+\)\))',row).group(1) if re.search(r'replaced_by: (None|Some\(ValueId\(\d+\)\))',row) else '?')})
    return out


def parse_event(line, file):
    m=re.search(r'event=structured_facts attempt=(\d+) label="([^"]+)" class=([^ ]+) method=([^ ]+) descriptor=([^ ]+)',line)
    if not m: raise ValueError('identity missing')
    attempt,label,cls,name,desc=m.groups()
    bci_set=field_value(line,'code_bci_set','{')
    code_bcis=[int(x) for x in re.findall(r'\d+',bci_set)]
    codefacts=field_value(line,'code_facts','{')
    ins=debug_container_after(codefacts,'instructions:', '[')
    instruction_rows=split_top(ins)
    ins_bcis=[int(re.search(r'InstructionFact \{ bci: (\d+)',x).group(1)) for x in instruction_rows]
    code_instructions=[{'bci':int(m.group(1)),'opcode':int(m.group(2))} for x in instruction_rows if (m:=re.search(r'InstructionFact \{ bci: (\d+), opcode: (\d+)',x))]
    census=split_top(field_value(line,'instruction_census','['))
    census_rows=[]
    for row in census:
        fs=split_tuple(row)
        ssas=split_top(fs[4]); effects=split_top(fs[5])
        census_rows.append({'bci':int(fs[0]),'opcode':int(fs[1]),'effective_opcode':int(fs[2]),'ssa_rows':ssas,'effect_rows':effects,'operation':fs[6]})
    operation_rows=split_top(field_value(line,'operations','['))
    operations=[]
    for row in operation_rows:
        fs=split_tuple(row)
        operations.append({'bci':int(fs[0]),'operation':fs[1]})
    param_accesses=split_top(field_value(line,'parameter_accesses','['))
    accesses=[]
    for row in param_accesses:
        fs=split_tuple(row)
        reads=[{'slot':int(a),'value':int(b)} for a,b in re.findall(r'Local\((\d+)\), ValueId\((\d+)\)',fs[3])]
        writes=[{'slot':int(a),'value':int(b)} for a,b in re.findall(r'Local\((\d+)\), ValueId\((\d+)\)',fs[4])]
        accesses.append({'bci':int(fs[0]),'opcode':int(fs[2]),'reads':reads,'writes':writes})
    ssa_values=parse_ssa_values(field_value(line,'ssa_table','{'))
    cfg=field_value(line,'canonical_cfg','{')
    handlers=field_value(line,'code_handlers','[')
    code_local_rows=[]
    for row in census_rows:
        sf=split_tuple(row['ssa_rows'][0])
        ssa_reads=sorted(int(x) for x in re.findall(r'Local\((\d+)\)',sf[3]))
        ssa_writes=sorted(int(x) for x in re.findall(r'Local\((\d+)\)',sf[4]))
        ef=split_tuple(row['effect_rows'][0])
        effect_reads=sorted(int(x) for x in re.findall(r'\d+',ef[3]))
        effect_writes=sorted(int(x) for x in re.findall(r'\d+',ef[4]))
        code_local_rows.append({'bci':row['bci'],'ssa_local_reads':ssa_reads,'effect_local_reads':effect_reads,'ssa_local_writes':ssa_writes,'effect_local_writes':effect_writes,'match':ssa_reads==effect_reads and ssa_writes==effect_writes})
    checks={
        'code_instruction_rows':len(ins_bcis), 'code_unique_bcis':len(set(ins_bcis)),
        'code_bci_set_size':len(code_bcis), 'census_rows':len(census_rows),
        'census_unique_bcis':len({r['bci'] for r in census_rows}),
        'operations_rows':len(operations), 'operations_unique_bcis':len({r['bci'] for r in operations}),
        'ssa_value_rows':len(ssa_values), 'ssa_definitions_all_parsed':all(v['definition']!='?' for v in ssa_values), 'ssa_local_effect_accesses_match':all(x['match'] for x in code_local_rows),
        'census_exact_code_bci_set':set(ins_bcis)==set(code_bcis)=={r['bci'] for r in census_rows},
        'one_ssa_row_per_code_bci':all(len(r['ssa_rows'])==1 for r in census_rows),
        'one_effect_row_per_code_bci':all(len(r['effect_rows'])==1 for r in census_rows),
        'one_operation_per_code_bci':len(operations)==len(code_bcis) and {r['bci'] for r in operations}==set(code_bcis),
        'no_extra_ssa_rows':field_value(line,'ssa_only_rows','[')=='[]',
        'no_extra_effect_rows':field_value(line,'effects_only_rows','[')=='[]',
        'no_missing_operations':all(r['operation']!='None' for r in census_rows),
        'handler_present':handlers!='[]', 'canonical_cfg_bytes':len(cfg),
    }
    direct=[]
    for access in accesses:
        row=next((r for r in census_rows if r['bci']==access['bci']),None)
        if row:
            # SSA load's produced stack value, its complete use list, and call receiver consumer.
            sf=split_tuple(row['ssa_rows'][0])
            produced=[int(v) for v in re.findall(r'Stack\(\d+\), ValueId\((\d+)\)',sf[4])]
            for vid in produced:
                vv=ssa_values[vid] if vid<len(ssa_values) else None
                receiver_calls=[]
                if vv:
                    for call in census_rows:
                        if call['operation'].startswith('Some(Invoke('):
                            call_ssa=split_tuple(call['ssa_rows'][0]); call_reads=call_ssa[3]
                            if re.search(rf'Stack\(0\), ValueId\({vid}\)',call_reads) and any(u['bci']==call['bci'] for u in vv['uses']): receiver_calls.append(call['bci'])
                direct.append({'load_bci':access['bci'],'slot_reads':access['reads'],'stack_value':vid,'definition':vv['definition'] if vv else '?','uses':vv['uses'] if vv else [],'direct_receiver_calls':receiver_calls})
    invokes=[]
    for op in operations:
        if 'Invoke(CallTarget' in op['operation']:
            inv={'bci':op['bci']}
            for key in ['owner','name','descriptor']:
                mm=re.search(rf'{key}: "([^"]*)"',op['operation']); inv[key]=mm.group(1) if mm else '?'
            inv['opcode']=next((r['opcode'] for r in census_rows if r['bci']==op['bci']),None)
            invokes.append(inv)
    return {'file':file,'attempt':int(attempt),'label':label,'class':cls,'method':name,'descriptor':desc,'parameter_slots':sorted({x['slot'] for a in accesses for x in a['reads']+a['writes']}),'parameter_accesses':accesses,'direct_load_values':direct,'invokes':invokes,'ssa_values':ssa_values,'code_instructions':code_instructions,'code_local_rows':code_local_rows,'census_rows':census_rows,'operations':operations,'checks':checks}


def main():
    events=[]
    for i in range(1,6):
        p=ROOT/f'{i}.stderr.raw'
        for line in p.read_text(errors='replace').splitlines():
            if line.startswith('JARDE_LIST_SSA event=structured_facts '): events.append(parse_event(line,p.name))
    (OUT/'facts.json').write_text(json.dumps({'schema':'cf11-list-ssa-root-v3-facts-review-v1','events':events},indent=2)+'\n')
    print('events',len(events))
    for e in events:
        c=e['checks']; print(e['label'],e['class'],e['method'],'code',c['code_instruction_rows'],'ssa values',c['ssa_value_rows'],'formal R/W',sum(len(x['reads']) for x in e['parameter_accesses']),sum(len(x['writes']) for x in e['parameter_accesses']),'census',all(c[k] for k in ['census_exact_code_bci_set','one_ssa_row_per_code_bci','one_effect_row_per_code_bci','one_operation_per_code_bci','no_extra_ssa_rows','no_extra_effect_rows']),'handlers',c['handler_present'])

if __name__=='__main__': main()
