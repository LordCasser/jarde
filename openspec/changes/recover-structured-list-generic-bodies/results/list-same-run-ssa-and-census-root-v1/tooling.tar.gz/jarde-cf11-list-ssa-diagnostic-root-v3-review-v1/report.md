# CF11 same-run List SSA facts review (root-v3)

This is an offline parse of the five captured stderr streams. The parser does not invoke Cargo, Java, JADX, Git, or the CLI and does not modify the captured receipts. Full per-event facts, including every Code instruction, census row, operation, formal local access, SSA definition/use, invocation descriptor, and validation boolean are in `facts.json`.

## Completeness and evidence boundary

The 18 events cover controls (10 methods), the fixed method repeated in three separately captured test runs, distinct String and Integer classes, an inner List method, and null String/Integer fixtures. For every event, Code instruction BCIs are unique and exactly equal the SSA/effects census BCIs; there is exactly one SSA row and one effects row per BCI; operations have one unique row per Code BCI; there are no SSA-only/effects-only rows or missing operations. All SSA definitions parsed, and SSA local read/write slots match effect local read/write slots at every BCI. The machine-readable checks are retained per event in `facts.json`.

The five targeted test commands (indexes 1–5 in `execution.json`) exited 0. The earlier reader fixture census command (index 0) exited 101 with observed counts `[1140, 5018, 474, 3141, 10]` versus old expected `[1133, 4995, 473, 3048, 10]`; receipt explicitly leaves independent branch-delta attribution pending. This diagnostic is not evidence that all reader fixtures passed.

All 4,822 source pins before instrumentation, after restoration, and after cleanup are byte-for-byte equal. The receipt says `source_restored=true`; cleanup reports target absent. The five raw stderr inputs remain preserved and are pinned in `pins.json`.

These facts establish that same-run Code/SSA/effects/operation and local access records were captured and internally align. They do not, alone, prove a generic projection API result or why a refusal occurred. The successful API tests are separate evidence. In particular, the event schema does not include the generic `Signature` attribute, so it cannot prove the wildcard signature from SSA facts alone.

## Control attribution from captured bytecode facts

- `rawAliasEscape`: slots 1 and 2 have reads and no formal writes. Slot 1 load at BCI 0 produces SSA value 13, whose only use is BCI 1 (alias store), not a List invoke receiver. The later receiver load from slot 1 at BCI 44 feeds iterator at 45. `List.add(Object)Z` is at BCI 35 through the alias local. This demonstrates that the first parameter read is not itself the receiver for that mutation.
- `reassigned`: slot 1 has a write at BCI 1 (`astore_1`), then a read at BCI 2 from the newly stored SSA value. Slot 2 is read at BCIs 0 and 29; no other formal writes are recorded. This is a real parameter-slot reassignment in the captured Code/SSA, rather than an inference from a Java source name.
- `wildcardNull`: slots 1 and 2 have reads, with no writes. `aconst_null` at BCI 28 produces a value consumed at BCI 29, the `List.add(Object)Z` call. This proves the physical null argument flow. The event does not report generic signature metadata; do not attribute the generic refusal specifically to wildcard variance based on this capture.
- `handled`: the Code event includes one exception handler (start 0, end 47, handler 50, catch type constant-pool index 63); SSA includes `Caught` definitions. Slots 1 and 2 are read and not written. The receiver/add path is present in the body facts. This establishes actual handler/SSA capture for the method, without requiring the body to be accepted as a generic projection.
- `indexOverload`: formal slots 1–4 are read; none are written. `List.remove(Object)Z` occurs at BCI 2, `List.remove(I)Object` at BCI 11, and `List.add(Object)Z` at BCI 19. Slot 1 loads at BCIs 0 and 8 are consumed as receivers at BCIs 2 and 11; slot 4 load at BCI 9 supplies the integer argument to `remove(I)`. This distinguishes the two physical overloads and their receiver/argument roles.
- `castBoundary`: slot 1 is read at BCI 0; slot 2 at BCIs 31 and 75; no writes. Physical `checkcast` instructions (opcode 192) occur at BCIs 26 and 60 and their produced values are consumed at 29 and 63. The later List add receiver is loaded from slot 2 at BCI 75 and consumed at 78. These casts remain present in Code; the facts do not imply their removal is safe.
- Positive `fixed`, `distinct`, `inner`, and `null` events show direct parameter loads consumed as List receivers and preserve their physical `checkcast`/null operations. The complete exact BCI and SSA relation is in `facts.json`; no source-level naming assumptions are used.

## Replay

Run `python3 /private/tmp/jarde-cf11-list-ssa-diagnostic-root-v3-review-v1/parse_facts.py` to regenerate `facts.json` from the pinned root-v3 execution receipt and stderr captures. The parser asserts each event's BCI and row invariants before writing output. It only reads `/private/tmp/jarde-cf11-list-ssa-diagnostic-root-v3/{execution.json,1.stderr.raw,...,5.stderr.raw}`.
