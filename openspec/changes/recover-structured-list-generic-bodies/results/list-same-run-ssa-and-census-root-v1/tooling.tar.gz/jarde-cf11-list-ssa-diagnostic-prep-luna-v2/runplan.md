# Root run plan

After the fullworkspace run is terminal, verify all `source_before` entries in `pins.json`, inspect `v1-to-v2.diff` and `baseline-to-patched.diff`, then apply only the report.rs diagnostic patch. The event runs after `selection.check(code)` and `Operations::of(code, ...)`, before downstream body-shape recovery, so `handled` is observed with the same run's handler table even if body rendering later becomes explanation-only.

Run the exact existing integration tests under the root guard, one process per label, with `--nocapture` and raw stdout/stderr capture:

- `controls`: `cargo test --test structured_list_generic_bodies nearby_list_controls_refuse_only_unproved_generic_projections -- --exact --nocapture`
- `fixed`: `cargo test --test structured_list_generic_bodies fixed_nested_string_body_projects_source_and_preserves_physical_origins -- --exact --nocapture`
- `distinct`: `cargo test --test structured_list_generic_bodies differently_named_string_and_integer_classes_follow_their_list_element_type -- --exact --nocapture`
- `inner`: `cargo test --test structured_list_generic_bodies inner_list_option_actual_uses_the_receiver_element_type -- --exact --nocapture`
- `null`: `cargo test --test structured_list_generic_bodies exact_list_null_add_removes_only_the_synthetic_object_wrapper -- --exact --nocapture`

Set `JARDE_LIST_SSA_DIAGNOSTIC_LABEL` to the matching label for each command. Separate runs distinguish same-name/same-descriptor `UpstreamNestedLoops.test` in the controls and fixed fixture, and the separately compiled `DistinctIntegerFixture.numbers` inner-option fixture.

Use the existing root guard: 5 GiB free-space floor, 1 GiB target ceiling, default Rust stack, one-second sampling. Restore `report.rs` byte-for-byte in a finally path, verify every source and fixture pin, and run `cargo clean` through the guarded cleanup path; confirm `target/` absent. Preserve raw outputs. A stop or failed command remains its own receipt and must not be spliced into a later result.

For each labelled method event, verify Code BCI uniqueness and exact one-to-one operation/SSA/effects pairing; inspect all physical formal slot reads/writes and the SSA definitions/use sites, including alias stores, invoke receiver stack values, duplicate/missing rows, handler records, and canonical exceptional edges. Join those same-run facts to the already frozen classfile/javap control inventory and the public report outcome. The diagnostic event is observation only; it does not certify a generic projection.
