# CF11 List SSA diagnostic prep v2

This private version moves the observation event from `generic_return_candidate` into `recover_inner`, directly after `Operations::of(code, ...)`. By this point this recovery run has selected and obtained its `MethodCodeFacts`, canonical CFG, SSA, and operations. The event therefore includes handled methods even if a later recovery branch returns before generic-candidate analysis.

The event is enabled only by `JARDE_LIST_SSA_DIAGNOSTIC_LABEL` and a fixed class/method allowlist. It prints label and class/method/descriptor identity, Code facts and handlers, canonical CFG, every Code BCI paired with matching SSA/effects/operation rows, SSA/effect rows outside the Code BCI inventory, formal slot reads/writes, and the complete SSA table. It no longer includes Program fields or re-runs the generic proof. It does not change product decisions, budget accounting, refusals, or published reports.

`diagnostic.patch` and `baseline-to-patched.diff` are the current source diff. `v1-to-v2.diff` compares the previous private candidate instrumentation with this version. `report.rs.base` and `report.rs.candidate` are included for root review. `pins.json` contains the current source/fixture pins and patch hash. The shared checkout was not edited and no toolchain or Git command was run.
