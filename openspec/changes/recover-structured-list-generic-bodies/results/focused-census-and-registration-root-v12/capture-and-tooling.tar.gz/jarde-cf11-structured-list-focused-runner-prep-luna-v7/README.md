# CF11 focused runner prep v7

v7 保留 v6，按 root 指示只刷新 `crates/jarde-java/src/report.rs` 的生产源 pin，并将冻结 CLI 目的地改为 root-v4。runner 的测试矩阵、资源 guard、argv、依赖 runner 与其余源码 pins 沿用 v6。

此 prep 尚未执行。Root 可用本 runner 启动 focused-root-v12；实际 source HEAD、命令流和 frozen CLI 哈希应以后续 execution receipt 为准。
