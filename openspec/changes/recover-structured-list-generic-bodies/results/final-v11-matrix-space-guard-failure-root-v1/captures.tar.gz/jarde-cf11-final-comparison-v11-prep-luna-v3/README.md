# CF11 最终对比 v11 私有准备包 v3

这是与 v1、v2 分开的第三版私有准备包，未修改前两版。`run.py` 中的 collector SHA 已绑定本版 `collect_controls.py`，checker 同时绑定 collector 和 batch runner；`pins.json` 逐项记录 focused run-v4 receipt、CLI v3、原始测试清单、guard 和 late-stop 输入。所有 captures 使用全新 `final-v11v3-*` 路径。`*-v2-v3.diff` 可逐项审阅本版变更。

run-v4 collector/checker 保留 12 组 class comparison、41 labels、352 commands、704 raw streams，以及 JDK 8/23、Runner/input、物理 class/source-map 和 compile failure 不运行检查。focused receipt 的 8 个命令、argv、raw streams、4822 个源码 pins、fmt 原始输出为空、默认 Cargo target、最终清理记录和 guard bypass 都需精确匹配。

四类测试输出均按原始 Cargo stdout 逐行解析 `test NAME ... STATUS` 并校验 summary：API 的 8 个确切名称/状态、jarde-java 的完整 375 名/状态、reader census 的完整 1 名/状态、P5 corpus fingerprint 的完整 6 名/状态。完整清单固定在 `focused_v11_raw_test_inventory.json`，并与 receipt 的结构化结果及 raw stream hash 交叉核对；reader 与 P5 census 的名称/状态还在源码常量中显式核准。

`late_stop_v3.py` 改用既有 run-validation resource guard，按 5 GiB free、1 GiB target、1 秒轮询运行两个串行 CLI 请求。两份 stdout/stderr 原始流均写入输出目录。receipt 记录命令前后 CLI/class 字节 pin、guard 资源样本、实际 AnalysisSteps 与 diagnostic；partial 与 full 退出码均有断言。即使 preflight/guard/解析失败，也尽可能保存 `execution.json` 和 raw 流；不会假定 CLI v3 的 usage 与 root-v2 相同。

只做了 Python 语法和静态交叉 hash 检查；没有运行 batch、checker、CLI、Cargo 或 JDK。

```sh
python3 /private/tmp/jarde-cf11-final-comparison-v11-prep-luna-v3/late_stop_v3.py --out /private/tmp/jarde-cf11-structured-list-late-stop-cli-v3-root-v1
```
