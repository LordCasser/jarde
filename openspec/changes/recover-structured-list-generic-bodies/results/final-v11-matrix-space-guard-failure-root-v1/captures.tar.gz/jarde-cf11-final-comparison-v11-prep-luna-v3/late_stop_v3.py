#!/usr/bin/env python3
"""Capture a guarded two-call late-stop observation with frozen CLI v3."""
from __future__ import annotations
from pathlib import Path
import argparse, datetime, hashlib, importlib.util, json, os, re, sys

ROOT = Path('/Users/lordcasser/workspace/projects/jarde').resolve()
CLI = Path('/private/tmp/jarde-cf11-structured-list-candidate-cli-root-v3')
CLI_SHA256 = '45b5fd1ef637d8879254743d51ea5ce66ec5400558b023e65a7448a9d596de09'
INPUT = Path('/private/tmp/jarde-cf11-structured-list-final-fixed-debug-root-v1/legs/javac23-original/classes/cf11/UpstreamNestedLoops.class')
INPUT_SHA256 = '8ece89e4d38751c20529622b57417afc8601368fc20078656ea2b24c17ed8231'
REFERENCE = Path('/private/tmp/jarde-cf11-structured-list-final-late-stop-cli-root-v2/execution.json')
REFERENCE_SHA256 = '986d5c47bdd2529e3639e97b8d35b53b1609d1964120f71e92786c8ac33d95ea'
GUARD_PATH = Path('/Users/lordcasser/workspace/projects/jarde/openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py')
GUARD_SHA256 = '51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
LIMIT = 32531


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pin(path: Path) -> dict:
    data=Path(path).read_bytes()
    return {'path':str(Path(path).resolve()),'bytes':len(data),'sha256':sha_bytes(data)}


def save(path: Path, record: dict) -> None:
    path.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def load_method(doc: dict) -> dict:
    for item in doc.get('methods',[]):
        desc=item.get('item',{}).get('descriptor',{}).get('escaped')
        if item.get('name',{}).get('escaped')=='test' and desc=='(Ljava/util/List;Ljava/util/List;)V': return item
    raise ValueError('target test method missing')


def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
    out=args.out.resolve()
    if out.exists(): raise SystemExit(f'refuse overwrite: {out}')
    out.mkdir(parents=True);raw=out/'raw';raw.mkdir();receipt=out/'execution.json'
    record={'schema':'cf11-late-stop-cli-v3-observation-v2','status':'preparing','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'limits':{'free_bytes_min':5*1024**3,'target_bytes_max':1024**3,'sample_interval_seconds':1},'budget_limit':LIMIT,
      'cli_before':None,'input_before':None,'guard_pin':None,'reference_v2':None,'commands':[],'checks':{},'errors':[]}
    save(receipt,record)
    try:
        record['cli_before']=pin(CLI);record['input_before']=pin(INPUT);record['reference_v2']=pin(REFERENCE);record['guard_pin']=pin(GUARD_PATH)
        reference_doc=json.loads(REFERENCE.read_text(encoding='utf-8'))
        record['root_v2_measured_reference']={'analysis_steps':reference_doc.get('analysis_steps'),'raw_text_and_map_equal_full':reference_doc.get('raw_text_and_map_equal_full'),'limit':32531,'interpretation':'reference only; new CLI usage is measured independently'}
        for path,expected,label in ((CLI,CLI_SHA256,'CLI'),(INPUT,INPUT_SHA256,'class input'),(REFERENCE,REFERENCE_SHA256,'root-v2 receipt'),(GUARD_PATH,GUARD_SHA256,'resource guard')):
            if pin(path)['sha256']!=expected: raise ValueError(f'{label} SHA pin mismatch')
        if (CLI.stat().st_mode&0o777)!=0o555: raise ValueError('frozen CLI mode is not 0555')
        spec=importlib.util.spec_from_file_location('cf11_late_stop_existing_guard',GUARD_PATH)
        if spec is None or spec.loader is None: raise RuntimeError('cannot load existing guard module')
        guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
        if sha_bytes(GUARD_PATH.read_bytes())!=GUARD_SHA256: raise ValueError('resource guard changed while loading')
        guard.OUT=raw;guard.ROOT=ROOT
        guard.expected_test_summaries=lambda index,stdout:None
        guard.ENV_VALUES={'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','RUST_TEST_THREADS':'1','CARGO_TERM_COLOR':'always'}
        guard.command_stream=lambda path:{'path':str(Path(path).resolve()),'bytes':Path(path).stat().st_size,'sha256':sha_bytes(Path(path).read_bytes())}
        # run_command itself supplies the existing 5 GiB / 1 GiB / one-second process-group guard.
        env={k:v for k,v in os.environ.items() if k not in ('JAVA_HOME','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH')};env.update(guard.ENV_VALUES)
        tasks=[('partial',[str(CLI),'class-source','--input',str(INPUT),'--class','cf11.UpstreamNestedLoops','--policy','single-class','--release','8','--format','json','--budget',f'analysis_steps={LIMIT}']),
               ('full',[str(CLI),'class-source','--input',str(INPUT),'--class','cf11.UpstreamNestedLoops','--policy','single-class','--release','8','--format','json'])]
        for index,(label,argv) in enumerate(tasks,1):
            row={'label':label,'pre_cli':pin(CLI),'pre_input':pin(INPUT),'argv':argv}
            save(receipt,record)
            try:
                observed=guard.run_command(index,argv,env)
                row.update(observed);row['label']=label;row['post_cli']=pin(CLI);row['post_input']=pin(INPUT)
                row['artifact_stable']=row['pre_cli']==row['post_cli'] and row['pre_input']==row['post_input']
                row['stderr_raw_saved']=Path(observed['streams']['stderr']['path']).is_file()
                row['stderr_raw_sha256']=observed['streams']['stderr']['sha256'];row['stdout_raw_saved']=Path(observed['streams']['stdout']['path']).is_file()
                record['commands'].append(row);save(receipt,record)
            except BaseException as error:
                row.update({'error_type':type(error).__name__,'error':str(error),'post_cli':pin(CLI),'post_input':pin(INPUT)})
                fallback={}
                for stream in ('stdout','stderr'):
                    stream_path=raw/f'{index}.{stream}.raw'
                    if not stream_path.exists(): stream_path.write_bytes(b'')
                    fallback[stream]={'path':str(stream_path.resolve()),'bytes':stream_path.stat().st_size,'sha256':sha_bytes(stream_path.read_bytes())}
                row['streams']=row.get('streams',fallback)
                row['stdout_raw_saved']=Path(row['streams']['stdout']['path']).is_file();row['stderr_raw_saved']=Path(row['streams']['stderr']['path']).is_file()
                record['commands'].append(row);record['errors'].append(f'{label}: {type(error).__name__}: {error}');save(receipt,record)
                continue
        # Parse saved raw streams only after both attempts; malformed/guard-stopped output still remains receipted.
        results={}
        for row in record['commands']:
            streams=row.get('streams',{});stdout_path=Path(streams.get('stdout',{}).get('path',''))
            if not stdout_path.is_file(): row['parse_error']='stdout raw missing';save(receipt,record);continue
            try: results[row['label']]=json.loads(stdout_path.read_text(encoding='utf-8'))
            except Exception as error: row['parse_error']=f'{type(error).__name__}: {error}';save(receipt,record)
        if 'partial' in results and 'full' in results:
            partial,full=results['partial'],results['full'];pm,fm=load_method(partial),load_method(full);pr,fr=pm['outcome']['report'],fm['outcome']['report']
            actual=partial.get('execution',{}).get('usage',{}).get('analysis_steps')
            diagnostic=next((x for x in partial.get('diagnostics',[]) if x.get('code')=='budget_exceeded_analysis_steps'),None)
            record['checks']={
              'partial_exit_code_4':next((x.get('exit_code')==4 for x in record['commands'] if x['label']=='partial'),False),
              'full_exit_code_0':next((x.get('exit_code')==0 for x in record['commands'] if x['label']=='full'),False),
              'both_artifact_pins_stable':all(x.get('artifact_stable') is True for x in record['commands']),
              'partial_execution_stopped_on_analysis_budget':partial.get('execution',{}).get('status')=='partial' and partial.get('execution',{}).get('reason',{}).get('dimension')=='analysis_steps' and partial.get('execution',{}).get('reason',{}).get('kind')=='budget_exceeded',
              'actual_usage_below_budget':isinstance(actual,int) and actual<LIMIT,
              'diagnostic_reports_actual_usage':diagnostic is not None and f'limit={LIMIT}, consumed={actual}, requested=' in diagnostic.get('message',''),
              'raw_method_body_complete':pr.get('execution',{}).get('status')=='complete' and pr.get('content')=='contains_statements',
              'full_execution_complete':full.get('execution',{}).get('status')=='complete',
              'raw_report_text_matches_full':pr.get('text')==fr.get('text'),
              'raw_report_source_map_matches_full':pr.get('source_map')==fr.get('source_map'),
              'raw_method_keeps_object_add':'l2.add((java.lang.Object) s1)' in pr.get('text',''),
              'generic_refusal_marker_present':any('generic Signature projection refused' in x for x in pm.get('markers',[])),
              'no_generic_method_declaration':'<String>' not in pm.get('declaration','') and 'List<String>' not in pr.get('text','') and 'List<java.lang.String>' not in pr.get('text',''),
            }
            record['observed_partial_analysis_steps']=actual
            record['observed_full_analysis_steps']=full.get('execution',{}).get('usage',{}).get('analysis_steps')
            record['observed_partial_diagnostics']=partial.get('diagnostics',[])
            record['status']='captured_checks_passed' if all(record['checks'].values()) else 'captured_check_mismatch'
        else:
            record['status']='captured_without_both_parseable_outputs'
    except BaseException as error:
        record['errors'].append(f'{type(error).__name__}: {error}')
        record['status']='preflight_or_runner_failure'
    finally:
        record['cli_after']=pin(CLI) if CLI.is_file() else None
        record['input_after']=pin(INPUT) if INPUT.is_file() else None
        record['cli_unchanged']=record['cli_before']==record['cli_after'] if record['cli_before'] else False
        record['input_unchanged']=record['input_before']==record['input_after'] if record['input_before'] else False
        record['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        save(receipt,record)
    print(json.dumps({'status':record['status'],'out':str(out),'checks':record.get('checks',{})},ensure_ascii=False))
    return 0 if record['status']=='captured_checks_passed' else 1

if __name__=='__main__':
    raise SystemExit(main())
