from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
HERE=Path(__file__).resolve().parent
COLLECTOR=Path('/private/tmp/jarde-cf11-final-comparison-v11-prep-luna-v3/collect_controls.py')
RECEIPT=Path('/private/tmp/jarde-cf11-structured-list-focused-root-v11/execution.json')
CLI=Path('/private/tmp/jarde-cf11-structured-list-candidate-cli-root-v3')
TEST_INVENTORY=Path('/private/tmp/jarde-cf11-final-comparison-v11-prep-luna-v3/focused_v11_raw_test_inventory.json')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(COLLECTOR)=='3a033096775745af0bb1523a4a26ffaf17e839884b4d5db92d0cbd7e4df5692c'
assert sha(RECEIPT)=='0a2acef11bc45b2614d98b282e42842859d9502c4d211643c294db429dc31e83'
assert sha(CLI)=='45b5fd1ef637d8879254743d51ea5ce66ec5400558b023e65a7448a9d596de09'
assert sha(TEST_INVENTORY)=='b440859d4795caa8984a66ab3a1d53a3258c07f390803f434bc0a20653bc1a26'
record={'status':'running','collector_sha256':sha(COLLECTOR),'build_receipt_sha256':sha(RECEIPT),'cli_sha256':sha(CLI),'commands':[]}
def save():(HERE/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
save()
for family in ('inner-option','null-add','fixed','string','integer','controls'):
 seed=Path('/private/tmp/jarde-cf11-structured-list-current-'+family+'-debug-root-v1/execution.json')
 config=json.loads(seed.read_text())['collector_config']
 for mode in ('debug','none'):
  out=Path('/private/tmp/jarde-cf11-structured-list-final-v11v3-'+family+'-'+mode+'-root-v1')
  args={**config,'source_debug':mode,'out':str(out),'cli':str(CLI),'cli_sha256':sha(CLI),'build_receipt':str(RECEIPT),'build_receipt_sha256':sha(RECEIPT),'receipt_cli_object':'cli_freeze','receipt_accepted_value':'passed_initial_product_validation'}
  argv=[sys.executable,'-B',str(COLLECTOR)]
  for key,value in args.items():argv+=['--'+key.replace('_','-'),str(value)]
  label=family+'-'+mode;row={'label':label,'argv':argv,'capture':str(out),'status':'running'};record['commands'].append(row);save()
  with (HERE/(label+'.stdout.raw')).open('wb') as so,(HERE/(label+'.stderr.raw')).open('wb') as se:
   row['exit_code']=subprocess.run(argv,cwd=ROOT,stdout=so,stderr=se).returncode
  row['status']='terminal';row['streams']={}
  for name in ('stdout','stderr'):
   p=HERE/(label+'.'+name+'.raw');row['streams'][name]={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
  save();print(label,row['exit_code'],flush=True)
  if row['exit_code']!=0:record['status']='failed';save();raise SystemExit(row['exit_code'])
record['status']='captures_complete_not_independently_accepted';save()
