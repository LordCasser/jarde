# CF11 exact List<S>.add(null) fixture

这是给 root 串行 Java/JADX/Jarde 验收的冻结 Java 8 输入；本目录只提供源文件、Runner 和字节清单，没有运行编译器或反编译器。

两个独立目标类分别覆盖精确的 `List<String>` 与 `List<Integer>`。每个 void 方法都有外层 `selected` 和内层 `available` foreach、真实 `equals`/条件/`size`/`clear` 用途；匹配分支对 `available` 调用 `add(null)`，另一个分支保留 `remove((Object) option)` overload 控制。Runner 的匹配用例应观察到 null 已追加、随后 fail-fast 异常；no-match 用例控制没有 add。两种元素类型都走同一语义，避免把 String 或 fixture 名称当成推断依据。

`manifest.json` 钉住精确源字节、字节数、SHA-256、目标类、Runner 和 Java 8 source level。验收须由 root 的串行工具链执行；本 fixture 的静态准备不代表生成源码已投影、已编译或运行一致。
