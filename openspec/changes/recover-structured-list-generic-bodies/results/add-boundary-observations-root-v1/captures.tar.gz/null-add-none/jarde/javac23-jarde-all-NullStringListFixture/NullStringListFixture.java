// jarde: presentation of `cf11/NullStringListFixture` from the class file's own declaration and one recovery run per member.
// jarde: not a compilable project: no imports and no resources are claimed (the `package` line is the class file's own name, not a claim about a directory); every place this text is not a full recovery carries a marker of this prefix.
package cf11;

public class NullStringListFixture extends java.lang.Object {
    public static int effects;

    public NullStringListFixture() {
        // @method <init>()V
        // @declaration a constructor of `cf11.NullStringListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        super();
        return;
    }

    // jarde: generic Signature projection refused for `strings(Ljava/util/List;Ljava/util/List;)V`: unsupported (ordinary_generic_source_unproved): return source is not a proven parameter value or selected member creation
    public void strings(java.util.List arg1, java.util.List arg2) {
        // @method strings(Ljava/util/List;Ljava/util/List;)V
        // @declaration an instance method of `cf11.NullStringListFixture`, member flags 0x0001
        // recovered from bytecode; presentation is not claimed to compile
        java.lang.String local4;
        java.util.Iterator local5;
        for (java.lang.Object iteratorElement17 : arg1) {
            local4 = (java.lang.String) iteratorElement17;
            for (java.lang.Object iteratorElement47 : arg2) {
                java.lang.String local6 = (java.lang.String) iteratorElement47;
                if (local4.equals((java.lang.Object) local6)) {
                    if (local4.length() == 5) {
                        arg2.add((java.lang.Object) null);
                        cf11.NullStringListFixture.effects = cf11.NullStringListFixture.effects + 1;
                    } else {
                        arg1.remove((java.lang.Object) local6);
                        cf11.NullStringListFixture.effects = cf11.NullStringListFixture.effects + 1;
                    }
                }
            }
        }
        if (arg2.size() > 0) {
            arg1.clear();
            cf11.NullStringListFixture.effects = cf11.NullStringListFixture.effects + 1;
        }
        return;
    }
}
