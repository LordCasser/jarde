# CF11 inner foreach option 边界 v2

v1 的身份探针使用两个 `new Integer(5000)`，但生产方法只在 `value.intValue() == 5` 时执行 `available.add(...)`。因此 v1 没有进入 add 分支，`addedSameAsInner=true` 的预期无效。

v2 把 identity probe 的 outer 和 inner 值都改为独立构造的 `new Integer(5)`。它们数值相等、引用不同，会满足 add 分支；修改后的 `available.add(option)` 应把 inner 引用追加到列表。ArrayList 的 foreach 迭代随后预期抛出 `ConcurrentModificationException`，追加状态仍可观察为 `[5, 5]`、`addedSameAsInner=true`、`addedSameAsOuter=false`。

生产类仍只相对已验收 independent Integer 输入更改一个表达式：`available.add(value)` 改成 `available.add(option)`。`manifest.json` 按现有输入格式固定 Java 8 source level、target class 与 runner 的完整源文件字节数和 SHA-256。v1 文件和目录未覆盖。本候选未运行 JDK、Cargo 或其他工具链。
