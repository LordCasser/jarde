from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path('/Users/lordcasser/workspace/projects/jarde')
HERE=Path(__file__).resolve().parent
COLLECTOR=Path('/private/tmp/jarde-cf11-structured-list-current-wholeclass-collector-prep-luna-v1/collect_controls.py')
RECEIPT=Path('/private/tmp/jarde-cf11-structured-list-focused-root-v9/execution.json')
CLI=Path('/private/tmp/jarde-cf11-structured-list-candidate-cli-root-v2')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(COLLECTOR)=='17d4b2423a21c80d5cdefd9bd6b2a4d80f3a087471c7f5251395d40d74abf6fc'
assert sha(RECEIPT)=='38c778201ed6166c690d96c96183954882a23e28c0b43864f7bc3c9908c7c917'
assert sha(CLI)=='bf9757a42d70cb01909466595baa4ecfdbfed7cd585527e008944290ce7736b9'
record={'status':'running','collector_sha256':sha(COLLECTOR),'build_receipt_sha256':sha(RECEIPT),'cli_sha256':sha(CLI),'commands':[]}
def save():(HERE/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
save()
for family in ('inner-option','null-add','fixed','string','integer','controls'):
 seed=Path('/private/tmp/jarde-cf11-structured-list-current-'+family+'-debug-root-v1/execution.json')
 config=json.loads(seed.read_text())['collector_config']
 for mode in ('debug','none'):
  out=Path('/private/tmp/jarde-cf11-structured-list-final-'+family+'-'+mode+'-root-v1')
  args={**config,'source_debug':mode,'out':str(out),'cli':str(CLI),'cli_sha256':sha(CLI),'build_receipt':str(RECEIPT),'build_receipt_sha256':sha(RECEIPT),'receipt_cli_object':'cli_freeze','receipt_accepted_value':'passed_initial_product_validation'}
  argv=[sys.executable,'-B',str(COLLECTOR)]
  for key,value in args.items():argv+=['--'+key.replace('_','-'),str(value)]
  label=family+'-'+mode;row={'label':label,'argv':argv,'capture':str(out),'status':'running'};record['commands'].append(row);save()
  with (HERE/(label+'.stdout.raw')).open('wb') as so,(HERE/(label+'.stderr.raw')).open('wb') as se:
   row['exit_code']=subprocess.run(argv,cwd=ROOT,stdout=so,stderr=se).returncode
  row['status']='terminal';row['streams']={}
  for name in ('stdout','stderr'):
   p=HERE/(label+'.'+name+'.raw');row['streams'][name]={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
  save();print(label,row['exit_code'],flush=True)
  if row['exit_code']!=0:record['status']='failed';save();raise SystemExit(row['exit_code'])
record['status']='captures_complete_not_independently_accepted';save()
