# CF11 final comparison acceptance checker v2

This private verifier extends the accepted v2 capture checker to the final 12-capture matrix: `fixed`, `string`, `integer`, `controls`, `inner-option`, and `null-add`, each with debug symbols and `-g:none`. It reads the saved captures and source tree; it does not run javac, JADX, Jarde, Cargo, or mutate the project. Its output explicitly leaves product acceptance and OpenSpec task completion false.

The verifier pins the current whole-class capture collector, root-owned batch runner, focused CLI receipt, base checker, parser, BLAKE3 runtime, and two added oracle manifests. Before checking captures, it asks the pinned collector's pure receipt validator to revalidate the complete focused build receipt, including all six raw command streams, the eight named API-test outcomes (`7 passed, 1 ignored`), all 371 named library tests, successful build and finally-clean, resource guard state, default Cargo target directory, and the live 4,822-file source manifest before/after/fmt closure. It independently checks the frozen CLI file's actual `0555` permissions.

For Jarde compilation, each javac argument list must exactly match the generated target source pin(s) for that JDK/profile plus the capture-local `inputs/Runner.java` copy. The copy’s byte count and SHA256 must equal the frozen Runner input, while its capture-local path must match both the receipt pin and javac argument. This includes both null-add target classes; omitted sources and extra unpinned inputs are rejected. The batch receipt must bind the pinned collector/CLI/focused-receipt hashes, each invocation must use the pinned collector path, and the pinned batch-runner file hash is checked.

`extra_oracles.json` pins the actual original compiler/runtime observations for `inner-option` and `null-add`. The inner identity label requires `addedSameAsInner=true` and `addedSameAsOuter=false`. The null-add manifest includes observed Java 8 and Java 23 source/class anchors for both debug profiles. The earlier inner no-debug original-class anchor is unavailable, so that one anchor result remains explicitly unbound; other checks still apply.

After the root-owned 12-capture batch reaches its terminal state, run this verifier with the actual paths supplied by the root. Do not substitute capture paths or hashes:

```sh
python3 /private/tmp/jarde-cf11-final-comparison-checker-luna-v2/accept_final_comparisons.py \
  --batch /actual/final-batch/execution.json \
  --focused-receipt /actual/focused-receipt/execution.json \
  --out /private/tmp/jarde-cf11-final-comparison-checker-luna-v2/acceptance.json
```

The script refuses to overwrite its output. The result verifies saved evidence only and does not establish product acceptance or task 1.2 completion.


The v2 source-binding failure was checked against actual fixed and null-add debug/none receipts: their Runner copies are capture-local, while the original source is under the input manifest directory. The v3 helper now compares the copy bytes/hash with the original and binds the copy path to receipt pins and javac arguments. Read-only source-binding checks passed for all four fixed/null-add captures; no final matrix acceptance was run.


Version 4 fixes the self-check schema string to match `pins.json` v3. The source-binding change from v3 is unchanged.
