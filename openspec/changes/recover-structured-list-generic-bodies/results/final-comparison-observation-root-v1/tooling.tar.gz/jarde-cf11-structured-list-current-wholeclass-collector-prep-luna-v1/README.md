# CF11 whole-class collector：focused runner v4（私有准备）

`collect_controls.py` 是从已审阅的 whole-class collector v6 复制的私有适配版。改动只在 focused build receipt preflight：绑定当前 focused runner v4 与其 preparation pins；精确要求 8 个 focused 测试名（7 passed、1 ignored）；并将完整 source manifest 的最低项数从旧的 4805 提高为 4822。receipt 中实际文件数仍动态读取；必须 before/after 完整列表相等，并通过 pinned focused runner v4 的 `source_manifest()` 与 `source_paths()` helper 独立重建完整期望清单，要求逐项精确相等；每个相对路径、字节数和 SHA-256 都与共享 workspace 当前文件一致。重复、越界、符号链接、缺失、遗漏或字节变化都会拒绝采集。focused runner v3 pins 中的 4805 是旧 prep 阶段历史值，v4 pins 的动态数量为 4822；collector 仍按当前 receipt 实际数量和 live 清单验证。

focused receipt 必须仍为 `cf11-structured-list-focused-run-v2` / `passed_initial_product_validation`，HEAD 固定为 `e9e3a0ec27e5bf7698bdf4817ff08d38bcb63374`，并通过六条 guarded 命令、finally `cargo clean`、target absent、source manifest before/after 和实际 CLI freeze 检查。CLI 路径、hash、receipt 路径及 hash 均按每次真实 v4 receipt 传入；collector 从参数与真实 receipt 的 `cli_freeze` 绑定获取 CLI，不预填旧 CLI 或构造 receipt。

JDK8/23、JADX、完整类、source-map、raw streams、命令 guard 与原 collector保持不变。12 项矩阵可复用当前六个 debug capture 的 `collector_config` 作为 seeds：fixed、string、integer、controls、inner-option、null-add。每个 seed 各运行 `--source-debug debug` 与 `--source-debug none`，并覆盖 `--out`、`--cli`、`--cli-sha256`、`--build-receipt`、`--build-receipt-sha256`；receipt 绑定选项使用 `--receipt-cli-object cli_freeze --receipt-status-key status --receipt-accepted-value passed_initial_product_validation --receipt-mode-key mode`。具体 CLI 和 receipt 参数必须来自 root 已完成的真实 focused v4 receipt。完整 seed execution pins 见 `pins.json`。

示例只表达 collector 参数关系；`$ACTUAL_*` 变量必须由 root 从本次 receipt 和 frozen CLI 填入，输出目录需为新的外部路径：

```sh
python3 -B /private/tmp/jarde-cf11-structured-list-current-wholeclass-collector-prep-luna-v1/collect_controls.py \
  --inputs-dir "$INPUTS_DIR" --inputs-manifest "$INPUTS_MANIFEST" \
  --source-debug debug --out "$FRESH_OUT" \
  --cli "$ACTUAL_CLI" --cli-sha256 "$ACTUAL_CLI_SHA256" \
  --build-receipt "$ACTUAL_RECEIPT" --build-receipt-sha256 "$ACTUAL_RECEIPT_SHA256" \
  --receipt-cli-object cli_freeze --receipt-status-key status \
  --receipt-accepted-value passed_initial_product_validation --receipt-mode-key mode \
  --jdk-manifest "$JDK_MANIFEST" --jdk-manifest-sha256 "$JDK_MANIFEST_SHA256" \
  --jadx "$JADX" --jadx-sha256 "$JADX_SHA256" \
  --jadx-jar "$JADX_JAR" --jadx-jar-sha256 "$JADX_JAR_SHA256" \
  --guard "$GUARD" --guard-sha256 "$GUARD_SHA256" \
  --scanner "$SCANNER" --scanner-sha256 "$SCANNER_SHA256" \
  --classfile-parser "$CLASSFILE_PARSER" --classfile-parser-sha256 "$CLASSFILE_PARSER_SHA256"
```

该 prep 没有执行 collector、Cargo、JDK、Git、网络或共享文件修改。它只为 root 后续独立采集准备脚本和输入引用，不代表 observation 成功或 product acceptance。
