# CF11 final comparison acceptance checker

This is a private, read-only verifier for the final 12 saved captures. It imports the previously accepted v2 comparison checker and extends its matrix to `fixed`, `string`, `integer`, `controls`, `inner-option`, and `null-add`, each with debug symbols and `-g:none`. It does not run javac, JADX, Jarde, Cargo, or mutate the project. Its output explicitly leaves product acceptance and OpenSpec task completion false.

`extra_oracles.json` pins actual original compiler/runtime observations for the inner-option and null-add families. The pins were taken from the observed capture receipts and their raw outputs/classes. The inner identity label requires `addedSameAsInner=true` and `addedSameAsOuter=false`. Null-add includes the observed Java 8 and Java 23 source/class anchors for both debug profiles. The inner no-debug original-class anchor is not available in the earlier capture, so that one class-anchor result is explicitly marked unbound; the new final capture still receives all other checks.

After the root-owned 12-capture batch reaches its terminal state, run this verifier with the actual paths supplied by the root. Do not substitute paths or hashes from this README:

```sh
python3 /private/tmp/jarde-cf11-final-comparison-checker-luna-v1/accept_final_comparisons.py \
  --batch /actual/final-batch/execution.json \
  --focused-receipt /actual/focused-receipt/execution.json \
  --out /private/tmp/jarde-cf11-final-comparison-checker-luna-v1/acceptance.json
```

The checker reads its pinned base checker, base pins, parser, BLAKE3 runtime, and extra-oracle manifest from the absolute paths in its source and `pins.json`. It refuses to overwrite the output. The output is an independent integrity/behavior observation over saved evidence, not product-level signoff.

Static preparation check: the Python source parses as an AST. No acceptance run has been made against the in-progress final batch.

Preparation-only read checks succeeded: AST parse and pins, both extra-oracle manifests against their raw execution receipts and original class files, seven inner-option labels/four null-add labels, and source-map physical coverage for the earlier observed debug captures. Those earlier generated sources are intentionally not used as acceptance fixtures because they predate the final typed projection. The in-progress final 12-capture batch has not been checked by this script.
