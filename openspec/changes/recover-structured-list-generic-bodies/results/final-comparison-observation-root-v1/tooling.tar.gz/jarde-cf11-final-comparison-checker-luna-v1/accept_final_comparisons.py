#!/usr/bin/env python3
"""Independently verify the frozen 12-capture CF11 comparison matrix."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
BASE_CHECKER = Path('/private/tmp/jarde-cf11-structured-list-current-comparison-accept-prep-luna-v2/accept_current_comparisons.py')
BASE_PINS = Path('/private/tmp/jarde-cf11-final-comparison-checker-luna-v1/base_v2_pins.json')
EXTRA_ORACLES = Path('/private/tmp/jarde-cf11-final-comparison-checker-luna-v1/extra_oracles.json')
PINS_PATH = Path(__file__).resolve().with_name('pins.json')
ROOT = Path('/Users/lordcasser/workspace/projects/jarde').resolve()
FAMILIES = ('fixed', 'string', 'integer', 'controls', 'inner-option', 'null-add')
MODES = ('debug', 'none')
SINGLE_CLASS_FAMILIES = ('fixed', 'string', 'integer', 'controls', 'inner-option')
COMMANDS = {'fixed': 29, 'string': 29, 'integer': 29, 'controls': 25, 'inner-option': 29, 'null-add': 35}
EXPECTED_LABELS = {
    'fixed': {'both-empty','unmatched','five-character-match-add','non-five-match-remove','non-five-match-continues-and-clears','null-first-list','null-second-list','null-element'},
    'string': {'string-isolated-empty','string-isolated-add-cme','string-isolated-remove-object-cme','string-isolated-null-element','string-isolated-null-list'},
    'integer': {'integer-isolated-empty','integer-isolated-add-cme','integer-isolated-remove-object-cme','integer-isolated-null-element','integer-isolated-null-list','integer-isolated-heap-pollution'},
    'controls': {'baseline-both-empty','baseline-unmatched','baseline-five-character-match-add','baseline-non-five-match-remove','baseline-remove-continues-and-clears','baseline-null-first-list','baseline-null-second-list','baseline-null-element','renamed-string-positive','integer-nested-add-positive','explicit-cast-object-boundary','raw-list-method-control','raw-alias-heap-pollution','parameter-reassignment','wildcard-null-write','try-catch-handler','remove-object-and-index-overloads'},
    'inner-option': {'integer-isolated-empty','integer-isolated-add-cme','integer-isolated-remove-object-cme','integer-isolated-null-element','integer-isolated-null-list','integer-isolated-heap-pollution','integer-inner-option-identity'},
    'null-add': {'string-null-add-cme','string-no-match','integer-null-add-cme','integer-no-match'},
}
MIN_FREE, MAX_TARGET = 5 * 1024**3, 1024**3
BASE = None
PARSER = None
BLAKE3 = None
PIN_DATA = None
ORACLE_DATA = None
CLI_FREEZE = None
RECEIPT_PIN = None
BATCH_PATH = None


def need(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def digest_file(path: Path) -> dict:
    h = hashlib.sha256(); size = 0
    with Path(path).open('rb') as stream:
        while block := stream.read(1024 * 1024):
            h.update(block); size += len(block)
    return {'path': str(Path(path).resolve()), 'bytes': size, 'sha256': h.hexdigest()}


def load_json(path: Path) -> dict:
    return json.loads(Path(path).read_text(encoding='utf-8'))


def file_pin(path: Path) -> dict:
    return digest_file(path)


def load_base():
    global BASE, PARSER, BLAKE3, PIN_DATA, ORACLE_DATA
    base_pins = load_json(BASE_PINS)
    base_pin = base_pins['artifacts']['accept_current_comparisons.py']
    need(digest_file(BASE_CHECKER) == base_pin, 'accepted v2 checker changed')
    spec = importlib.util.spec_from_file_location('cf11_accepted_v2_checker', BASE_CHECKER)
    need(spec is not None and spec.loader is not None, 'cannot load accepted v2 checker')
    BASE = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(BASE)
    BASE.PIN_DATA = base_pins
    PIN_DATA = load_json(PINS_PATH)
    need(PIN_DATA.get('schema') == 'cf11-final-comparison-checker-pins-v1', 'checker pins schema mismatch')
    need(PIN_DATA.get('base_checker') == base_pin, 'base checker pin differs')
    need(PIN_DATA.get('base_pins') == digest_file(BASE_PINS), 'base pins changed')
    need(PIN_DATA.get('extra_oracles') == digest_file(EXTRA_ORACLES), 'extra oracle manifest changed')
    need(digest_file(Path(__file__)) == PIN_DATA.get('checker'), 'final checker script differs from pins')
    parser_pin = base_pins['classfile_parser']
    need(digest_file(Path(parser_pin['path'])) == parser_pin, 'pinned classfile parser differs')
    PARSER = BASE.pinned_module('cf11_final_comparison_classfile_parser', Path(parser_pin['path']), parser_pin['sha256'])
    BLAKE3, _ = BASE.load_blake3()
    BASE.PARSER = PARSER
    BASE.BLAKE3 = BLAKE3
    ORACLE_DATA = load_json(EXTRA_ORACLES)
    need(ORACLE_DATA.get('schema') == 'cf11-final-comparison-extra-oracles-v1' and ORACLE_DATA.get('status') == 'frozen_from_observed_original_runs', 'extra oracle manifest status differs')


def labels_from_stdout(data: bytes, family: str) -> list[str]:
    try:
        lines = data.decode('utf-8').splitlines()
    except UnicodeDecodeError as error:
        raise ValueError(f'{family} oracle is not UTF-8: {error}')
    need(lines and all(lines), f'{family} oracle has an empty row')
    labels = []
    for line in lines:
        fields = line.split('|')
        label = fields[0]
        need(label, f'{family} oracle row has an empty label')
        labels.append(label)
        need(len(fields) >= 2 and fields[1].startswith('exception=') and fields[1].split('=', 1)[1], f'{family} row lacks an exception result')
        if family == 'fixed':
            need(len(fields) == 4 and fields[2].startswith('l1=') and fields[3].startswith('l2='), 'fixed oracle row field shape differs')
        else:
            need(len(fields) >= 5 and fields[2].startswith(('left=', 'selected=')) and fields[3].startswith(('right=', 'available=')) and fields[4].startswith('effects=') and fields[4][8:].isdigit(), f'{family} oracle row state/effects fields differ')
    need(len(labels) == len(set(labels)) and set(labels) == EXPECTED_LABELS[family], f'{family} exact oracle label set differs')
    if family == 'inner-option':
        line = next(line for line in lines if line.startswith('integer-inner-option-identity|'))
        fields = dict(field.split('=', 1) for field in line.split('|')[1:] if '=' in field)
        need(fields.get('addedSameAsInner') == 'true' and fields.get('addedSameAsOuter') == 'false', 'inner-option identity oracle is not exact')
    return labels


def verify_extra_oracle(family: str) -> tuple[dict, bytes]:
    anchor = ORACLE_DATA['families'][family]
    execution_pin = anchor['execution']
    need(digest_file(Path(execution_pin['path'])) == execution_pin, f'{family} old oracle execution pin differs')
    run = load_json(Path(execution_pin['path']))
    need(run.get('status') == 'observed' and run.get('classes') == anchor['classes'], f'{family} frozen oracle capture is not observed or class set differs')
    manifest_pin = anchor['inputs_manifest']
    need(digest_file(Path(manifest_pin['path'])) == manifest_pin, f'{family} input manifest pin differs')
    need(run.get('inputs_manifest') == manifest_pin and run.get('input_entries') == anchor['input_entries'], f'{family} input manifest entries differ')
    inputs_dir = Path(run.get('collector_config', {}).get('inputs_dir', ''))
    for entry in anchor['input_entries'].get('target_classes', []) + [anchor['input_entries'].get('runner', {})]:
        source = inputs_dir / entry['source']
        need(source.is_file() and digest_file(source)['bytes'] == entry['bytes'] and digest_file(source)['sha256'] == entry['sha256'], f'{family} frozen input source differs: {source}')
    outputs = []
    for jdk in ('javac8', 'javac23'):
        comp = next((row for row in run.get('original_compile_rows', []) if row.get('label') == f'{jdk}-original'), None)
        need(comp is not None and comp.get('compile_exit') == 0 and comp.get('class_set_exact') is True and comp.get('run_exit') == 0, f'{family}/{jdk} original oracle compile/run absent')
        command = next((row for row in run.get('commands', []) if row.get('label') == comp.get('run_command')), None)
        need(command is not None and command.get('exit_code') == 0, f'{family}/{jdk} original run command failed')
        expected = anchor['oracle_runs'][jdk]
        stdout = command.get('streams', {}).get('stdout', {})
        stderr = command.get('streams', {}).get('stderr', {})
        need(digest_file(Path(stdout['path'])) == expected['stdout'] and stdout == expected['stdout'], f'{family}/{jdk} frozen stdout pin differs')
        need(digest_file(Path(stderr['path'])) == expected['stderr'] and stderr['bytes'] == 0, f'{family}/{jdk} frozen stderr pin differs/nonempty')
        original_classes = anchor['original_class_pins'][jdk]
        need(comp.get('classes') == original_classes, f'{family}/{jdk} original class pins differ')
        for class_pin in original_classes:
            need(digest_file(Path(class_pin['path'])) == class_pin, f'{family}/{jdk} original class changed')
        outputs.append(Path(stdout['path']).read_bytes())
    need(outputs[0] == outputs[1], f'{family} Java 8 and Java 23 frozen oracle output differs')
    need(sha(outputs[0]) == anchor['oracle_runs']['javac8']['stdout']['sha256'], f'{family} stdout hash differs')
    labels_from_stdout(outputs[0], family)
    return run, outputs[0]


def oracle_for(family: str) -> tuple[dict, bytes]:
    if family in ('fixed', 'string', 'integer', 'controls'):
        run, output = BASE.oracle_for(family)
        labels_from_stdout(output, family)
        return run, output
    return verify_extra_oracle(family)


def verify_batch(batch_path: Path, receipt_pin: dict, cli_freeze: dict) -> tuple[dict, dict[str, Path]]:
    batch = load_json(batch_path)
    need(batch.get('status') == 'captures_complete_not_independently_accepted', 'batch receipt is not terminal/complete')
    rows = batch.get('commands')
    expected_keys = {f'{family}-{mode}' for family in FAMILIES for mode in MODES}
    need(isinstance(rows, list) and len(rows) == 12, 'final batch must contain exactly 12 capture invocations')
    by_label = {row.get('label'): row for row in rows}
    need(len(by_label) == 12 and set(by_label) == expected_keys, 'batch invocation labels differ from the exact 12-capture matrix')
    captures = {}
    for family in FAMILIES:
        for mode in MODES:
            key = f'{family}-{mode}'
            row = by_label[key]
            path = Path(row.get('capture', '')).resolve()
            need(row.get('status') == 'terminal' and row.get('exit_code') == 0 and path.is_dir(), f'{key} capture invocation failed or directory missing')
            count = COMMANDS[family]
            captures[key] = path
            argv = row.get('argv', [])
            need('--out' in argv and Path(argv[argv.index('--out') + 1]).resolve() == path, f'{key} --out differs from batch capture')
            need('--source-debug' in argv and argv[argv.index('--source-debug') + 1] == mode, f'{key} source-debug differs')
            need('--cli' in argv and Path(argv[argv.index('--cli') + 1]).resolve() == Path(cli_freeze['path']).resolve(), f'{key} CLI differs from focused receipt')
            need('--cli-sha256' in argv and argv[argv.index('--cli-sha256') + 1] == cli_freeze['sha256'], f'{key} CLI SHA differs')
            need('--build-receipt' in argv and Path(argv[argv.index('--build-receipt') + 1]).resolve() == Path(receipt_pin['path']).resolve(), f'{key} focused receipt path differs')
            need('--build-receipt-sha256' in argv and argv[argv.index('--build-receipt-sha256') + 1] == receipt_pin['sha256'], f'{key} focused receipt SHA differs')
            for stream in ('stdout', 'stderr'):
                pin = row.get('streams', {}).get(stream)
                need(isinstance(pin, dict) and digest_file(Path(pin['path'])) == pin, f'{key} batch {stream} pin differs')
    return batch, captures


def verify_live_cli_and_receipt(receipt_path: Path) -> tuple[dict, dict]:
    receipt_pin = digest_file(receipt_path)
    receipt = load_json(receipt_path)
    need(receipt.get('schema') == 'cf11-structured-list-focused-run-v2' and receipt.get('status') == 'passed_initial_product_validation', 'focused receipt schema/status differs')
    cli = receipt.get('cli_freeze')
    need(isinstance(cli, dict) and {'path', 'bytes', 'sha256', 'mode'} <= cli.keys(), 'focused receipt CLI freeze absent')
    cli_pin = {key: cli[key] for key in ('path', 'bytes', 'sha256')}
    need(digest_file(Path(cli['path'])) == cli_pin and cli.get('mode') == '0o555', 'focused CLI artifact differs from receipt freeze')
    return receipt_pin, cli


def verify_source_tool_pins(run: dict, receipt_pin: dict, cli_freeze: dict) -> None:
    before = run.get('source_tool_pins_before'); after = run.get('source_tool_pins_after')
    need(isinstance(before, list) and before and before == after and run.get('source_tool_inputs_unchanged') is True, 'source/tool pins changed during capture')
    seen = set(); cli_pin = {key: cli_freeze[key] for key in ('path', 'bytes', 'sha256')}; found_cli = False
    for pin in before:
        path = Path(pin['path']).resolve()
        need(str(path) not in seen, f'duplicate source/tool pin: {path}')
        seen.add(str(path))
        need(digest_file(path) == pin, f'source/tool file changed after capture: {path}')
        if path == Path(cli_freeze['path']).resolve():
            need(pin == cli_pin, 'capture CLI pin differs from focused receipt')
            found_cli = True
    need(found_cli, 'capture source/tool pins omit focused CLI')
    need(run.get('cli') == cli_pin and run.get('cli_mode') == cli_freeze['mode'], 'capture CLI or mode differs from focused receipt')
    need(run.get('build_receipt') == receipt_pin and run.get('build_receipt_cli_binding') == cli_freeze, 'capture does not bind focused receipt and CLI')
    validation = run.get('build_receipt_validation', {}).get('source_manifest', {})
    need(isinstance(validation.get('count'), int) and validation['count'] > 0, 'capture lacks source closure validation')


def verify_original_rows(run: dict, raw: dict[int, dict[str, bytes]], family: str, oracle: bytes) -> list[str]:
    labels = {row['label']: row for row in run['commands']}
    outputs = []
    for jdk in ('javac8', 'javac23'):
        comp = labels.get(f'{jdk}-original-compile'); runrow = labels.get(f'{jdk}-original-run')
        need(comp is not None and comp.get('exit_code') == 0 and runrow is not None and runrow.get('exit_code') == 0, f'{family}/{jdk} original compile/run failed')
        need(raw[runrow['index']]['stderr'] == b'', f'{family}/{jdk} original runner wrote stderr')
        stdout = raw[runrow['index']]['stdout']
        need(stdout == oracle, f'{family}/{jdk} original output differs byte-for-byte from frozen oracle')
        outputs.append(stdout)
    need(outputs[0] == outputs[1], f'{family} Java 8/23 original outputs differ')
    labels_seen = labels_from_stdout(outputs[0], family)
    return labels_seen


def verify_class_profiles(run: dict, root: Path, family: str) -> tuple[list[dict], list[dict]]:
    profiles = run.get('jarde_profiles', [])
    classes = run.get('classes', [])
    expected_classes = set(classes)
    expected = {(class_name, jdk, mode) for class_name in expected_classes for jdk in ('javac8', 'javac23') for mode in ('default', 'all')}
    actual = {(row.get('class'), row.get('jdk'), row.get('mode')) for row in profiles}
    need(len(profiles) == len(expected) and actual == expected, f'{family} Jarde profile matrix differs')
    for profile in profiles:
        need(profile.get('render_exit') == 0, f'{family}/{profile.get("label")} render failed')
        command = next((row for row in run.get('commands', []) if row.get('label') == profile.get('render_command')), None)
        need(command is not None and command.get('exit_code') == 0, f'{family}/{profile.get("label")} render command absent/failed')
        need(profile.get('render_stdout_sha256') == sha((root/'raw'/f"{command['index']}.stdout.raw").read_bytes()) and profile.get('render_stderr_sha256') == sha((root/'raw'/f"{command['index']}.stderr.raw").read_bytes()), f'{family}/{profile.get("label")} render raw hashes differ')
    fingerprints = [BASE.verify_rendered_class_b3(run, root, profile) for profile in profiles]
    return profiles, fingerprints


def verify_source_map_utf8(report: dict, label: str) -> None:
    text = report.get('text')
    segments = report.get('source_map', {}).get('segments')
    need(isinstance(text, str) and isinstance(segments, list) and segments, f'{label} raw source/map absent')
    encoded = text.encode('utf-8')
    for segment in segments:
        start, end = segment.get('start'), segment.get('end')
        need(isinstance(start, int) and isinstance(end, int) and 0 <= start <= end <= len(encoded), f'{label} source-map byte span out of bounds')
        try:
            encoded[start:end].decode('utf-8')
        except UnicodeDecodeError:
            raise ValueError(f'{label} source-map span splits a UTF-8 code point')


def verify_physical_maps(run: dict, root: Path, profiles: list[dict], family: str) -> list[dict]:
    out = []
    for profile in profiles:
        doc = load_json(Path(profile['report_pin']['path']))
        class_path, _ = BASE.physical_class(run, root, profile['jdk'], profile['class'])
        gaps = []
        for method in doc.get('methods', []):
            identity = method.get('item', {}).get('identity', {})
            name = bytes(identity.get('name', [])).decode('ascii')
            desc = bytes(identity.get('descriptor', [])).decode('ascii')
            parsed = PARSER.parse_method(class_path.read_bytes(), name, desc)
            physical = {pc for pc, _, _ in PARSER.decode(parsed['code'])}
            rec = method.get('outcome', {}).get('report', {})
            verify_source_map_utf8(rec, f'{profile["label"]} {name}{desc}')
            segments = rec.get('source_map', {}).get('segments')
            mapped = set()
            for segment in segments:
                origin = segment.get('origin', {})
                facts = ([origin['primary']] if origin.get('primary') is not None else []) + origin.get('derived', [])
                for fact in facts:
                    need(fact.get('method') == identity, f'{profile["label"]} {name}{desc} map belongs to another method')
                    bci = fact.get('bci')
                    need(bci in physical, f'{profile["label"]} {name}{desc} map references nonphysical BCI {bci}')
                    mapped.add(bci)
            missing = sorted(physical - mapped)
            if missing:
                gaps.append({'name': name, 'descriptor': desc, 'physical_instruction_count': len(physical), 'mapped_bci_count': len(mapped), 'missing_physical_bcis': missing, 'exception_handler_count': parsed['exception_count']})
        if family == 'controls':
            need(len(gaps) == 1 and gaps[0]['name'] == 'handled' and gaps[0]['exception_handler_count'] == 1, f'controls physical map gap differs: {profile["label"]} {gaps}')
        else:
            need(not gaps, f'{family} physical body map gaps: {profile["label"]} {gaps}')
        out.append({'label': profile['label'], 'class': profile['class'], 'method_count': len(doc.get('methods', [])), 'physical_coverage_complete': not gaps, 'gaps': gaps})
    return out


def verify_default_all(profiles: list[dict]) -> list[dict]:
    out = []
    for class_name in sorted({row['class'] for row in profiles}):
        for jdk in ('javac8', 'javac23'):
            left = next(row for row in profiles if row['class'] == class_name and row['jdk'] == jdk and row['mode'] == 'default')
            right = next(row for row in profiles if row['class'] == class_name and row['jdk'] == jdk and row['mode'] == 'all')
            a, b = load_json(Path(left['report_pin']['path'])), load_json(Path(right['report_pin']['path']))
            sig = lambda doc: [(m.get('item', {}).get('identity'), m.get('text'), m.get('outcome', {}).get('report', {}).get('source_map', {}).get('segments')) for m in doc.get('methods', [])]
            need(a.get('text') == b.get('text') and sig(a) == sig(b), f'{class_name}/{jdk} default/all source/map differs')
            out.append({'class': class_name, 'jdk': jdk, 'default_all_equal': True})
    return out


def verify_source_text(family: str, profiles: list[dict]) -> list[dict]:
    results = []
    for profile in profiles:
        source = Path(profile['source_pin']['path'])
        need(digest_file(source) == profile['source_pin'], f'{profile["label"]} generated source pin changed')
        text = source.read_text(encoding='utf-8')
        if family == 'fixed':
            element = 'String'; add = r'\.add\(\s*[A-Za-z_$][\w$]*\s*\)'
        elif family in ('string',):
            element = 'String'; add = r'\.add\(\s*[A-Za-z_$][\w$]*\s*\)'
        elif family in ('integer', 'inner-option'):
            element = 'Integer'; add = r'\.add\(\s*[A-Za-z_$][\w$]*\s*\)'
        elif family == 'null-add':
            element = 'String' if profile['class'].endswith('NullStringListFixture') else 'Integer'
            add = r'\.add\(\s*null\s*\)'
        else:
            return []
        need(re.search(r'java\.util\.List<java\.lang\.' + element + r'>', text) is not None, f'{profile["label"]} List<{element}> absent')
        need(re.search(add, text) is not None, f'{profile["label"]} expected add operand absent')
        need(re.search(r'\.remove\(\s*\(java\.lang\.Object\)\s*[A-Za-z_$][\w$]*\s*\)', text) is not None, f'{profile["label"]} remove(Object) overload/cast absent')
        need(re.search(r'\(java\.lang\.' + element + r'\)\s*iteratorElement', text) is not None, f'{profile["label"]} physical iterator element cast absent')
        results.append({'label': profile['label'], 'class': profile['class'], 'generic_element': element, 'typed_add': True, 'object_remove': True, 'physical_cast': True})
    return results


def verify_null_compile_groups(run: dict, raw: dict[int, dict[str, bytes]], oracle: bytes, profiles: list[dict], mode: str) -> dict:
    mapped = {row['label']: row for row in run.get('commands', [])}
    need(len(mapped) == len(run.get('commands', [])), 'null-add duplicate command labels')
    rows = run.get('jarde_compile_rows', []) + run.get('jadx_compile_rows', [])
    need(len(run.get('jarde_compile_rows', [])) == 4 and len(run.get('jadx_compile_rows', [])) == 4 and len(rows) == 8, 'null-add requires four Jarde and four JADX complete pairs')
    expected = set()
    for jdk in ('javac8', 'javac23'):
        expected.update({f'{jdk}-jarde-default-combined', f'{jdk}-jarde-all-combined', f'{jdk}-jadx-default', f'{jdk}-jadx-none'})
    by_label = {row.get('label'): row for row in rows}
    need(len(by_label) == 8 and set(by_label) == expected, 'null-add combined compile/run labels differ')
    target_classes = set(run['classes'])
    expected_class_paths = sorted([name.replace('.', '/') + '.class' for name in target_classes] + ['cf11/Runner.class'])
    for label, item in by_label.items():
        need(item.get('compile_exit') == 0 and item.get('run_exit') == 0 and item.get('class_set_exact') is True, f'null-add compile/run pair failed: {label}')
        comp = mapped.get(item.get('compile_command')); runrow = mapped.get(item.get('run_command'))
        need(comp is not None and comp.get('exit_code') == 0 and runrow is not None and runrow.get('exit_code') == 0, f'null-add raw command receipt absent: {label}')
        need(raw[runrow['index']]['stdout'] == oracle and raw[runrow['index']]['stderr'] == b'', f'null-add {label} runtime differs from frozen oracle bytes')
        need(item.get('class_paths') == expected_class_paths, f'null-add class path set differs: {label}')
        for class_pin in item.get('classes', []):
            need(digest_file(Path(class_pin['path'])) == class_pin, f'null-add generated class SHA differs: {label}')
        flags = [arg for arg in comp['argv'] if arg in ('-g', '-g:none')]
        need(flags == (['-g:none'] if mode == 'none' else ['-g']), f'null-add compile debug flag differs: {label}')
    for item in run.get('jarde_compile_rows', []):
        jdk, style = item['label'].split('-')[0], item['label'].split('-')[2]
        expected_sources = {}
        for profile in profiles:
            if profile['jdk'] == jdk and profile['mode'] == style:
                expected_sources[Path(profile['source_pin']['path']).name] = profile['source_pin']
        need(set(expected_sources) == {'NullStringListFixture.java', 'NullIntegerListFixture.java'}, f'null-add {item["label"]} profiles incomplete')
        for source_pin in item.get('source_pins', []):
            if Path(source_pin['path']).name in expected_sources:
                need(source_pin == expected_sources[Path(source_pin['path']).name] and digest_file(Path(source_pin['path'])) == source_pin, f'null-add compile source differs from rendered profile: {item["label"]}')
    return {'positive_compile_run_pairs': 8, 'all_runtime_bytes_equal_frozen_oracle': True, 'two_target_classes_compiled_together': True, 'jadx_and_jarde_checked': True}


def verify_compile_groups(run: dict, raw: dict[int, dict[str, bytes]], family: str, oracle: bytes, profiles: list[dict], mode: str) -> dict:
    if family == 'controls':
        return BASE.verify_compile_groups(run, raw, 'controls', run['classes'][0], mode, oracle)
    if family == 'null-add':
        return verify_null_compile_groups(run, raw, oracle, profiles, mode)
    base_family = 'integer' if family == 'inner-option' else family
    return BASE.verify_compile_groups(run, raw, base_family, run['classes'][0], mode, oracle)


def verify_javap(run: dict, raw: dict[int, dict[str, bytes]], root: Path, family: str, mode: str) -> list[dict]:
    if mode != 'none':
        return []
    items = run.get('javap', [])
    expected = {(class_name, jdk) for class_name in run['classes'] for jdk in ('javac8', 'javac23')}
    actual = {(item.get('class'), item.get('jdk')) for item in items}
    need(len(items) == len(expected) and actual == expected, f'{family} no-debug javap matrix differs')
    out = []
    for item in items:
        row = next((candidate for candidate in run['commands'] if candidate.get('label') == item.get('command')), None)
        need(row is not None and row.get('exit_code') == 0, f'{family} no-debug javap command failed')
        stdout = raw[row['index']]['stdout']; pin = item['stdout_pin']; path = Path(pin['path'])
        need(digest_file(path) == pin and path.read_bytes() == stdout, f'{family} no-debug javap capture differs')
        text = stdout.decode('utf-8')
        start = text.find(item['class'].split('.')[-1] + '(')
        section = text[start:] if start >= 0 else text
        need(re.search(r'^\s*(?:LineNumberTable|LocalVariableTable|LocalVariableTypeTable):', section, re.M) is None, f'{family}/{item["class"]} no-debug javap contains debug tables')
        need(re.search(r'^\s*Signature:', section, re.M) is not None, f'{family}/{item["class"]} no-debug javap lacks generic Signature')
        out.append({'class': item['class'], 'jdk': item['jdk'], 'debug_tables_absent': True, 'signature_present': True})
    return out


def verify_class_anchor(run: dict, root: Path, family: str, mode: str, anchor_run: dict, anchor_extra: dict | None) -> dict:
    if family in ('fixed', 'string', 'integer', 'controls'):
        return BASE.verify_original_class_anchor(run, root, family, mode)
    mode_pins = (anchor_extra or {}).get('mode_class_pins', {}).get(mode)
    if mode_pins is None:
        return {'anchor_bound': False, 'reason': f'no frozen {mode} class anchor'}
    checked = []
    for jdk in ('javac8', 'javac23'):
        current = next(row for row in run['original_compile_rows'] if row['label'] == f'{jdk}-original')
        current_by_name = {Path(item['path']).name: item for item in current['classes']}
        expected_by_name = {Path(item['path']).name: item for item in mode_pins[jdk]}
        need(set(current_by_name) == set(expected_by_name), f'{family}/{mode}/{jdk} original class set differs from frozen mode anchor')
        for name, pin in expected_by_name.items():
            actual = current_by_name[name]
            need(actual['bytes'] == pin['bytes'] and actual['sha256'] == pin['sha256'], f'{family}/{mode}/{jdk} original class differs from frozen mode anchor: {name}')
            checked.append({'jdk': jdk, 'class_file': name, 'bytes': actual['bytes'], 'sha256': actual['sha256']})
    return {'anchor_bound': True, 'physical_classes': checked}


def verify_capture(key: str, family: str, mode: str, root: Path, anchor_run: dict, oracle: bytes, receipt_pin: dict, cli_freeze: dict, extra_anchor: dict | None) -> dict:
    execution = root / 'execution.json'; run = load_json(execution)
    need(run.get('schema') == 'cf11-target-full-source-capture-v2' and run.get('status') == 'observed', f'{key} capture not observed')
    need(run.get('compiler_debug_info') == mode and run.get('collector_config', {}).get('source_debug') == mode, f'{key} debug mode differs')
    need(run.get('classes') == anchor_run.get('classes') and run.get('input_entries') == anchor_run.get('input_entries'), f'{key} target classes/input fixture differ from oracle')
    need(run.get('inputs_manifest_path') == anchor_run.get('inputs_manifest_path') and digest_file(Path(run['inputs_manifest_path'])) == run['inputs_manifest'], f'{key} input manifest differs')
    cfg, base_cfg = run.get('collector_config', {}), anchor_run.get('collector_config', {})
    for field in ('inputs_dir','inputs_manifest','jdk_manifest','jdk_manifest_sha256','jadx','jadx_sha256','jadx_jar','jadx_jar_sha256','guard','guard_sha256','scanner','scanner_sha256','classfile_parser','classfile_parser_sha256'):
        need(cfg.get(field) == base_cfg.get(field), f'{key} frozen tool/input pin differs: {field}')
    need(cfg.get('cli') == cli_freeze['path'] and cfg.get('cli_sha256') == cli_freeze['sha256'], f'{key} CLI config differs')
    need(cfg.get('build_receipt') == receipt_pin['path'] and cfg.get('build_receipt_sha256') == receipt_pin['sha256'], f'{key} focused receipt config differs')
    need(cfg.get('receipt_cli_object') == 'cli_freeze' and cfg.get('receipt_accepted_value') == 'passed_initial_product_validation', f'{key} focused receipt binding differs')
    expected_count = COMMANDS[family]
    need(len(run.get('commands', [])) == expected_count and run.get('actual_command_count') == expected_count, f'{key} command count differs')
    need(run.get('resource_guard') == {'minimum_free_bytes': MIN_FREE, 'maximum_target_bytes': MAX_TARGET, 'poll_seconds': 1, 'peak_target_sampled': True}, f'{key} resource guard differs')
    verify_source_tool_pins(run, receipt_pin, cli_freeze)
    raw = BASE.verify_raw_streams(run, root)
    for row in run['commands']:
        if row['label'].endswith('-compile'):
            flags = [arg for arg in row['argv'] if arg in ('-g', '-g:none')]
            need(flags == (['-g:none'] if mode == 'none' else ['-g']), f'{key} javac debug flag differs: {row["label"]}')
    oracle_labels = verify_original_rows(run, raw, family, oracle)
    need(len(run.get('original_compile_rows', [])) == 2, f'{key} original JDK inventory differs')
    for row in run['original_compile_rows']:
        need(row.get('class_set_exact') is True and row.get('run_exit') == 0, f'{key} original class set/run differs')
    profiles, fingerprints = verify_class_profiles(run, root, family)
    default_all = verify_default_all(profiles)
    compile = verify_compile_groups(run, raw, family, oracle, profiles, mode)
    body_maps = verify_physical_maps(run, root, profiles, family)
    gaps = BASE.verify_source_map_gaps(run, root, profiles, raw, mode) if family == 'controls' else []
    source_types = verify_source_text(family, profiles)
    javap = verify_javap(run, raw, root, family, mode)
    class_anchor = verify_class_anchor(run, root, family, mode, anchor_run, extra_anchor)
    return {
        'key': key, 'family': family, 'mode': mode, 'execution': digest_file(execution),
        'classes': run['classes'], 'command_count': expected_count, 'raw_stream_count': expected_count * 2,
        'oracle_labels': oracle_labels, 'oracle_sha256': sha(oracle), 'oracle_bytes': len(oracle),
        'original_class_anchor': class_anchor, 'source_tool_pin_count': len(run['source_tool_pins_before']),
        'source_tool_pins_stable_and_live': True, 'physical_class_b3_and_body_maps': fingerprints,
        'default_all': default_all, 'compile_observation': compile, 'generic_source_checks': source_types,
        'physical_body_maps': body_maps, 'handler_source_map_gaps': gaps, 'no_debug_javap': javap,
    }


def verify_all(args) -> dict:
    global RECEIPT_PIN, CLI_FREEZE, BATCH_PATH, EXTRA_ORACLES
    load_base()
    receipt_path = args.focused_receipt.resolve(); RECEIPT_PIN, CLI_FREEZE = verify_live_cli_and_receipt(receipt_path)
    need(args.extra_oracles.resolve() == EXTRA_ORACLES.resolve(), 'extra oracle path differs from frozen manifest')
    batch_path = args.batch.resolve(); BATCH_PATH = batch_path
    batch, capture_paths = verify_batch(batch_path, RECEIPT_PIN, CLI_FREEZE)
    anchors = {}; oracles = {}; extra_anchors = {}
    for family in FAMILIES:
        if family in ('fixed', 'string', 'integer', 'controls'):
            anchors[family], oracles[family] = BASE.oracle_for(family)
        else:
            anchors[family], oracles[family] = verify_extra_oracle(family)
            extra_anchors[family] = ORACLE_DATA['families'][family]
    results = {}
    for family in FAMILIES:
        for mode in MODES:
            key = f'{family}-{mode}'
            results[key] = verify_capture(key, family, mode, capture_paths[key], anchors[family], oracles[family], RECEIPT_PIN, CLI_FREEZE, extra_anchors.get(family))
    for family in FAMILIES:
        left, right = results[f'{family}-debug'], results[f'{family}-none']
        need(left['oracle_labels'] == right['oracle_labels'] and left['oracle_sha256'] == right['oracle_sha256'], f'{family} debug/none oracle differs')
        need(set(left['oracle_labels']) == EXPECTED_LABELS[family], f'{family} exact labels differ')
    need(sum(row['command_count'] for row in results.values()) == 352, 'final 12-capture command total differs from 352')
    need(sum(row['raw_stream_count'] for row in results.values()) == 704, 'final raw stream total differs from 704')
    positive_pairs = sum(row['compile_observation'].get('positive_compile_run_pairs', 0) for row in results.values())
    negative_groups = sum(row['compile_observation'].get('negative_compile_groups', 0) for row in results.values())
    need(positive_pairs == 80 and negative_groups == 24, 'positive/negative compile totals differ')
    debug_gaps, none_gaps = results['controls-debug']['handler_source_map_gaps'], results['controls-none']['handler_source_map_gaps']
    gap_key = lambda row: (row['jdk'], row['label'], tuple(row['missing_physical_bcis']), row['exception_handler_count'])
    need(sorted(map(gap_key, debug_gaps)) == sorted(map(gap_key, none_gaps)), 'controls debug/none handler map gaps differ')
    b3after = BASE.blake3_inventory()
    need(b3after == BASE.PIN_DATA['blake3_dependency']['files_after_check'], 'blake3 package inventory changed during verification')
    expected_label_union = set().union(*(EXPECTED_LABELS[family] for family in FAMILIES))
    need(len(expected_label_union) == 41, 'cross-family oracle label union differs')
    return {
        'schema': 'cf11-final-comparison-observation-acceptance-v1',
        'status': 'verified_current_saved_comparison_observations',
        'product_acceptance': False, 'task1_2_complete': False,
        'acceptance_scope': 'saved raw evidence integrity, exact frozen-oracle equality, generated source/class checks, and physical-body source-map coverage',
        'batch_execution': digest_file(BATCH_PATH), 'focused_receipt': RECEIPT_PIN,
        'capture_count': len(results), 'actual_command_count': 352, 'raw_stream_count': 704,
        'oracle_label_counts': {family: len(EXPECTED_LABELS[family]) for family in FAMILIES},
        'oracle_family_label_union_count': len(expected_label_union), 'debug_none_oracles_equal': True,
        'positive_compile_run_pairs': positive_pairs, 'combined_failed_compile_groups': negative_groups,
        'controls_compile_failures_without_runtime': True, 'controls_handler_gaps_per_mode': 4,
        'captures': list(results.values()),
        'remaining_limitations': ['This checker verifies saved comparison evidence only; it does not establish product acceptance or task 1.2 completion.', 'Stopping/negative-SSA attribution remains outside this comparison batch.'],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--batch', type=Path, required=True, help='final 12-capture batch execution.json')
    parser.add_argument('--focused-receipt', type=Path, required=True, help='frozen focused CLI build receipt execution.json')
    parser.add_argument('--extra-oracles', type=Path, default=EXTRA_ORACLES, help='pinned inner-option/null-add old oracle manifest')
    parser.add_argument('--out', type=Path, required=True, help='new acceptance JSON path')
    args = parser.parse_args()
    out = args.out.resolve()
    need(not out.exists(), f'refuse overwrite: {out}')
    result = verify_all(args)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': result['status'], 'out': str(out), 'captures': result['capture_count'], 'commands': result['actual_command_count'], 'raw_streams': result['raw_stream_count'], 'product_acceptance': False, 'task1_2_complete': False}, ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, KeyError, OSError, TypeError, IndexError) as error:
        print(f'REJECTED: {type(error).__name__}: {error}', file=sys.stderr)
        raise SystemExit(1)
