import importlib.util,json,os,subprocess,hashlib,shutil,sys
from pathlib import Path
ROOT=Path('/Users/lordcasser/workspace/projects/jarde');OUT=Path(sys.argv[1]);assert not OUT.exists() and not (ROOT/'target').exists()
def mod(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
G=ROOT/'openspec/changes/preserve-proved-loop-latch-origins/results/run-validation-build-root-v9.py'
assert hashlib.sha256(G.read_bytes()).hexdigest()=='51103f51323197db7663279776c80bd1eab95adbf5e98e26f9360293d82b8c33'
g=mod(G,'cf11_clippy_guard');g.ROOT=ROOT;g.OUT=OUT;g.expected_test_summaries=lambda i,o:None
g.command_stream=lambda p:{'path':str(p),'bytes':Path(p).stat().st_size,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()}
sc=mod(ROOT/'openspec/changes/recover-proved-conditional-switch-fallthrough/results/target-size-scan-root-v1.py','cf11_scan');g.target_bytes=lambda:sc.target_bytes(ROOT)
cl=mod(Path('/private/tmp/jarde-iterator-assignment-full-validation-prep-luna-v2/workspace_runner.py'),'cf11_closure');before=cl.pin_sources(cl.source_paths())
env=os.environ.copy()
for k in ('JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS','CLASSPATH','RUST_MIN_STACK'):env.pop(k,None)
env.update(g.ENV_VALUES)
r={'schema':'cf11-clippy-preflight-v1','status':'running','runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_pins_before':before,'commands':[],'guard_limits':{'minimum_free_bytes':g.FREE_LIMIT,'maximum_target_bytes':g.TARGET_LIMIT,'poll_seconds':1},'rust_min_stack':env.get('RUST_MIN_STACK')}
OUT.mkdir()
def save():(OUT/'execution.json').write_text(json.dumps(r,indent=2)+'\n')
save()
try:
 ci=(ROOT/'.github/workflows/ci.yml').read_text();a=ci.index('          cargo clippy');b=ci.index('\n\n',a)
 for argv in (['cargo','fmt','--all','--','--check'],ci[a:b].split()):
  row=g.run_command(len(r['commands']),argv,env);r['commands'].append(row);save();assert row['exit_code']==0 and row['guard_stop'] is None
 r['status']='passed'
except BaseException as e:r.update(status='failed',error=repr(e))
finally:
 fb=shutil.disk_usage(ROOT).free
 with (OUT/'clean.stdout.raw').open('xb') as so,(OUT/'clean.stderr.raw').open('xb') as se:rc=subprocess.run(['cargo','clean'],cwd=ROOT,env=env,stdout=so,stderr=se,start_new_session=True).returncode
 r['cleanup']={'argv':['cargo','clean'],'exit_code':rc,'exact_cleanup_only':True,'free_before_bytes':fb,'free_after_bytes':shutil.disk_usage(ROOT).free,'target_absent':not (ROOT/'target').exists(),'streams':{n:g.command_stream(OUT/f'clean.{n}.raw') for n in ('stdout','stderr')}}
 r['source_pins_after']=cl.pin_sources(cl.source_paths());save();assert rc==0 and not (ROOT/'target').exists() and before==r['source_pins_after']
print(json.dumps({'status':r['status'],'command_exits':[x['exit_code'] for x in r['commands']],'cleanup_exit':rc,'source_pins':len(before)}));raise SystemExit(0 if r['status']=='passed' else 1)
