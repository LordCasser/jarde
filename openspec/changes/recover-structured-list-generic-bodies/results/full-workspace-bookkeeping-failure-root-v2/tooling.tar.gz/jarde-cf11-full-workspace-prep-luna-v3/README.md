# CF11 全工作区与最终验证准备 v3

此目录仅供 root 审查并按需执行。它没有启动 Cargo/JDK、Git 或网络命令，也没有修改共享仓库。所有执行输出必须写入新的 `/private/tmp` 目录；脚本拒绝覆盖已存在输出。

`workspace_runner.py` 接收 focused v6 的真实 `execution.json`、该文件 SHA、冻结 CLI 路径和 SHA。它验证 focused schema `cf11-structured-list-focused-run-v4`、HEAD `e9e3a0ec27e5bf7698bdf4817ff08d38bcb63374`、8 条命令及其 raw streams、7 passed/1 ignored API、375 个 Java lib tests、reader census、P5 fingerprint 和 finally-clean。候选 CLI 固定到 `/private/tmp/jarde-cf11-structured-list-candidate-cli-root-v3`，并从实际 focused receipt 逐字段核对文件长度、SHA 和权限。

全工作区源码闭包在运行前后动态枚举 `src/`、`crates/`、`tests/`、`examples/`、`.cargo/`、成员 manifest、Cargo lock/config 和现有 closure helper 纳入的实际文件；闭包必须与 focused v6 manifest 完全相等。目录遍历错误、链接、缺失文件或字节变化都会失败，不使用准备时观察到的文件数作为判据。

runner 按 workspace Cargo metadata 动态生成两组相同 target batches，分别使用固定的两个 Proptest seed。每个批次保留 raw stdout/stderr，并受 guard 的 5 GiB 空闲空间、1 GiB target 和 1 秒采样限制；不覆盖默认 Rust 栈。最终 `cargo clean` 在 finally 路径执行，保留原始输出和清理前后观测。

`accept_workspace.py` 是独立只读复核：它从原始 stdout 的 Cargo `compiler-artifact` JSON 重建本批测试 target，再将 stderr 的 `Running ... (target/debug/...)` 与 stdout 的每个具名测试结果/summary 逐一配对。它要求每个 metadata target 在每个 seed 中恰好执行一次，并重新核对完整具名结果、三个新诊断 gates、7 passed/1 ignored focused tests、375 Java lib tests、reader census 与 P5 fingerprint。验收输出仅表示本机观察，不代表 CI 或产品完成。

`final-build-runner.py` 保留最终 fmt、仓库 CI workflow 中精确 clippy 命令、严格 OpenSpec 校验、CLI 重建字节一致性和 finally-clean；final acceptor 重新核对收据、raw streams、动态源码闭包和 CLI 冻结身份。它依赖本目录 workspace runner/acceptor 的 pins。

准备状态是 `prepared_not_executed`。focused v6 的 runner SHA 为 `b222ba19e1962ce0c9164b1e82e546740bfe7e195b9bb4388c3cbe9d630b7d65`，root 正在 fresh 输出目录 `/private/tmp/jarde-cf11-structured-list-focused-root-v11` 执行。其 P5 命令使用标准输出模式以保留全部具名结果；四个 Java census 名称按完整 `report::generic_void_parameter_census_tests::...` 路径核对。完成后 root 应先复核真实收据，再提供它的 SHA 与实际冻结 CLI SHA。不得把此准备包表述为验证通过。

仅做 Python AST/静态结构审查及此前已完成的旧 raw parser 兼容性检查；未运行本包的 main，也未运行任何工具链。
